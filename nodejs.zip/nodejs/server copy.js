var fs = require('fs');
var options1 = {
   // key: fs.readFileSync('/home/ubuntu/.config/ssl/medcallz.com.au.key', 'utf8'),
  //  cert: fs.readFileSync('/home/ubuntu/.config/ssl/medcallz.com.au.crt', 'utf8')
};

const axios = require('axios');
// Define the URL you want to request


var requestListener = function (request, response) {
    response.writeHead(200, { 'Content-Type': 'text/plain' });
    response.end('Hello You\n');
}
var
    app = require('http').createServer(options1, handler),
    io = require('socket.io')(app, {
        path: "/nodejs/",
    });
//     redis = require('redis'),
//     tls = require('tls'),
//     redisClient = redis.createClient({ host: 'localhost', port: 6379 });
// redis_pub = redis.createClient({ host: 'localhost', port: 6379 });

// redisClient.on('connect', function () {
//     console.log('connected');
// });
// redisClient.on('ready', function () {
//     console.log("Redis is ready");
// });

app.listen(3000, () => {
    console.log('listening on *:3000');
});


function handler(req, res) {

    if (req.method === 'POST' && req.url === '/send_event') {
        let body = '';

        req.on('data', chunk => {
            body += chunk.toString(); // Collect request data
        });

        req.on('end', () => {
            try {
                const data = JSON.parse(body);
                // console.log("Received API request:", data);
                // console.log("Received API event_name:", data.event_name);
                console.log("Received API event_data:", data.event_data);

                if (!data.event_name) throw new Error("Missing event_name");

                // Allow event_data to be object or array
                if (!Array.isArray(data.event_data) && typeof data.event_data !== "object") {
                    throw new Error("event_data must be an array or object");
                }

                io.emit(data.event_name, JSON.stringify(data.event_data));

                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, data: data.event_data }));

            } catch (error) {
                console.error("Error processing request:", error);
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: error.message }));
            }
        });

        req.on('error', error => {
            console.error("Request Error:", error.message);
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: "Request processing error" }));
        });
    }
    fs.readFile(__dirname + '/index.html', function (err, data) {
        if (err) {
            res.writeHead(500);
            return res.end('Error loading index.html');
        }
        res.writeHead(200);
        res.end(data);
    });
}

/***
    Redis Channels Subscribes
***/
// redisClient.subscribe('readinfo.messages');
// redisClient.subscribe('read.messages');
// redisClient.subscribe('delete.messages');
// redisClient.subscribe('edit.message');
// redisClient.subscribe('chat.messages');
// redisClient.subscribe('typing');

/***
    Redis Events
***/


// redisClient.on('message', function (channel, message) {
//     var result = JSON.parse(message);
//     io.emit(channel, result);
//     // io.emit('message', result);
// });

/***
    Socket.io Connection Event
***/


var clients = [];
io.on('connection', (socket) => {

    socket.on('pong', function (data) {
        console.log("Pong received from client");
    });


    /***
        Socket.io Events
    ***/

    socket.on('join', function (data) {

        socket.join(data.room);
        clients.push(data.room);
        socket.emit('joined', { message: 'Joined room: ' + data.room, users_connected: clients });

    });

    socket.on('typing', function (msg) {

        io.emit('typing', { 'message': msg.message, 'username': msg.username, 'fullname': msg.fullname, 'touser_id': msg.touser_id, 'appstatus': msg.appstatus, 'typingperson': msg.typingperson });
    });
    socket.on('chat.messages', (data) => {
        console.log(data);
        redis_pub.publish("chat.messages", data);
        var jsonData = JSON.parse(data);
        if (jsonData.message.savestatus == 1) {

            const apiUrl = 'https://dev.medcallz.com.au/api/hp_api_main/storeMessageApi';

            // Data to send in the request body
            const postData = {
                fromuser: jsonData.fromuser,
                touser: jsonData.touser,
                message: jsonData.message,
                ref_name: jsonData.ref_name,
                file_path: jsonData.file_path,
                video_status: jsonData.video_status,
            };

            // Use axios to make a POST request
            axios.post(apiUrl, postData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            })
                .then(response => {
                    console.log(response.data);
                    io.emit('chat.messages', response.data);
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }

    });

    socket.on('edit.message', function (data) {
        redis_pub.publish("edit.message", data);
    });

    socket.on('delete.messages', function (data) {
        redis_pub.publish("delete.messages", data);
    });

    socket.on('read.messages', function (data) {
        redis_pub.publish("read.messages", data);
    });

    /*socket.on('readinfo.messages', function(data){
        console.log(data);
        redis_pub.publish("readinfo.messages",data);       
    });*/

    socket.on('disconnect', function () {

        /*socket.broadcast.to(socket.room).emit('updateChat', 'System', {
          zeit: new Date(), text: socket.user + ' is now offline.'
        });*/
        console.log("Disconnected.");
    });
    /*socket.on('read_on_click', function(msg){
        
        io.emit('read_on_click', { 'message': msg.message, 'username': msg.username, 'fullname' : msg.fullname,  'touser_id' : msg.touser_id});
    }); */


});
