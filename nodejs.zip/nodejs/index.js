var fs = require('fs');
var options1 = {
  key: fs.readFileSync('/home/ubuntu/.config/ssl/4/dev.medcallz.com.au.key', 'utf8'),
  cert: fs.readFileSync('/home/ubuntu/.config/ssl/4/dev_medcallz_com_au.crt', 'utf8')
};
const express = require('express');
const apps = express();
var 
  app = require('https').createServer(options1,handler),
  io =  require('socket.io')(app, {
    path: "/nodejs/"
  });
console.log(io);

io.on('connection', (socket) => {
  socket.on('chat message', (msg) => {
    console.log(msg);
    io.emit('chat message', msg);
  });
});

app.listen(3000, () => {
  console.log('listening on *:3000');
});



function handler (req, res) {
      fs.readFile(__dirname + '/index.html', function(err, data) {

        console.log(data);
            if(err) {
                res.writeHead(500);
                return res.end('Error loading index.html');
            }
            res.writeHead(200);
            res.end(data);
        });
    }