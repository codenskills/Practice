<?php if (!defined('BASEPATH'))
    exit('No direct script access allowed');
/**
 * Appointments
 *
 * This model handles appointment types with color codes. It operates the following tables:
 * - Universal appointment types,
 *
 * @author	Medcallz 03/09/2015
 */

class Payments extends CI_Model
{

    function __construct()
    {
        parent::__construct();

    }



    public function savePaymentInfo($data)
    {
        try {
            $this->db->insert('mc_patient_payment_method', $data);
            return $this->db->insert_id();
        } catch (\Exception $e) {
            return false;
        }
    }

    public function getPaymentInfo($payment_id)
    {
        try {
            return $this->db->where('id', $payment_id)->get('mc_patient_payment')->row();
        } catch (\Exception $e) {
            return false;
        }
    }

    public function updatepaymentPaymentLogs($data, $id)
    {
        try {
            return $this->db->where('id', $id)->update('mc_patient_payment', $data);
        } catch (\Exception $e) {
            return false;
        }
    }
    public function updatepaymentPaymentLogsByMethodID($data, $id)
    {
        try {
            return $this->db->where('payment_method_id', $id)->update('mc_patient_payment', $data);
        } catch (\Exception $e) {
            return false;
        }
    }

    public function getUserPaymentHistory($user_id)
    {
        try {
            return $this->db->where('patient_user_id', $user_id)->get('mc_patient_payment')->result();
        } catch (\Exception $e) {
            return false;
        }
    }



    /* yashvir */
    public function getUserRow($col, $val)
    {
        try {
            return $this->db->where($col, $val)->get('mc_users')->row();
        } catch (\Exception $e) {
            return false;
        }
    }
    public function updateUser($col, $val, $data)
    {
        try {
            return $this->db->where($col, $val)->update('mc_users', $data);
        } catch (\Exception $e) {
            return false;
        }
    }


    //Medical Service Log 
    public function createMedicalServiceLogs($data)
    {
        try {
            $this->db->insert('mc_medical_services_log', $data);
            return $this->db->insert_id();
        } catch (\Exception $e) {
            //echo $e->getMessage(); 
            return false;
        }
    }
    public function getMedicalServiceLogsRow($col, $val)
    {
        try {
            return $this->db->where($col, $val)->get('mc_medical_services_log')->row();
        } catch (\Exception $e) {
            return false;
        }
    }
    public function checkPaymentStatusBySessionId($col, $val)
    {
        try {
            $query = $this->db
                ->select('
                log.id as ms_logid, 
                log.patient_user_id as patient_user_id, 
                log.hp_user_id as hp_user_id, 
                log.is_entry as is_entry, 
                service.status as service_status, 
                payment.status as payment_status
            ')
                ->from('mc_medical_services_log log')
                ->join('mc_medical_services service', 'service.medical_services_log_id = log.id', 'left')
                ->join('mc_medical_services_payment payment', 'payment.medical_service_id = service.id', 'left')
                ->where("log.$col", $val)
                ->get();
            if ($query->num_rows() > 0) {
                return $query->row(); // Return result as an object
            } else {
                return null; // No matching record found
            }
        } catch (\Exception $e) {
            echo $e->getMessage();
            return false; // Return false if an exception occurs
        }
    }




    public function updateMedicalServiceLogs($col, $val, $data)
    {
        try {
            return $this->db->where($col, $val)->update('mc_medical_services_log', $data);
        } catch (\Exception $e) {
            return false;
        }
    }
    //Medical Service  
    public function createMedicalService($data)
    {
        try {
            $this->db->insert('mc_medical_services', $data);
            return $this->db->insert_id();
        } catch (\Exception $e) {
            return false;
        }
    }
    public function getMedicalServiceRow($col, $val)
    {
        try {
            return $this->db->where($col, $val)->get('mc_medical_services')->row();
        } catch (\Exception $e) {
            return false;
        }
    }
    public function updateMedicalService($col, $val, $data)
    {
        try {
            return $this->db->where($col, $val)->update('mc_medical_services', $data);
        } catch (\Exception $e) {
            return false;
        }
    }
    //Medical Service HP Assign  
    public function createMedicalServiceHPAssign($data)
    {
        try {
            $this->db->insert('mc_medical_services_hp_assign', $data);
            return $this->db->insert_id();
        } catch (\Exception $e) {
            return false;
        }
    }
    public function getMedicalServiceHPAssignRow($col, $val)
    {
        try {
            return $this->db->where($col, $val)->order_by('id', 'DESC')->limit(1)->get('mc_medical_services_hp_assign')->row();
        } catch (\Exception $e) {
            return false;
        }
    }
    public function updateMedicalServiceHPAssign($col, $val, $data)
    {
        try {
            return $this->db->where($col, $val)->update('mc_medical_services_hp_assign', $data);
        } catch (\Exception $e) {
            return false;
        }
    }


    public function cronMedicalServiceHPAssignCheckUpdate()
    {
        try {
            $query = $this->db->select('
                    mc_medical_services_hp_assign.id AS assign_id,
                    mc_medical_services_hp_assign.medical_service_id AS medical_service_id,
                    mc_medical_services_hp_assign.patient_user_id,
                    mc_medical_services_hp_assign.hp_user_id,        
                    mc_medical_services_log.payload
                ')
                ->join('mc_medical_services', 'mc_medical_services.id = mc_medical_services_hp_assign.medical_service_id', 'left')
                ->join('mc_medical_services_log', 'mc_medical_services_log.id = mc_medical_services.medical_services_log_id', 'left')
                ->where('mc_medical_services_hp_assign.status', 0)
                ->where('mc_medical_services_hp_assign.created_at <', 'NOW() - INTERVAL ' . HP_ACCEPT_WAITING_TIME . ' MINUTE', false)
                ->where("NOT EXISTS (
                    SELECT 1 FROM mc_medical_services_hp_assign AS sub 
                    WHERE sub.medical_service_id = mc_medical_services_hp_assign.medical_service_id 
                    AND sub.id > mc_medical_services_hp_assign.id 
                    AND sub.status != 0
                )", null, false)
                ->get('mc_medical_services_hp_assign');

            $affectedRows = $query->result_array();

            // echo $this->db->last_query();die;
            $updatedStatus = false;
            if (!empty($affectedRows)) {
                $affectedIds = array_column($affectedRows, 'assign_id'); // Use alias
                $this->db->set('status', 2)->where_in('id', $affectedIds)->update('mc_medical_services_hp_assign');
                $updatedStatus = $this->db->affected_rows() > 0 ? true : false;
                foreach ($affectedRows as &$row) {
                    $row['hp_assign_status'] = $updatedStatus;
                }
            }
            return $affectedRows;
        } catch (\Exception $e) {
            error_log($e->getMessage());
            return false;
        }
    }




    //Medical Service Payments
    public function createMedicalServicePayment($data)
    {
        try {
            $this->db->insert('mc_medical_services_payment', $data);
            return $this->db->insert_id();
        } catch (\Exception $e) {
            // echo $e->getMessage(); 
            return false;
        }
    }
    public function getMedicalServicePaymentRow($col, $val)
    {
        try {
            return $this->db->where($col, $val)->get('mc_medical_services_payment')->row();
        } catch (\Exception $e) {
            return false;
        }
    }
    public function updateMedicalServicePayment($col, $val, $data)
    {
        try {
            return $this->db->where($col, $val)->update('mc_medical_services_payment', $data);
        } catch (\Exception $e) {
            return false;
        }
    }
}
