<?php if (!defined('BASEPATH'))
    exit('No direct script access allowed');
/**
 * Appointments
 *
 * This model handles appointment types with color codes. It operates the following tables:
 * - Universal appointment types,
 *
 * @author	Medcallz 03/09/2015
 */

class mc_services extends CI_Model
{

    function __construct()
    {
        parent::__construct();

    }
    public function getOnlineDoctorsCount()
    {
        return $this->db->from("mc_hp_info")
            ->join("mc_users", "mc_users.id = mc_hp_info.user_id")
            ->where("mc_users.activated", "1")
            ->where("consult_now_status", "1")
            ->get()
            ->num_rows();
    }

    public function getServices($id = false, $is_api = false)
    {

        if ($id) {
            $lang = $this->session->userdata('site_lang');
            if ($lang != "english") {
                $res = $this->db->select("id," . $lang . "_name as name," . $lang . "_description as description,icon,price,category_id")->where("status", "1")->where("id", $id)->get("mc_services")->row();
            } else {
                $res = $this->db->select("id,name,description,icon,price,category_id")->where("status", "1")->where("id", $id)->get("mc_services")->row();
            }
            if (isset($res->icon)) {
                $res->icon = base_url("assets/images/virtual_consult/" . $res->icon);
            } else {
                $res->icon = base_url("assets/images/virtual_consult/default-service-icon.svg");
            }
            $res->price = number_format((float) $res->price, 2, '.', '');

            //print_r($res);
            // die();
            return $res;
        } else {
            $lang = $this->session->userdata('site_lang');
            if ($lang != "english") {
                $category_list = $this->db->select("id," . $lang . "_name as name")->get("mc_services_category")->result_array();
            } else {
                $category_list = $this->db->select("id,name")->get("mc_services_category")->result_array();
            }
            $new_category = [];
            foreach ($category_list as $rec) {
                $lang = $this->session->userdata('site_lang');
                if ($lang != "english") {
                    $result = $this->db->select("id," . $lang . "_name as name," . $lang . "_description as description,icon,category_id")->where("status", "1")->where("category_id", $rec['id'])->get("mc_services")->result();
                } else {
                    $result = $this->db->select("id,name,description,icon,category_id")->where("status", "1")->where("category_id", $rec['id'])->get("mc_services")->result();
                }

                foreach ($result as $r) {
                    if (isset($r->icon)) {
                        $r->icon = base_url("assets/images/virtual_consult/" . $r->icon);
                    } else {
                        $r->icon = base_url("assets/images/virtual_consult/default-service-icon.svg");
                    }
                }
                if ($result) {
                    $rec['list'] = $result;
                } else {
                    $rec['list'] = [];
                }
                $new_category[] = $rec;
            }
            return $new_category;
        }
    }

    public function getDoctorServices($userid)
    {
        $res = $this->db->select("service_id")->where("user_id", $userid)->get("mc_hp_services")->result_array();
        if ($res) {
            return array_column($res, 'service_id');
        } else {
            return [];
        }
    }

    public function addUpdateHpService($userid, $services_list)
    {
        $this->db->where("user_id", $userid)->delete("mc_hp_services");
        $insert = [];
        foreach ($services_list as $rec) {
            $insert[] = ["user_id" => $userid, "service_id" => $rec];
        }
        if (!empty($insert)) {
            $res = $this->db->insert_batch("mc_hp_services", $insert);
            if ($res) {
                return true;
            }
            return false;
        }
        return true;
    }


    public function getLiveDoctorListCountByServiceId($service_id)
    {
        return $this->db->distinct()->select("mc_hp_info.hp_id,mc_hp_info.full_hp_name,mc_hp_info.user_id,mc_hp_info.providerSpecialty as speciality,languages,state")
            ->join("mc_hp_info", "mc_hp_info.user_id = mc_hp_services.user_id")
            ->join("mc_users", "mc_users.id = mc_hp_info.user_id")
            ->where("mc_users.activated", "1")
            ->where("service_id", $service_id)
            ->where("consult_now_status", 1)
            ->get("mc_hp_services")
            ->num_rows();
    }

    public function getLiveDoctorListByServiceId($service_id, $start, $per_page)
    {
        $res = $this->db->distinct()->select("mc_hp_info.hp_id,familyName,givenName,mc_hp_info.full_hp_name,mc_hp_info.user_id,mc_hp_info.providerSpecialty as speciality,languages,state")
            ->join("mc_hp_info", "mc_hp_info.user_id = mc_hp_services.user_id")
            ->join("mc_users", "mc_users.id = mc_hp_info.user_id")
            ->where("mc_users.activated", "1")
            ->where("consult_now_status", 1)
            ->where("service_id", $service_id)
            ->limit($per_page, $start)
            ->get("mc_hp_services")
            ->result_array();

        // $last_query = $this->db->last_query();
        $newRes = [];
        foreach ($res as $rec) {
            $result = $this->mc_constants->get_speciality_name($rec['speciality']);
            $rec['specialiy_name'] = $result['speciality'];
            $languages = explode(',', $rec['languages']);
            $l = $this->db->select("languages")->where_in("ID", $languages)->get("mc_languages")->result_array();
            $l = array_column($l, 'languages');
            $rec['state_name'] = $this->mc_constants->get_statename_by_stateid($rec['state']);
            $rec['lang_name'] = implode(', ', $l);
            $hpInfo = $this->mc_constants->userheaderInfo($rec['user_id']);
            $img = $this->db->select("image")->where("user_id", $rec['user_id'])->get("mc_clinic_admin")->row();
            if (isset($img) && $img->image != "") {
                $rec['avatar'] = base_url() . "assets/images/hp_images/" . str_replace(' ', '_', $img->image);
            }
            if (!file_exists($rec['avatar'])) {
                $rec['avatar'] = "";
                $rec['avatar2'] = $this->mc_constants->makeInitials($rec['givenName'], $rec['familyName']);
            }

            $rec['hp_share_url'] = base_url("virtual_consult/patient/consult_doctors_list/" . @$service_id) . '?hp_id=' . @$rec['hp_id'];
            $rec['avatar_alt'] = $this->lang->line('Medcallz');
            $newRes[] = $rec;
        }
        // $newRes = [];
        return $newRes;
    }
    public function getHpDetail($hp_id)
    {
        $this->load->library("mc_constants");
        $rec = $this->db->select("mc_hp_info.*")->where("hp_id", $hp_id)->get("mc_hp_info")->row_array();
        $rec = $this->db->select("mc_hp_info.*, mc_hp_metadata.*")
            ->from("mc_hp_info")
            ->join("mc_hp_metadata", "mc_hp_metadata.user_id = mc_hp_info.user_id", "left")
            ->where("mc_hp_info.hp_id", $hp_id)
            ->get()
            ->row_array();



        $speciality = $rec['speciality'];
        $res = $this->mc_constants->get_speciality_name($speciality);
        $rec['specialiy_name'] = $res['speciality'];

        $languages = explode(',', $rec['languages']);
        $lang_names = [];
        foreach ($languages as $r) {
            $lang_names[] = $this->mc_constants->langage_name($rec['languages']);
        }
        if ($rec['state']) {
            $rec['state_name'] = $this->mc_constants->get_statename_by_stateid($rec['state']);
        } else {
            $rec['state_name'] = "";
        }

        $rec['lang_name'] = implode(',', $lang_names);
        $hpInfo = $this->mc_constants->userheaderInfo($rec['user_id']);


        //$rec['avatar'] = base_url() . "assets/images/hp_images/" . str_replace(' ', '_', $rec['image']);

        $img = $this->db->select("image")->where("user_id", $rec['user_id'])->get("mc_clinic_admin")->row();
        if (isset($img) && $img->image != "") {
            $rec['avatar'] = base_url() . "assets/images/hp_images/" . str_replace(' ', '_', $img->image);
        }
        if (!file_exists($rec['avatar'])) {
            $rec['avatar'] = "";
            $rec['avatar2'] = $this->mc_constants->makeInitials($rec['givenName'], $rec['familyName']);
        }
        return $rec;

    }
    public function getHpDetailByUserId($user_id)
    {
        $hp_info = $this->db->select('mc_hp_info.hp_id')
            ->where('user_id', $user_id)
            ->get('mc_hp_info')
            ->row();
        if (!empty($hp_info)) {
            return $this->getHpDetail($hp_info->hp_id);
        }
        return false;
    }


    //Yashvir Consult Now
    public function getHPMetaByHPUserId($hpuserid)
    {
        $query = $this->db->select("*")->where("user_id", $hpuserid)->get("mc_hp_metadata")->row() ?: null;
        //echo  'Last Query: ' . $this->db->last_query();die;
        return $query;
    }





    public function totalPatientAppointmentList($user_id, $status = null)
    {
        $this->db->from('mc_medical_services')->where('patient_user_id', $user_id);

        if ($status !== null) {
            $this->db->where('status', $status);
        }

        return $this->db->count_all_results(); // Efficient way to count rows
    }

    public function patientAppointmentList($user_id, $start, $per_page, $status = null)
    {
        $this->db->select('*')->where('patient_user_id', $user_id);
        if ($status !== null) {
            $this->db->where('status', $status);
        }
        $this->db->limit($per_page, $start);
        $query = $this->db->get('mc_medical_services');

        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return [];
    }

}
