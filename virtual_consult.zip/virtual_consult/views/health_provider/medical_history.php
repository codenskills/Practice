<section id="patients-appointments">
    <div class="container">
        <div class="video-consult-container">
            <div class="appointment-header appointment-header-health-provider">
                <div class="appointment-text">
                    <h4 class="heading-main">Past consults</h4>
                    <div class="consult-date-slider-wrap">
                        <div class="owl-carousel owl-theme consult-date-slider">
                            <div class="item">
                                <p><svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M17.5 8.33332H2.5M13.3333 1.66666V4.99999M6.66667 1.66666V4.99999M8.75 11.6667L10 10.8333V15M8.95833 15H11.0417M6.5 18.3333H13.5C14.9001 18.3333 15.6002 18.3333 16.135 18.0608C16.6054 17.8212 16.9878 17.4387 17.2275 16.9683C17.5 16.4335 17.5 15.7335 17.5 14.3333V7.33332C17.5 5.93319 17.5 5.23313 17.2275 4.69835C16.9878 4.22794 16.6054 3.84549 16.135 3.60581C15.6002 3.33332 14.9001 3.33332 13.5 3.33332H6.5C5.09987 3.33332 4.3998 3.33332 3.86502 3.60581C3.39462 3.84549 3.01217 4.22794 2.77248 4.69835C2.5 5.23313 2.5 5.93319 2.5 7.33332V14.3333C2.5 15.7335 2.5 16.4335 2.77248 16.9683C3.01217 17.4387 3.39462 17.8212 3.86502 18.0608C4.3998 18.3333 5.09987 18.3333 6.5 18.3333Z"
                                            stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg>May, 2024</p>
                            </div>
                            <div class="item">
                                <p><svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M17.5 8.33332H2.5M13.3333 1.66666V4.99999M6.66667 1.66666V4.99999M8.75 11.6667L10 10.8333V15M8.95833 15H11.0417M6.5 18.3333H13.5C14.9001 18.3333 15.6002 18.3333 16.135 18.0608C16.6054 17.8212 16.9878 17.4387 17.2275 16.9683C17.5 16.4335 17.5 15.7335 17.5 14.3333V7.33332C17.5 5.93319 17.5 5.23313 17.2275 4.69835C16.9878 4.22794 16.6054 3.84549 16.135 3.60581C15.6002 3.33332 14.9001 3.33332 13.5 3.33332H6.5C5.09987 3.33332 4.3998 3.33332 3.86502 3.60581C3.39462 3.84549 3.01217 4.22794 2.77248 4.69835C2.5 5.23313 2.5 5.93319 2.5 7.33332V14.3333C2.5 15.7335 2.5 16.4335 2.77248 16.9683C3.01217 17.4387 3.39462 17.8212 3.86502 18.0608C4.3998 18.3333 5.09987 18.3333 6.5 18.3333Z"
                                            stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg>May, 2024</p>
                            </div>
                        </div>
                    </div>
                </div>
                <ul class="appointment-menu">
                    <li>
                        <a href="<?php echo base_url();?>virtual_consult/health_provider/appointment_pending">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M7.50002 15.4167H12.5M5.50002 1.66666H14.5C14.9667 1.66666 15.2001 1.66666 15.3783 1.75748C15.5351 1.83738 15.6626 1.96486 15.7425 2.12166C15.8334 2.29992 15.8334 2.53328 15.8334 2.99999V4.72875C15.8334 5.1364 15.8334 5.34023 15.7873 5.53204C15.7465 5.7021 15.6791 5.86468 15.5878 6.0138C15.4847 6.18199 15.3406 6.32612 15.0523 6.61437L12.6095 9.05718C12.2795 9.3872 12.1145 9.5522 12.0527 9.74248C11.9983 9.90985 11.9983 10.0901 12.0527 10.2575C12.1145 10.4478 12.2795 10.6128 12.6095 10.9428L15.0523 13.3856C15.3406 13.6739 15.4847 13.818 15.5878 13.9862C15.6791 14.1353 15.7465 14.2979 15.7873 14.4679C15.8334 14.6597 15.8334 14.8636 15.8334 15.2712V17C15.8334 17.4667 15.8334 17.7001 15.7425 17.8783C15.6626 18.0351 15.5351 18.1626 15.3783 18.2425C15.2001 18.3333 14.9667 18.3333 14.5 18.3333H5.50002C5.03331 18.3333 4.79995 18.3333 4.62169 18.2425C4.46489 18.1626 4.33741 18.0351 4.25751 17.8783C4.16669 17.7001 4.16669 17.4667 4.16669 17V15.2712C4.16669 14.8636 4.16669 14.6597 4.21274 14.4679C4.25357 14.2979 4.32091 14.1353 4.41229 13.9862C4.51536 13.818 4.65948 13.6739 4.94774 13.3856L7.39055 10.9428C7.72056 10.6128 7.88557 10.4478 7.94739 10.2575C8.00177 10.0901 8.00177 9.90985 7.94739 9.74248C7.88557 9.5522 7.72055 9.38719 7.39054 9.05718L4.94773 6.61437C4.65948 6.32612 4.51536 6.18199 4.41229 6.0138C4.32091 5.86468 4.25357 5.7021 4.21274 5.53204C4.16669 5.34023 4.16669 5.1364 4.16669 4.72875V2.99999C4.16669 2.53328 4.16669 2.29992 4.25751 2.12166C4.33741 1.96486 4.46489 1.83738 4.62169 1.75748C4.79995 1.66666 5.03331 1.66666 5.50002 1.66666Z"
                                    stroke="#344054" stroke-width="1.67" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>
                            Pending
                        </a>
                    </li>
                    <li>
                        <a class="active"
                            href="<?php echo base_url();?>virtual_consult/health_provider/past_consult"><svg width="20"
                                height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M18.9166 11.25L17.2505 9.58333L15.5833 11.25M17.5 10C17.5 14.1421 14.1421 17.5 10 17.5C5.85786 17.5 2.5 14.1421 2.5 10C2.5 5.85786 5.85786 2.5 10 2.5C12.7516 2.5 15.1571 3.98178 16.4621 6.19091M10 5.83333V10L12.5 11.6667"
                                    stroke="#667085" stroke-width="1.67" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>
                            Past consults</a>
                    </li>
                </ul>
            </div>
            <div class="p-filters-contain">
                <div class="p-filters">
                    <h6 class="filter-text">Filters</h6>
                    <div class="responsive-filter-bar">
                        <h6 class="filter-text-responsive"><svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M5 10H15M2.5 5H17.5M7.5 15H12.5" stroke="#101828" stroke-width="1.66667"
                                    stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                            Filters</h6>
                        <svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 1.5L6 6.5L11 1.5" stroke="#98A2B3" stroke-width="1.66667" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>

                    </div>
                    <div class="overlay-responsive"></div>
                    <ul class="filter-list">
                        <div class="res-close-btn">
                            <button type="button" class="close-filter-list close-filter-btn"><svg width="14" height="14"
                                    viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2"
                                        stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg></button>
                        </div>
                        <li class="active-drop">
                            <div class="drop-down-filters toggle-drop-btn show-filter-list">
                                <h5>Appointment type</h5>
                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg"
                                    alt="icon">
                            </div>
                            <div class="drop-filters-content">
                                <div class="drop-checkbox-wrap">
                                    <form>
                                        <div class="form-group">
                                            <input type="checkbox" id="atall">
                                            <label for="atall">All appointments (7)</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="atfture">
                                            <label for="atfture">Future (1)</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="atpast">
                                            <label for="atpast">Past (3)</label>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </li>
                        <hr>
                        <li>
                            <div class="drop-down-filters toggle-drop-btn">
                                <h5>Status</h5>
                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg"
                                    alt="icon">
                            </div>
                            <div class="drop-filters-content">
                                <div class="drop-checkbox-wrap">
                                    <form>
                                        <div class="form-group">
                                            <input type="checkbox" id="stsall">
                                            <label for="stsall">All (4)</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="stsacnf">
                                            <label for="stsacnf">Confirmed (1)</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="stsapst">
                                            <label for="stsapst">Past (3)</label>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </li>
                        <hr>
                        <li>
                            <div class="drop-down-filters toggle-drop-btn">
                                <h5>Patients</h5>
                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg"
                                    alt="icon">
                            </div>
                            <div class="drop-filters-content">
                                <input type="text" placeholder="Search..." class="specialities-search">
                                <div class="drop-checkbox-wrap">
                                    <form>
                                        <div class="form-group">
                                            <input type="checkbox" id="allspecialities">
                                            <label for="allspecialities">All patients (20)</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="Cardiology">
                                            <label for="Cardiology">Galven Mouton</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="Dermatology">
                                            <label for="Dermatology">Winna Yarrington</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="Gastroenterology">
                                            <label for="Gastroenterology">Ethan Gonzalez</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="Hematology">
                                            <label for="Hematology">Christin Bridgwood</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="Nephrology">
                                            <label for="Nephrology">Matthew Taylor</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="Neurology">
                                            <label for="Neurology">Addison Tuley</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="Oncology">
                                            <label for="Oncology">Rachelle Harnott</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="Pediatrics">
                                            <label for="Pediatrics">Valene Caple</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="Pediatrics">
                                            <label for="Pediatrics">Diego MacCumiskey</label>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </li>
                        <div class="res-filter-apply-btn-wrap">
                            <button type="button" class="res-apply-btn">Apply filters <span>(2)</span></button>
                        </div>
                    </ul>

                </div>
                <div class="doctors-list-container">
                    <div class="d-flex-row">
                        <div class="result-text">
                            <p>7 total appointment</p>
                        </div>
                        <div class="health-provider-serch-bar">
                            <input type="text" placeholder="Search for patient">
                        </div>
                    </div>
                    <div class="past-consult-listing-wrap">
                        <div class="medical-history-back-div-wrap">
                            <a href="<?php echo base_url();?>virtual_consult/health_provider/past_consult" class="unfilled-button"><svg width="20" height="20" viewBox="0 0 20 20"
                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M15.8334 10.0001H4.16675M4.16675 10.0001L10.0001 15.8334M4.16675 10.0001L10.0001 4.16675"
                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg></a>
                            <div class="medical-history-back-div-user-profile">
                                <div class="medical-history-back-div-user-profile-img">
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg02.png"
                                        alt="patient photo">
                                </div>
                                <div class="medical-history-back-div-user-profile-info">
                                    <p>Orelia Espada</p>
                                </div>
                            </div>
                        </div>
                        <ul class="no-style nopadd nomargin past-consult-listing-list medical-history-table-listing">
                            <!--th-->
                            <li class="past-consult-listing-heading">
                                <div class="consult-date">
                                    <h6>Date</h6>
                                </div>
                                <div class="consult-health-provider-name">
                                    <h6>Health provider</h6>
                                </div>
                                <div class="consult-speciality">
                                    <h6>Speciality</h6>
                                </div>
                                <div class="consult-type">
                                    <h6>Type</h6>
                                </div>
                                <div class="consult-resson">
                                    <h6>Reason</h6>
                                </div>
                                <div class="consult-button">
                                    <h6></h6>
                                </div>
                            </li>
                            <!--th-->
                            <!--tbody-->
                            <li>
                                <div class="desktop-past-consult-list">
                                    <div class="consult-date">
                                        <p>08/11/2023, 03:07pm</p>
                                    </div>
                                    <div class="consult-health-provider-name">
                                        <div class="consult-health-provider-profile">
                                            <div class="consult-health-provider-img">
                                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg02.png"
                                                    alt="patient photo">
                                            </div>
                                            <div class="consult-health-provider-info">
                                                <p>Dr. Rhiamon Langdale</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="consult-speciality">
                                        <p>Orthopedics</p>
                                    </div>
                                    <div class="consult-type">
                                        <p>Telehealth</p>
                                    </div>
                                    <div class="consult-resson">
                                        <p>Medical certificate</p>
                                    </div>
                                    <div class="consult-button medical-history-action-button">
                                        <a href="javascript:void(0)" class="view-details-modal-health-provider-btn outline-button tooltip">
                                            <span class="medical-history-action-button-text">View details</span><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M12 16V12M12 8H12.01M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z" stroke="#475467" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                            <span class="tooltiptext">View details</span>
                                        </a>
                                            
                                    </div>
                                </div>    
                                <div class="mobile-past-consult-list">
                                    <div class="mobile-past-consult-list-head">
                                        <h6>Telehealth</h6>
                                    </div>
                                    <div class="mobile-past-consult-list-body">
                                        <div class="consult-health-provider-mobile-flex">
                                            <div class="consult-health-provider-profile">
                                                <div class="consult-health-provider-img">
                                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg02.png"
                                                        alt="patient photo">
                                                </div>
                                                <div class="consult-health-provider-info">
                                                    <h6>Dr. Lindy Strongitharm</h6>
                                                    <p>Cardiac Imaging</p>
                                                </div>
                                            </div>
                                            <div class="consult-time-mobile">
                                                <p>08/11/2023 <span>03:07pm</span></p>
                                            </div>
                                        </div>
                                        <div class="consult-reason-wrap-mobile">
                                            <p>Reason</p>
                                            <p class="large-pr">Medical certificate</p>
                                        </div>
                                    </div>
                                    <div class="mobile-past-consult-list-bottom">
                                        <button type="button"
                                            class="view-details-modal-health-provider-btn outline-button">View
                                            details</button>
                                     
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="desktop-past-consult-list">
                                    <div class="consult-date">
                                        <p>08/11/2023, 03:07pm</p>
                                    </div>
                                    <div class="consult-health-provider-name">
                                        <div class="consult-health-provider-profile">
                                            <div class="consult-health-provider-img">
                                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg02.png"
                                                    alt="patient photo">
                                            </div>
                                            <div class="consult-health-provider-info">
                                                <p>Dr. Rhiamon Langdale</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="consult-speciality">
                                        <p>Orthopedics</p>
                                    </div>
                                    <div class="consult-type">
                                        <p>Telehealth</p>
                                    </div>
                                    <div class="consult-resson">
                                        <p>Medical certificate</p>
                                    </div>
                                    <div class="consult-button medical-history-action-button">
                                        <a href="javascript:void(0)" class="view-details-modal-health-provider-btn outline-button tooltip">
                                            <span class="medical-history-action-button-text">View details</span><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M12 16V12M12 8H12.01M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z" stroke="#475467" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                            <span class="tooltiptext">View details</span>
                                        </a>
                                            
                                    </div>
                                </div>    
                                <div class="mobile-past-consult-list">
                                    <div class="mobile-past-consult-list-head">
                                        <h6>Telehealth</h6>
                                    </div>
                                    <div class="mobile-past-consult-list-body">
                                        <div class="consult-health-provider-mobile-flex">
                                            <div class="consult-health-provider-profile">
                                                <div class="consult-health-provider-img">
                                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg02.png"
                                                        alt="patient photo">
                                                </div>
                                                <div class="consult-health-provider-info">
                                                    <h6>Dr. Lindy Strongitharm</h6>
                                                    <p>Cardiac Imaging</p>
                                                </div>
                                            </div>
                                            <div class="consult-time-mobile">
                                                <p>08/11/2023 <span>03:07pm</span></p>
                                            </div>
                                        </div>
                                        <div class="consult-reason-wrap-mobile">
                                            <p>Reason</p>
                                            <p class="large-pr">Medical certificate</p>
                                        </div>
                                    </div>
                                    <div class="mobile-past-consult-list-bottom">
                                        <button type="button"
                                            class="view-details-modal-health-provider-btn outline-button">View
                                            details</button>
                                     
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="desktop-past-consult-list">
                                    <div class="consult-date">
                                        <p>08/11/2023, 03:07pm</p>
                                    </div>
                                    <div class="consult-health-provider-name">
                                        <div class="consult-health-provider-profile">
                                            <div class="consult-health-provider-img">
                                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg02.png"
                                                    alt="patient photo">
                                            </div>
                                            <div class="consult-health-provider-info">
                                                <p>Dr. Rhiamon Langdale</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="consult-speciality">
                                        <p>Orthopedics</p>
                                    </div>
                                    <div class="consult-type">
                                        <p>Telehealth</p>
                                    </div>
                                    <div class="consult-resson">
                                        <p>Medical certificate</p>
                                    </div>
                                    <div class="consult-button medical-history-action-button">
                                        <a href="javascript:void(0)" class="view-details-modal-health-provider-btn outline-button tooltip">
                                            <span class="medical-history-action-button-text">View details</span><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M12 16V12M12 8H12.01M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z" stroke="#475467" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                            <span class="tooltiptext">View details</span>
                                        </a>
                                            
                                    </div>
                                </div>    
                                <div class="mobile-past-consult-list">
                                    <div class="mobile-past-consult-list-head">
                                        <h6>Telehealth</h6>
                                    </div>
                                    <div class="mobile-past-consult-list-body">
                                        <div class="consult-health-provider-mobile-flex">
                                            <div class="consult-health-provider-profile">
                                                <div class="consult-health-provider-img">
                                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg02.png"
                                                        alt="patient photo">
                                                </div>
                                                <div class="consult-health-provider-info">
                                                    <h6>Dr. Lindy Strongitharm</h6>
                                                    <p>Cardiac Imaging</p>
                                                </div>
                                            </div>
                                            <div class="consult-time-mobile">
                                                <p>08/11/2023 <span>03:07pm</span></p>
                                            </div>
                                        </div>
                                        <div class="consult-reason-wrap-mobile">
                                            <p>Reason</p>
                                            <p class="large-pr">Medical certificate</p>
                                        </div>
                                    </div>
                                    <div class="mobile-past-consult-list-bottom">
                                        <button type="button"
                                            class="view-details-modal-health-provider-btn outline-button">View
                                            details</button>
                                     
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="desktop-past-consult-list">
                                    <div class="consult-date">
                                        <p>08/11/2023, 03:07pm</p>
                                    </div>
                                    <div class="consult-health-provider-name">
                                        <div class="consult-health-provider-profile">
                                            <div class="consult-health-provider-img">
                                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg02.png"
                                                    alt="patient photo">
                                            </div>
                                            <div class="consult-health-provider-info">
                                                <p>Dr. Rhiamon Langdale</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="consult-speciality">
                                        <p>Orthopedics</p>
                                    </div>
                                    <div class="consult-type">
                                        <p>Telehealth</p>
                                    </div>
                                    <div class="consult-resson">
                                        <p>Medical certificate</p>
                                    </div>
                                    <div class="consult-button medical-history-action-button">
                                        <a href="javascript:void(0)" class="view-details-modal-health-provider-btn outline-button tooltip">
                                            <span class="medical-history-action-button-text">View details</span><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M12 16V12M12 8H12.01M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z" stroke="#475467" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                            <span class="tooltiptext">View details</span>
                                        </a>
                                            
                                    </div>
                                </div>    
                                <div class="mobile-past-consult-list">
                                    <div class="mobile-past-consult-list-head">
                                        <h6>Telehealth</h6>
                                    </div>
                                    <div class="mobile-past-consult-list-body">
                                        <div class="consult-health-provider-mobile-flex">
                                            <div class="consult-health-provider-profile">
                                                <div class="consult-health-provider-img">
                                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg02.png"
                                                        alt="patient photo">
                                                </div>
                                                <div class="consult-health-provider-info">
                                                    <h6>Dr. Lindy Strongitharm</h6>
                                                    <p>Cardiac Imaging</p>
                                                </div>
                                            </div>
                                            <div class="consult-time-mobile">
                                                <p>08/11/2023 <span>03:07pm</span></p>
                                            </div>
                                        </div>
                                        <div class="consult-reason-wrap-mobile">
                                            <p>Reason</p>
                                            <p class="large-pr">Medical certificate</p>
                                        </div>
                                    </div>
                                    <div class="mobile-past-consult-list-bottom">
                                        <button type="button"
                                            class="view-details-modal-health-provider-btn outline-button">View
                                            details</button>
                                     
                                    </div>
                                </div>
                            </li>
                            <!--tbody-->
                        </ul>
                        <div class="pagination-row">
                            <div class="left-pagination">
                                <button type="button" class="pagination-button"><svg width="14" height="14"
                                        viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M12.8337 6.99996H1.16699M1.16699 6.99996L7.00033 12.8333M1.16699 6.99996L7.00033 1.16663"
                                            stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                            stroke-linejoin="round"></path>
                                    </svg>
                                    Previous</button>
                            </div>
                            <div class="center-pagination">
                                <ul class="pagination-number">
                                    <li>
                                        <button type="button" active="">1</button>
                                    </li>
                                    <li>
                                        <button type="button">2</button>
                                    </li>
                                    <li>
                                        <button type="button">3</button>
                                    </li>
                                    <li>
                                        <button type="button">...</button>
                                    </li>
                                    <li>
                                        <button type="button">8</button>
                                    </li>
                                    <li>
                                        <button type="button">9</button>
                                    </li>
                                    <li>
                                        <button type="button">10</button>
                                    </li>
                                </ul>
                            </div>
                            <div class="right-pagination">
                                <button type="button" class="pagination-button">Next<svg width="14" height="14"
                                        viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M1.1665 6.99996H12.8332M12.8332 6.99996L6.99984 1.16663M12.8332 6.99996L6.99984 12.8333"
                                            stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                            stroke-linejoin="round"></path>
                                    </svg>

                                </button>
                            </div>
                        </div>
                        <div class="pagination-row-responsive">
                            <button type="button" class="pagination-button-responsive"><svg width="14" height="14"
                                    viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M12.8337 6.99996H1.16699M1.16699 6.99996L7.00033 12.8333M1.16699 6.99996L7.00033 1.16663"
                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                        stroke-linejoin="round"></path>
                                </svg>
                            </button>
                            <p>page <span>1</span> of <span>10</span></p>
                            <button type="button" class="pagination-button-responsive"><svg width="14" height="14"
                                    viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M1.1665 6.99996H12.8332M12.8332 6.99996L6.99984 1.16663M12.8332 6.99996L6.99984 12.8333"
                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                        stroke-linejoin="round"></path>
                                </svg>

                            </button>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<!--Appointment Summary modal-->
<div class="modal view-details-modal-health-provider">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Appointment Summary</h1>
                <span class="closecurrentpopup"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round"></path>
                    </svg></span>
        </div>
        <div class="modal-body">
            <div class="appointment-summary-modal-wrap">
                <h5 class="steps-sub-heading">Reason for consultation</h5>
                <ul class="custom-radio-type-btn">
                    <li>
                        <input type="radio" id="carer-certificate" name="carer-certificate" checked>
                        <label for="carer-certificate">Carer Certificate</label>
                    </li>
                    <li>
                        <input type="radio" id="medical-consult" name="medical-consult" checked>
                        <label for="medical-consult">Medical consult</label>
                    </li>
                </ul>
                <div class="questionnaire-wrap">
                    <div class="view-hp-patient-details-toggle-btn">
                        <h5>Questionnaire</h5>
                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/questionnaire-down.svg"
                            alt="icon">
                    </div>
                    <div class="view-hp-patient-details-toggle-content">
                        <h5 class="steps-sub-heading"> Selected service(s)</h5>
                        <ul class="summary-list nopadd list-style-none">

                            <li>
                                <p class="steps-sub-para">Online video consultation ( Medical certificate, Carer
                                    certificate, Imaging/Investigation, Pathology request, Referral request etc)<br>1 x
                                    $100</p>
                                <p class="steps-sub-para">$100</p>
                            </li>
                        </ul>
                        <h5 class="steps-sub-heading"> Pharmacy</h5>
                        <input class="input-text-style mb-0"
                            value=" Pharmacy 777 Lynwood, Lynwood Village Shopping Centre, Shop 6-9, 6 Lynwood Avenue, LYNWOOD, WA, 6147"
                            disabled>
                        <h5 class="steps-sub-heading">Payment method</h5>
                        <ul class="payment-method-list nopadd list-style-none health-provider-selected-method-wrap">
                            <li class="step-border border-radius step-border">
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M0.5 8C0.5 3.85786 3.85786 0.5 8 0.5C12.1421 0.5 15.5 3.85786 15.5 8C15.5 12.1421 12.1421 15.5 8 15.5C3.85786 15.5 0.5 12.1421 0.5 8Z"
                                        fill="#F9FAFB" />
                                    <path
                                        d="M0.5 8C0.5 3.85786 3.85786 0.5 8 0.5C12.1421 0.5 15.5 3.85786 15.5 8C15.5 12.1421 12.1421 15.5 8 15.5C3.85786 15.5 0.5 12.1421 0.5 8Z"
                                        stroke="#D0D5DD" />
                                    <path
                                        d="M5 8C5 6.34315 6.34315 5 8 5C9.65685 5 11 6.34315 11 8C11 9.65685 9.65685 11 8 11C6.34315 11 5 9.65685 5 8Z"
                                        fill="#D0D5DD" />
                                </svg>
                                <label class="custom-radio-container payment-method-list-padd">
                                    <div class="payment-radio-flex">
                                        <div class="payment-icon"><img
                                                src="<?php echo base_url(); ?>assets/images/virtual_consult/wechat.svg"
                                                alt="payment-icon"></div>WeChat Pay
                                    </div>
                                </label>
                            </li>
                        </ul>
                        <ul class="summary-list nopadd list-style-none">
                            <li>
                                <p class="steps-sub-para color-black">Subtotal</p>
                                <p class="steps-sub-para color-black">$200</p>
                            </li>
                            <li>
                                <p class="steps-sub-para">Online video consultation ( Medical certificate, Carer
                                    certificate,
                                    Imaging/Investigation, Pathology request, Referral request etc)</p>
                                <p class="steps-sub-para">$100</p>
                            </li>
                            <li>
                                <p class="steps-sub-para">Service 2</p>
                                <p class="steps-sub-para">$100</p>
                            </li>
                            <li>
                                <p class="steps-sub-para">Internet handling fee<br><span>(Non-refundable processing
                                        fees)</span>
                                </p>
                                <p class="steps-sub-para">$10</p>
                            </li>
                        </ul>

                        <div class="final-summary">
                            <p class="steps-sub-para">Total amount</p>
                            <p class="steps-sub-para">$210</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">

                <div class="confirmed-consultation-btn-view">
                    <button type="button" class="closecurrentpopup unfilled-button hide-close-mobile">Close</button>
                    <a href="#" class="unfilled-danger-button cancel-health-appointment-list-modal-btn">
                        Decline</a>
                    <a href="#" class="primary-button"><svg width="21" height="20" viewBox="0 0 21 20" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M17.1663 5L7.99967 14.1667L3.83301 10" stroke="white" stroke-width="1.66667"
                                stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        Confirm consultation</a>
                </div>
            </div>
        </div>

    </div>
</div>

<!--My Appointment cancel modal-->
<div class="modal cancel-health-appointment-list-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Please provide reason for cancellation</h1>
                <span class="closecurrentpopup"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round"></path>
                    </svg></span>
        </div>
        <div class="modal-body">
            <div class="cancel-appointment-list-wrap">
                <textarea name="cancel-message" class="text-area-style" id="cancel-message"></textarea>
            </div>

        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">
                <button type="button" class="primary-button dangerstyle">Cancel appointment</button>
                <button type="button" class="closecurrentpopup unfilled-button">Close</button>
            </div>
        </div>

    </div>
</div>
<script>
    $(document).ready(function() {
        if ($('.consult-date-slider').length) {
            $('.consult-date-slider').owlCarousel({
                loop: false,
                margin: 0,
                items: 1,
                nav: true,
                autoWidth: false,
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 1
                    },
                    1000: {
                        items: 1
                    }
                }
            });
        }
        $(".owl-prev").html(
            '<img src="<?php echo base_url(); ?>assets/images/virtual_consult/carousel-prev.svg">');
        $(".owl-next").html(
            '<img src="<?php echo base_url(); ?>assets/images/virtual_consult/carousel-next.svg">');
    });
</script>
<script>
    $('.view-hp-patient-details-toggle-btn').click(function() {
        $('.view-hp-patient-details-toggle-btn').toggleClass("active");
    });
</script>

<script>
    function customAlerts(selector, action = "open", contentData = '') {
        if (contentData) {
            $(".alert_content").html(contentData);
        }
        if (action == "open") {
            $(selector).addClass('show-modal');
            $("body").addClass('modal-open');
        } else {
            $(selector).removeClass('show-modal');
            $("body").removeClass('modal-open');
        }
    }
    $(".view-details-modal-health-provider-btn").click(function() {
        customAlerts(".view-details-modal-health-provider", "open");
    });
    $(".cancel-health-appointment-list-modal-btn").click(function() {
        customAlerts(".cancel-health-appointment-list-modal", "open");
        customAlerts(".view-details-modal-health-provider", "close");
    });
</script>
<?php $this->load->view('inc/virtual_consult/footer'); ?>