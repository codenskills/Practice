<section id="hp-video-consults-sec">
    <div class="container">
        <!-- hp-video-consults-desktop-head-->
        <div class="hp-video-consults-head">
            <div class="hp-video-consult-doctor-wrap">
                <div class="hp-video-consult-doctor-profile-img">
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg02.png" alt="doctor img">
                    <span class="available-dots"></span>
                </div>
                <div class="hp-video-consult-doctor-profile-content">
                    <h6>Olivia Rhye</h6>
                    <p>DOB: 01-10-2024</p>
                </div>
            </div>
            <div class="hp-video-consult-medical-notes">
                <div class="hp-video-consult-medical-note-inner">
                    <span id="hp-video-consult-medical-note-count">1</span>
                    <h6 id="hp-video-consult-medical-note-text">Medical notes</h6>
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up-primary.svg" alt="icon">
                </div>
                <div class="hp-video-consult-medical-note-inner-drop-content">
                    <ul class="hp-video-consult-tabs-drop-list" id="hp-video-tabs-list">
                        <li>
                            <a class="video-consult-tab active" onclick="showDiv('video-consult-sec-1')"
                                id="video-consult-tab-1">
                                <span>1</span>
                                Medical notes
                            </a>
                        </li>
                        <li>
                            <a class="video-consult-tab" onclick="showDiv('video-consult-sec-2')"
                                id="video-consult-tab-2">
                                <span>2</span>
                                Pathology request
                            </a>
                        </li>
                        <li>
                            <a class="video-consult-tab" onclick="showDiv('video-consult-sec-3')"
                                id="video-consult-tab-3">
                                <span>3</span>
                                Imaging request
                            </a>
                        </li>
                        <li>
                            <a class="video-consult-tab" onclick="showDiv('video-consult-sec-4')"
                                id="video-consult-tab-4">
                                <span>4</span>
                                Medical / care certification
                            </a>
                        </li>
                        <li>
                            <a class="video-consult-tab" onclick="showDiv('video-consult-sec-5')"
                                id="video-consult-tab-5">
                                <span>5</span>
                                General / referral letter
                            </a>
                        </li>
                        <li>
                            <a class="video-consult-tab" onclick="showDiv('video-consult-sec-6')"
                                id="video-consult-tab-6">
                                <span>6</span>
                                view / edit medications
                            </a>
                        </li>
                        <li>
                            <a class="video-consult-tab" onclick="showDiv('video-consult-sec-7')"
                                id="video-consult-tab-7">
                                <span>7</span>
                                Send files
                            </a>
                        </li>
                        <li>
                            <a class="video-consult-tab" onclick="showDiv('video-consult-sec-8')"
                                id="video-consult-tab-8">
                                <span>8</span>
                                Invoice
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="hp-video-consult-tab-progress">
                <div class="hp-video-consult-tab-progress-inner">
                    <progress id="hp-video-consults-tab-progress" value="10" max="80"> </progress>
                    <p><span id="hp-video-consult-tab-progress-count">1</span>/8</p>
                </div>
            </div>
        </div>
        <!-- end-hp-video-consults-desktop-head-->

        <!-- hp-video-consults-mobile-head-->
        <div class="hp-video-consults-head-mobile">
            <div class="hp-video-consult-medical-notes-mobile hp-video-head-mobile-trigger">
                <div class="hp-video-consult-medical-note-inner">
                    <span id="hp-video-consult-medical-note-count">1</span>
                    <h6 id="hp-video-consult-medical-note-text">Medical notes</h6>
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up-primary.svg" alt="icon">
                </div>
            </div>
        </div>
        <!-- end-hp-video-consults-mobile-head-->

        <!--step1-->
        <div class="hp-video-consults-section-content video-consult-tab-sec" id="video-consult-sec-1">
            <div class="hp-video-consults-tabs-outer-container">
                <div class="hp-video-consults-tabs-inner-container video-consults-copy-flex-container">
                    <div class="hp-video-consults-copy-checkbox">
                        <h6 class="hp-video-inner-primary-heading">Send copy to patient's portal</h6>
                        <div class="drop-checkbox-wrap">
                            <form>
                                <div class="form-group">
                                    <input type="checkbox" id="medcallz_account">
                                    <label for="medcallz_account">Medcallz account</label>
                                </div>
                                <div class="form-group">
                                    <input type="checkbox" id="email">
                                    <label for="email">Email</label>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="hp-video-consults-add-template">
                        <a href="#" class="outline-button video-consults-add-template-trigger"><svg width="20"
                                height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M11.6667 1.89136V5.33348C11.6667 5.80018 11.6667 6.03354 11.7575 6.2118C11.8374 6.3686 11.9649 6.49609 12.1217 6.57598C12.2999 6.66681 12.5333 6.66681 13 6.66681H16.4421M13.3333 10.8334H6.66668M13.3333 14.1667H6.66668M8.33334 7.50008H6.66668M11.6667 1.66675H7.33334C5.93321 1.66675 5.23315 1.66675 4.69837 1.93923C4.22796 2.17892 3.84551 2.56137 3.60583 3.03177C3.33334 3.56655 3.33334 4.26662 3.33334 5.66675V14.3334C3.33334 15.7335 3.33334 16.4336 3.60583 16.9684C3.84551 17.4388 4.22796 17.8212 4.69837 18.0609C5.23315 18.3334 5.93321 18.3334 7.33334 18.3334H12.6667C14.0668 18.3334 14.7669 18.3334 15.3017 18.0609C15.7721 17.8212 16.1545 17.4388 16.3942 16.9684C16.6667 16.4336 16.6667 15.7335 16.6667 14.3334V6.66675L11.6667 1.66675Z"
                                    stroke="#344054" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>Add template</a>
                    </div>
                </div>
            </div>
            <div class="hp-video-consults-tabs-outer-container">
                <div class="hp-video-consults-tabs-inner-container">
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/editer.png" alt=""
                        class="dummy-img-editor">
                </div>
            </div>
            <div class="hp-video-consults-tabs-footer hp-video-consults-tabs-outer-container">
                <div class="tabs-footer-left-button">
                    <a href="#" class="outline-button">Skip</a>
                </div>
                <div class="tabs-footer-center-button">
                    <a class="outline-button">Cancel</a>
                    <a data-target="#video-consult-sec-2" data-index="1" class="changeTextButton primary-button"
                        onclick="showSection('video-consult-sec-1', 'video-consult-sec-2') ; increaseLength()">Next<svg
                            width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M4.16667 10.2987H15.8333M15.8333 10.2987L10 4.46533M15.8333 10.2987L10 16.132"
                                stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
                        </svg></a>
                </div>
                <div class="tabs-footer-right-button">
                    <a href="#" class="outline-button">Preview</a>
                </div>
            </div>
        </div>

        <!--step2-->
        <div class="hp-video-consults-section-content video-consult-tab-sec" id="video-consult-sec-2"
            style="display: none;">
            <div class="hp-video-consults-tabs-outer-container">
                <div class="hp-video-consults-tabs-inner-container">
                    <div class="hp-video-consults-copy-checkbox">
                        <h6 class="hp-video-inner-primary-heading">Send copy to patient's portal</h6>
                        <div class="drop-checkbox-wrap">
                            <form>
                                <div class="form-group">
                                    <input type="checkbox" id="copy_pathology_account">
                                    <label for="copy_pathology_account">Medcallz account</label>
                                </div>
                                <div class="form-group">
                                    <input type="checkbox" id="copy_pathology_email">
                                    <label for="copy_pathology_email">Email</label>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="hp-video-consults-section-content">
                <div class="hp-video-consults-tabs-outer-container">
                    <div class="hp-video-consults-tabs-inner-container pathology-table-container">
                        <div class="hp-video-consults-tab-toggle-btn">
                            <h6 class="hp-video-inner-primary-heading">Send to pathology company (in Medcallz)</h6>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg" alt="icon">
                        </div>
                        <div class="hp-video-consults-tab-toggle-content">
                            <div class="drop-checkbox-wrap">
                                <form>
                                    <div class="form-group">
                                        <input type="checkbox" id="pathology_company">
                                        <label for="pathology_company">Send to pathology company (in Medcallz)</label>
                                    </div>
                                </form>
                            </div>
                            <div class="pathology-search-bar-flex">
                                <button class="outline-button"><svg width="20" height="20" viewBox="0 0 20 20"
                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                            stroke="#344054" stroke-width="1.66667" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg>Favourites</button>
                                <input type="text" placeholder="Search" class="input-text-color-900">
                            </div>
                            <div class="pathology-table-wrap">
                                <ul class="pathology-table-ul">
                                    <li class="pathology-table-head">
                                        <div class="pathology-table-country-td">
                                            <h6>Country/state</h6> <img
                                                src="<?php echo base_url(); ?>assets/images/virtual_consult/switch-vertical.svg"
                                                alt="switch icon">
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6>Speciality</h6> <img
                                                src="<?php echo base_url(); ?>assets/images/virtual_consult/switch-vertical.svg"
                                                alt="switch icon">
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6>Health provider</h6> <img
                                                src="<?php echo base_url(); ?>assets/images/virtual_consult/switch-vertical.svg"
                                                alt="switch icon">
                                        </div>
                                        <div class="pathology-table-select-td">

                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Pathology Services</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>Western diagnostics Pathology Nursing Home</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></button>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Pathology Services</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>Western diagnostics Pathology Nursing Home</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></button>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Pathology Services</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>Western diagnostics Pathology Nursing Home</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></button>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Pathology Services</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>Western diagnostics Pathology Nursing Home</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></button>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Pathology Services</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>Western diagnostics Pathology Nursing Home</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></button>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Pathology Services</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>Western diagnostics Pathology Nursing Home</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></button>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Pathology Services</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>Western diagnostics Pathology Nursing Home</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></button>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="hp-video-consults-tabs-inner-container">
                        <div class="hp-video-consults-tab-toggle-btn">
                            <h6 class="hp-video-inner-primary-heading">Send to pathology company (not in Medcallz)</h6>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg" alt="icon">
                        </div>
                        <div class="hp-video-consults-tab-toggle-content">
                            <div class="drop-checkbox-wrap">
                                <form>
                                    <div class="form-group">
                                        <input type="checkbox" id="pathology_not_medcallz">
                                        <label for="pathology_not_medcallz">Send to pathology company (not in
                                            Medcallz)</label>
                                    </div>
                                </form>
                            </div>
                            <div class="hp-video-consults-form">
                                <div class="hp-video-consults-form-col-full col-bottom-space-xl">
                                    <label class="hp-video-consult-input-label">Name of pathology company</label>
                                    <input type="text" class="input-text-style">
                                </div>
                                <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                    <div class="hp-video-consults-form-col-half-innner">
                                        <label class="hp-video-consult-input-label">Address</label>
                                        <input type="text" class="input-text-style">
                                    </div>
                                    <div class="hp-video-consults-form-col-half-innner">
                                        <label class="hp-video-consult-input-label">Email</label>
                                        <input type="email" class="input-text-style">
                                    </div>
                                </div>
                                <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                    <div class="hp-video-consults-form-col-half-innner">
                                        <label class="hp-video-consult-input-label">Phone</label>

                                        <div class="phone-number-input">
                                            <input id="pathology_company_contact_number" class="input-text-style">
                                        </div>
                                    </div>
                                    <div class="hp-video-consults-form-col-half-innner">
                                        <label class="hp-video-consult-input-label">Fax</label>
                                        <input type="email" class="input-text-style">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="hp-video-consults-tabs-outer-container">
                    <div class="hp-video-consults-tabs-inner-container noborder nopadd">
                        <div class="hp-video-consults-tab-toggle-btn">
                            <h6 class="hp-video-inner-primary-heading">Form</h6>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg" alt="icon">
                        </div>
                        <div class="hp-video-consults-tab-toggle-content">
                            <div class="hp-video-apcc-wrap">
                                <div class="hp-video-apcc-left">
                                    <p>Please present this at an approved Pathology Collection Centre (APCC).<br>This
                                        document is issued in accordance with the NATA and RCPA accreditation
                                        requirements</p>
                                    <div class="hp-video-apcc-left-logo">
                                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/nata_icon.png"
                                            alt="nata icon" />
                                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/rcpa_icon.png"
                                            alt="rcpa icon" />
                                    </div>
                                </div>
                                <div class="hp-video-apcc-right">
                                    <h5>OFFICE USE ONLY</h5>
                                    <h5 class="color-primary">LABORATORY COPY</h5>
                                </div>
                            </div>
                            <div class="drop-checkbox-wrap apcc-flex-checkbox">
                                <div class="form-group">
                                    <input type="checkbox" id="pathology_pensioner">
                                    <label for="pathology_pensioner">Pensioner</label>
                                </div>
                                <div class="form-group">
                                    <input type="checkbox" id="health_care_card">
                                    <label for="health_care_card">Health care card</label>
                                </div>
                                <div class="form-group">
                                    <input type="checkbox" id="Veterans_affairs">
                                    <label for="Veterans_affairs">Veteran’s affairs</label>
                                </div>
                            </div>
                            <div class="hp-video-consults-tabs-inner-container">
                                <div class="hp-video-consults-tab-toggle-btn">
                                    <h6 class="hp-video-inner-primary-heading">Patient details</h6>
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg"
                                        alt="icon">
                                </div>
                                <div class="hp-video-consults-tab-toggle-content">
                                    <div class="hp-video-consults-form pt-0">
                                        <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">First Name</label>
                                                <input type="text" class="input-text-style">
                                            </div>
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Last name</label>
                                                <input type="text" class="input-text-style">
                                            </div>
                                        </div>
                                        <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Sex</label>
                                                <select class="input-text-style">
                                                    <option>Male</option>
                                                    <option>Female</option>
                                                    <option>Other</option>
                                                </select>
                                            </div>
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Date of birth</label>
                                                <div class="datepicker-wrap">
                                                    <input type="text" id="video-consult-dob-datepicker"
                                                        class="date color-text-primary" readonly="readonly"
                                                        placeholder="9/02/2024">
                                                    <svg width="12" height="8" viewBox="0 0 12 8" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 1.5L6 6.5L11 1.5" stroke="#667085"
                                                            stroke-width="1.66667" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Address</label>
                                                <input type="text" class="input-text-style">
                                            </div>
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Contact No. (Mobile)</label>
                                                <div class="phone-number-input">
                                                    <input type="text" id="form_patient_contact_number"
                                                        class="input-text-style">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="hp-video-consults-tabs-inner-container">
                                <div class="hp-video-consults-tab-toggle-btn">
                                    <h6 class="hp-video-inner-primary-heading">Medicare details</h6>
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg"
                                        alt="icon">
                                </div>
                                <div class="hp-video-consults-tab-toggle-content">
                                    <div class="hp-video-consults-form pt-0">
                                        <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Medicare (Public health)
                                                    number</label>
                                                <input type="text" class="input-text-style">
                                            </div>
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Medicare (Public health)
                                                    individual reference number</label>
                                                <input type="text" class="input-text-style">
                                            </div>
                                        </div>
                                        <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Medicare expiry</label>
                                                <div class="datepicker-wrap">
                                                    <input type="text" id="video-consult-medicare-expire-datepicker"
                                                        class="date color-text-primary" readonly="readonly"
                                                        placeholder="9/02/2024">
                                                    <svg width="12" height="8" viewBox="0 0 12 8" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 1.5L6 6.5L11 1.5" stroke="#667085"
                                                            stroke-width="1.66667" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                    </svg>
                                                </div>
                                            </div>
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">DVA / Veteran / Pension
                                                    number</label>
                                                <input type="text" class="input-text-style">
                                            </div>
                                        </div>
                                        <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Private insurance company
                                                    name</label>
                                                <input type="text" class="input-text-style">
                                            </div>
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Private insurance
                                                    number</label>
                                                <input type="email" class="input-text-style">
                                            </div>
                                        </div>
                                        <div class="hp-video-consults-form-col-half-50">
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Private insurance issue
                                                    date</label>
                                                <div class="datepicker-wrap">
                                                    <input type="text" id="video-consult-private-insurance-datepicker"
                                                        class="date color-text-primary" readonly="readonly"
                                                        placeholder="9/02/2024">
                                                    <svg width="12" height="8" viewBox="0 0 12 8" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 1.5L6 6.5L11 1.5" stroke="#667085"
                                                            stroke-width="1.66667" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="hp-video-consults-tabs-inner-container">
                                <div class="hp-video-consults-tab-toggle-btn">
                                    <h6 class="hp-video-inner-primary-heading">Tests requested</h6>
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg"
                                        alt="icon">
                                </div>
                                <div class="hp-video-consults-tab-toggle-content">
                                    <div class="hp-video-consults-form pt-0">
                                        <div class="hp-video-consults-form-col-full col-bottom-space-xl">
                                            <label class="hp-video-consult-input-label">Name of test(s)</label>
                                            <input type="text" class="input-text-style">
                                        </div>
                                    </div>
                                    <div class="drop-checkbox-wrap apcc-flex-checkbox mt-0 col-bottom-space-xl">
                                        <div class="form-group">
                                            <input type="checkbox" id="Fasting">
                                            <label for="Fasting">Fasting</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="hormone_therapy">
                                            <label for="hormone_therapy">Hormone therapy</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="non-fasting">
                                            <label for="non-fasting">Non-fasting</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="Pregnant">
                                            <label for="Pregnant">Pregnant</label>
                                        </div>
                                    </div>
                                    <div class="gestational-age-input-wrap">
                                        <label class="hp-video-consult-input-label">Gestational age</label>
                                        <input type="text" class="input-text-style">
                                    </div>
                                </div>
                            </div>
                            <div class="hp-video-consults-tabs-inner-container">
                                <div class="hp-video-consults-tab-toggle-btn">
                                    <h6 class="hp-video-inner-primary-heading">Clinical notes</h6>
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg"
                                        alt="icon">
                                </div>
                                <div class="hp-video-consults-tab-toggle-content">
                                    <div class="hp-video-consults-form pt-0">
                                        <div class="hp-video-consults-form-col-full col-bottom-space-xl">
                                            <label class="hp-video-consult-input-label">Notes</label>
                                            <textarea id="clinic-notes-textarea"></textarea>
                                        </div>
                                        <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Phone number</label>
                                                <div class="phone-number-input">
                                                    <input type="text" class="input-text-style"
                                                        id="clinical_notes_phone_number">
                                                </div>
                                            </div>
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">By date</label>
                                                <div class="datepicker-wrap">
                                                    <input type="text" id="notes-by-datepcker"
                                                        class="date color-text-primary" readonly="readonly"
                                                        placeholder="9/02/2024">
                                                    <svg width="12" height="8" viewBox="0 0 12 8" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 1.5L6 6.5L11 1.5" stroke="#667085"
                                                            stroke-width="1.66667" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clinical-notes-status-flex">
                                        <div class="drop-checkbox-wrap apcc-flex-checkbox mt-0">
                                            <div class="form-group">
                                                <input type="checkbox" id="Fasting">
                                                <label for="Fasting">Fasting</label>
                                            </div>
                                            <div class="form-group">
                                                <input type="checkbox" id="hormone_therapy">
                                                <label for="hormone_therapy">Hormone therapy</label>
                                            </div>
                                            <div class="form-group">
                                                <input type="checkbox" id="non-fasting">
                                                <label for="non-fasting">Non-fasting</label>
                                            </div>
                                            <div class="form-group">
                                                <input type="checkbox" id="Pregnant">
                                                <label for="Pregnant">Pregnant</label>
                                            </div>
                                        </div>
                                        <div class="clinical-notes-status-radio-flex">
                                            <label class="clinical-notes-status-label">Hospital status</label>
                                            <div class="flex-row-radio">
                                                <label class="custom-radio-container">
                                                    Non-hospital
                                                    <input type="radio" checked="checked" name="hospital_status">
                                                    <span class="radio-checkmark"></span>
                                                </label>
                                                <label class="custom-radio-container">
                                                    Hospital
                                                    <input type="radio" name="hospital_status">
                                                    <span class="radio-checkmark"></span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="hp-video-consults-tabs-inner-container">
                                <div class="hp-video-consults-tab-toggle-btn">
                                    <h6 class="hp-video-inner-primary-heading">Requesting doctor's signature and request
                                        date</h6>
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg"
                                        alt="icon">
                                </div>
                                <div class="hp-video-consults-tab-toggle-content">
                                    <div class="video-requesting-doctor-signature-flex">
                                        <div
                                            class="video-requesting-doctor-signature-left video-requesting-doctor-signature-col">
                                            <div class="video-requesting-doctor-text-wrap">
                                                <h5>PERSON COLLECTING SPECIMEN(S) TO COMPLETE:</h5>
                                                <p>I certify I established the identity of the patient name on this
                                                    request, collected and immediately labelled the accompanying
                                                    specimen(s) with the patient’s details.</p>
                                            </div>
                                            <div class="video-requesting-doctor-signature-form">
                                                <div
                                                    class="video-requesting-doctor-signature-form-group col-bottom-space-xl">
                                                    <label class="hp-video-consult-input-label">Name</label>
                                                    <input type="text" class="input-text-style">
                                                </div>
                                                <div class="video-requesting-doctor-signature-form-group">
                                                    <label class="hp-video-consult-input-label">Signature</label>
                                                    <textarea></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="video-requesting-doctor-signature-right video-requesting-doctor-signature-col">
                                            <div class="video-requesting-doctor-text-wrap">
                                                <h5>REQUESTING DOCTOR’S SIGNATURE AND REQUEST DATE:</h5>
                                                <p>I certify I established the identity of the patient name on this
                                                    request, collected and immediately labelled the accompanying
                                                    specimen(s) with the patient’s details.</p>
                                            </div>
                                            <div class="video-requesting-doctor-signature-form">
                                                <div
                                                    class="video-requesting-doctor-signature-form-group col-bottom-space-xl">
                                                    <label class="hp-video-consult-input-label">Health provider
                                                        name</label>
                                                    <input type="text" class="input-text-style">
                                                </div>
                                                <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                                    <div class="hp-video-consults-form-col-half-innner">
                                                        <label class="hp-video-consult-input-label">Provider
                                                            number</label>
                                                        <input type="text" class="input-text-style">
                                                    </div>
                                                    <div class="hp-video-consults-form-col-half-innner">
                                                        <label class="hp-video-consult-input-label">Date</label>
                                                        <div class="datepicker-wrap">
                                                            <input type="text" id="pathlogy-doctor-datepicker"
                                                                class="date color-text-primary" readonly="readonly"
                                                                placeholder="9/02/2024">
                                                            <svg width="12" height="8" viewBox="0 0 12 8" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M1 1.5L6 6.5L11 1.5" stroke="#667085"
                                                                    stroke-width="1.66667" stroke-linecap="round"
                                                                    stroke-linejoin="round" />
                                                            </svg>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="video-requesting-doctor-signature-form-group">
                                                    <label class="hp-video-consult-input-label">Signature</label>
                                                    <textarea></textarea>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="hp-video-consults-tabs-inner-container">
                                <div
                                    class="hp-video-consults-form-col-half col-bottom-space-3xl copy-reports-textareas">
                                    <div class="hp-video-consults-form-col-half-innner">
                                        <label class="hp-video-consult-input-label">Copy reports</label>
                                        <textarea id="copy-repeort"></textarea>
                                    </div>
                                    <div class="hp-video-consults-form-col-half-innner">
                                        <label class="hp-video-consult-input-label">Requesting doctor</label>
                                        <textarea id="requesting-doctor"></textarea>
                                    </div>
                                </div>
                                <div class="drop-checkbox-wrap mt-0 col-bottom-space-3xl">
                                    <div class="form-group">
                                        <input type="checkbox" id="self-determine-checkbox">
                                        <label for="self-determine-checkbox">Tick if self determine</label>
                                    </div>
                                </div>
                                <div class="sst-tables-wrap">
                                    <div class="sst-tables-wrap-row">
                                        <div class="sst-tables-col">
                                            <h6>SST</h6>
                                            <p>Tube</p>
                                        </div>
                                        <div class="sst-tables-col">
                                            <h6>EDTA</h6>
                                            <p>Tube</p>
                                        </div>
                                        <div class="sst-tables-col">
                                            <h6>Histo</h6>
                                            <p>Cont</p>
                                        </div>
                                        <div class="sst-tables-col">
                                            <h6>Pap</h6>
                                            <p>Slide</p>
                                        </div>
                                        <div class="sst-tables-col">
                                            <h6>ThP</h6>
                                            <p>Thin Prep</p>
                                        </div>
                                        <div class="sst-tables-col">
                                            <h6>Swap</h6>
                                            <p>-</p>
                                        </div>
                                    </div>
                                    <div class="sst-tables-wrap-row">
                                        <div class="sst-tables-col">
                                            <h6>Frozen</h6>
                                            <p>-</p>
                                        </div>
                                        <div class="sst-tables-col">
                                            <h6>Dedicated EDTA</h6>
                                            <p>Tube</p>
                                        </div>
                                        <div class="sst-tables-col">
                                            <h6>Other</h6>
                                            <p>-</p>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="hp-video-consults-form-border col-top-bottom-space-3xl col-margin-bottom-space-3xl">
                                    <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                        <div class="hp-video-consults-form-col-half-innner">
                                            <label class="hp-video-consult-input-label">Staff ID/Location
                                                Code/Collection type (stamp)</label>
                                            <input type="text" class="input-text-style">
                                        </div>
                                        <div class="hp-video-consults-form-col-half-innner">
                                            <label class="hp-video-consult-input-label">Pay cat</label>
                                            <input type="text" class="input-text-style">
                                        </div>
                                    </div>
                                    <div class="hp-video-consults-form-col-half">
                                        <div class="hp-video-consults-form-col-half-innner">
                                            <label class="hp-video-consult-input-label">Date collected</label>
                                            <div class="datepicker-wrap">
                                                <input type="text" id="date-collected-datepcker"
                                                    class="date color-text-primary" readonly="readonly"
                                                    placeholder="9/02/2024">
                                                <svg width="12" height="8" viewBox="0 0 12 8" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M1 1.5L6 6.5L11 1.5" stroke="#667085"
                                                        stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                        <div class="hp-video-consults-form-col-half-innner">
                                            <label class="hp-video-consult-input-label">Time collected</label>
                                            <input type="text" class="input-text-style">
                                        </div>
                                    </div>
                                </div>
                                <div class="video-requesting-medicare-account-dec-flex col-bottom-space-3xl">
                                    <div class="video-requesting-medicare-account-dec-col">
                                        <h6>Medicare Assignment (Section 20A of the Health Insurance Act 1973)</h6>
                                        <p>I offer to assign my right to benefits to the approved pathology practitioner
                                            who will render the requested pathology service(s) and any eligible
                                            pathologist determinable service(s) established as necessary by the
                                            practitioner.</p>
                                    </div>
                                    <div class="video-requesting-medicare-account-dec-col">
                                        <h6>Account Declaration</h6>
                                        <p>Should any of the tests requested by my doctor not be eligible for Medicare
                                            benefits, I Understand that I will receive an account for these tests and
                                            agree to pay in full.</p>
                                    </div>
                                </div>
                                <div class="hp-video-consult-patient-signature-input-wrap col-margin-bottom-space-3xl">
                                    <p>Patient Signature</p>
                                </div>
                                <div class="video-requesting-medicare-account-dec-text-wrap">
                                    <p>The Medicare Benefits Schedule is managed by the Department of Health and Ageing
                                        and administered by Medicare Australia. Your rebate is the Australian
                                        government’s subsidy for your tests that are included in the Schedule.</p>
                                    <p>If any of your tests are not covered in the Schedule you will not receive a
                                        Medicare rebate.</p>
                                    <p>You are expected to pay for these tests in full.</p>
                                </div>
                            </div>
                            <div class="hp-video-consults-tabs-inner-container bring-to-appopintment-container">
                                <p>Ensure to bring to the appointment</p>
                                <ul class="bring-to-appointment-wrap">
                                    <li>Request form</li>
                                    <li><span class="list-dot"></span>Medicare card</li>
                                    <li><span class="list-dot"></span>Pension/Health Care/Vet Affairs Card (if
                                        applicable)</li>
                                </ul>
                            </div>
                            <div class="hp-video-consults-tabs-inner-container copy-patient-portal-checkbox-container">
                                <div class="drop-checkbox-wrap mt-0">
                                    <div class="form-group">
                                        <input type="checkbox" id="copy_patient_portal_checkbox">
                                        <label for="copy_patient_portal_checkbox">Send copy to patient’s portal</label>
                                    </div>
                                </div>
                                <div class="hp-video-consults-form pt-0">
                                    <div class="hp-video-consults-form-col-full">
                                        <label class="hp-video-consult-input-label">Please enter the email address of
                                            blood test company to whom you want to send this report</label>
                                        <input type="text" class="input-text-style">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="hp-video-consults-tabs-footer hp-video-consults-tabs-outer-container">
                <div class="tabs-footer-left-button">
                    <a href="#" class="outline-button">Skip</a>
                </div>
                <div class="tabs-footer-center-button">
                    <a class="outline-button changeTextButton" data-index="0" data-target="#video-consult-sec-2"
                        onclick="showSection('video-consult-sec-2', 'video-consult-sec-1') ; decreaseLength()">Previous</a>
                    <a class="primary-button changeTextButton" data-index="2" data-target="#video-consult-sec-3"
                        onclick="showSection('video-consult-sec-2', 'video-consult-sec-3') ; increaseLength()">Next<svg
                            width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M4.16667 10.2987H15.8333M15.8333 10.2987L10 4.46533M15.8333 10.2987L10 16.132"
                                stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
                        </svg></a>
                </div>
                <div class="tabs-footer-right-button">
                    <a href="#" class="outline-button">Preview</a>
                </div>
            </div>
        </div>

        <!--step3-->
        <div class="hp-video-consults-section-content video-consult-tab-sec" id="video-consult-sec-3"
            style="display: none;">
            <div class="hp-video-consults-tabs-outer-container">
                <div class="hp-video-consults-tabs-inner-container">
                    <div class="hp-video-consults-copy-checkbox">
                        <h6 class="hp-video-inner-primary-heading">Send copy to patient's portal</h6>
                        <div class="drop-checkbox-wrap">
                            <form>
                                <div class="form-group">
                                    <input type="checkbox" id="medcallz_account">
                                    <label for="medcallz_account">Medcallz account</label>
                                </div>
                                <div class="form-group">
                                    <input type="checkbox" id="email">
                                    <label for="email">Email</label>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="hp-video-consults-section-content">
                <div class="hp-video-consults-tabs-outer-container">
                    <div class="hp-video-consults-tabs-inner-container pathology-table-container">
                        <div class="hp-video-consults-tab-toggle-btn">
                            <h6 class="hp-video-inner-primary-heading">Send to pathology company (in Medcallz)</h6>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg" alt="icon">
                        </div>
                        <div class="hp-video-consults-tab-toggle-content">
                            <div class="drop-checkbox-wrap">
                                <form>
                                    <div class="form-group">
                                        <input type="checkbox" id="pathology_company">
                                        <label for="pathology_company">Send to pathology company (in Medcallz)</label>
                                    </div>
                                </form>
                            </div>
                            <div class="pathology-search-bar-flex">
                                <button class="outline-button"><svg width="20" height="20" viewBox="0 0 20 20"
                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                            stroke="#344054" stroke-width="1.66667" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg>Favourites</button>
                                <input type="text" placeholder="Search" class="input-text-color-900">
                            </div>
                            <div class="pathology-table-wrap">
                                <ul class="pathology-table-ul">
                                    <li class="pathology-table-head">
                                        <div class="pathology-table-country-td">
                                            <h6>Country/state</h6> <img
                                                src="<?php echo base_url(); ?>assets/images/virtual_consult/switch-vertical.svg"
                                                alt="switch icon">
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6>Speciality</h6> <img
                                                src="<?php echo base_url(); ?>assets/images/virtual_consult/switch-vertical.svg"
                                                alt="switch icon">
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6>Health provider</h6> <img
                                                src="<?php echo base_url(); ?>assets/images/virtual_consult/switch-vertical.svg"
                                                alt="switch icon">
                                        </div>
                                        <div class="pathology-table-select-td">

                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Service 2</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>HP 2</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></button>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Service 3</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>HP 3</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></button>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Service 4</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>HP 4</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></button>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Service 5</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>HP 5</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></button>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Service 6</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>HP 6</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></button>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Service 7</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>HP 7</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></button>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Service 8</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>HP 8</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></button>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="hp-video-consults-tabs-inner-container">
                        <div class="hp-video-consults-tab-toggle-btn">
                            <h6 class="hp-video-inner-primary-heading">Send to pathology company (not in Medcallz)</h6>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg" alt="icon">
                        </div>
                        <div class="hp-video-consults-tab-toggle-content">
                            <div class="drop-checkbox-wrap">
                                <form>
                                    <div class="form-group">
                                        <input type="checkbox" id="pathology_not_medcallz">
                                        <label for="pathology_not_medcallz">Send to pathology company (not in
                                            Medcallz)</label>
                                    </div>
                                </form>
                            </div>
                            <div class="hp-video-consults-form">
                                <div class="hp-video-consults-form-col-full col-bottom-space-xl">
                                    <label class="hp-video-consult-input-label">Name of pathology company</label>
                                    <input type="text" class="input-text-style">
                                </div>
                                <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                    <div class="hp-video-consults-form-col-half-innner">
                                        <label class="hp-video-consult-input-label">Address</label>
                                        <input type="text" class="input-text-style">
                                    </div>
                                    <div class="hp-video-consults-form-col-half-innner">
                                        <label class="hp-video-consult-input-label">Email</label>
                                        <input type="email" class="input-text-style">
                                    </div>
                                </div>
                                <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                    <div class="hp-video-consults-form-col-half-innner">
                                        <label class="hp-video-consult-input-label">Phone</label>
                                        <div class="phone-number-input">
                                            <input type="text" class="input-text-style"
                                                id="imaging_request_pathology_mobile">
                                        </div>
                                    </div>
                                    <div class="hp-video-consults-form-col-half-innner">
                                        <label class="hp-video-consult-input-label">Fax</label>
                                        <input type="email" class="input-text-style">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="hp-video-consults-tabs-outer-container">
                    <div class="hp-video-consults-tabs-inner-container noborder nopadd">
                        <div class="hp-video-consults-tab-toggle-btn">
                            <h6 class="hp-video-inner-primary-heading">Form</h6>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg" alt="icon">
                        </div>
                        <div class="hp-video-consults-tab-toggle-content">
                            <div class="hp-video-apcc-wrap">
                                <div class="hp-video-apcc-left">
                                    <p>Please present this at an approved Pathology Collection Centre (APCC).<br>This
                                        document is issued in accordance with the NATA and RCPA accreditation
                                        requirements</p>
                                    <div class="hp-video-apcc-left-logo">
                                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/nata_icon.png"
                                            alt="nata icon" />
                                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/rcpa_icon.png"
                                            alt="rcpa icon" />
                                    </div>
                                </div>
                                <div class="hp-video-apcc-right">
                                    <h5>OFFICE USE ONLY</h5>
                                    <h5 class="color-primary">LABORATORY COPY</h5>
                                </div>
                            </div>
                            <div class="drop-checkbox-wrap apcc-flex-checkbox">
                                <div class="form-group">
                                    <input type="checkbox" id="pathology_pensioner">
                                    <label for="pathology_pensioner">Pensioner</label>
                                </div>
                                <div class="form-group">
                                    <input type="checkbox" id="health_care_card">
                                    <label for="health_care_card">Health care card</label>
                                </div>
                                <div class="form-group">
                                    <input type="checkbox" id="Veterans_affairs">
                                    <label for="Veterans_affairs">Veteran’s affairs</label>
                                </div>
                            </div>
                            <div class="hp-video-consults-tabs-inner-container">
                                <div class="hp-video-consults-tab-toggle-btn">
                                    <h6 class="hp-video-inner-primary-heading">Patient details</h6>
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg"
                                        alt="icon">
                                </div>
                                <div class="hp-video-consults-tab-toggle-content">
                                    <div class="hp-video-consults-form pt-0">
                                        <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">First Name</label>
                                                <input type="text" class="input-text-style">
                                            </div>
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Last name</label>
                                                <input type="text" class="input-text-style">
                                            </div>
                                        </div>
                                        <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Sex</label>
                                                <select class="input-text-style">
                                                    <option>Male</option>
                                                    <option>Female</option>
                                                    <option>Other</option>
                                                </select>
                                            </div>
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Date of birth</label>
                                                <div class="datepicker-wrap">
                                                    <input type="text" id="video-consult-dob-datepicker"
                                                        class="date color-text-primary" readonly="readonly"
                                                        placeholder="9/02/2024">
                                                    <svg width="12" height="8" viewBox="0 0 12 8" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 1.5L6 6.5L11 1.5" stroke="#667085"
                                                            stroke-width="1.66667" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Address</label>
                                                <input type="text" class="input-text-style">
                                            </div>
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Contact No. (Mobile)</label>
                                                <div class="phone-number-input">
                                                    <input type="text" class="input-text-style"
                                                        id="imaging_request_patient_mobile">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="hp-video-consults-tabs-inner-container">
                                <div class="hp-video-consults-tab-toggle-btn">
                                    <h6 class="hp-video-inner-primary-heading">Medicare details</h6>
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg"
                                        alt="icon">
                                </div>
                                <div class="hp-video-consults-tab-toggle-content">
                                    <div class="hp-video-consults-form pt-0">
                                        <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Medicare (Public health)
                                                    number</label>
                                                <input type="text" class="input-text-style">
                                            </div>
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Medicare (Public health)
                                                    individual reference number</label>
                                                <input type="text" class="input-text-style">
                                            </div>
                                        </div>
                                        <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Medicare expiry</label>
                                                <div class="datepicker-wrap">
                                                    <input type="text" id="video-consult-medicare-expire-datepicker"
                                                        class="date color-text-primary" readonly="readonly"
                                                        placeholder="9/02/2024">
                                                    <svg width="12" height="8" viewBox="0 0 12 8" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 1.5L6 6.5L11 1.5" stroke="#667085"
                                                            stroke-width="1.66667" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                    </svg>
                                                </div>
                                            </div>
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">DVA / Veteran / Pension
                                                    number</label>
                                                <input type="text" class="input-text-style">
                                            </div>
                                        </div>
                                        <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Private insurance company
                                                    name</label>
                                                <input type="text" class="input-text-style">
                                            </div>
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Private insurance
                                                    number</label>
                                                <input type="email" class="input-text-style">
                                            </div>
                                        </div>
                                        <div class="hp-video-consults-form-col-half-50">
                                            <div class="hp-video-consults-form-col-half-innner">
                                                <label class="hp-video-consult-input-label">Private insurance issue
                                                    date</label>
                                                <div class="datepicker-wrap">
                                                    <input type="text" id="video-consult-private-insurance-datepicker"
                                                        class="date color-text-primary" readonly="readonly"
                                                        placeholder="9/02/2024">
                                                    <svg width="12" height="8" viewBox="0 0 12 8" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 1.5L6 6.5L11 1.5" stroke="#667085"
                                                            stroke-width="1.66667" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="hp-video-consults-tabs-inner-container">
                                <div class="hp-video-consults-tab-toggle-btn">
                                    <h6 class="hp-video-inner-primary-heading">Tests requested</h6>
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg"
                                        alt="icon">
                                </div>
                                <div class="hp-video-consults-tab-toggle-content">
                                    <div class="hp-video-consults-form pt-0">
                                        <div class="hp-video-consults-form-col-full">
                                            <label class="hp-video-consult-input-label">Name of test(s)</label>
                                            <input type="text" class="input-text-style">
                                        </div>
                                    </div>
                                    <div class="tests-communication-requested-flex">
                                        <div class="tests-communication-requested-col">
                                            <h4 class="hp-video-inner-primary-heading">Tests requested</h4>
                                            <div class="drop-checkbox-wrap apcc-flex-checkbox mt-0">
                                                <div class="form-group">
                                                    <input type="checkbox" id="Standard">
                                                    <label for="Standard">Standard</label>
                                                </div>
                                                <div class="form-group">
                                                    <input type="checkbox" id="Airbone">
                                                    <label for="Airbone">Airbone</label>
                                                </div>
                                                <div class="form-group">
                                                    <input type="checkbox" id="Contact">
                                                    <label for="Contact">Contact</label>
                                                </div>
                                                <div class="form-group">
                                                    <input type="checkbox" id="Droplet">
                                                    <label for="Droplet">Droplet</label>
                                                </div>
                                            </div>
                                            <h4 class="hp-video-inner-primary-heading">IV access</h4>
                                            <div class="tests-communication-iv-access-radio-wrap">
                                                <p>IV Cannula In-Situ</p>
                                                <div class="flex-row-radio">
                                                    <label class="custom-radio-container">
                                                        Yes
                                                        <input type="radio" checked="checked" name="iv-access-question">
                                                        <span class="radio-checkmark"></span>
                                                    </label>
                                                    <label class="custom-radio-container">
                                                        No
                                                        <input type="radio" name="iv-access-question">
                                                        <span class="radio-checkmark"></span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tests-communication-requested-col">
                                            <h4 class="hp-video-inner-primary-heading">Communication</h4>
                                            <div class="drop-checkbox-wrap apcc-flex-checkbox mt-0">
                                                <div class="form-group">
                                                    <input type="checkbox" id="Interpreter-requested">
                                                    <label for="Interpreter-requested">Interpreter requested</label>
                                                </div>
                                            </div>
                                            <h4 class="hp-video-inner-primary-heading">Anticoagulation therapy</h4>
                                            <div class="tests-communication-iv-access-radio-wrap">
                                                <p>Which anticoagulant/antiplatelet agent is the patient on?</p>
                                                <div class="flex-row-radio">
                                                    <label class="custom-radio-container">
                                                        Yes
                                                        <input type="radio" checked="checked"
                                                            name="anticoagulation-therapy-question">
                                                        <span class="radio-checkmark"></span>
                                                    </label>
                                                    <label class="custom-radio-container">
                                                        No
                                                        <input type="radio" name="anticoagulation-therapy-question">
                                                        <span class="radio-checkmark"></span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="hp-video-consults-form col-bottom-space-3xl">
                                        <div class="hp-video-consults-form-col-full">
                                            <label class="hp-video-consult-input-label">Site</label>
                                            <input type="text" class="input-text-style">
                                        </div>
                                    </div>
                                    <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                        <div class="hp-video-consults-form-col-half-innner">
                                            <label class="hp-video-consult-input-label">Language</label>
                                            <select class="input-text-style">
                                                <option>English</option>
                                                <option>French</option>
                                            </select>
                                        </div>
                                        <div class="hp-video-consults-form-col-half-innner">
                                            <label class="hp-video-consult-input-label">Patient transport</label>
                                            <select class="input-text-style">
                                                <option>Option 1</option>
                                                <option>Option 2</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                        <div class="hp-video-consults-form-col-half-innner">
                                            <label class="hp-video-consult-input-label">INR</label>
                                            <input type="text" class="input-text-style">
                                        </div>
                                        <div class="hp-video-consults-form-col-half-innner">
                                            <label class="hp-video-consult-input-label">Platelets</label>
                                            <input type="text" class="input-text-style">
                                        </div>
                                    </div>
                                    <div class="hp-video-consults-form-col-half">
                                        <div class="hp-video-consults-form-col-half-innner">
                                            <label class="hp-video-consult-input-label">Appt</label>
                                            <input type="text" class="input-text-style">
                                        </div>
                                        <div class="hp-video-consults-form-col-half-innner">
                                            <label class="hp-video-consult-input-label">Date</label>
                                            <div class="datepicker-wrap">
                                                <input type="text" id="tests-requeste-datepicker" class="date"
                                                    readonly="readonly" placeholder="9/02/2024">
                                                <svg width="12" height="8" viewBox="0 0 12 8" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M1 1.5L6 6.5L11 1.5" stroke="#667085"
                                                        stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="hp-video-consults-tabs-inner-container">
                                <div class="hp-video-consults-tab-toggle-btn">
                                    <h6 class="hp-video-inner-primary-heading">Clinical notes</h6>
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg"
                                        alt="icon">
                                </div>
                                <div class="hp-video-consults-tab-toggle-content">
                                    <div class="hp-video-consults-form pt-0">
                                        <div class="hp-video-consults-form-col-full col-bottom-space-xl">
                                            <label class="hp-video-consult-input-label">Notes</label>
                                            <textarea id="clinic-notes-textarea"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="hp-video-consults-tabs-inner-container">
                                <div class="hp-video-consults-tab-toggle-btn">
                                    <h6 class="hp-video-inner-primary-heading">Essential for contrast / Interventional
                                        procedures (Risk factors)</h6>
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg"
                                        alt="icon">
                                </div>
                                <div class="hp-video-consults-tab-toggle-content">
                                    <div class="essential-factors-flex-wrap">
                                        <div class="essential-factors-flex-col">
                                            <ul>
                                                <li>
                                                    <p>Age>65 years</p>
                                                    <div class="flex-row-radio">
                                                        <label class="custom-radio-container">
                                                            Yes
                                                            <input type="radio" checked="checked"
                                                                name="essential_age_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                        <label class="custom-radio-container">
                                                            No
                                                            <input type="radio" name="essential_age_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                    </div>
                                                </li>
                                                <li>
                                                    <p>Renal Impairment / dialysis</p>
                                                    <div class="flex-row-radio">
                                                        <label class="custom-radio-container">
                                                            Yes
                                                            <input type="radio" checked="checked"
                                                                name="essential_rental-dialysis_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                        <label class="custom-radio-container">
                                                            No
                                                            <input type="radio" name="dialysis_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                    </div>
                                                </li>
                                                <li>
                                                    <p>Diabetic</p>
                                                    <div class="flex-row-radio">
                                                        <label class="custom-radio-container">
                                                            Yes
                                                            <input type="radio" checked="checked"
                                                                name="essential_diabetic_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                        <label class="custom-radio-container">
                                                            No
                                                            <input type="radio" name="essential_diabetic_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                    </div>
                                                </li>
                                                <li>
                                                    <p>Taking metformin</p>
                                                    <div class="flex-row-radio">
                                                        <label class="custom-radio-container">
                                                            Yes
                                                            <input type="radio" checked="checked"
                                                                name="essential_metformin_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                        <label class="custom-radio-container">
                                                            No
                                                            <input type="radio" name="essential_metformin_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                    </div>
                                                </li>
                                                <li>
                                                    <p>Nephrotoxic medication</p>
                                                    <div class="flex-row-radio">
                                                        <label class="custom-radio-container">
                                                            Yes
                                                            <input type="radio" checked="checked"
                                                                name="essential_nephrotoxic_medication_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                        <label class="custom-radio-container">
                                                            No
                                                            <input type="radio"
                                                                name="essential_nephrotoxic_medication_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                    </div>
                                                </li>
                                                <li>
                                                    <p>Recent lodinated contrast</p>
                                                    <div class="flex-row-radio">
                                                        <label class="custom-radio-container">
                                                            Yes
                                                            <input type="radio" checked="checked"
                                                                name="essential_lodinated_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                        <label class="custom-radio-container">
                                                            No
                                                            <input type="radio" name="essential_lodinated_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="essential-factors-flex-col">
                                            <ul>
                                                <li>
                                                    <p>Asthmatic</p>
                                                    <div class="flex-row-radio">
                                                        <label class="custom-radio-container">
                                                            Yes
                                                            <input type="radio" checked="checked"
                                                                name="essential_asthmatic_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                        <label class="custom-radio-container">
                                                            No
                                                            <input type="radio" name="essential_asthmatic_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                    </div>
                                                </li>
                                                <li>
                                                    <p>Myeloma</p>
                                                    <div class="flex-row-radio">
                                                        <label class="custom-radio-container">
                                                            Yes
                                                            <input type="radio" checked="checked"
                                                                name="essential_myeloma_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                        <label class="custom-radio-container">
                                                            No
                                                            <input type="radio" name="essential_myeloma_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                    </div>
                                                </li>
                                                <li>
                                                    <p>Hearth failure/shock</p>
                                                    <div class="flex-row-radio">
                                                        <label class="custom-radio-container">
                                                            Yes
                                                            <input type="radio" checked="checked"
                                                                name="essential_hearth_failure_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                        <label class="custom-radio-container">
                                                            No
                                                            <input type="radio" name="essential_hearth_failure_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                    </div>
                                                </li>
                                                <li>
                                                    <p>Liver disease</p>
                                                    <div class="flex-row-radio">
                                                        <label class="custom-radio-container">
                                                            Yes
                                                            <input type="radio" checked="checked"
                                                                name="essential_liver_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                        <label class="custom-radio-container">
                                                            No
                                                            <input type="radio" name="essential_liver_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                    </div>
                                                </li>
                                                <li>
                                                    <p>Respiratory disease</p>
                                                    <div class="flex-row-radio">
                                                        <label class="custom-radio-container">
                                                            Yes
                                                            <input type="radio" checked="checked"
                                                                name="essential_respiratory_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                        <label class="custom-radio-container">
                                                            No
                                                            <input type="radio" name="essential_respiratory_factor">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="hp-video-consults-tabs-inner-container">
                                <div class="hp-video-consults-tab-toggle-btn">
                                    <h6 class="hp-video-inner-primary-heading">If yes to any of the above</h6>
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg"
                                        alt="icon">
                                </div>
                                <div class="hp-video-consults-tab-toggle-content">
                                    <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                        <div class="hp-video-consults-form-col-half-innner">
                                            <label class="hp-video-consult-input-label">Creatinine</label>
                                            <input type="text" class="input-text-style">
                                        </div>
                                        <div class="hp-video-consults-form-col-half-innner">
                                            <label class="hp-video-consult-input-label">Date</label>
                                            <div class="datepicker-wrap">
                                                <input type="text" id="essential-risk-datepicker" class="date"
                                                    readonly="readonly" placeholder="9/02/2024">
                                                <svg width="12" height="8" viewBox="0 0 12 8" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M1 1.5L6 6.5L11 1.5" stroke="#667085"
                                                        stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="hp-video-consults-form-col-half">
                                        <div class="hp-video-consults-form-col-half-innner">
                                            <label class="hp-video-consult-input-label">Weight</label>
                                            <input type="text" class="input-text-style">
                                        </div>
                                        <div class="hp-video-consults-form-col-half-innner">
                                            <label class="hp-video-consult-input-label">eGFR</label>
                                            <input type="text" class="input-text-style">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="hp-video-consults-tabs-inner-container">
                                <div class="hp-video-consults-tab-toggle-btn">
                                    <h6 class="hp-video-inner-primary-heading">Does the patient have?</h6>
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg"
                                        alt="icon">
                                </div>
                                <div class="hp-video-consults-tab-toggle-content">
                                    <div class="essential-factors-flex-wrap">
                                        <div class="essential-factors-flex-col">
                                            <ul>
                                                <li>
                                                    <p>History of welding, grinding, sheet metal work</p>
                                                    <div class="flex-row-radio">
                                                        <label class="custom-radio-container">
                                                            Yes
                                                            <input type="radio" checked="checked"
                                                                name="paitent_work_record">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                        <label class="custom-radio-container">
                                                            No
                                                            <input type="radio" name="paitent_work_record">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                    </div>
                                                </li>
                                                <li>
                                                    <p>Brain aneurysm clip</p>
                                                    <div class="flex-row-radio">
                                                        <label class="custom-radio-container">
                                                            Yes
                                                            <input type="radio" checked="checked"
                                                                name="paitent_brain_clip">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                        <label class="custom-radio-container">
                                                            No
                                                            <input type="radio" name="paitent_brain_clip">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                    </div>
                                                </li>
                                                <li>
                                                    <p>Pregnant</p>
                                                    <div class="flex-row-radio">
                                                        <label class="custom-radio-container">
                                                            Yes
                                                            <input type="radio" checked="checked"
                                                                name="patient_pregnant">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                        <label class="custom-radio-container">
                                                            No
                                                            <input type="radio" name="patient_pregnant">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="essential-factors-flex-col">
                                            <ul>
                                                <li>
                                                    <p>Cardiac pacemaker</p>
                                                    <div class="flex-row-radio">
                                                        <label class="custom-radio-container">
                                                            Yes
                                                            <input type="radio" checked="checked"
                                                                name="cardiac_pacemaker">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                        <label class="custom-radio-container">
                                                            No
                                                            <input type="radio" name="cardiac_pacemaker">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                    </div>
                                                </li>
                                                <li>
                                                    <p>Cochlear implant</p>
                                                    <div class="flex-row-radio">
                                                        <label class="custom-radio-container">
                                                            Yes
                                                            <input type="radio" checked="checked"
                                                                name="cochlear_implant">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                        <label class="custom-radio-container">
                                                            No
                                                            <input type="radio" name="cochlear_implant">
                                                            <span class="radio-checkmark"></span>
                                                        </label>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="hp-video-consults-tabs-inner-container">
                                <div class="clinical-notes-status-flex clinical-notes-status-step3">
                                    <div class="drop-checkbox-wrap apcc-flex-checkbox mt-0">
                                        <div class="form-group">
                                            <input type="checkbox" id="private_checkbox">
                                            <label for="Fasting">Private</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="schedule_fee_checkbox">
                                            <label for="hormone_therapy">Schedule fee</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="bulk_bill_checkbox">
                                            <label for="non-fasting">Bulk-bill</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="Urgent_checkbox">
                                            <label for="Pregnant">Urgent</label>
                                        </div>
                                    </div>
                                    <div class="clinical-notes-status-radio-flex">
                                        <label class="clinical-notes-status-label">Hospital status</label>
                                        <div class="flex-row-radio">
                                            <label class="custom-radio-container">
                                                Non-hospital
                                                <input type="radio" checked="checked" name="hospital_status">
                                                <span class="radio-checkmark"></span>
                                            </label>
                                            <label class="custom-radio-container">
                                                Hospital
                                                <input type="radio" name="hospital_status">
                                                <span class="radio-checkmark"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="hp-video-consults-tabs-inner-container">
                                <div class="hp-video-consults-tab-toggle-btn">
                                    <h6 class="hp-video-inner-primary-heading">Requesting doctor's signature and request
                                        date</h6>
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg"
                                        alt="icon">
                                </div>
                                <div class="hp-video-consults-tab-toggle-content">
                                    <div class="doctor-signature-request-date-wrap">
                                        <div class="hp-video-consults-form-col-full">
                                            <label class="hp-video-consult-input-label">Date</label>

                                            <div class="datepicker-wrap">
                                                <input type="text" id="requesting-doctor-datepicker" class="date"
                                                    readonly="readonly" placeholder="9/02/2024">
                                                <svg width="12" height="8" viewBox="0 0 12 8" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M1 1.5L6 6.5L11 1.5" stroke="#667085"
                                                        stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                        <div class="doctor-signature-wrap">
                                            <div class="hp-video-consult-doctor-signature-input-wrap">
                                                <p>Doctor’s signature</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="hp-video-consults-tabs-inner-container">
                                <div
                                    class="hp-video-consults-form-col-half col-bottom-space-3xl copy-reports-textareas">
                                    <div class="hp-video-consults-form-col-half-innner">
                                        <label class="hp-video-consult-input-label">Copy reports</label>
                                        <textarea id="copy-repeort"></textarea>
                                    </div>
                                    <div class="hp-video-consults-form-col-half-innner">
                                        <label class="hp-video-consult-input-label">Requesting doctor</label>
                                        <textarea id="requesting-doctor"></textarea>
                                    </div>
                                </div>
                                <div class="drop-checkbox-wrap apcc-flex-checkbox col-bottom-space-3xl">
                                    <div class="form-group">
                                        <input type="checkbox" id="films-report-patient">
                                        <label for="films-report-patient">Films & report return with patient</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="send-report-medical-objects">
                                        <label for="send-report-medical-objects">Send report via Medical-Objects or
                                            Fax</label>
                                    </div>
                                </div>

                                <div class="video-requesting-medicare-account-dec-text-wrap">
                                    <p>The Medicare Benefits Schedule is managed by the Department of Health and Ageing
                                        and administered by Medicare Australia. Your rebate is the Australian
                                        government’s subsidy for your tests that are included in the Schedule.</p>
                                    <p>If any of your tests are not covered in the Schedule you will not receive a
                                        Medicare rebate.</p>
                                    <p>You are expected to pay for these tests in full.</p>
                                </div>
                            </div>
                            <div class="hp-video-consults-tabs-inner-container bring-to-appopintment-container">
                                <p>Ensure to bring to the appointment</p>
                                <ul class="bring-to-appointment-wrap">
                                    <li>Request form</li>
                                    <li><span class="list-dot"></span>Medicare card</li>
                                    <li><span class="list-dot"></span>Pension/Health Care/Vet Affairs Card (if
                                        applicable)</li>
                                </ul>
                            </div>
                            <div class="hp-video-consults-tabs-inner-container copy-patient-portal-checkbox-container">
                                <div class="drop-checkbox-wrap mt-0">
                                    <div class="form-group">
                                        <input type="checkbox" id="copy_patient_portal_checkbox">
                                        <label for="copy_patient_portal_checkbox">Send copy to patient’s portal</label>
                                    </div>
                                </div>
                                <div class="hp-video-consults-form pt-0">
                                    <div class="hp-video-consults-form-col-full">
                                        <label class="hp-video-consult-input-label">Please enter the email address of
                                            blood test company to whom you want to send this report</label>
                                        <input type="text" class="input-text-style">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="hp-video-consults-tabs-footer hp-video-consults-tabs-outer-container">
                <div class="tabs-footer-left-button">
                    <a href="#" class="outline-button">Skip</a>
                </div>
                <div class="tabs-footer-center-button">
                    <a class="outline-button changeTextButton" data-index="1" data-target="#video-consult-sec-3"
                        onclick="showSection('video-consult-sec-3', 'video-consult-sec-2') ; decreaseLength()">Previous</a>
                    <a class="primary-button changeTextButton" data-index="3" data-target="#video-consult-sec-4"
                        onclick="showSection('video-consult-sec-3', 'video-consult-sec-4') ; increaseLength()">Next<svg
                            width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M4.16667 10.2987H15.8333M15.8333 10.2987L10 4.46533M15.8333 10.2987L10 16.132"
                                stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
                        </svg></a>
                </div>
                <div class="tabs-footer-right-button">
                    <a href="#" class="outline-button">Preview</a>
                </div>
            </div>
        </div>

        <!--step4-->
        <div class="hp-video-consults-section-content video-consult-tab-sec" id="video-consult-sec-4"
            style="display: none;">
            <div class="hp-video-consults-section-content">
                <div class="hp-video-consults-tabs-outer-container">
                    <div class="hp-video-consults-tabs-inner-container video-consults-copy-flex-container">
                        <div class="hp-video-consults-copy-checkbox">
                            <h6 class="hp-video-inner-primary-heading">Send copy to patient's portal</h6>
                            <div class="drop-checkbox-wrap">
                                <form>
                                    <div class="form-group">
                                        <input type="checkbox" id="medcallz_account">
                                        <label for="medcallz_account">Medcallz account</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="email">
                                        <label for="email">Email</label>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="hp-video-consults-add-template">
                            <a href="#" class="outline-button video-consults-add-template-trigger"><svg width="20"
                                    height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M11.6667 1.89136V5.33348C11.6667 5.80018 11.6667 6.03354 11.7575 6.2118C11.8374 6.3686 11.9649 6.49609 12.1217 6.57598C12.2999 6.66681 12.5333 6.66681 13 6.66681H16.4421M13.3333 10.8334H6.66668M13.3333 14.1667H6.66668M8.33334 7.50008H6.66668M11.6667 1.66675H7.33334C5.93321 1.66675 5.23315 1.66675 4.69837 1.93923C4.22796 2.17892 3.84551 2.56137 3.60583 3.03177C3.33334 3.56655 3.33334 4.26662 3.33334 5.66675V14.3334C3.33334 15.7335 3.33334 16.4336 3.60583 16.9684C3.84551 17.4388 4.22796 17.8212 4.69837 18.0609C5.23315 18.3334 5.93321 18.3334 7.33334 18.3334H12.6667C14.0668 18.3334 14.7669 18.3334 15.3017 18.0609C15.7721 17.8212 16.1545 17.4388 16.3942 16.9684C16.6667 16.4336 16.6667 15.7335 16.6667 14.3334V6.66675L11.6667 1.66675Z"
                                        stroke="#344054" stroke-width="1.66667" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>Add template</a>
                        </div>
                    </div>
                </div>
                <div class="hp-video-consults-tabs-outer-container">
                    <div class="hp-video-consults-tabs-inner-container">
                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/editer.png" alt=""
                            class="dummy-img-editor">
                    </div>
                </div>
            </div>
            <div class="hp-video-consults-tabs-footer hp-video-consults-tabs-outer-container">
                <div class="tabs-footer-left-button">
                    <a href="#" class="outline-button">Skip</a>
                </div>
                <div class="tabs-footer-center-button">
                    <a class="outline-button changeTextButton" data-index="2" data-target="#video-consult-sec-4"
                        onclick="showSection('video-consult-sec-4', 'video-consult-sec-3') ; decreaseLength()">Previous</a>
                    <a class="primary-button changeTextButton" data-index="4" data-target="#video-consult-sec-5"
                        onclick="showSection('video-consult-sec-4', 'video-consult-sec-5') ; increaseLength()">Next<svg
                            width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M4.16667 10.2987H15.8333M15.8333 10.2987L10 4.46533M15.8333 10.2987L10 16.132"
                                stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
                        </svg></a>
                </div>
                <div class="tabs-footer-right-button">
                    <a href="#" class="outline-button">Preview</a>
                </div>
            </div>
        </div>

        <!--step5-->
        <div class="hp-video-consults-section-content video-consult-tab-sec" id="video-consult-sec-5"
            style="display: none;">
            <div class="hp-video-consults-section-content">
                <div class="hp-video-consults-tabs-outer-container">
                    <div class="hp-video-consults-tabs-inner-container video-consults-copy-flex-container">
                        <div class="hp-video-consults-copy-checkbox">
                            <h6 class="hp-video-inner-primary-heading">Send copy to patient's portal</h6>
                            <div class="drop-checkbox-wrap">
                                <form>
                                    <div class="form-group">
                                        <input type="checkbox" id="medcallz_account">
                                        <label for="medcallz_account">Medcallz account</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="email">
                                        <label for="email">Email</label>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="hp-video-consults-add-template">
                            <a href="#" class="outline-button video-consults-add-template-trigger"><svg width="20"
                                    height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M11.6667 1.89136V5.33348C11.6667 5.80018 11.6667 6.03354 11.7575 6.2118C11.8374 6.3686 11.9649 6.49609 12.1217 6.57598C12.2999 6.66681 12.5333 6.66681 13 6.66681H16.4421M13.3333 10.8334H6.66668M13.3333 14.1667H6.66668M8.33334 7.50008H6.66668M11.6667 1.66675H7.33334C5.93321 1.66675 5.23315 1.66675 4.69837 1.93923C4.22796 2.17892 3.84551 2.56137 3.60583 3.03177C3.33334 3.56655 3.33334 4.26662 3.33334 5.66675V14.3334C3.33334 15.7335 3.33334 16.4336 3.60583 16.9684C3.84551 17.4388 4.22796 17.8212 4.69837 18.0609C5.23315 18.3334 5.93321 18.3334 7.33334 18.3334H12.6667C14.0668 18.3334 14.7669 18.3334 15.3017 18.0609C15.7721 17.8212 16.1545 17.4388 16.3942 16.9684C16.6667 16.4336 16.6667 15.7335 16.6667 14.3334V6.66675L11.6667 1.66675Z"
                                        stroke="#344054" stroke-width="1.66667" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>Add template</a>
                        </div>
                    </div>
                    <div class="hp-video-consults-tabs-inner-container pathology-table-container">
                        <div class="hp-video-consults-tab-toggle-btn">
                            <h6 class="hp-video-inner-primary-heading">Send to Health Providers (in Medcallz)</h6>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg" alt="icon">
                        </div>
                        <div class="hp-video-consults-tab-toggle-content">
                            <div class="drop-checkbox-wrap">
                                <form>
                                    <div class="form-group">
                                        <input type="checkbox" id="send_to_hp">
                                        <label for="send_to_hp">Send to Health Providers (not in Medcallz)</label>
                                    </div>
                                </form>
                            </div>
                            <div class="pathology-search-bar-flex">
                                <button class="outline-button"><svg width="20" height="20" viewBox="0 0 20 20"
                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                            stroke="#344054" stroke-width="1.66667" stroke-linecap="round"
                                            stroke-linejoin="round"></path>
                                    </svg>Favourites</button>
                                <input type="text" placeholder="Search" class="input-text-color-900">
                            </div>
                            <div class="pathology-table-wrap">
                                <ul class="pathology-table-ul">
                                    <li class="pathology-table-head">
                                        <div class="pathology-table-country-td">
                                            <h6>Country/state</h6> <img
                                                src="<?php echo base_url(); ?>assets/images/virtual_consult/switch-vertical.svg"
                                                alt="switch icon">
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6>Speciality</h6> <img
                                                src="<?php echo base_url(); ?>assets/images/virtual_consult/switch-vertical.svg"
                                                alt="switch icon">
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6>Health provider</h6> <img
                                                src="<?php echo base_url(); ?>assets/images/virtual_consult/switch-vertical.svg"
                                                alt="switch icon">
                                        </div>
                                        <div class="pathology-table-select-td">

                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Service 2</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>HP 2</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round"></path>
                                                </svg></button>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Service 3</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>HP 3</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round"></path>
                                                </svg></button>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Service 4</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>HP 4</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round"></path>
                                                </svg></button>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Service 5</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>HP 5</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round"></path>
                                                </svg></button>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Service 6</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>HP 6</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round"></path>
                                                </svg></button>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Service 7</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>HP 7</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round"></path>
                                                </svg></button>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="pathology-table-country-td">
                                            <h6 class="pathology-table-responsive-heading">Country/state</h6>
                                            <p>Australia (WA)</p>
                                        </div>
                                        <div class="pathology-table-speciality-td">
                                            <h6 class="pathology-table-responsive-heading">Speciality</h6>
                                            <p>Service 8</p>
                                        </div>
                                        <div class="pathology-table-health-provider-td">
                                            <h6 class="pathology-table-responsive-heading">Health provider</h6>
                                            <p>HP 8</p>
                                        </div>
                                        <div class="pathology-table-select-td">
                                            <button class="pathology-select-btn">Select</button>
                                            <button class="pathology-star-btn"><svg width="20" height="20"
                                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.40253 2.8778C9.59461 2.48869 9.69064 2.29413 9.82102 2.23197C9.93445 2.17789 10.0662 2.17789 10.1797 2.23197C10.31 2.29413 10.4061 2.48869 10.5981 2.8778L12.4204 6.56944C12.4771 6.68432 12.5054 6.74176 12.5469 6.78635C12.5836 6.82584 12.6276 6.85783 12.6764 6.88056C12.7316 6.90623 12.795 6.91549 12.9218 6.93402L16.9978 7.5298C17.427 7.59253 17.6417 7.6239 17.741 7.72874C17.8274 7.81995 17.868 7.94529 17.8516 8.06985C17.8327 8.21302 17.6773 8.36436 17.3666 8.66702L14.4182 11.5387C14.3263 11.6282 14.2803 11.673 14.2507 11.7263C14.2244 11.7734 14.2076 11.8252 14.2011 11.8788C14.1937 11.9393 14.2046 12.0025 14.2263 12.129L14.922 16.1851C14.9953 16.6129 15.032 16.8269 14.9631 16.9538C14.9031 17.0642 14.7965 17.1417 14.6729 17.1646C14.5308 17.1909 14.3388 17.0899 13.9546 16.8879L10.3106 14.9716C10.1971 14.9119 10.1403 14.882 10.0805 14.8703C10.0276 14.8599 9.97311 14.8599 9.92015 14.8703C9.86034 14.882 9.80358 14.9119 9.69004 14.9716L6.0461 16.8879C5.66192 17.0899 5.46984 17.1909 5.3278 17.1646C5.20423 17.1417 5.09759 17.0642 5.03761 16.9538C4.96866 16.8269 5.00535 16.6129 5.07872 16.1851L5.7744 12.129C5.79609 12.0025 5.80693 11.9393 5.79959 11.8788C5.7931 11.8252 5.77625 11.7734 5.75 11.7263C5.72034 11.673 5.67439 11.6282 5.58248 11.5387L2.63413 8.66702C2.32338 8.36436 2.168 8.21302 2.1491 8.06985C2.13265 7.94529 2.17329 7.81995 2.2597 7.72874C2.35902 7.6239 2.57363 7.59253 3.00286 7.5298L7.07892 6.93402C7.20568 6.91549 7.26906 6.90623 7.32426 6.88056C7.37313 6.85783 7.41713 6.82584 7.45381 6.78635C7.49525 6.74176 7.5236 6.68432 7.5803 6.56944L9.40253 2.8778Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round"></path>
                                                </svg></button>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="hp-video-consults-tabs-inner-container">
                        <div class="hp-video-consults-tab-toggle-btn">
                            <h6 class="hp-video-inner-primary-heading">Send to Health Providers (not in Medcallz)</h6>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg" alt="icon">
                        </div>
                        <div class="hp-video-consults-tab-toggle-content">
                            <div class="drop-checkbox-wrap">
                                <form>
                                    <div class="form-group">
                                        <input type="checkbox" id="pathology_not_medcallz">
                                        <label for="pathology_not_medcallz">Send to Health Providers (not in
                                            Medcallz)</label>
                                    </div>
                                </form>
                            </div>
                            <div class="hp-video-consults-form">
                                <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                    <div class="hp-video-consults-form-col-half-innner">
                                        <label class="hp-video-consult-input-label">Name of Health Provider</label>
                                        <input type="text" class="input-text-style">
                                    </div>
                                    <div class="hp-video-consults-form-col-half-innner">
                                        <label class="hp-video-consult-input-label">Medical Practice/Clinic name</label>
                                        <input type="email" class="input-text-style">
                                    </div>
                                </div>
                                <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                                    <div class="hp-video-consults-form-col-half-innner">
                                        <label class="hp-video-consult-input-label">Address</label>
                                        <input type="text" class="input-text-style">
                                    </div>
                                    <div class="hp-video-consults-form-col-half-innner">
                                        <label class="hp-video-consult-input-label">Email</label>
                                        <input type="email" class="input-text-style">
                                    </div>
                                </div>
                                <div class="hp-video-consults-form-col-half">
                                    <div class="hp-video-consults-form-col-half-innner">
                                        <label class="hp-video-consult-input-label">Phone</label>
                                        <div class="phone-number-input">
                                            <input type="text" class="input-text-style"
                                                id="referral_letter_health_providers_mobile">
                                        </div>
                                    </div>
                                    <div class="hp-video-consults-form-col-half-innner">
                                        <label class="hp-video-consult-input-label">Fax</label>
                                        <input type="email" class="input-text-style">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="hp-video-consults-tabs-outer-container">
                    <div class="hp-video-consults-tabs-inner-container">
                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/editer.png" alt=""
                            class="dummy-img-editor">
                    </div>
                </div>
                <div class="hp-video-consults-tabs-footer hp-video-consults-tabs-outer-container">
                    <div class="tabs-footer-left-button">
                        <a href="#" class="outline-button">Skip</a>
                    </div>
                    <div class="tabs-footer-center-button">
                        <a class="outline-button changeTextButton" data-index="3" data-target="#video-consult-sec-5"
                            onclick="showSection('video-consult-sec-5', 'video-consult-sec-4') ; decreaseLength()">Previous</a>
                        <a class="primary-button changeTextButton" data-index="5" data-target="#video-consult-sec-6"
                            onclick="showSection('video-consult-sec-5', 'video-consult-sec-6') ; increaseLength()">Next<svg
                                width="20" height="21" viewBox="0 0 20 21" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M4.16667 10.2987H15.8333M15.8333 10.2987L10 4.46533M15.8333 10.2987L10 16.132"
                                    stroke="white" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg></a>
                    </div>
                    <div class="tabs-footer-right-button">
                        <a href="#" class="outline-button">Preview</a>
                    </div>
                </div>
            </div>
        </div>

        <!--step6-->
        <div class="hp-video-consults-section-content video-consult-tab-sec" id="video-consult-sec-6"
            style="display: none;">
            <div class="hp-video-consults-tabs-outer-container">
                <div class="hp-video-consults-tabs-inner-container">
                    <div class="view-medicine-prescribe-heading-flex col-bottom-space-3xl">
                        <h6 class="hp-video-inner-primary-heading pb-0">Step 1: Patient details</h6>
                        <a href="#" class="outline-button"><svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M9.99998 16.6667H17.5M2.5 16.6667H3.89545C4.3031 16.6667 4.50693 16.6667 4.69874 16.6206C4.8688 16.5798 5.03138 16.5125 5.1805 16.4211C5.34869 16.318 5.49282 16.1739 5.78107 15.8856L16.25 5.41669C16.9404 4.72634 16.9404 3.60705 16.25 2.91669C15.5597 2.22634 14.4404 2.22634 13.75 2.91669L3.28105 13.3856C2.9928 13.6739 2.84867 13.818 2.7456 13.9862C2.65422 14.1353 2.58688 14.2979 2.54605 14.468C2.5 14.6598 2.5 14.8636 2.5 15.2713V16.6667Z"
                                    stroke="#344054" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>Edit patient details</a>
                    </div>
                    <div class="patient-details-summary-wrp">
                        <div class="patient-details-summary-heading">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_3640_24821)">
                                    <path
                                        d="M3.33368 18.1812C3.83583 18.3333 4.51407 18.3333 5.66699 18.3333H14.3337C15.4866 18.3333 16.1648 18.3333 16.667 18.1812M3.33368 18.1812C3.22601 18.1486 3.12644 18.1089 3.03202 18.0608C2.56161 17.8212 2.17916 17.4387 1.93948 16.9683C1.66699 16.4335 1.66699 15.7335 1.66699 14.3333V5.66666C1.66699 4.26653 1.66699 3.56646 1.93948 3.03168C2.17916 2.56128 2.56161 2.17882 3.03202 1.93914C3.5668 1.66666 4.26686 1.66666 5.66699 1.66666H14.3337C15.7338 1.66666 16.4339 1.66666 16.9686 1.93914C17.439 2.17882 17.8215 2.56128 18.0612 3.03168C18.3337 3.56646 18.3337 4.26653 18.3337 5.66666V14.3333C18.3337 15.7335 18.3337 16.4335 18.0612 16.9683C17.8215 17.4387 17.439 17.8212 16.9686 18.0608C16.8742 18.1089 16.7746 18.1486 16.667 18.1812M3.33368 18.1812C3.33395 17.5067 3.338 17.1499 3.39771 16.8497C3.66073 15.5274 4.69439 14.4937 6.01669 14.2307C6.33869 14.1667 6.7259 14.1667 7.50033 14.1667H12.5003C13.2748 14.1667 13.662 14.1667 13.984 14.2307C15.3063 14.4937 16.3399 15.5274 16.6029 16.8497C16.6627 17.1499 16.6667 17.5067 16.667 18.1812M13.3337 7.91666C13.3337 9.75761 11.8413 11.25 10.0003 11.25C8.15938 11.25 6.66699 9.75761 6.66699 7.91666C6.66699 6.07571 8.15938 4.58332 10.0003 4.58332C11.8413 4.58332 13.3337 6.07571 13.3337 7.91666Z"
                                        stroke="#1B71B8" stroke-width="1.67" stroke-linecap="round"
                                        stroke-linejoin="round"></path>
                                </g>
                                <defs>
                                    <clipPath id="clip0_3640_24821">
                                        <rect width="20" height="20" fill="white"></rect>
                                    </clipPath>
                                </defs>
                            </svg>
                            <h5>Profile</h5>
                        </div>
                        <ul>
                            <li>
                                <label>First name</label>
                                <p>Allepatnow</p>
                            </li>
                            <li>
                                <label>Last name</label>
                                <p>Watsons</p>
                            </li>
                            <li>
                                <label>Marital status</label>
                                <p>Married (and not separated)</p>
                            </li>
                            <li>
                                <label>Gender</label>
                                <p>Female</p>
                            </li>
                            <li>
                                <label>Date of birth</label>
                                <p>06-02-1995</p>
                            </li>
                        </ul>
                    </div>
                    <div class="patient-details-summary-wrp">
                        <div class="patient-details-summary-heading">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_3640_24844)">
                                    <path
                                        d="M10.0003 13.3333V10M10.0003 6.66667H10.0087M18.3337 10C18.3337 14.6024 14.6027 18.3333 10.0003 18.3333C5.39795 18.3333 1.66699 14.6024 1.66699 10C1.66699 5.39763 5.39795 1.66667 10.0003 1.66667C14.6027 1.66667 18.3337 5.39763 18.3337 10Z"
                                        stroke="#1B71B8" stroke-width="1.67" stroke-linecap="round"
                                        stroke-linejoin="round"></path>
                                </g>
                                <defs>
                                    <clipPath id="clip0_3640_24844">
                                        <rect width="20" height="20" fill="white"></rect>
                                    </clipPath>
                                </defs>
                            </svg>
                            <h5>Contact</h5>
                        </div>
                        <ul>
                            <li>
                                <label>Email address</label>
                                <p>kfosdikeeg@dmoz.org</p>
                            </li>
                            <li>
                                <label>Street address</label>
                                <p>8875 Harvey Track, Apt. 221</p>
                            </li>
                            <li>
                                <label>State</label>
                                <p>Australia Capital Territory</p>
                            </li>
                            <li>
                                <label>Suburb</label>
                                <p>North Ashleyland</p>
                            </li>
                            <li>
                                <label>Postcode</label>
                                <p>1904</p>
                            </li>
                            <li>
                                <label>Mobile No. (Preferred)</label>
                                <p>+61 0415 781 721</p>
                            </li>
                            <li>
                                <label>Time zone</label>
                                <p>Australia/Perth</p>
                            </li>
                            <li>
                                <label>Country</label>
                                <p>Australia</p>
                            </li>
                        </ul>
                    </div>
                    <div class="patient-details-summary-wrp">
                        <div class="patient-details-summary-heading">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M10 6.66667V13.3333M6.66667 10H13.3333M6.5 17.5H13.5C14.9001 17.5 15.6002 17.5 16.135 17.2275C16.6054 16.9878 16.9878 16.6054 17.2275 16.135C17.5 15.6002 17.5 14.9001 17.5 13.5V6.5C17.5 5.09987 17.5 4.3998 17.2275 3.86502C16.9878 3.39462 16.6054 3.01217 16.135 2.77248C15.6002 2.5 14.9001 2.5 13.5 2.5H6.5C5.09987 2.5 4.3998 2.5 3.86502 2.77248C3.39462 3.01217 3.01217 3.39462 2.77248 3.86502C2.5 4.3998 2.5 5.09987 2.5 6.5V13.5C2.5 14.9001 2.5 15.6002 2.77248 16.135C3.01217 16.6054 3.39462 16.9878 3.86502 17.2275C4.3998 17.5 5.09987 17.5 6.5 17.5Z"
                                    stroke="#1B71B8" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round">
                                </path>
                            </svg>
                            <h5>Insurance</h5>
                        </div>
                        <ul>
                            <li>
                                <label>Medicare number</label>
                                <p>MN001</p>
                            </li>
                            <li>
                                <label>Medicare (Public Health) Individual Reference Number (IRN)</label>
                                <p>IRb3737</p>
                            </li>
                            <li>
                                <label>Medicare expire</label>
                                <p>27-05-2033</p>
                            </li>
                            <li>
                                <label>Private insurance company name</label>
                                <p>COmp</p>
                            </li>
                            <li>
                                <label>Private insurance number</label>
                                <p>PIN</p>
                            </li>
                            <li>
                                <label>Private insurance issue date</label>
                                <p>22-05-2040</p>
                            </li>

                            <li>
                                <label>Dva / Veteran number</label>
                                <p>Dv</p>
                            </li>
                            <li>
                                <label>DVA card colour</label>
                                <p>-</p>
                            </li>
                            <li>
                                <label>Pension number</label>
                                <p>PN01</p>
                            </li>
                        </ul>
                        <div class="ihi-patient-field-text">
                            <h4>Individual Healthcare Identifier (IHI)</h4>
                            <p>You must validate your patient’s IHI to e-prescribe</p>
                        </div>
                        <ul>
                            <li>
                                <label>IHI status</label>
                                <p class="ihi-active-status"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_8645_5161)">
                                            <path
                                                d="M5.00016 8.00001L7.00016 10L11.0002 6.00001M14.6668 8.00001C14.6668 11.6819 11.6821 14.6667 8.00016 14.6667C4.31826 14.6667 1.3335 11.6819 1.3335 8.00001C1.3335 4.31811 4.31826 1.33334 8.00016 1.33334C11.6821 1.33334 14.6668 4.31811 14.6668 8.00001Z"
                                                stroke="#079455" stroke-width="1.33333" stroke-linecap="round"
                                                stroke-linejoin="round"></path>
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_8645_5161">
                                                <rect width="16" height="16" fill="white"></rect>
                                            </clipPath>
                                        </defs>
                                    </svg>Lisinopril</p>
                            </li>
                            <li>
                                <label>IHI number</label>
                                <p>8123123123123456</p>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="hp-video-consults-tabs-inner-container">
                    <div class="view-medicine-prescribe-heading-flex col-bottom-space-3xl">
                        <div class="view-medicine-flex-heading">
                            <h6 class="hp-video-inner-primary-heading pb-0">Step 2: Select medication or create
                                customized medications for compounding</h6>
                            <a href="#">Reset script</a>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/mims-logo.png" alt="mims logo"
                            class="video-medication-mims-logo">
                        </div>
                        
                    </div>
                    <h6 class="hp-video-inner-primary-heading pb-0">Select Medication</h6>
                    <div class="add-drugs-wrap">
                        <label class="add-drug-heading">Add Drugs</label>
                        <input type="search" class="input-search-style" value="Algo">
                        <p>Only 1 PBS item is allowed per script for e-prescribing (paperless). Up to 3 PBS items are allowed per script for paper prescriptions, except for Authority PBS items (only 1 permissible per script).</p>
                        <ul class="search-drug-list">
                            <li>
                            Algoderm Sterile Rope Dressing
                            <button type="button" class="outline-button custom-preparation-modal-trigger">Select</button>
                            </li>
                            <li>
                            Algoderm Sterile Rope Dressing
                            <button type="button" class="outline-button custom-preparation-modal-trigger">Select</button>
                            </li>
                            <li>
                            Algoderm Sterile Rope Dressing
                            <button type="button" class="outline-button custom-preparation-modal-trigger">Select</button>
                            </li>
                            <li>
                            Algoderm Sterile Rope Dressing
                            <button type="button" class="outline-button custom-preparation-modal-trigger">Select</button>
                            </li>
                            <li>
                            Algoderm Sterile Single Sachet Dressing
                            <button type="button" class="outline-button custom-preparation-modal-trigger">Select</button>
                            </li>
                            <li>
                            Algoderm Sterile Single Sachet Dressing
                            <button type="button" class="outline-button custom-preparation-modal-trigger">Select</button>
                            </li>
                        </ul>
                    </div>
                    <div class="create-customized-medications-wrap">
                    <h6 class="hp-video-inner-primary-heading pb-0">Create customized medications for compounding</h6>
                    <button class="outline-button create-custom-prescription-modal-trigger"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9.99935 4.1665V15.8332M4.16602 9.99984H15.8327" stroke="#344054" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>Custom preparation items</button> 
                    </div>
                </div>
                <div class="hp-video-consults-tabs-inner-container">
                    <div class="view-medicine-prescribe-heading-flex col-bottom-space-3xl">   
                        <h6 class="hp-video-inner-primary-heading pb-0">Step 3: Summary of medications prescribed</h6>
                    </div>
                    <ul class="summary-medications-prescribed-table">
                        <!-- <th> -->
                        <li class="summary-medications-prescribed-table-head">
                            <div class="prescribed-table-drug-name-col">Drug name</div>
                            <div class="prescribed-table-drug-qty-col">QTY</div>
                            <div class="prescribed-table-rpts-col">RPTS</div>
                            <div class="prescribed-table-pbs-status-col">PBS Status</div>
                            <div class="prescribed-table-action-col"></div>
                        </li>
                        <!-- <tbody> -->
                        <li class="summary-medications-prescribed-table-body">
                            <div class="prescribed-table-drug-name-col">
                                <span class="summary-medications-prescribed-th-mobile">Drug name</span>
                                Atorvastatin<span class="prescribed-table-status-active">Active</span>
                            </div>
                            <div class="prescribed-table-drug-qty-col"><span class="summary-medications-prescribed-th-mobile">QTY</span>1</div>
                            <div class="prescribed-table-rpts-col"><span class="summary-medications-prescribed-th-mobile">RPTS</span>1</div>
                            <div class="prescribed-table-pbs-status-col"><span class="summary-medications-prescribed-th-mobile">PBS Status</span>Private</div>
                            <div class="prescribed-table-action-col">
                            <a href="javascript:void(0)" class="drug-details-scenario-1-trigger unfilled-button">Details</a>
                            <button class="unfilled-button tooltip delete-medications-prescribe-modal-trigger">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M13.3333 4.99984V4.33317C13.3333 3.39975 13.3333 2.93304 13.1517 2.57652C12.9919 2.26292 12.7369 2.00795 12.4233 1.84816C12.0668 1.6665 11.6001 1.6665 10.6667 1.6665H9.33333C8.39991 1.6665 7.9332 1.6665 7.57668 1.84816C7.26308 2.00795 7.00811 2.26292 6.84832 2.57652C6.66667 2.93304 6.66667 3.39975 6.66667 4.33317V4.99984M8.33333 9.58317V13.7498M11.6667 9.58317V13.7498M2.5 4.99984H17.5M15.8333 4.99984V14.3332C15.8333 15.7333 15.8333 16.4334 15.5608 16.9681C15.3212 17.4386 14.9387 17.821 14.4683 18.0607C13.9335 18.3332 13.2335 18.3332 11.8333 18.3332H8.16667C6.76654 18.3332 6.06647 18.3332 5.53169 18.0607C5.06129 17.821 4.67883 17.4386 4.43915 16.9681C4.16667 16.4334 4.16667 15.7333 4.16667 14.3332V4.99984" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <span class="tooltiptext">Delete</span>
                            </button>
                            </div>
                        </li>  
                        <li class="summary-medications-prescribed-table-body">
                            <div class="prescribed-table-drug-name-col">
                                <span class="summary-medications-prescribed-th-mobile">Drug name</span>
                                Metformin<span class="prescribed-table-status-active">Inctive</span>
                            </div>
                            <div class="prescribed-table-drug-qty-col"><span class="summary-medications-prescribed-th-mobile">QTY</span>2</div>
                            <div class="prescribed-table-rpts-col"><span class="summary-medications-prescribed-th-mobile">RPTS</span>2</div>
                            <div class="prescribed-table-pbs-status-col"><span class="summary-medications-prescribed-th-mobile">PBS Status</span>Private</div>
                            <div class="prescribed-table-action-col">
                            <a href="javascript:void(0)" class="drug-details-scenario-1-trigger unfilled-button">Details</a>
                            <button class="unfilled-button tooltip delete-medications-prescribe-modal-trigger">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M13.3333 4.99984V4.33317C13.3333 3.39975 13.3333 2.93304 13.1517 2.57652C12.9919 2.26292 12.7369 2.00795 12.4233 1.84816C12.0668 1.6665 11.6001 1.6665 10.6667 1.6665H9.33333C8.39991 1.6665 7.9332 1.6665 7.57668 1.84816C7.26308 2.00795 7.00811 2.26292 6.84832 2.57652C6.66667 2.93304 6.66667 3.39975 6.66667 4.33317V4.99984M8.33333 9.58317V13.7498M11.6667 9.58317V13.7498M2.5 4.99984H17.5M15.8333 4.99984V14.3332C15.8333 15.7333 15.8333 16.4334 15.5608 16.9681C15.3212 17.4386 14.9387 17.821 14.4683 18.0607C13.9335 18.3332 13.2335 18.3332 11.8333 18.3332H8.16667C6.76654 18.3332 6.06647 18.3332 5.53169 18.0607C5.06129 17.821 4.67883 17.4386 4.43915 16.9681C4.16667 16.4334 4.16667 15.7333 4.16667 14.3332V4.99984" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <span class="tooltiptext">Delete</span>
                            </button>
                            </div>
                        </li>  
                    </ul>
                </div>
                <div class="hp-video-consults-tabs-inner-container">
                    <div class="view-medicine-prescribe-heading-flex col-bottom-space-3xl">   
                        <h6 class="hp-video-inner-primary-heading pb-0">Step 4: Choose mode of delivery of medication scripts</h6>
                    </div>
                    <div class="delivery-medication-script-date-flex">
                        <p class="delivery-medication-script-date">Date 2024.06.17</p>
                        <div class="drop-checkbox-wrap">
                                <div class="form-group">
                                    <input type="checkbox" id="create_paper_script">
                                    <label for="create_paper_script">Create paper script</label>
                                </div>
                        </div>
                    </div>
                    <div class="flex-row-radio choose-delivery-scripts-radio">
                        <label class="custom-radio-container">
                            Print paper token only
                            <input type="radio" checked="checked" name="choose_medication_scripts">
                            <span class="radio-checkmark"></span>
                        </label>
                        <label class="custom-radio-container">
                            Send to patient mobile
                            <input type="radio" name="choose_medication_scripts" id="script-patient-mobile-radio">
                            <span class="radio-checkmark"></span>
                        </label>
                        <label class="custom-radio-container">
                        Send to patient email
                            <input type="radio" name="choose_medication_scripts" id="script-patient-email-radio">
                            <span class="radio-checkmark"></span>
                        </label>
                        <label class="custom-radio-container">
                        Send to pharmacy email
                            <input type="radio" name="choose_medication_scripts" id="script-select-pharmacy-radio">
                            <span class="radio-checkmark"></span>
                        </label>
                    </div>
                    <div class="medication-send-to-patient-mobile-wrap" id="script-patient-mobile">
                        <label class="choose-delivery-scripts-label">Patient mobile</label>
                        <input type="text" class="input-text-style" id="medication-scripts-patient-contact" >    
                    </div>
                    <div class="medication-send-to-patient-mobile-wrap" id="script-patient-email">
                        <label class="choose-delivery-scripts-label">Patient email</label>
                        <input type="email" class="input-text-style input-email-icon-field">    
                    </div>
                    <div class="medication-send-to-pharmacy-email-wrap" id="script-select-pharmacy">
                        <label class="choose-delivery-scripts-label">Selected Pharmacy</label>
                        <div class="medication-send-to-pharmacy-email-form-wrap">
                            <div class="medication-send-to-pharmacy-email-form-col">
                                <label>Country</label>
                                <input type="text" value="Australia" class="input-text-style" disabled>
                            </div>
                            <div class="medication-send-to-pharmacy-email-form-col">
                                <label>State</label>
                                <select class="input-text-style">
                                        <option>Western Australia</option>
                                        <option>Western Australia</option>
                                </select>
                            </div>
                        </div>
                        <div class="selected-pharmacy-tabs-wrap">
                            <ul class="selected-pharmacy-tabs-button-list">
                                <li class="active">
                                    <a href="#select-pharmacy-tab">Select pharmacy</a>
                                </li>
                                <li>
                                    <a href="#add-pharmacy-tab">Add pharmacy</a>
                                </li>
                            </ul>
                            <div class="selected-pharmacy-tabs-content">
                                <div id="select-pharmacy-tab" class="selected-pharmacy-tabs active">
                                <input type="search" class="input-search-style" value="Afs Pharmacies Rockhampton - Frenchville, Corner Dorn">
                                </div>
                                <div id="add-pharmacy-tab" class="selected-pharmacy-tabs">
                                    <div class="add-pharmacy-tab-form-wrap">
                                        <div class="add-pharmacy-tab-form-col">
                                            <label>
                                            Name of pharmacy
                                            </label>
                                            <input type="text" class="input-text-style">
                                        </div>
                                    </div>
                                    <div class="add-pharmacy-tab-form-wrap">
                                        <div class="add-pharmacy-tab-form-col">
                                            <label>
                                            Address
                                            </label>
                                            <input type="text" class="input-text-style">
                                        </div>
                                        <div class="add-pharmacy-tab-form-col">
                                            <label>
                                            State
                                            </label>
                                            <select class="input-text-style">
                                                <option>Western Australia</option>
                                                <option>Western Australia</option>
                                            </select>
                                        </div>
                                        <div class="add-pharmacy-tab-form-col">
                                            <label>
                                            Postcode
                                            </label>
                                            <input type="text" class="input-text-style">
                                        </div>
                                        <div class="add-pharmacy-tab-form-col">
                                            <label>
                                            Email
                                            </label>
                                            <input type="email" class="input-text-style">
                                        </div>
                                        <div class="add-pharmacy-tab-form-col">
                                            <label>
                                            Phone
                                            </label>
                                            <input type="text" class="input-text-style">
                                        </div>
                                        <div class="add-pharmacy-tab-form-col">
                                            <label>
                                            Fax
                                            </label>
                                            <input type="text" class="input-text-style">
                                        </div>
                                    </div>
                                    <div class="add-pharmacy-tab-form-submit">
                                    <button type="submit" class="primary-button">Add pharmacy</button>
                                    </div>
                                </div>
                            </div>
                        </div>   
                    </div>
                </div>
            </div>
            <div class="hp-video-consults-tabs-footer hp-video-consults-tabs-outer-container">
                <div class="tabs-footer-left-button">
                    <a href="#" class="outline-button">Skip</a>
                </div>
                <div class="tabs-footer-center-button">
                    <a class="outline-button changeTextButton" data-index="4" data-target="#video-consult-sec-6"
                        onclick="showSection('video-consult-sec-6', 'video-consult-sec-5') ; decreaseLength()">Previous</a>
                    <a class="primary-button changeTextButton" data-index="6" data-target="#video-consult-sec-7"
                        onclick="showSection('video-consult-sec-6', 'video-consult-sec-7') ; increaseLength()">Next<svg
                            width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M4.16667 10.2987H15.8333M15.8333 10.2987L10 4.46533M15.8333 10.2987L10 16.132"
                                stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
                        </svg></a>
                </div>
                <div class="tabs-footer-right-button">
                    <a href="#" class="outline-button">Preview</a>
                </div>
            </div>
        </div>

        <!--step7-->
        <div class="hp-video-consults-section-content video-consult-tab-sec" id="video-consult-sec-7"
            style="display: none;">
            <div class="hp-video-consults-tabs-outer-container">
                <div class="hp-video-consults-tabs-inner-container">
                    <h6 class="hp-video-inner-primary-heading col-bottom-space-3xl">Send files</h6>
                    <div class="hp-video-consult-send-file-upload">
                        <input id="video-consult-send-file-label" type="file">
                        <label for="video-consult-send-file-label">
                            <div class="video-consult-send-upload-btn">
                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/upload-cloud-icon.svg"
                                    alt="upload icon">
                                <h5><span>Click to upload</span> or drag and drop</h5>
                                <p>File should be less than 8 MB. Please upload only .gif, .png, .jpg, .jpeg files</p>
                            </div>
                        </label>
                    </div>
                    <div class="hp-video-consult-send-file-upload-results">
                        <ul>
                            <li>
                                <div class="video-consult-file-upload-results-wrap">
                                    <div class="video-consult-file-upload-results-icon">
                                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/pdf-icon.svg"
                                            alt="upload type icon">
                                    </div>
                                    <div class="video-consult-file-upload-results-text">
                                        <h6>Tech design requirements.pdf</h6>
                                        <p>200 KB</p>
                                        <div class="video-consult-file-upload-results-progress-bar">
                                            <progress value="100" max="100"></progress>
                                            <p>100%</p>
                                        </div>
                                        <button class="consult-file-upload-complete-btn"><svg width="12" height="12"
                                                viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M10 3L4.5 8.5L2 6" stroke="white" stroke-width="1.6666"
                                                    stroke-linecap="round" stroke-linejoin="round" />
                                            </svg></button>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="video-consult-file-upload-results-wrap">
                                    <div class="video-consult-file-upload-results-icon">
                                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/mp4-icon.svg"
                                            alt="upload type icon">
                                    </div>
                                    <div class="video-consult-file-upload-results-text">
                                        <h6>Dashboard recording.mp4</h6>
                                        <p>16 MB</p>
                                        <div class="video-consult-file-upload-results-progress-bar">
                                            <progress value="40" max="100"></progress>
                                            <p>40%</p>
                                        </div>
                                        <button class="consult-file-upload-delete-btn"><svg width="20" height="20"
                                                viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M13.3333 5.00008V4.33341C13.3333 3.39999 13.3333 2.93328 13.1517 2.57676C12.9919 2.26316 12.7369 2.00819 12.4233 1.8484C12.0668 1.66675 11.6001 1.66675 10.6667 1.66675H9.33333C8.39991 1.66675 7.9332 1.66675 7.57668 1.8484C7.26308 2.00819 7.00811 2.26316 6.84832 2.57676C6.66667 2.93328 6.66667 3.39999 6.66667 4.33341V5.00008M8.33333 9.58342V13.7501M11.6667 9.58342V13.7501M2.5 5.00008H17.5M15.8333 5.00008V14.3334C15.8333 15.7335 15.8333 16.4336 15.5608 16.9684C15.3212 17.4388 14.9387 17.8212 14.4683 18.0609C13.9335 18.3334 13.2335 18.3334 11.8333 18.3334H8.16667C6.76654 18.3334 6.06647 18.3334 5.53169 18.0609C5.06129 17.8212 4.67883 17.4388 4.43915 16.9684C4.16667 16.4336 4.16667 15.7335 4.16667 14.3334V5.00008"
                                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg></button>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="video-consult-file-upload-results-wrap">
                                    <div class="video-consult-file-upload-results-icon">
                                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/fig-icon.svg"
                                            alt="upload type icon">
                                    </div>
                                    <div class="video-consult-file-upload-results-text">
                                        <h6>Dashboard prototype FINAL.fig</h6>
                                        <p>4.2 MB</p>
                                        <div class="video-consult-file-upload-results-progress-bar">
                                            <progress value="80" max="100"></progress>
                                            <p>80%</p>
                                        </div>
                                        <button class="consult-file-upload-delete-btn"><svg width="20" height="20"
                                                viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M13.3333 5.00008V4.33341C13.3333 3.39999 13.3333 2.93328 13.1517 2.57676C12.9919 2.26316 12.7369 2.00819 12.4233 1.8484C12.0668 1.66675 11.6001 1.66675 10.6667 1.66675H9.33333C8.39991 1.66675 7.9332 1.66675 7.57668 1.8484C7.26308 2.00819 7.00811 2.26316 6.84832 2.57676C6.66667 2.93328 6.66667 3.39999 6.66667 4.33341V5.00008M8.33333 9.58342V13.7501M11.6667 9.58342V13.7501M2.5 5.00008H17.5M15.8333 5.00008V14.3334C15.8333 15.7335 15.8333 16.4336 15.5608 16.9684C15.3212 17.4388 14.9387 17.8212 14.4683 18.0609C13.9335 18.3334 13.2335 18.3334 11.8333 18.3334H8.16667C6.76654 18.3334 6.06647 18.3334 5.53169 18.0609C5.06129 17.8212 4.67883 17.4388 4.43915 16.9684C4.16667 16.4336 4.16667 15.7335 4.16667 14.3334V5.00008"
                                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg></button>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="hp-video-consults-tabs-footer hp-video-consults-tabs-outer-container">
                <div class="tabs-footer-left-button">
                    <a href="#" class="outline-button">Skip</a>
                </div>
                <div class="tabs-footer-center-button">
                    <a class="outline-button changeTextButton" data-index="5" data-target="#video-consult-sec-7"
                        onclick="showSection('video-consult-sec-7', 'video-consult-sec-6') ; decreaseLength()">Previous</a>
                    <a class="primary-button changeTextButton" data-index="7" data-target="#video-consult-sec-8"
                        onclick="showSection('video-consult-sec-7', 'video-consult-sec-8') ; increaseLength()">Next<svg
                            width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M4.16667 10.2987H15.8333M15.8333 10.2987L10 4.46533M15.8333 10.2987L10 16.132"
                                stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
                        </svg></a>
                </div>
                <div class="tabs-footer-right-button">
                    <a href="#" class="outline-button">Preview</a>
                </div>
            </div>
        </div>

        <!--step8-->
        <div class="hp-video-consults-section-content video-consult-tab-sec" id="video-consult-sec-8"
            style="display: none;">
            <div class="hp-video-consults-tabs-outer-container">
                <div class="hp-video-consults-tabs-inner-container-for-invoice">
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/billing-invoice-img.svg"
                        alt="invoice">
                    <p>Billing / Invoice summary</p>
                </div>
                <div class="hp-video-consults-tabs-inner-container">
                    <h6 class="hp-video-inner-primary-heading col-bottom-space-3xl">Patient details</h6>
                    <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                        <div class="hp-video-consults-form-col-half-innner">
                            <label class="hp-video-consult-input-label">First name</label>
                            <input type="text" class="input-text-style">
                        </div>
                        <div class="hp-video-consults-form-col-half-innner">
                            <label class="hp-video-consult-input-label">Last name</label>
                            <input type="text" class="input-text-style">
                        </div>
                    </div>
                    <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                        <div class="hp-video-consults-form-col-half-innner">
                            <label class="hp-video-consult-input-label">Address</label>
                            <input type="text" class="input-text-style">
                        </div>
                        <div class="hp-video-consults-form-col-half-innner">
                            <label class="hp-video-consult-input-label">Email</label>
                            <input type="email" class="input-text-style">
                        </div>
                    </div>
                    <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                        <div class="hp-video-consults-form-col-half-innner">
                            <label class="hp-video-consult-input-label">Date of birth</label>
                            <div class="datepicker-wrap">
                                <input type="text" id="video-consult-invoice-patient-datepicker" class="date"
                                    readonly="readonly" placeholder="9/02/2024">
                                <svg width="12" height="8" viewBox="0 0 12 8" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 1.5L6 6.5L11 1.5" stroke="#667085" stroke-width="1.66667"
                                        stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                        </div>
                        <div class="hp-video-consults-form-col-half-innner">
                            <label class="hp-video-consult-input-label">Residential address</label>
                            <input type="email" class="input-text-style">
                        </div>
                    </div>
                    <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                        <div class="hp-video-consults-form-col-half-innner">
                            <label class="hp-video-consult-input-label">Medicare number</label>
                            <input type="text" class="input-text-style">
                        </div>
                        <div class="hp-video-consults-form-col-half-innner">
                            <label class="hp-video-consult-input-label">Private insurance company</label>
                            <input type="email" class="input-text-style">
                        </div>
                    </div>
                    <div class="hp-video-consults-form-col-half-50">
                        <div class="hp-video-consults-form-col-half-innner">
                            <label class="hp-video-consult-input-label">Private insurance number</label>
                            <input type="text" class="input-text-style">
                        </div>
                    </div>
                </div>
                <div class="hp-video-consults-tabs-inner-container">
                    <h6 class="hp-video-inner-primary-heading col-bottom-space-3xl">Medical practitioner details</h6>
                    <div class="hp-video-consults-form-col-half col-bottom-space-xl">
                        <div class="hp-video-consults-form-col-half-innner">
                            <label class="hp-video-consult-input-label">Name of practitioner who rendered the
                                services</label>
                            <input type="text" class="input-text-style">
                        </div>
                        <div class="hp-video-consults-form-col-half-innner">
                            <label class="hp-video-consult-input-label">Provider No</label>
                            <input type="text" class="input-text-style">
                        </div>
                    </div>
                    <div class="hp-video-consults-form-col-half-50">
                        <div class="hp-video-consults-form-col-half-innner">
                            <label class="hp-video-consult-input-label">Date of service</label>
                            <div class="datepicker-wrap">
                                <input type="text" id="mp-date-of-service-datepicker" class="date" readonly="readonly"
                                    placeholder="9/02/2024">
                                <svg width="12" height="8" viewBox="0 0 12 8" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 1.5L6 6.5L11 1.5" stroke="#667085" stroke-width="1.66667"
                                        stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="hp-video-consults-tabs-outer-container">
                <div class="hp-video-consults-tabs-inner-container">
                    <h6 class="hp-video-inner-primary-heading col-bottom-space-3xl">Type of payment</h6>
                    <div class="flex-row-radio hp-invoice-payment-types-radio">
                        <label class="custom-radio-container">
                            Not applicable
                            <input type="radio" name="types_of_payment">
                            <span class="radio-checkmark"></span>
                        </label>
                        <label class="custom-radio-container">
                            Receipt and rebate
                            <input type="radio" checked="checked" name="types_of_payment">
                            <span class="radio-checkmark"></span>
                        </label>
                        <label class="custom-radio-container">
                            Coupon
                            <input type="radio" name="types_of_payment">
                            <span class="radio-checkmark"></span>
                        </label>
                        <label class="custom-radio-container">
                            Credit card
                            <input type="radio" name="types_of_payment">
                            <span class="radio-checkmark"></span>
                        </label>
                        <label class="custom-radio-container">
                            Bulk bill
                            <input type="radio" name="types_of_payment">
                            <span class="radio-checkmark"></span>
                        </label>
                    </div>
                </div>
                <div class="hp-video-consults-tabs-inner-container">
                    <h6 class="hp-video-inner-primary-heading col-bottom-space-3xl">Payment method</h6>
                    <div class="hp-video-consults-form-col-half-50 col-bottom-space-3xl">
                        <div class="hp-video-consults-form-col-half-innner">
                            <label class="hp-video-consult-input-label">Coupon code</label>
                            <input type="text" class="input-text-style" value="123456ASDSA" disabled>
                        </div>
                    </div>
                    <div class="checked-payment-method-list">
                        <ul class="payment-method-list nopadd list-style-none health-provider-selected-method-wrap">
                            <li class="step-border border-radius step-border">
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M0.5 8C0.5 3.85786 3.85786 0.5 8 0.5C12.1421 0.5 15.5 3.85786 15.5 8C15.5 12.1421 12.1421 15.5 8 15.5C3.85786 15.5 0.5 12.1421 0.5 8Z"
                                        fill="#F9FAFB"></path>
                                    <path
                                        d="M0.5 8C0.5 3.85786 3.85786 0.5 8 0.5C12.1421 0.5 15.5 3.85786 15.5 8C15.5 12.1421 12.1421 15.5 8 15.5C3.85786 15.5 0.5 12.1421 0.5 8Z"
                                        stroke="#D0D5DD"></path>
                                    <path
                                        d="M5 8C5 6.34315 6.34315 5 8 5C9.65685 5 11 6.34315 11 8C11 9.65685 9.65685 11 8 11C6.34315 11 5 9.65685 5 8Z"
                                        fill="#D0D5DD"></path>
                                </svg>
                                <label class="custom-radio-container payment-method-list-padd">
                                    <div class="payment-radio-flex">
                                        <div class="payment-icon"><img
                                                src="<?php echo base_url(); ?>assets/images/virtual_consult/wechat.svg"
                                                alt="payment-icon"></div>WeChat Pay
                                    </div>
                                </label>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="hp-video-consults-tabs-inner-container">
                    <h6 class="hp-video-inner-primary-heading col-bottom-space-3xl">Services</h6>
                    <div class="hp-video-consult-invoice-services-table">
                        <ul class="hp-video-consult-invoice-services-table-list">
                            <li class="hp-video-consult-invoice-services-table-head">
                                <div class="invoice-service-item-td">
                                    <h6>Item</h6>
                                </div>
                                <div class="invoice-service-description-td">
                                    <h6>Description</h6>
                                </div>
                                <div class="invoice-service-table-amount-td">
                                    <h6>Amount</h6>
                                </div>
                                <div class="invoice-service-table-action-td">
                                </div>
                            </li>
                            <li>
                                <div class="invoice-service-item-td">
                                    <label class="hp-video-consult-invoice-services-table-res-label">Item</label>
                                    <select class="input-text-style">
                                        <option>Select service</option>
                                        <option>Select service 1</option>
                                        <option>Select service 2</option>
                                        <option>Select service 3</option>
                                        <option>Select service 4</option>
                                    </select>
                                </div>
                                <div class="invoice-service-description-td">
                                    <label class="hp-video-consult-invoice-services-table-res-label">Description</label>
                                    <input type="text" class="input-text-style" />
                                </div>
                                <div class="invoice-service-table-amount-td">
                                    <label class="hp-video-consult-invoice-services-table-res-label">Amount</label>
                                    <div class="invoice-service-table-amount-input-wrap">
                                        <p><span>$</span> 1000.00</p>
                                        <select class="input-text-style">
                                            <option>USD</option>
                                            <option>USD</option>
                                            <option>USD</option>
                                            <select>
                                    </div>
                                </div>
                                <div class="invoice-service-table-action-td">
                                    <button class="invoice-service-table-delete-btn"><svg width="20" height="21"
                                            viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M13.3333 5.24056V4.57389C13.3333 3.64047 13.3333 3.17376 13.1517 2.81724C12.9919 2.50364 12.7369 2.24867 12.4233 2.08888C12.0668 1.90723 11.6001 1.90723 10.6667 1.90723H9.33333C8.39991 1.90723 7.9332 1.90723 7.57668 2.08888C7.26308 2.24867 7.00811 2.50364 6.84832 2.81724C6.66667 3.17376 6.66667 3.64047 6.66667 4.57389V5.24056M8.33333 9.82389V13.9906M11.6667 9.82389V13.9906M2.5 5.24056H17.5M15.8333 5.24056V14.5739C15.8333 15.974 15.8333 16.6741 15.5608 17.2089C15.3212 17.6793 14.9387 18.0617 14.4683 18.3014C13.9335 18.5739 13.2335 18.5739 11.8333 18.5739H8.16667C6.76654 18.5739 6.06647 18.5739 5.53169 18.3014C5.06129 18.0617 4.67883 17.6793 4.43915 17.2089C4.16667 16.6741 4.16667 15.974 4.16667 14.5739V5.24056"
                                                stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                        </svg><span>Delete</span></button>
                                </div>
                            </li>
                            <li>
                                <div class="invoice-service-item-td">
                                    <label class="hp-video-consult-invoice-services-table-res-label">Item</label>
                                    <select class="input-text-style">
                                        <option>Select service</option>
                                        <option>Select service 1</option>
                                        <option>Select service 2</option>
                                        <option>Select service 3</option>
                                        <option>Select service 4</option>
                                    </select>
                                </div>
                                <div class="invoice-service-description-td">
                                    <label class="hp-video-consult-invoice-services-table-res-label">Description</label>
                                    <input type="text" class="input-text-style" />
                                </div>
                                <div class="invoice-service-table-amount-td">
                                    <label class="hp-video-consult-invoice-services-table-res-label">Amount</label>
                                    <div class="invoice-service-table-amount-input-wrap">
                                        <p><span>$</span> 1000.00</p>
                                        <select class="input-text-style">
                                            <option>USD</option>
                                            <option>USD</option>
                                            <option>USD</option>
                                            <select>
                                    </div>
                                </div>
                                <div class="invoice-service-table-action-td">
                                    <button class="invoice-service-table-delete-btn"><svg width="20" height="21"
                                            viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M13.3333 5.24056V4.57389C13.3333 3.64047 13.3333 3.17376 13.1517 2.81724C12.9919 2.50364 12.7369 2.24867 12.4233 2.08888C12.0668 1.90723 11.6001 1.90723 10.6667 1.90723H9.33333C8.39991 1.90723 7.9332 1.90723 7.57668 2.08888C7.26308 2.24867 7.00811 2.50364 6.84832 2.81724C6.66667 3.17376 6.66667 3.64047 6.66667 4.57389V5.24056M8.33333 9.82389V13.9906M11.6667 9.82389V13.9906M2.5 5.24056H17.5M15.8333 5.24056V14.5739C15.8333 15.974 15.8333 16.6741 15.5608 17.2089C15.3212 17.6793 14.9387 18.0617 14.4683 18.3014C13.9335 18.5739 13.2335 18.5739 11.8333 18.5739H8.16667C6.76654 18.5739 6.06647 18.5739 5.53169 18.3014C5.06129 18.0617 4.67883 17.6793 4.43915 17.2089C4.16667 16.6741 4.16667 15.974 4.16667 14.5739V5.24056"
                                                stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                        </svg><span>Delete</span></button>
                                </div>
                            </li>
                        </ul>
                        <div class="invoice-service-table-append-row-wrap">
                            <button type="button" class="invoice-service-table-append-button-style"
                                id="invoice-service-table-append-btn">
                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path d="M9.99999 4.16666V15.8333M4.16666 9.99999H15.8333" stroke="#475467"
                                        stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                                Add row
                            </button>
                        </div>
                    </div>
                </div>
                <div class="hp-video-consults-tabs-inner-container">
                    <h6 class="hp-video-inner-primary-heading col-bottom-space-3xl">Summary</h6>
                    <div class="hp-video-summary-list-heading">
                        <p>Subtotal</p>
                        <p>$200</p>
                    </div>
                    <ul class="hp-video-summary-list nopadd list-style-none">
                        <li>
                            <p>Online video consultation ( Medical certificate, Carer certificate,
                                Imaging/Investigation, Pathology request, Referral request etc)</p>
                            <p>$100</p>
                        </li>
                        <li>
                            <p>Service 2</p>
                            <p>$100</p>
                        </li>
                        <li>
                            <p>Internet handling fee<br><span>(Non-refundable processing fees)</span>
                            </p>
                            <p>$10</p>
                        </li>
                    </ul>
                    <div class="hp-video-summary-list-total">
                        <p>Total amount</p>
                        <p>$210</p>
                    </div>
                </div>
            </div>
            <div
                class="hp-video-consults-tabs-footer hp-video-consults-tabs-footer-justify-center hp-video-consults-tabs-outer-container">
                <div class="tabs-footer-center-button">
                    <a class="outline-button changeTextButton" data-index="6" data-target="#video-consult-sec-7"
                        onclick="showSection('video-consult-sec-8', 'video-consult-sec-7') ; decreaseLength()">Previous</a>
                    <a class="primary-button">Complete consultation</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!--rename-template-name-modal-->
<div class="modal rename-template-name-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Rename template</h1>
                <span class="closecurrentpopup"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round"></path>
                    </svg>
                </span>
        </div>
        <div class="modal-body">
            <div class="rename-template-name-modal-wrap">
                <input type="text" class="input-text-style" placeholder="Current name of tempalte" />
            </div>
        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">
                <button type="button" class="primary-button">Save</button>
                <button type="button" class="closecurrentpopup unfilled-button">Close</button>
            </div>
        </div>

    </div>
</div>
<!--video-consults-add-template-modal-->
<div class="modal video-consults-add-template-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Load template</h1>
                <span class="closecurrentpopup"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round"></path>
                    </svg>
                </span>
        </div>
        <div class="modal-body">
            <div class="video-consults-add-template-modal-wrap">
                <div class="video-consults-add-template-search-wrap">
                    <div class="video-consults-add-template-text">
                        <p>All tempaltes <span>(15)</span></p>
                    </div>
                    <div class="video-consults-add-template-input">
                        <input type="text" class="input-serach-style" placeholder="Search">
                        <input id="video-consults-template-upload-file" type="file">
                        <label for="video-consults-template-upload-file"
                            class="video-consults-template-upload-file-btn">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M3.33341 13.5352C2.32843 12.8625 1.66675 11.7168 1.66675 10.4167C1.66675 8.46369 3.15967 6.85941 5.06653 6.68281C5.45659 4.31011 7.51695 2.5 10.0001 2.5C12.4832 2.5 14.5436 4.31011 14.9336 6.68281C16.8405 6.85941 18.3334 8.46369 18.3334 10.4167C18.3334 11.7168 17.6717 12.8625 16.6667 13.5352M6.66675 13.3333L10.0001 10M10.0001 10L13.3334 13.3333M10.0001 10V17.5"
                                    stroke="#344054" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>
                            Upload template
                        </label>
                    </div>
                </div>
                <ul class="video-consults-template-name-list">
                    <li class="video-consults-template-name-list-heading">
                        <p>Template name</p>
                    </li>
                    <li>
                        <p>Template name 1</p><button
                            class="video-consults-edit-template-btn rename-template-name-modal-trigger"><svg width="20"
                                height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M2.39662 15.0963C2.43491 14.7517 2.45405 14.5794 2.50618 14.4184C2.55243 14.2755 2.61778 14.1396 2.70045 14.0142C2.79363 13.8729 2.91621 13.7503 3.16136 13.5052L14.1666 2.49992C15.0871 1.57945 16.5795 1.57945 17.4999 2.49993C18.4204 3.4204 18.4204 4.91279 17.4999 5.83326L6.49469 16.8385C6.24954 17.0836 6.12696 17.2062 5.98566 17.2994C5.86029 17.3821 5.72433 17.4474 5.58146 17.4937C5.42042 17.5458 5.24813 17.5649 4.90356 17.6032L2.08325 17.9166L2.39662 15.0963Z"
                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg></button>
                    </li>
                    <li>
                        <p>Template name 2</p><button
                            class="video-consults-edit-template-btn rename-template-name-modal-trigger"><svg width="20"
                                height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M2.39662 15.0963C2.43491 14.7517 2.45405 14.5794 2.50618 14.4184C2.55243 14.2755 2.61778 14.1396 2.70045 14.0142C2.79363 13.8729 2.91621 13.7503 3.16136 13.5052L14.1666 2.49992C15.0871 1.57945 16.5795 1.57945 17.4999 2.49993C18.4204 3.4204 18.4204 4.91279 17.4999 5.83326L6.49469 16.8385C6.24954 17.0836 6.12696 17.2062 5.98566 17.2994C5.86029 17.3821 5.72433 17.4474 5.58146 17.4937C5.42042 17.5458 5.24813 17.5649 4.90356 17.6032L2.08325 17.9166L2.39662 15.0963Z"
                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg></button>
                    </li>
                    <li>
                        <p>Template name 3</p><button
                            class="video-consults-edit-template-btn rename-template-name-modal-trigger"><svg width="20"
                                height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M2.39662 15.0963C2.43491 14.7517 2.45405 14.5794 2.50618 14.4184C2.55243 14.2755 2.61778 14.1396 2.70045 14.0142C2.79363 13.8729 2.91621 13.7503 3.16136 13.5052L14.1666 2.49992C15.0871 1.57945 16.5795 1.57945 17.4999 2.49993C18.4204 3.4204 18.4204 4.91279 17.4999 5.83326L6.49469 16.8385C6.24954 17.0836 6.12696 17.2062 5.98566 17.2994C5.86029 17.3821 5.72433 17.4474 5.58146 17.4937C5.42042 17.5458 5.24813 17.5649 4.90356 17.6032L2.08325 17.9166L2.39662 15.0963Z"
                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg></button>
                    </li>
                    <li>
                        <p>Template name 4</p><button
                            class="video-consults-edit-template-btn rename-template-name-modal-trigger"><svg width="20"
                                height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M2.39662 15.0963C2.43491 14.7517 2.45405 14.5794 2.50618 14.4184C2.55243 14.2755 2.61778 14.1396 2.70045 14.0142C2.79363 13.8729 2.91621 13.7503 3.16136 13.5052L14.1666 2.49992C15.0871 1.57945 16.5795 1.57945 17.4999 2.49993C18.4204 3.4204 18.4204 4.91279 17.4999 5.83326L6.49469 16.8385C6.24954 17.0836 6.12696 17.2062 5.98566 17.2994C5.86029 17.3821 5.72433 17.4474 5.58146 17.4937C5.42042 17.5458 5.24813 17.5649 4.90356 17.6032L2.08325 17.9166L2.39662 15.0963Z"
                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg></button>
                    </li>
                    <li>
                        <p>Template name 5</p><button
                            class="video-consults-edit-template-btn rename-template-name-modal-trigger"><svg width="20"
                                height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M2.39662 15.0963C2.43491 14.7517 2.45405 14.5794 2.50618 14.4184C2.55243 14.2755 2.61778 14.1396 2.70045 14.0142C2.79363 13.8729 2.91621 13.7503 3.16136 13.5052L14.1666 2.49992C15.0871 1.57945 16.5795 1.57945 17.4999 2.49993C18.4204 3.4204 18.4204 4.91279 17.4999 5.83326L6.49469 16.8385C6.24954 17.0836 6.12696 17.2062 5.98566 17.2994C5.86029 17.3821 5.72433 17.4474 5.58146 17.4937C5.42042 17.5458 5.24813 17.5649 4.90356 17.6032L2.08325 17.9166L2.39662 15.0963Z"
                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg></button>
                    </li>
                    <li>
                        <p>Template name 6</p><button
                            class="video-consults-edit-template-btn rename-template-name-modal-trigger"><svg width="20"
                                height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M2.39662 15.0963C2.43491 14.7517 2.45405 14.5794 2.50618 14.4184C2.55243 14.2755 2.61778 14.1396 2.70045 14.0142C2.79363 13.8729 2.91621 13.7503 3.16136 13.5052L14.1666 2.49992C15.0871 1.57945 16.5795 1.57945 17.4999 2.49993C18.4204 3.4204 18.4204 4.91279 17.4999 5.83326L6.49469 16.8385C6.24954 17.0836 6.12696 17.2062 5.98566 17.2994C5.86029 17.3821 5.72433 17.4474 5.58146 17.4937C5.42042 17.5458 5.24813 17.5649 4.90356 17.6032L2.08325 17.9166L2.39662 15.0963Z"
                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg></button>
                    </li>
                    <li>
                        <p>Template name 7</p><button
                            class="video-consults-edit-template-btn rename-template-name-modal-trigger"><svg width="20"
                                height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M2.39662 15.0963C2.43491 14.7517 2.45405 14.5794 2.50618 14.4184C2.55243 14.2755 2.61778 14.1396 2.70045 14.0142C2.79363 13.8729 2.91621 13.7503 3.16136 13.5052L14.1666 2.49992C15.0871 1.57945 16.5795 1.57945 17.4999 2.49993C18.4204 3.4204 18.4204 4.91279 17.4999 5.83326L6.49469 16.8385C6.24954 17.0836 6.12696 17.2062 5.98566 17.2994C5.86029 17.3821 5.72433 17.4474 5.58146 17.4937C5.42042 17.5458 5.24813 17.5649 4.90356 17.6032L2.08325 17.9166L2.39662 15.0963Z"
                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg></button>
                    </li>
                    <li>
                        <p>Template name 8</p><button
                            class="video-consults-edit-template-btn rename-template-name-modal-trigger"><svg width="20"
                                height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M2.39662 15.0963C2.43491 14.7517 2.45405 14.5794 2.50618 14.4184C2.55243 14.2755 2.61778 14.1396 2.70045 14.0142C2.79363 13.8729 2.91621 13.7503 3.16136 13.5052L14.1666 2.49992C15.0871 1.57945 16.5795 1.57945 17.4999 2.49993C18.4204 3.4204 18.4204 4.91279 17.4999 5.83326L6.49469 16.8385C6.24954 17.0836 6.12696 17.2062 5.98566 17.2994C5.86029 17.3821 5.72433 17.4474 5.58146 17.4937C5.42042 17.5458 5.24813 17.5649 4.90356 17.6032L2.08325 17.9166L2.39662 15.0963Z"
                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg></button>
                    </li>
                    <li>
                        <p>Template name 9</p><button
                            class="video-consults-edit-template-btn rename-template-name-modal-trigger"><svg width="20"
                                height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M2.39662 15.0963C2.43491 14.7517 2.45405 14.5794 2.50618 14.4184C2.55243 14.2755 2.61778 14.1396 2.70045 14.0142C2.79363 13.8729 2.91621 13.7503 3.16136 13.5052L14.1666 2.49992C15.0871 1.57945 16.5795 1.57945 17.4999 2.49993C18.4204 3.4204 18.4204 4.91279 17.4999 5.83326L6.49469 16.8385C6.24954 17.0836 6.12696 17.2062 5.98566 17.2994C5.86029 17.3821 5.72433 17.4474 5.58146 17.4937C5.42042 17.5458 5.24813 17.5649 4.90356 17.6032L2.08325 17.9166L2.39662 15.0963Z"
                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg></button>
                    </li>
                    <li>
                        <p>Template name 10</p><button
                            class="video-consults-edit-template-btn rename-template-name-modal-trigger"><svg width="20"
                                height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M2.39662 15.0963C2.43491 14.7517 2.45405 14.5794 2.50618 14.4184C2.55243 14.2755 2.61778 14.1396 2.70045 14.0142C2.79363 13.8729 2.91621 13.7503 3.16136 13.5052L14.1666 2.49992C15.0871 1.57945 16.5795 1.57945 17.4999 2.49993C18.4204 3.4204 18.4204 4.91279 17.4999 5.83326L6.49469 16.8385C6.24954 17.0836 6.12696 17.2062 5.98566 17.2994C5.86029 17.3821 5.72433 17.4474 5.58146 17.4937C5.42042 17.5458 5.24813 17.5649 4.90356 17.6032L2.08325 17.9166L2.39662 15.0963Z"
                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg></button>
                    </li>
                </ul>
                <div class="video-consults-template-pagination">
                    <div class="pagination-row">
                        <div class="left-pagination">
                            <button type="button" class="pagination-button"><svg width="14" height="14"
                                    viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M12.8337 6.99996H1.16699M1.16699 6.99996L7.00033 12.8333M1.16699 6.99996L7.00033 1.16663"
                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                        stroke-linejoin="round"></path>
                                </svg>
                                Previous</button>
                        </div>
                        <div class="center-pagination">
                            <ul class="pagination-number">
                                <li>
                                    <button type="button" active="">1</button>
                                </li>
                                <li>
                                    <button type="button">2</button>
                                </li>
                                <li>
                                    <button type="button">3</button>
                                </li>
                                <li>
                                    <button type="button">...</button>
                                </li>
                                <li>
                                    <button type="button">8</button>
                                </li>
                                <li>
                                    <button type="button">9</button>
                                </li>
                                <li>
                                    <button type="button">10</button>
                                </li>
                            </ul>
                        </div>
                        <div class="right-pagination">
                            <button type="button" class="pagination-button">Next<svg width="14" height="14"
                                    viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M1.1665 6.99996H12.8332M12.8332 6.99996L6.99984 1.16663M12.8332 6.99996L6.99984 12.8333"
                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                        stroke-linejoin="round"></path>
                                </svg>

                            </button>
                        </div>
                    </div>
                    <div class="pagination-row-responsive">
                        <button type="button" class="pagination-button-responsive"><svg width="14" height="14"
                                viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M12.8337 6.99996H1.16699M1.16699 6.99996L7.00033 12.8333M1.16699 6.99996L7.00033 1.16663"
                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round"></path>
                            </svg>
                        </button>
                        <p>page <span>1</span> of <span>10</span></p>
                        <button type="button" class="pagination-button-responsive"><svg width="14" height="14"
                                viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M1.1665 6.99996H12.8332M12.8332 6.99996L6.99984 1.16663M12.8332 6.99996L6.99984 12.8333"
                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round"></path>
                            </svg>

                        </button>
                    </div>
                </div>

            </div>
        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">
                <button type="button" class="closecurrentpopup unfilled-button">Close</button>
            </div>
        </div>
    </div>
</div>

<!--hp-video-head-mobile-modal-->
<div class="modal hp-video-head-mobile-modal">
    <div class="modal-content">
        <div class="modal-body">
            <div class="hp-video-head-mobile-modal-wrap">
                <div class="hp-video-consult-doctor-wrap">
                    <div class="hp-video-consult-doctor-profile-img">
                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg02.png"
                            alt="doctor img">
                        <span class="available-dots"></span>
                    </div>
                    <div class="hp-video-consult-doctor-profile-content">
                        <h6>Olivia Rhye</h6>
                        <p>DOB: 01-10-2024</p>
                    </div>
                </div>
                <div class="hp-video-consult-tab-progress-inner">
                    <progress id="hp-video-consults-tab-progress" value="10" max="80"> </progress>
                    <p><span id="hp-video-consult-tab-progress-count">1</span>/8</p>
                </div>
                <ul class="hp-video-consult-tabs-drop-list" id="hp-video-tabs-list">
                    <li>
                        <a class="video-consult-tab active" onclick="showDiv('video-consult-sec-1')"
                            id="video-consult-tab-1">
                            <span>1</span>
                            Medical notes
                        </a>
                    </li>
                    <li>
                        <a class="video-consult-tab" onclick="showDiv('video-consult-sec-2')"
                            id="video-consult-tab-2-new">
                            <span>2</span>
                            Pathology request
                        </a>
                    </li>
                    <li>
                        <a class="video-consult-tab" onclick="showDiv('video-consult-sec-3')" id="video-consult-tab-3">
                            <span>3</span>
                            Imaging request
                        </a>
                    </li>
                    <li>
                        <a class="video-consult-tab" onclick="showDiv('video-consult-sec-4')" id="video-consult-tab-4">
                            <span>4</span>
                            Medical / care certification
                        </a>
                    </li>
                    <li>
                        <a class="video-consult-tab" onclick="showDiv('video-consult-sec-5')" id="video-consult-tab-5">
                            <span>5</span>
                            General / referral letter
                        </a>
                    </li>
                    <li>
                        <a class="video-consult-tab" onclick="showDiv('video-consult-sec-6')" id="video-consult-tab-6">
                            <span>6</span>
                            view / edit medications
                        </a>
                    </li>
                    <li>
                        <a class="video-consult-tab" onclick="showDiv('video-consult-sec-7')" id="video-consult-tab-7">
                            <span>7</span>
                            Send files
                        </a>
                    </li>
                    <li>
                        <a class="video-consult-tab" onclick="showDiv('video-consult-sec-8')" id="video-consult-tab-8">
                            <span>8</span>
                            Invoice
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">
                <button type="button" class="closecurrentpopup unfilled-button">Close</button>
            </div>
        </div>

    </div>
</div>

<!--Drug details: scenario 1-->
<div class="modal drug-details-scenario-1-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Paracetamol 1000mg per 100mL Infusion</h1>
                <span class="closecurrentpopup"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round"></path>
                    </svg>
                </span>
        </div>
        <div class="modal-body">
            <div class="drug-details-modal-wrap">
                <div class="drug-details-modal-inner-wrap">
                    <div class="drug-details-grid-two">
                        <div class="drug-details-grid-col">
                            <label>Product Name</label>
                            <p>Algoderm Sterile Single Sachet Dressing</p>
                        </div>
                        <div class="drug-details-grid-col">
                            <label>Indications</label>
                            <p>Unscheduled</p>
                        </div>
                        <div class="drug-details-grid-col">
                            <label>Molecules</label>
                            <a href="#">Read more</a>
                        </div>
                        <div class="drug-details-grid-col">
                            <label>ROAs</label>
                            <p>Topical/Cutaneous</p>
                        </div>
                        <div class="drug-details-grid-col">
                            <label>AU Poison Schedule</label>
                            <p>Unscheduled</p>
                        </div>
                    </div>
                    <p class="drug-detail-indication"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_13067_64758)">
                    <path d="M9.99935 13.3327V9.99935M9.99935 6.66602H10.0077M18.3327 9.99935C18.3327 14.6017 14.6017 18.3327 9.99935 18.3327C5.39698 18.3327 1.66602 14.6017 1.66602 9.99935C1.66602 5.39698 5.39698 1.66602 9.99935 1.66602C14.6017 1.66602 18.3327 5.39698 18.3327 9.99935Z" stroke="#1B71B8" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/>
                    </g>
                    <defs>
                    <clipPath id="clip0_13067_64758">
                    <rect width="20" height="20" fill="white"/>
                    </clipPath>
                    </defs>
                    </svg>* Prescription will display the brand name only</p>
                </div>
                <div class="drug-details-modal-inner-wrap">
                    <div class="drug-details-form-group">
                        <label class="drug-details-form-label">Drug pack detail</label>
                        <select class="input-text-style">
                            <option>Drug pack detail 1</option>
                            <option>Drug pack detail 2</option>
                        </select>
                    </div>
                    <div class="drug-details-form-group drug-details-two-grid-form">
                        <div class="drug-details-two-grid-col">
                            <label class="drug-details-form-label">Quantity, (PBS Max: NA)</label>
                            <input type="text" class="input-text-style" value="1">
                        </div>
                        <div class="drug-details-two-grid-col">
                            <label class="drug-details-form-label">Repeats, (PBS Max: NA)</label>
                            <input type="text" class="input-text-style" value="0">
                        </div>
                    </div>
                    <div class="drug-details-form-group">
                        <div class="drug-details-form-radio">
                            <label class="custom-radio-container">
                                Private
                                <input type="radio" checked="checked" name="drug_detial_option">
                                <span class="radio-checkmark"></span>
                            </label>
                            <label class="custom-radio-container">
                                Section 100
                                <input type="radio" name="drug_detial_option">
                                <span class="radio-checkmark"></span>
                            </label>                          
                        </div>
                    </div>
                    <div class="generate-script-no-wrap">
                        <button  type="button" class="outline-button-primary">Generate Script No.</button>
                        <div class="generate-script-no-outer">
                            <span>No̱ 00780118</span>
                        </div>
                        <a href="#">Provide an existing script number</a>
                    </div>
                </div>
                <div class="drug-details-modal-inner-wrap">
                    <div class="drug-details-form-group">
                        <label class="drug-details-form-label">PBS Authority:</label>
                        <input type="text" class="input-text-style">
                    </div>
                    <p class="authority-helpline-text pb-xl">RPBS Authority Hotline:<a href="tel:+1800552580">1800 552 580</a></p>
                    <p class="authority-helpline-text">PBS Authority Hotline:<a href="tel:+1800888333">1800 888 333</a></p>
                    <div class="custome-checkbox-container pbs-authority-checkbox-flex">
                        <label for="unusual_dose">
                            Unusual dose
                            <input type="checkbox" id="unusual_dose" name="unusual_dose">
                            <span class="checkmark"></span>
                        </label>
                        <label for="emergency_supply">
                            <input type="checkbox" id="emergency_supply" name="emergency_supply">
                            Emergency supply
                            <span class="checkmark"></span>
                            </label>
                        <label for="regulation_49">
                            <input type="checkbox" id="regulation_49" name="regulation_49">
                            Regulation 49 (previously regulation 24)
                            <span class="checkmark"></span>
                            </label>
                        <label for="no_send_script">
                            <input type="checkbox" id="no_send_script" name="no_send_script">
                            DO NOT send to Active script list
                            <span class="checkmark"></span>
                        </label>
                        <label for="brand_substitution">
                            <input type="checkbox" id="brand_substitution" name="brand_substitution">
                            Brand substitution not permitted
                            <span class="checkmark"></span>
                        </label>
                    </div>
                </div>
                <div class="drug-details-modal-inner-wrap">
                    <div class="drug-details-form-group drug-details-two-grid-form">
                        <div class="drug-details-two-grid-col">
                            <label class="drug-details-form-label">Treatment use</label>
                            <select class="input-text-style">
                                <option></option>
                                <option></option>
                            </select>
                        </div>
                        <div class="drug-details-two-grid-col">
                            <label class="drug-details-form-label">Send to pharmacy</label>
                            <select class="input-text-style">
                                <option></option>
                                <option></option>
                            </select>
                        </div>
                    </div>
                    <div class="drug-details-form-group">
                        <label class="drug-details-form-label">Directions (max 250 character)</label>
                        <input type="text" class="input-text-style">
                    </div>
                    <div class="drug-details-form-group">
                        <label class="drug-details-form-label">Reason for Prescribing (optional, max 50 characters)</label>
                        <input type="text" class="input-text-style">
                    </div>
                    <div class="drug-details-form-group">
                        <label class="drug-details-form-label">Notes (optional, max 50 characters)</label>
                        <input type="text" class="input-text-style">
                    </div>
                    <div class="drug-details-form-group mb-0">
                        <label class="drug-details-form-label">CTG Annotation (optional)</label>
                        <input type="text" class="input-text-style">
                    </div>
                </div>    
            </div>
        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">
                <button type="button" class="closecurrentpopup unfilled-button">Close</button>
                <button type="button" class="primary-button">Save</button>
            </div>
        </div>
    </div>
</div>

<!--Drug details: scenario 2-->
<div class="modal drug-details-scenario-2-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Dolutegraravir 50 mg - Abacavir 600 mg</h1>
                <span class="closecurrentpopup"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round"></path>
                    </svg>
                </span>
        </div>
        <div class="modal-body">
            <div class="drug-details-modal-wrap">
                <div class="drug-details-modal-inner-wrap">
                    <div class="drug-details-grid-two">
                        <div class="drug-details-grid-col">
                            <label>Product Name</label>
                            <p>Dolutegravir 50 mg - Abacavir 600 mg</p>
                            <p>Lamivudine 300 mg Coated Tablet</p>
                        </div>
                        <div class="drug-details-grid-col">
                            <label>ROAs</label>
                            <p>Oral</p>
                        </div>
                        <div class="drug-details-grid-col">
                            <label>Molecules</label>
                            <p>Dolutegravir 50 mg, Abacavir 600 mg, Lamivudine 300 mg</p>
                            <a href="#" class="mt-xs">Read more</a>
                        </div>
                        <div class="drug-details-grid-col">
                            <label>AU Poison Schedule</label>
                            <p>S4</p>
                        </div>
                    </div>
                </div>           
                <div class="drug-details-modal-inner-wrap">
                    <div class="drug-details-grid-two">
                        <div class="drug-details-grid-col">
                            <label>PBS Code</label>
                            <p>10345L</p>
                        </div>
                        <div class="drug-details-grid-col">
                            <label>PBS type</label>
                            <p>Section 100</p>
                        </div>
                        <div class="drug-details-grid-col">
                            <label>PBS Program</label>
                            <p>Community Access</p>
                        </div>
                        <div class="drug-details-grid-col">
                            <label>Max Quantity</label>
                            <p>60</p>
                        </div>   
                        <div class="drug-details-grid-col">
                            <label>Max Repeats</label>
                            <p>60</p>
                        </div>                    
                    </div>
                    <div class="drug-details-select-wrap">
                        <ul class="drug-details-select-list">
                            <li>
                                <div class="drug-details-select-list-head">
                                    <div class="drug-details-select-list-head-left">
                                        <p>Streamline code:<span>10116</span></p>
                                        <p>Restriction type:<span>Streamlined authority</span></p>
                                    </div>  
                                    <div class="drug-details-select-list-head-right">
                                        <button class="primary-button">Select</button>
                                    </div>  
                                </div>
                                <div class="drug-details-select-list-body">                                   
                                    <div class="drug-details-select-list-body-list">
                                        <p>10116 HIV infection Treatment Phase</p>
                                        <span>Continuing treatment</span>
                                    </div>  
                                    <div class="drug-details-select-list-body-list">
                                        <p>Clinical criteria</p>
                                        <span>Patient must have previously received PBS-subsidised therapy for HIV infection.</span>
                                    </div> 
                                </div>
                            </li>
                            <li>
                                <div class="drug-details-select-list-head">
                                    <div class="drug-details-select-list-head-left">
                                        <p>Streamline code:<span>10116</span></p>
                                        <p>Restriction type:<span>Streamlined authority</span></p>
                                    </div>  
                                    <div class="drug-details-select-list-head-right">
                                        <button class="primary-button">Select</button>
                                    </div>  
                                </div>
                                <div class="drug-details-select-list-body">                                   
                                    <div class="drug-details-select-list-body-list">
                                        <p>10116 HIV infection Treatment Phase</p>
                                        <span>Continuing treatment</span>
                                    </div>  
                                    <div class="drug-details-select-list-body-list">
                                        <p>Clinical criteria</p>
                                        <span>Patient must have previously received PBS-subsidised therapy for HIV infection.</span>
                                    </div> 
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>                    
            </div>
        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">
                <button type="button" class="closecurrentpopup unfilled-button">Close</button>
            </div>
        </div>
    </div>
</div>

<!--alert modal-->
<div class="modal delete-medications-prescribe-modal alert-modal-style">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Confirmation</h5>
            <span class="closecurrentpopup">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns=" http://www.w3.org/2000/svg ">
                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
            </span>
        </div>
        <div class="modal-body">
            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/alert-icon.svg" alt="alert icon">
            <p>Are you sure you want to delete?</p>
        </div>  
        <div class="modal-footer">
            <div class="flex-modal-button">  
                <button type="button" class="dangerstyle primary-button">Delete</button>             
                <button type="button" class="closecurrentpopup unfilled-button">Close</button>
            </div>
        </div>      
    </div>
</div>

<!--Custom prescription items modal-->
<div class="modal custom-prescription-items-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Custom prescription items</h5>
            <span class="closecurrentpopup">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns=" http://www.w3.org/2000/svg ">
                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
            </span>
        </div>
        <div class="modal-body">
            <div class="custom-prescription-items-modal-wrap">
                <input type="search" class="input-search-style" placeholder="Search">
                <ul class="custom-prescription-items-table">
                    <!-- <th> -->
                    <li class="custom-prescription-items-table-th">
                        <div class="custom-prescription-drug-details-col">Drug details</div>
                        <div class="custom-prescription-drug-quantity-col">Quantity</div>
                        <div class="custom-prescription-drug-repeats-col">Repeats</div>
                        <div class="custom-prescription-drug-action-col"></div>
                    </li>
                    <li class="custom-prescription-items-table-tbody">
                        <div class="custom-prescription-drug-details-col">
                        <div class="custome-checkbox-container">
                            <span class="custom-prescription-items-table-th-responsive">Drug details</span>
                            <label for="drug_1">
                                SALICYLIC ACID 8% CETRIMIDE 1% IN SVI
                                <span>mg 1 tablet</span>
                                <input type="checkbox" id="drug_1" name="drug_1">
                                <span class="checkmark"></span>
                            </label>
                        </div>
                        </div>
                        <div class="custom-prescription-drug-quantity-col">
                        <span class="custom-prescription-items-table-th-responsive">Quantity</span>
                            <p>1</p>
                        </div>
                        <div class="custom-prescription-drug-repeats-col">
                        <span class="custom-prescription-items-table-th-responsive">Repeats</span>
                            <p>1</p>
                        </div>
                        <div class="custom-prescription-drug-action-col">
                            <button type="button" class="unfilled-button tooltip update-prescription-modal-trigger">
                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/table-edit-icon.svg" alt="edit-icon">
                                <span class="tooltiptext">Edit</span>
                                <span class="custom-prescription-drug-table-responsive-btn-text">Edit</span>
                            </button>
                            <button type="button" class="unfilled-button tooltip">
                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/table-delete-icon.svg" alt="edit-icon">
                                <span class="tooltiptext">Delete</span>
                                <span class="custom-prescription-drug-table-responsive-btn-text">Delete</span>
                            </button>
                        </div>
                    </li>
                    <li class="custom-prescription-items-table-tbody">
                        <div class="custom-prescription-drug-details-col">
                        <div class="custome-checkbox-container">
                            <span class="custom-prescription-items-table-th-responsive">Drug details</span>
                            <label for="drug_1">
                                SALICYLIC ACID 8% CETRIMIDE 1% IN SVI
                                <span>mg 1 tablet</span>
                                <input type="checkbox" id="drug_1" name="drug_1">
                                <span class="checkmark"></span>
                            </label>
                        </div>
                        </div>
                        <div class="custom-prescription-drug-quantity-col">
                        <span class="custom-prescription-items-table-th-responsive">Quantity</span>
                            <p>1</p>
                        </div>
                        <div class="custom-prescription-drug-repeats-col">
                        <span class="custom-prescription-items-table-th-responsive">Repeats</span>
                            <p>1</p>
                        </div>
                        <div class="custom-prescription-drug-action-col">
                            <button type="button" class="unfilled-button tooltip update-prescription-modal-trigger">
                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/table-edit-icon.svg" alt="edit-icon">
                                <span class="tooltiptext">Edit</span>
                                <span class="custom-prescription-drug-table-responsive-btn-text">Edit</span>
                            </button>
                            <button type="button" class="unfilled-button tooltip">
                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/table-delete-icon.svg" alt="edit-icon">
                                <span class="tooltiptext">Delete</span>
                                <span class="custom-prescription-drug-table-responsive-btn-text">Delete</span>
                            </button>
                        </div>
                    </li>
                </ul>
                <div class="pagination-row">
                        <div class="left-pagination">
                            <button type="button" class="pagination-button"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M12.8337 6.99996H1.16699M1.16699 6.99996L7.00033 12.8333M1.16699 6.99996L7.00033 1.16663" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                                Previous</button>
                        </div>
                        <div class="center-pagination">
                            <ul class="pagination-number">
                                <li>
                                    <button type="button" class="active">1</button>
                                </li>
                               
                            </ul>
                        </div>
                        <div class="right-pagination">
                            <button type="button" class="pagination-button">Next<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1.1665 6.99996H12.8332M12.8332 6.99996L6.99984 1.16663M12.8332 6.99996L6.99984 12.8333" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>

                            </button>
                        </div>
                    </div>
                    <div class="pagination-row-responsive">
                        <button type="button" class="pagination-button-responsive"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M12.8337 6.99996H1.16699M1.16699 6.99996L7.00033 12.8333M1.16699 6.99996L7.00033 1.16663" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </button>
                        <p>page <span>1</span> of <span>10</span></p>
                        <button type="button" class="pagination-button-responsive"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1.1665 6.99996H12.8332M12.8332 6.99996L6.99984 1.16663M12.8332 6.99996L6.99984 12.8333" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>

                        </button>
                    </div>
            </div>
        </div>  
        <div class="modal-footer">
            <div class="flex-modal-button">  
                <button type="button" class="primary-button">Create</button>             
                <button type="button" class="disabled-button">Select</button>
            </div>
        </div>      
    </div>
</div>
<!--Create custom prescription modal-->
<div class="modal create-custom-prescription-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Create custom prescription item</h5>
            <span class="closecurrentpopup">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns=" http://www.w3.org/2000/svg ">
                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
            </span>
        </div>
        <div class="modal-body">
            <div class="drug-details-form-group">
                <label class="drug-details-form-label">Compound name</label>
                <input type="text" class="input-text-style">
            </div>
            <div class="drug-details-form-group drug-details-two-grid-form">
                <div class="drug-details-two-grid-col">
                    <label class="drug-details-form-label">Dosage form</label>
                    <input type="text" class="input-text-style">
                </div>
                <div class="drug-details-two-grid-col">
                    <label class="drug-details-form-label">Item strenght</label>
                    <input type="text" class="input-text-style">
                </div>
            </div>
            <div class="drug-details-form-group drug-details-two-grid-form">
                <div class="drug-details-two-grid-col">
                    <label class="drug-details-form-label">Route of administration</label>
                    <input type="text" class="input-text-style">
                </div>
                <div class="drug-details-two-grid-col">
                    <label class="drug-details-form-label">Quantity</label>
                    <input type="text" class="input-text-style">
                </div>
            </div>
            <div class="drug-details-form-group drug-details-two-grid-form">
                <div class="drug-details-two-grid-col">
                    <label class="drug-details-form-label">Repeats</label>
                    <input type="text" class="input-text-style">
                </div>
                <div class="drug-details-two-grid-col">
                    <label class="drug-details-form-label">PBS code</label>
                    <input type="text" class="input-text-style">
                </div>
            </div>
        </div>  
        <div class="modal-footer">
            <div class="flex-modal-button">  
                <button type="button" class="unfilled-button closecurrentpopup">Cancel</button>             
                <button type="button" class="primary-button">Create</button>
            </div>
        </div>      
    </div>
</div>
<!--update custom prescription modal-->
<div class="modal update-custom-prescription-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Update custom prescription item</h5>
            <span class="closecurrentpopup">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns=" http://www.w3.org/2000/svg ">
                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
            </span>
        </div>
        <div class="modal-body">
            <div class="drug-details-form-group">
                <label class="drug-details-form-label">Compound name</label>
                <input type="text" class="input-text-style" value="Salicylic acid 8% Cetrimide 1% in SVI">
            </div>
            <div class="drug-details-form-group drug-details-two-grid-form">
                <div class="drug-details-two-grid-col">
                    <label class="drug-details-form-label">Dosage form</label>
                    <input type="text" class="input-text-style" value="1 tablet">
                </div>
                <div class="drug-details-two-grid-col">
                    <label class="drug-details-form-label">Item strenght</label>
                    <input type="text" class="input-text-style" value="mg">
                </div>
            </div>
            <div class="drug-details-form-group drug-details-two-grid-form">
                <div class="drug-details-two-grid-col">
                    <label class="drug-details-form-label">Route of administration</label>
                    <input type="text" class="input-text-style" value="Topical">
                </div>
                <div class="drug-details-two-grid-col">
                    <label class="drug-details-form-label">Quantity</label>
                    <input type="text" class="input-text-style" value="1">
                </div>
            </div>
            <div class="drug-details-form-group drug-details-two-grid-form">
                <div class="drug-details-two-grid-col">
                    <label class="drug-details-form-label">Repeats</label>
                    <input type="text" class="input-text-style" value="1">
                </div>
                <div class="drug-details-two-grid-col">
                    <label class="drug-details-form-label">PBS code</label>
                    <input type="text" class="input-text-style">
                </div>
            </div>
        </div>  
        <div class="modal-footer">
            <div class="flex-modal-button">  
                <button type="button" class="unfilled-button closecurrentpopup">Cancel</button>             
                <button type="button" class="primary-button">Update</button>
            </div>
        </div>      
    </div>
</div>
<?php $this->load->view('inc/virtual_consult/footer');?>


<script>
    $(document).ready(function() {
        var filter_cntry_class = true;
        $(".filter_cntry").click(function() {
            $(this).toggleClass('filter_cntry_active');
            filter_cntry_class = false;
        });
        $("html").click(function() {
            if (filter_cntry_class) {
                $(".filter_cntry").removeClass('filter_cntry_active');
            }
            filter_cntry_class = true;
        });
    });
</script>
<script>
    function showSection(hideSectionId, showSectionId) {
        $(".video-consult-tab-sec").removeClass("show-particuler-id");
        $(".video-consult-tab-sec").removeClass("hidden");
        $(".video-consult-tab-sec").hide();
        console.log(hideSectionId, '--', showSectionId);
        document.getElementById(hideSectionId).style.display = 'none';
        document.getElementById(showSectionId).style.display = 'block';
    }
</script>
<script>
    $(document).ready(function() {
        $('#hp-video-tabs-list li a').on('click', function(event) {
            event.preventDefault();
            $('#hp-video-tabs-list li a.active').removeClass('active');
            $(this).addClass('active');
        });
    });
</script>

<script>
    $(document).ready(function() {
        var tabclickbtn1 = true;
        var progressbarid = document.getElementById('hp-video-consults-tab-progress');
        var tabclickbtn = document.getElementById('video-consult-tab-1');
        var notecount = document.getElementById('hp-video-consult-medical-note-count');
        var notetext = document.getElementById('hp-video-consult-medical-note-text');
        var progresscount = document.getElementById('hp-video-consult-tab-progress-count');
        tabclickbtn.addEventListener("click", function() {
            progressbarid.max = 80;
            progressbarid.value = 10;
            progresscount.innerHTML = 1;
            notecount.innerHTML = "1";
            notetext.innerHTML = "Medical notes";
        });
        var tabclickbtn1 = false;
    });
    $(document).ready(function() {
        var tabclickbtn2 = true;
        var progressbarid = document.getElementById('hp-video-consults-tab-progress');
        var allsec = document.getElementsByClassName('video-consult-tab-sec');
        var tabclickbtn = document.getElementById('video-consult-tab-2');
        var notecount = document.getElementById('hp-video-consult-medical-note-count');
        var notetext = document.getElementById('hp-video-consult-medical-note-text');
        var progresscount = document.getElementById('hp-video-consult-tab-progress-count');
        tabclickbtn.addEventListener("click", function() {
            progressbarid.max = 80;
            progressbarid.value = 20;
            progresscount.innerHTML = 2;
            notecount.innerHTML = 2;
            notetext.innerHTML = "Pathology request";
        });
        var tabclickbtn2 = false;
    });
    $(document).ready(function() {
        var tabclickbtn3 = true;
        var progressbarid = document.getElementById('hp-video-consults-tab-progress');
        var tabclickbtn = document.getElementById('video-consult-tab-3');
        var notecount = document.getElementById('hp-video-consult-medical-note-count');
        var notetext = document.getElementById('hp-video-consult-medical-note-text');
        var progresscount = document.getElementById('hp-video-consult-tab-progress-count');
        tabclickbtn.addEventListener("click", function() {
            progressbarid.max = 80;
            progressbarid.value = 30;
            progresscount.innerHTML = 3;
            notecount.innerHTML = 3;
            notetext.innerHTML = "Imaging request";
        });
        var tabclickbtn3 = false;
    });
    $(document).ready(function() {
        var tabclickbtn4 = true;
        var progressbarid = document.getElementById('hp-video-consults-tab-progress');
        var tabclickbtn = document.getElementById('video-consult-tab-4');
        var notecount = document.getElementById('hp-video-consult-medical-note-count');
        var notetext = document.getElementById('hp-video-consult-medical-note-text');
        var progresscount = document.getElementById('hp-video-consult-tab-progress-count');
        tabclickbtn.addEventListener("click", function() {
            progressbarid.max = 80;
            progressbarid.value = 40;
            progresscount.innerHTML = 4;
            notecount.innerHTML = 4;
            notetext.innerHTML = "Medical / care certification";
        });
        var tabclickbtn4 = false;
    });
    $(document).ready(function() {
        var tabclickbtn5 = true;
        var progressbarid = document.getElementById('hp-video-consults-tab-progress');
        var tabclickbtn = document.getElementById('video-consult-tab-5');
        var notecount = document.getElementById('hp-video-consult-medical-note-count');
        var notetext = document.getElementById('hp-video-consult-medical-note-text');
        var progresscount = document.getElementById('hp-video-consult-tab-progress-count');
        tabclickbtn.addEventListener("click", function() {
            progressbarid.max = 80;
            progressbarid.value = 50;
            progresscount.innerHTML = 5;
            notecount.innerHTML = 5;
            notetext.innerHTML = "General / referral letter";
        });
        var tabclickbtn5 = false;
    });
    $(document).ready(function() {
        var tabclickbtn6 = true;
        var progressbarid = document.getElementById('hp-video-consults-tab-progress');
        var tabclickbtn = document.getElementById('video-consult-tab-6');
        var notecount = document.getElementById('hp-video-consult-medical-note-count');
        var notetext = document.getElementById('hp-video-consult-medical-note-text');
        var progresscount = document.getElementById('hp-video-consult-tab-progress-count');
        tabclickbtn.addEventListener("click", function() {
            progressbarid.max = 80;
            progressbarid.value = 60;
            progresscount.innerHTML = 6;
            notecount.innerHTML = 6;
            notetext.innerHTML = "view / edit medications";
        });
        var tabclickbtn6 = false;
    });
    $(document).ready(function() {
        var tabclickbtn7 = true;
        var progressbarid = document.getElementById('hp-video-consults-tab-progress');
        var tabclickbtn = document.getElementById('video-consult-tab-7');
        var notecount = document.getElementById('hp-video-consult-medical-note-count');
        var notetext = document.getElementById('hp-video-consult-medical-note-text');
        var progresscount = document.getElementById('hp-video-consult-tab-progress-count');
        tabclickbtn.addEventListener("click", function() {
            progressbarid.max = 80;
            progressbarid.value = 70;
            progresscount.innerHTML = 7;
            notecount.innerHTML = 7;
            notetext.innerHTML = "Send files";
        });
        var tabclickbtn7 = false;
    });
    $(document).ready(function() {
        var tabclickbtn8 = true;
        var progressbarid = document.getElementById('hp-video-consults-tab-progress');
        var tabclickbtn = document.getElementById('video-consult-tab-8');
        var notecount = document.getElementById('hp-video-consult-medical-note-count');
        var notetext = document.getElementById('hp-video-consult-medical-note-text');
        var progresscount = document.getElementById('hp-video-consult-tab-progress-count');
        tabclickbtn.addEventListener("click", function() {
            progressbarid.max = 80;
            progressbarid.value = 80;
            progresscount.innerHTML = 8;
            notecount.innerHTML = 8;
            notetext.innerHTML = "Invoice";
        });
        var tabclickbtn8 = false;
    });
</script>
<script>
    function showDiv(divId) {
        const divs = document.querySelectorAll('.video-consult-tab-sec');
        divs.forEach(div => div.classList.add('hidden'));
        $(".video-consult-tab-sec").removeClass('show-particuler-id');
        const targetDiv = document.getElementById(divId);
        if (targetDiv) {
            targetDiv.classList.remove('hidden');
            targetDiv.classList.add('show-particuler-id');
        };
    }
</script>
<script>
    var currentLength;

    function increaseLength() {
        currentLength = document.getElementById("hp-video-consults-tab-progress").value;
        if (currentLength < 90) {
            currentLength += 10;
            document.getElementById("hp-video-consults-tab-progress").value = currentLength;
        } else if (currentLength >= 90 && currentLength < 100) {
            currentLength = 100;
            document.getElementById("hp-video-consults-tab-progress").value = currentLength;
        }
        document.getElementById('hp-video-consult-tab-progress-count').innerHTML++;
        document.getElementById('hp-video-consult-medical-note-count').innerHTML++;
    }

    function decreaseLength() {
        currentLength = document.getElementById("hp-video-consults-tab-progress").value;
        if (currentLength > 10) {
            currentLength -= 10;
            document.getElementById("hp-video-consults-tab-progress").value = currentLength;
        } else if (currentLength > 10 && currentLength <= 10) {
            currentLength = 10;
            document.getElementById("hp-video-consults-tab-progress").value = currentLength;
        }
        document.getElementById('hp-video-consult-tab-progress-count').innerHTML--;
        document.getElementById('hp-video-consult-medical-note-count').innerHTML--;
    }
</script>
<script>
    $(document).ready(function() {
        var hpvideoconsultnote = true;
        $(".hp-video-consult-medical-notes").click(function() {
            $(".hp-video-consult-medical-note-inner").toggleClass('show');
            hpvideoconsultnote = false;
        });
        $("html").click(function() {
            if (hpvideoconsultnote) {
                $(".hp-video-consult-medical-note-inner").removeClass('show');
            }
            hpvideoconsultnote = true;
        });
    });
</script>

<script>
    $(document).ready(function() {
        var hpvideotab = true;
        $(".hp-video-consults-tab-toggle-btn").click(function() {
            $(this).toggleClass('hide-tab-toggle-content');
            hpvideotab = false;
        });
        $("html").click(function() {
            if (hpvideotab) {
                $(".hp-video-consults-tab-toggle-btn").removeClass('hide-tab-toggle-content');
            }
            hpvideotab = true;
        });
    });
</script>
<script>
    $(".tabs-footer-center-button .changeTextButton").click(function() {
        $(window).scrollTop(0);
    });
</script>
<script>
    $(document).ready(function() {
        var input = document.querySelector("#pathology_company_contact_number");
        const contact_number_1 = window.intlTelInput(input, {
            allowDropdown: true,
            hiddenInput: () => "phone_full",
            initialCountry: "au",
            showSelectedDialCode: true,
            utilsScript: baseUrl + "assets/plugins/intl-tel-input-master/build/js/utils.js"
        });
    });
    $(document).ready(function() {
        var input = document.querySelector("#imaging_request_pathology_mobile");
        const contact_number_1 = window.intlTelInput(input, {
            allowDropdown: true,
            hiddenInput: () => "phone_full",
            initialCountry: "au",
            showSelectedDialCode: true,
            utilsScript: baseUrl + "assets/plugins/intl-tel-input-master/build/js/utils.js"
        });
    });
    $(document).ready(function() {
        var input = document.querySelector("#referral_letter_health_providers_mobile");
        const contact_number_1 = window.intlTelInput(input, {
            allowDropdown: true,
            hiddenInput: () => "phone_full",
            initialCountry: "au",
            showSelectedDialCode: true,
            utilsScript: baseUrl + "assets/plugins/intl-tel-input-master/build/js/utils.js"
        });
    });
    $(document).ready(function() {
        var input = document.querySelector("#medication-scripts-patient-contact");
        const contact_number_1 = window.intlTelInput(input, {
            allowDropdown: true,
            hiddenInput: () => "phone_full",
            initialCountry: "au",
            showSelectedDialCode: true,
            utilsScript: baseUrl + "assets/plugins/intl-tel-input-master/build/js/utils.js"
        });
    });
    
</script>
<script>
    let texts = ["Medical notes", "Pathology request", "Imaging request", "Medical / care certification",
        "General / referral letter", "view / edit medications", "Send files", "Invoice"
    ];
    let buttons = document.querySelectorAll('.changeTextButton');
    buttons.forEach(button => {
        button.addEventListener('click', function() {
            let index = this.getAttribute('data-index');
            document.getElementById('hp-video-consult-medical-note-text').innerText = texts[index];
        });
    });
</script>
<script>
    $(window).scroll(function() {
        var scroll = $(window).scrollTop();
        if (scroll >= 100) {
            $(".hp-video-consults-head").addClass("sticky-video-consults-head");
            $(".hp-video-consults-head-mobile").addClass("sticky-hp-video-consults-head-mobile");
        } else {
            $(".hp-video-consults-head").removeClass("sticky-video-consults-head");
            $(".hp-video-consults-head-mobile").removeClass("sticky-hp-video-consults-head-mobile");
        }
    });
</script>
<script>
    $(document).ready(function() {
        if ($("#pathlogy-doctor-datepicker").length) {
            $("#pathlogy-doctor-datepicker").datepicker({
                firstDay: 1,
                showOtherMonths: true,
                changeMonth: true,
                changeYear: true,
                dateFormat: "dd/mm/yy",
                beforeShow: function(input, inst) {
                    $(inst.dpDiv).addClass('flex-datepicker');
                },
                onClose: function(dateText, inst) {
                    var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
                    $(this).datepicker('setDate', new Date(year, 1));
                    $(inst.dpDiv).removeClass('flex-datepicker');
                }
            });
        }
        if ($("#requesting-doctor-datepicker").length) {
            $("#requesting-doctor-datepicker").datepicker({
                firstDay: 1,
                showOtherMonths: true,
                changeMonth: true,
                changeYear: true,
                dateFormat: "dd/mm/yy",
                beforeShow: function(input, inst) {
                    $(inst.dpDiv).addClass('flex-datepicker');
                },
                onClose: function(dateText, inst) {
                    var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
                    $(this).datepicker('setDate', new Date(year, 1));
                    $(inst.dpDiv).removeClass('flex-datepicker');
                }
            });
        }
    });
</script>
<script>
$(document).ready(function () {
    $(".selected-pharmacy-tabs-button-list a").click(function (e) {
        e.preventDefault();

        let tabId = $(this).attr("href");

        $(".selected-pharmacy-tabs").removeClass("active");
        $(tabId).addClass("active");

        $(".selected-pharmacy-tabs-button-list li").removeClass("active");
        $(this).parent().addClass("active");
    });
});
</script>
<script>
 $(document).ready(function() {
    $("#script-patient-mobile, #script-patient-email, #script-select-pharmacy").hide(); 

    $("input[name='choose_medication_scripts']").change(function() {
        $("#script-patient-mobile, #script-patient-email, #script-select-pharmacy").hide();
        if ($("#script-patient-mobile-radio").is(":checked")) {
            $("#script-patient-mobile").show();
        } 
        if ($("#script-patient-email-radio").is(":checked")) {
            $("#script-patient-email").show();
        } 
        if ($("#script-select-pharmacy-radio").is(":checked")) {
            $("#script-select-pharmacy").show();
        } 
    });
});
</script>

<!---modal script-->
<script>
    function customAlerts(selector, action = "open", contentData = '') {
        if (action == "open") {
            $(selector).addClass('show-modal');
            $("body").addClass('modal-open');
        } else {
            $(selector).removeClass('show-modal');
            $("body").removeClass('modal-open');
        }
    }
    $(".rename-template-name-modal-trigger").click(function() {
        customAlerts(".rename-template-name-modal", "open");
    });
    $(".hp-video-head-mobile-trigger").click(function() {
        customAlerts(".hp-video-head-mobile-modal", "open");
    });
    $(".hp-video-head-mobile-modal .video-consult-tab").click(function() {
        customAlerts(".hp-video-head-mobile-modal", "close");
    });
    $(".video-consults-add-template-trigger").click(function() {
        customAlerts(".video-consults-add-template-modal", "open");
    });
    $(".video-consults-edit-template-btn").click(function() {
        customAlerts(".video-consults-add-template-modal", "close");
    });
    $(".drug-details-scenario-1-trigger").click(function() {
        customAlerts(".drug-details-scenario-1-modal", "open");
    });
    $(".delete-medications-prescribe-modal-trigger").click(function() {
        customAlerts(".delete-medications-prescribe-modal", "open");
    });
    $(".custom-preparation-modal-trigger").click(function() {
        customAlerts(".custom-prescription-items-modal", "open");
    });
    $(".create-custom-prescription-modal-trigger").click(function() {
        customAlerts(".create-custom-prescription-modal", "open");
    });
    $(".update-prescription-modal-trigger").click(function() {
        customAlerts(".update-custom-prescription-modal", "open");
        customAlerts(".custom-prescription-items-modal", "close");
    });

    $(document).on("click", ".closecurrentpopup", function() {
        $(this).parents('.modal').removeClass('show-modal');
        $("body").removeClass('modal-open');
    });
</script>


