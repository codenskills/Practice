<?php
$token = "007eJxTYAg88c7ZOfNnX9P25OXfJkROnq769kHi/4mP/92I2/hxt7qTAkOqkYGRqUlqsolZooGJSVKSpbmhZVKqZZqhmUmyhblZ6jKnA+kNgYwMTLGXmBkZIBDEZ2ZITEpmYAAAVvMidw==";
$appId = "fd7716a6e1394250b5a12dd2012d6068";
$customerKey = "c4bc10903e30463f853c9d8ee3014c9d";
$customerSecret = "264fdaaafc1642e4aa6ced3afc506ce9";
$channel = "abc";
//$token = "";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agora Video Call with Transcription and Translation</title>


    <style>
        body {
            font-family: Arial, sans-serif;
        }

        #video-container {
            display: flex;
            gap: 20px;
            justify-content: center;
            align-items: center;
            height: 60vh;
        }

        #local-video,
        #remote-video {
            width: 400px;
            height: 300px;
            border: 1px solid black;
            background-color: black;
        }

        #controls,
        #chat-container {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 10px;
        }

        button {
            padding: 10px;
            font-size: 16px;
            cursor: pointer;
        }

        #chat-box {
            width: 300px;
            height: 200px;
            border: 1px solid black;
            overflow-y: scroll;
            padding: 10px;
            background: #f9f9f9;
        }

        #message-input {
            width: 200px;
            padding: 5px;
        }
    </style>
</head>

<body>

    <h2>Agora Video Call with Transcription and Translation</h2>


    <div id="video-container">
        <div id="local-video"></div>
        <div id="remote-video"></div>
    </div>

    <div id="controls">
        <button id="joinBtn">Join Call</button>
        <button id="muteAudioBtn">Mute Audio</button>
        <button id="pauseVideoBtn">Pause Video</button>
        <button id="endCallBtn">End Call</button>
    </div>


    <!-- stt -->
    <!-- <form id="stt-form" name="stt-form">
        <div class="row join-info-group">
            <div class="col-sm">
                <p class="join-info-text">User ID for the bot to pull the audio from channel</p>
                <input id="puller-uid" type="text" placeholder="enter the int uid" value="111111"
                    onkeyup="this.value=this.value.replace(/[^0-9]/g,'')"
                    onafterpaste="this.value=this.value.replace(/[^0-9]/g,'')">
            </div>

            <div class="col-sm">
                <p class="join-info-text">User ID for the bot to push the text to channel</p>
                <input id="pusher-uid" type="text" placeholder="enter the int uid" value="222222"
                    onkeyup="this.value=this.value.replace(/[^0-9]/g,'')"
                    onafterpaste="this.value=this.value.replace(/[^0-9]/g,'')">
            </div>

        </div>
    </form> -->


    <!-- trans -->
    <h2 class="title">The transcription and translation text</h2>
    <section class="row" style="display:flex; justify-content: space-around">
        <div class="col-sm" id="stt-transcribe" style="display:nonee; width:40%">
            <div class="content">
            </div>
        </div>
        <div class="col-sm" id="stt-translate" style="display:nonee;width:40%">
            <div class="content">
            </div>
        </div>
    </section>

    <script src="<?php echo base_url('assets/agora/jquery-3.4.1.min.js'); ?>"></script>
    <script src="https://download.agora.io/sdk/release/AgoraRTC_N.js"></script>

    <script src="<?php echo base_url('assets/agora/protobuf.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/agora/proto_index.js'); ?>"></script>
    <script>

        const customerKey = "c4bc10903e30463f853c9d8ee3014c9d";
        const customerSecret = "264fdaaafc1642e4aa6ced3afc506ce9";
        const APP_ID = "e834ae750258453cb081b19fdf9e5c6a"; // Replace with your Agora App ID
        const CHANNEL = "abc";
        const TOKEN = "007eJxTYAg88c7ZOfNnX9P25OXfJkROnq769kHi/4mP/92I2/hxt7qTAkOqkYGRqUlqsolZooGJSVKSpbmhZVKqZZqhmUmyhblZ6jKnA+kNgYwMTLGXmBkZIBDEZ2ZITEpmYAAAVvMidw==";
        // const USER_ID = "user_" + Math.floor(Math.random() * 1000); // Generate random user ID
        let USER_ID = 123456;
        const ROLE = "host";


        let client = AgoraRTC.createClient({ mode: "rtc", codec: "vp8" });
        //let client = AgoraRTC.createClient({ mode: "live", codec: "vp8" });


        let localTracks = {
            audioTrack: null,
            videoTrack: null
        };

        var gatewayAddress = "https://api.agora.io";
        let transcribeIndex = 0;
        let translateIndex = 0;
        let taskId = '';


        function GetAuthorization() {
            if (!customerKey || !customerSecret) {
                return "";
            }
            const authorization = `Basic ` + btoa(`${customerKey}:${customerSecret}`);
            return authorization;
        }



        document.getElementById("joinBtn").addEventListener("click", async () => {
            console.log("Join button clicked, starting the call setup");

            // Agora Video Call Setup

            console.log("Client instance:", client);

            try {


                //     client.setClientRole(ROLE);
                //     client.on("stream-message", handleStreammessage);

                //     USER_ID = await client.join(APP_ID, CHANNEL, TOKEN || null, USER_ID || null);

                //     if (!localTracks.audioTrack) {
                //         localTracks.audioTrack = await AgoraRTC.createMicrophoneAudioTrack({
                //             encoderConfig: "music_standard"
                //         });
                //     }
                //     if (ROLE === "host") {
                //         await client.publish(localTracks.audioTrack);
                //     }



                // Join the channel first
                USER_ID = await client.join(APP_ID, CHANNEL, TOKEN || null, USER_ID || null);

                // Now register your stream-message listener (or this can be done before joining)
                client.on("stream-message", handleStreammessage);

                // Create local tracks
                const tracks = await AgoraRTC.createMicrophoneAndCameraTracks({
                    encoderConfig: "music_standard"
                });
                localTracks.audioTrack = tracks[0];
                localTracks.videoTrack = tracks[1];

                // Play local video
                localTracks.videoTrack.play("local-video");

                // Now publish the tracks since we've already joined
                await client.publish(Object.values(localTracks));

                // Listen for remote users publishing their streams
                client.on("user-published", async (user, mediaType) => {
                    await client.subscribe(user, mediaType);
                    if (mediaType === "video") {
                        const remoteVideoTrack = user.videoTrack;
                        remoteVideoTrack.play("remote-video");
                    }
                    if (mediaType === "audio") {
                        user.audioTrack.play();
                    }
                });


                await startTranscription();  // Check if this is being executed

            } catch (err) {
                console.error("Error during join or transcription setup:", err);
            }
        });




        function handleStreammessage(msgUid, data) {
            console.log("Received stream message:", data);
            const msg = $protobufRoot.lookup("Text").decode(data) || {};
            console.log("Decoded message:", msg);
            const { words, data_type, trans = [], duration_ms, uid } = msg;

            if (data_type == "transcribe") {
                if (words.length) {
                    let isFinal = false;
                    let text = "";
                    words.forEach(item => {
                        if (item.isFinal) {
                            isFinal = true;
                        }
                        text += item?.text;
                    });
                    addTranscribeItem(uid, text);
                    if (isFinal) {
                        transcribeIndex++;
                    }
                }
            } else if (data_type == "translate") {
                if (trans.length) {
                    trans.forEach(item => {
                        let text = "";
                        item?.texts.forEach(v => text += v);
                        addTranslateItem(uid, text);
                        if (item.isFinal) {
                            translateIndex++;
                        }
                    });
                }
            }
        }




        async function acquireToken() {
            const url = `${gatewayAddress}/v1/projects/${APP_ID}/rtsc/speech-to-text/builderTokens`;
            const data = {
                instanceId: CHANNEL
            };

            try {
                let res = await fetch(url, {
                    method: 'POST',
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": GetAuthorization()
                    },
                    body: JSON.stringify(data)
                });

                if (res.status === 200) {
                    return await res.json();
                } else {
                    throw new Error(`Failed to acquire token: ${res.status}`);
                }
            } catch (error) {
                console.error("Token acquisition failed:", error);
                throw error;
            }
        }

        async function startTranscription() {

            const authorization = GetAuthorization();
            if (!authorization) {
                throw new Error("key or secret is empty");
            }

            try {
                const data = await acquireToken();

                tokenName = data.tokenName;
                const url = `${gatewayAddress}/v1/projects/${APP_ID}/rtsc/speech-to-text/tasks?builderToken=${tokenName}`;
                const pullUid = "111111";
                const pullToken = TOKEN;
                const pushUid = "222222";
                const pushToken = TOKEN;
                const speakingLanguage = "en-US";
                const translationLanguage = "zh-CN";
                let body = {
                    "audio": {
                        "subscribeSource": "AGORARTC",
                        "agoraRtcConfig": {
                            "channelName": CHANNEL,
                            "uid": pullUid,
                            "token": pullToken,
                            "channelType": "LIVE_TYPE",
                            "subscribeConfig": {
                                "subscribeMode": "CHANNEL_MODE"
                            },
                            "maxIdleTime": 10
                        }
                    },
                    "config": {
                        "features": ["RECOGNIZE"],
                        "recognizeConfig": {
                            "language": speakingLanguage,
                            "model": "Model",
                            "connectionTimeout": 60,
                            "output": {
                                "destinations": ["AgoraRTCDataStream"],
                                "agoraRTCDataStream": {
                                    "channelName": CHANNEL,
                                    "uid": pushUid,
                                    "token": pushToken
                                }
                            }
                        }
                    }
                };
                if (translationLanguage) {
                    body.config.translateConfig = {
                        "languages": [{
                            "source": speakingLanguage,
                            "target": [translationLanguage]
                        }]
                    };
                }
                console.log("Transcription request body:", body);
                try {
                    let res = await fetch(url, {
                        method: 'POST',
                        headers: {
                            "Content-Type": "application/json",
                            "Authorization": authorization
                        },
                        body: JSON.stringify(body)
                    });

                    res = await res.json();
                    console.log("Transcription started successfully:", res);
                    taskId = res.taskId;
                } catch (err) {
                    console.error("Error in starting transcription:", err);
                    throw new Error("Transcription failed to start");
                }
            } catch (err) {
                console.error("Error in starting transcription:", err);
                throw new Error("Transcription failed to start");
            }
        }
        async function stopTranscription() {
            if (!taskId) {
                return;
            }
            const url = `${gatewayAddress}/v1/projects/${APP_ID}/rtsc/speech-to-text/tasks/${taskId}?builderToken=${tokenName}`;
            await fetch(url, {
                method: 'DELETE',
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": GetAuthorization()
                }
            });
            taskId = null;
        }
        function addTranscribeItem(uid, msg) {
            if ($(`#transcribe-${transcribeIndex}`)[0]) {
                $(`#transcribe-${transcribeIndex} .msg`).html(msg);
            } else {
                let uname="";
                if(uid==123456){
                    uname="Yashvir";
                }else if(uid==888){
                    uname="Anil";
                }else if(uid==987){
                    uname="Kintan";
                }else{
                    uname=uid;
                }
                const $item = $(`<div class="item" id="transcribe-${transcribeIndex}"><strong><span class="uid">${uname}</span>:</strong> <span class="msg">${msg}</span></div>`);
                $("#stt-transcribe .content").append($item);
            }
        }
        function addTranslateItem(uid, msg) {
            if ($(`#translate-${translateIndex}`)[0]) {
                $(`#translate-${translateIndex} .msg`).html(msg);
            } else {
                let uname="";
                if(uid==123456){
                    uname="Yashvir";
                }else if(uid==987){
                    uname="Kintan";
                }else if(uid==888){
                    uname="Anil";
                }else{
                    uname=uid;
                }
                //${uname}
                const $item = $(`<div class="item" id="translate-${translateIndex}"><span class="uid"></span> <span class="msg">${msg}</span> </div>`);
                $("#stt-translate .content").append($item);
            }
        }





        // Mute/Unmute Audio
        document.getElementById("muteAudioBtn").addEventListener("click", () => {
            if (localTracks.audioTrack.muted) {
                localTracks.audioTrack.setMuted(false);
                document.getElementById("muteAudioBtn").innerText = "Mute Audio";
            } else {
                localTracks.audioTrack.setMuted(true);
                document.getElementById("muteAudioBtn").innerText = "Unmute Audio";
            }
        });

        // Pause/Resume Video
        document.getElementById("pauseVideoBtn").addEventListener("click", () => {
            if (localTracks.videoTrack.muted) {
                localTracks.videoTrack.setMuted(false);
                document.getElementById("pauseVideoBtn").innerText = "Pause Video";
            } else {
                localTracks.videoTrack.setMuted(true);
                document.getElementById("pauseVideoBtn").innerText = "Resume Video";
            }
        });

        // End Call
        document.getElementById("endCallBtn").addEventListener("click", async () => {
            for (let trackName in localTracks) {
                let track = localTracks[trackName];
                if (track) {
                    track.stop();
                    track.close();
                }
            }
            await client.leave();
            document.getElementById("local-video").innerHTML = "";
            document.getElementById("remote-video").innerHTML = "";
            alert("Call Ended");


        });



    </script>

</body>

</html>













<!-- 
 ########################################################
Only Video Workinj
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agora Video Call with Chat</title>

    <script src="https://download.agora.io/sdk/release/AgoraRTC_N.js"></script>




    <script>
        function chatSDKLoaded() {
            console.log("Agora Chat SDK loaded:", window.AgoraChat);
        }
    </script>




    <style>
        body {
            font-family: Arial, sans-serif;
        }

        #video-container {
            display: flex;
            gap: 20px;
            justify-content: center;
            align-items: center;
            height: 60vh;
        }

        #local-video,
        #remote-video {
            width: 400px;
            height: 300px;
            border: 1px solid black;
            background-color: black;
        }

        #controls,
        #chat-container {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 10px;
        }

        button {
            padding: 10px;
            font-size: 16px;
            cursor: pointer;
        }

        #chat-box {
            width: 300px;
            height: 200px;
            border: 1px solid black;
            overflow-y: scroll;
            padding: 10px;
            background: #f9f9f9;
        }

        #message-input {
            width: 200px;
            padding: 5px;
        }
    </style>
</head>

<body>

    <h2>Agora Video Call with Chat</h2>
    <button id="joinBtn">Join Call</button>

    <div id="video-container">
        <div id="local-video"></div>
        <div id="remote-video"></div>
    </div>

    <div id="controls">
        <button id="muteAudioBtn">Mute Audio</button>
        <button id="pauseVideoBtn">Pause Video</button>
        <button id="endCallBtn">End Call</button>
    </div>

    <div id="chat-container">
        <div id="chat-box"></div>
        <input type="text" id="message-input" placeholder="Type a message...">
        <button id="sendBtn">Send</button>
    </div>

    <script>
        console.log("Agora Chat SDK:", window.AgoraChat);

        const APP_ID = "fd7716a6e1394250b5a12dd2012d6068"; // Replace with your Agora App ID
        const CHANNEL = "abc";
        const TOKEN = "007eJxTYJg3IUffpUqsQepbRA2n/jSXtd8k7ja/v3Nbm+PXxTbvTysVGNJSzM0NzRLNUg2NLU2MTA2STBMNjVJSjAyApJmBmYWU+Pr0hkBGhuvWH5kZGSAQxGdmSExKZmAAAB/xHsA=";
        const USER_ID = "user_" + Math.floor(Math.random() * 1000); // Generate random user ID

        let client;
        let chatClient;
        let localTracks = {
            audioTrack: null,
            videoTrack: null
        };

        document.getElementById("joinBtn").addEventListener("click", async () => {
            // Agora Video Call Setup
            client = AgoraRTC.createClient({ mode: "rtc", codec: "vp8" });

            await client.join(APP_ID, CHANNEL, TOKEN, null);

            const tracks = await AgoraRTC.createMicrophoneAndCameraTracks();
            localTracks.audioTrack = tracks[0];
            localTracks.videoTrack = tracks[1];

            localTracks.videoTrack.play("local-video");

            await client.publish(Object.values(localTracks));

            client.on("user-published", async (user, mediaType) => {
                await client.subscribe(user, mediaType);

                if (mediaType === "video") {
                    const remoteVideoTrack = user.videoTrack;
                    remoteVideoTrack.play("remote-video");
                }
                if (mediaType === "audio") {
                    user.audioTrack.play();
                }
            });

            // Agora Chat Setup
            chatClient = new AgoraChat.connection({
                appKey: APP_ID, // Replace with Agora App Key
            });

            chatClient.open({
                user: USER_ID,
                agoraToken: TOKEN // If using token authentication
            }).then(() => {
                console.log("Agora Chat connected");
                chatClient.addEventHandler("onTextMessage", (message) => {
                    displayMessage(message.from, message.data);
                });
            }).catch(err => console.error("Chat connection error:", err));
        });

        // Send Message
        document.getElementById("sendBtn").addEventListener("click", () => {
            const messageText = document.getElementById("message-input").value;
            if (messageText.trim() !== "") {
                let message = AgoraChat.message.create({
                    type: "txt",
                    to: CHANNEL, // Send message to channel
                    chatType: "groupChat",
                    msg: messageText
                });

                chatClient.send(message).then(() => {
                    displayMessage("Me", messageText);
                    document.getElementById("message-input").value = "";
                }).catch(err => console.error("Message send error:", err));
            }
        });

        // Display Message in Chat
        function displayMessage(user, text) {
            const chatBox = document.getElementById("chat-box");
            const message = document.createElement("p");
            message.innerHTML = `<strong>${user}:</strong> ${text}`;
            chatBox.appendChild(message);
            chatBox.scrollTop = chatBox.scrollHeight;
        }

        // Mute/Unmute Audio
        document.getElementById("muteAudioBtn").addEventListener("click", () => {
            if (localTracks.audioTrack.muted) {
                localTracks.audioTrack.setMuted(false);
                document.getElementById("muteAudioBtn").innerText = "Mute Audio";
            } else {
                localTracks.audioTrack.setMuted(true);
                document.getElementById("muteAudioBtn").innerText = "Unmute Audio";
            }
        });

        // Pause/Resume Video
        document.getElementById("pauseVideoBtn").addEventListener("click", () => {
            if (localTracks.videoTrack.muted) {
                localTracks.videoTrack.setMuted(false);
                document.getElementById("pauseVideoBtn").innerText = "Pause Video";
            } else {
                localTracks.videoTrack.setMuted(true);
                document.getElementById("pauseVideoBtn").innerText = "Resume Video";
            }
        });

        // End Call
        document.getElementById("endCallBtn").addEventListener("click", async () => {
            for (let trackName in localTracks) {
                let track = localTracks[trackName];
                if (track) {
                    track.stop();
                    track.close();
                }
            }
            await client.leave();
            document.getElementById("local-video").innerHTML = "";
            document.getElementById("remote-video").innerHTML = "";
            alert("Call Ended");

            // Disconnect Chat
            chatClient.close();
        });

    </script>

</body>

</html> -->