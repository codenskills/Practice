<?php
$token = "007eJxTYNB5u2+pN9+0jzfjXoc7bF2V92jDfP9pqiLdOjkuUjtPvn2hwJCWYm5uaJZolmpobGliZGqQZJpoaJSSYmQAJM0MzCwexW1IbwhkZJCWKmBmZIBAEJ+ZITEpmYEBAIHjHz0=";
$appId = "fd7716a6e1394250b5a12dd2012d6068";
$customerKey = "c4bc10903e30463f853c9d8ee3014c9d";
$customerSecret = "264fdaaafc1642e4aa6ced3afc506ce9";
$channel = "abc";
//$token = "";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Realtime Transcription -- Agora</title>
    <link rel="stylesheet" href="https://webdemo.agora.io/assets/bootstrap.min.css">
    <link rel="stylesheet" href="https://webdemo.agora.io/stt/index.css">
</head>

<body>
    <div class="container-fluid banner">
        <p class="banner-text">Realtime Transcription</p>
        <a style="color: rgb(255, 255, 255);fill: rgb(255, 255, 255);fill-rule: evenodd; position: absolute; right: 10px; top: 4px;"
            class="Header-link " href="https://github.com/AgoraIO/API-Examples-Web/tree/main/Demo">
            <svg class="octicon octicon-mark-github v-align-middle" height="32" viewBox="0 0 16 16" version="1.1"
                width="32" aria-hidden="true">
                <path fill-rule="evenodd"
                    d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z">
                </path>
            </svg>
        </a>
    </div>

    <section id="alert-wrapper">
        <div id="success-alert" class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Congratulations!</strong><span> You can invite others to watch your live by click </span><a href=""
                target="_blank">here</a>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div id="rtc-alert" class="alert alert-danger alert-dismissible fade show" role="alert">
            You should first join rtc!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div id="parameters-alert" class="alert alert-danger alert-dismissible" role="alert">
            Please check the parameters!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </section>


    <div class="container">
        <!-- rtc -->
        <form id="join-form" name="join-form">
            <div class="row join-info-group">
                <div class="col-sm sso-hidden">
                    <p class="join-info-text">AppID</p>
                    <input id="appid" type="text" placeholder="enter appid" value="<?php echo $appId; ?>">
                    <p class="tips">If you don`t know what is your appid, checkout <a
                            href="https://docs.agora.io/en/Agora%20Platform/terms?platform=All%20Platforms#a-nameappidaapp-id">this</a>
                    </p>
                </div>
                <div class="col-sm sso-hidden">
                    <p class="join-info-text">Token(optional)</p>
                    <input id="token" type="text" placeholder="enter token" value="<?php echo $token; ?>">
                    <p class="tips">If you don`t know what is your token, checkout <a
                            href="https://docs.agora.io/en/Agora%20Platform/terms?platform=All%20Platforms#a-namekeyadynamic-key">this</a>
                    </p>
                </div>
                <div class="col-sm">
                    <p class="join-info-text">Channel</p>
                    <input id="channel" type="text" placeholder="enter channel name" required
                        value="<?php echo $channel; ?>">
                    <p class="tips">If you don`t know what is your channel, checkout <a
                            href="https://docs.agora.io/en/Agora%20Platform/terms?platform=All%20Platforms#channel">this</a>
                    </p>
                </div>
                <div class="col-sm">
                    <p class="join-info-text">User ID(optional)</p>
                    <input id="uid" type="text" onkeyup="this.value=this.value.replace(/[^0-9]/g,'')" value="123456"
                        onafterpaste="this.value=this.value.replace(/[^0-9]/g,'')" placeholder="Enter the user ID">
                </div>
            </div>

            <div class="button-group">
                <button id="host-join" type="submit" class="btn btn-primary btn-sm">Join as host</button>
                <button id="audience-join" type="submit" class="btn btn-primary btn-sm">Join as audience</button>
                <button id="leave" type="button" class="btn btn-primary btn-sm" disabled>Leave</button>
            </div>
        </form>

        <form id="key-form" name="key-form">
            <div class="row join-info-group">
                <div class="col-sm">
                    <div class="join-info-key">key</div>
                    <input id="key" type="text" placeholder="enter the key" value="<?php echo $customerKey; ?>">
                    <p class="tips">The restful API security
                        You find your key and secret in the <a href="https://console.agora.io/">Agora Console</a>
                    </p>
                </div>
                <div class="col-sm">
                    <div class="join-info-secret">secret</div>
                    <input id="secret" type="text" placeholder="enter the secret"
                        value="<?php echo $customerSecret; ?>">
                </div>
            </div>
        </form>
        <!-- stt -->
        <form id="stt-form" name="stt-form">
            <div class="row join-info-group">
                <div class="col-sm">
                    <p class="join-info-text">User ID for the bot to pull the audio from channel</p>
                    <input id="puller-uid" type="text" placeholder="enter the int uid" value="111111"
                        onkeyup="this.value=this.value.replace(/[^0-9]/g,'')"
                        onafterpaste="this.value=this.value.replace(/[^0-9]/g,'')">
                </div>
                <div class="col-sm">
                    <p class="join-info-text">Token(optional)</p>
                    <input id="puller-token" type="text" placeholder="token of the puller"
                        value="<?php echo $token; ?>">
                </div>
                <div class="col-sm">
                    <p class="join-info-text">User ID for the bot to push the text to channel</p>
                    <input id="pusher-uid" type="text" placeholder="enter the int uid" value="222222"
                        onkeyup="this.value=this.value.replace(/[^0-9]/g,'')"
                        onafterpaste="this.value=this.value.replace(/[^0-9]/g,'')">
                </div>
                <div class="col-sm">
                    <p class="join-info-text">Token(optional)</p>
                    <input id="pusher-token" type="text" placeholder="token of the pusher"
                        value="<?php echo $token; ?>">
                </div>
            </div>

            <!-- language -->
            <div class="row">
                <div class="col-sm">
                    <p class="join-info-text">Speaking Language</p>
                    <input id="speaking-language" type="text" placeholder="language code" value="en-US">
                    <p class="tips">input the language code, such as en-US, zh-CN</p>
                </div>
                <div class="col-sm">
                    <p class="join-info-text">Translation Language(optional)</p>
                    <input id="translation-language" type="text" placeholder="language code" value="zh-CN">
                    <p class="tips">input the language code, such as en-US, zh-CN</p>
                </div>
            </div>

            <div class="button-group">
                <button id="start-trans" type="submit" class="btn btn-primary btn-sm">Start Channel
                    Transcription</button>
                <button id="stop-trans" type="button" class="btn btn-primary btn-sm" disabled>Stop task</button>
            </div>
        </form>


        <!-- trans -->
        <div class="title">After start the transcription, Please say something, you wil see the text here</div>
        <section class="row">
            <div class="col-sm" id="stt-transcribe" style="display:none">
                <div class="content">
                </div>
            </div>
            <div class="col-sm" id="stt-translate" style="display:none">
                <div class="content">
                </div>
            </div>
        </section>
    </div>


    <script src="https://webdemo.agora.io/assets/jquery-3.4.1.min.js"></script>
    <script src="https://webdemo.agora.io/assets/bootstrap.bundle.min.js"></script>
    <script src="https://download.agora.io/sdk/release/AgoraRTC_N.js"></script>
    <script src="https://webdemo.agora.io/stt/proto/protobuf.min.js"></script>
    <!-- <script src="https://webdemo.agora.io/stt/proto/index.js"></script>
    <script src="https://webdemo.agora.io/stt/stt.js"></script> -->



    <script src="<?php echo base_url('assets/agora/proto_index.js'); ?>"></script>
    <script src="<?php echo base_url('assets/agora/stt.js'); ?>"></script>

</body>

</html>


<?php


// // Example JSON string from WebRTC stats
// $jsonData = '{
//     "_type": "wrtc_stats",
//     "_message": {
//         "lts": 1739534562656,
//         "sid": "890A776A520E3353D4B8F483DCFE922E",
//         "uid": 123456,
//         "stats": {
//             "misc": [
//                 {
//                     "addition": {
//                         "2006": 23,
//                         "2205": 251,
//                         "2219": 2
//                     }
//                 }
//             ],
//             "outbound": [
//                 {
//                     "audio": {}
//                 }
//             ]
//         }
//     }
// }';

// // Decode the JSON string into a PHP array
// $data = json_decode($jsonData, true);

// // Extract data from the array
// $lts = $data['_message']['lts'];  // Timestamp
// $sid = $data['_message']['sid'];  // Session ID
// $uid = $data['_message']['uid'];  // User ID

// // Extract stats from "misc" array
// $miscStats = $data['_message']['stats']['misc'][0]['addition'];
// $packetLoss = isset($miscStats['2006']) ? $miscStats['2006'] : 'N/A';
// $jitter = isset($miscStats['2205']) ? $miscStats['2205'] : 'N/A';
// $errorCode = isset($miscStats['2219']) ? $miscStats['2219'] : 'N/A';

// // Format timestamp into human-readable date
// $timestamp = date('Y-m-d H:i:s', $lts / 1000);  // Convert milliseconds to seconds

// // Generate the text output
// $textOutput = "WebRTC Stats Information:\n";
// $textOutput .= "Timestamp: $timestamp\n";
// $textOutput .= "Session ID: $sid\n";
// $textOutput .= "User ID: $uid\n";
// $textOutput .= "Packet Loss (2006): $packetLoss\n";
// $textOutput .= "Jitter (2205): $jitter\n";
// $textOutput .= "Error Code (2219): $errorCode\n";
// $textOutput .= "Outbound Audio Stats: N/A (No data available)\n";  // Example where no outbound data was provided

// // Display the result
// echo nl2br($textOutput);  // nl2br ensures proper line breaks in HTML output


?>

<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Web SDK Voice & Speech-to-Text Quickstart</title>
    <script src="https://cdn.agora.io/sdk/release/AgoraRTC_N.js"></script>
    <script src="https://download.agora.io/sdk/release/AgoraRTC_N.js"></script>
    <style>
        #transcription {
            margin-top: 20px;
            font-size: 20px;
            color: #333;
        }
    </style>
</head>
<body>
    <h2 class="left-align">Web SDK Voice Quickstart</h2>
    <div class="row">
        <div>
            <button type="button" id="join">Join</button>
            <button type="button" id="leave">Leave</button>
        </div>
    </div>
    
    
    <div id="transcription"></div>
    
    <script>
        let rtc = {
            localAudioTrack: null,
            client: null,
            sttClient: null,  // Speech to Text client
            transcriptionText: ''
        };

        let options = {
            appId: "fd7716a6e1394250b5a12dd2012d6068",  // Your App ID
            channel: "abc",  // Channel name
            token: "007eJxTYJg3IUffpUqsQepbRA2n/jSXtd8k7ja/v3Nbm+PXxTbvTysVGNJSzM0NzRLNUg2NLU2MTA2STBMNjVJSjAyApJmBmYWU+Pr0hkBGhuvWH5kZGSAQxGdmSExKZmAAAB/xHsA=",  // Token for authentication
            uid: 123456,  // User ID
        };

        // Initialize the AgoraRTC client
        function initializeClient() {
            rtc.client = AgoraRTC.createClient({ mode: "rtc", codec: "vp8" });
            setupEventListeners();
        }

        // Handle remote user events
        function setupEventListeners() {
            rtc.client.on("user-published", async (user, mediaType) => {
                await rtc.client.subscribe(user, mediaType);
                console.log("Subscribed to remote user.");
                if (mediaType === "audio") {
                    const remoteAudioTrack = user.audioTrack;
                    remoteAudioTrack.play();
                }
            });

            rtc.client.on("user-unpublished", async (user) => {
                await rtc.client.unsubscribe(user);
                console.log("Unsubscribed from remote user.");
            });
        }

        // Join the channel and publish local audio
        async function joinChannel() {
            await rtc.client.join(options.appId, options.channel, options.token, options.uid);
            await publishLocalAudio();
            console.log("Publish success!");
            // Start speech-to-text once connected
            startSpeechToText();
        }

        // Publish local audio track
        async function publishLocalAudio() {
            rtc.localAudioTrack = await AgoraRTC.createMicrophoneAudioTrack();
            await rtc.client.publish([rtc.localAudioTrack]);
        }

        // Leave the channel and clean up
        async function leaveChannel() {
            rtc.localAudioTrack.close();
            await rtc.client.leave();
            console.log("Left the channel.");
            stopSpeechToText(); // Stop STT when leaving the channel
        }

        // Start speech-to-text transcription
        function startSpeechToText() {
            rtc.sttClient = AgoraRTC.createSpeechToTextClient({
                appId: options.appId,
                channelName: options.channel
            });

            rtc.sttClient.on("text", function (text) {
                console.log("Transcription received: ", text);
                rtc.transcriptionText = text;  // Update transcription text
                displayTranscription();  // Update the UI
            });

            // Optionally handle errors or other events from STT
            rtc.sttClient.on("error", (error) => {
                console.error("STT error:", error);
            });

            rtc.sttClient.start();
        }

        // Stop the speech-to-text process
        function stopSpeechToText() {
            if (rtc.sttClient) {
                rtc.sttClient.stop();
                console.log("Speech-to-text stopped.");
            }
        }

        // Display the transcription on the page
        function displayTranscription() {
            const transcriptionDiv = document.getElementById("transcription");
            transcriptionDiv.textContent = rtc.transcriptionText;
        }

        // Set up button click handlers
        function setupButtonHandlers() {
            document.getElementById("join").onclick = joinChannel;
            document.getElementById("leave").onclick = leaveChannel;
        }

        // Start the basic call process
        function startBasicCall() {
            initializeClient();
            window.onload = setupButtonHandlers;
        }

        startBasicCall();
    </script>
</body>
</html>
-->

<?php
$token = "007eJxTYJg3IUffpUqsQepbRA2n/jSXtd8k7ja/v3Nbm+PXxTbvTysVGNJSzM0NzRLNUg2NLU2MTA2STBMNjVJSjAyApJmBmYWU+Pr0hkBGhuvWH5kZGSAQxGdmSExKZmAAAB/xHsA=";
$appid = "fd7716a6e1394250b5a12dd2012d6068";
$instancechannele = "abc";
?>
<?php


// // Step 1: Get the builder token
// $ch = curl_init();

// // Set the URL for the API request to create a builder token
// curl_setopt($ch, CURLOPT_URL, "https://api.agora.io/v1/projects/$appid/rtsc/speech-to-text/builderTokens");

// // Set cURL options
// curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);  // Return response as string
// curl_setopt($ch, CURLOPT_POST, true);            // Set method to POST
// curl_setopt($ch, CURLOPT_HTTPHEADER, array(
//     'Content-Type: Application/json',             // Set content type header
//     'Authorization: agora token="' . $token . '"' // Authorization header
// ));

// // Set the data payload for the POST request
// $data = array(
//     "instanceId" => $instancechannele
// );
// curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data)); // Encode data to JSON

// // Execute cURL request
// $response = curl_exec($ch);

// // Check for errors
// if ($response === false) {
//     echo "cURL Error: " . curl_error($ch);
//     exit;
// } else {
//     // Decode the response to extract the tokenName
//     $responseData = json_decode($response, true);
//     $builderToken = $responseData['tokenName']; // Extract tokenName from the response
//     echo "Builder Token: " . $builderToken . "\n"; // For debugging purposes
// }

// // Close cURL session
// curl_close($ch);

// // Step 2: Use the builder token to create a speech-to-text task
// $curl = curl_init();

// curl_setopt_array($curl, array(
//     CURLOPT_URL => 'https://api.agora.io/v1/projects/' . $appid . '/rtsc/speech-to-text/tasks?builderToken=' . $builderToken,
//     CURLOPT_RETURNTRANSFER => true,
//     CURLOPT_ENCODING => '',
//     CURLOPT_MAXREDIRS => 10,
//     CURLOPT_TIMEOUT => 0,
//     CURLOPT_FOLLOWLOCATION => true,
//     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//     CURLOPT_CUSTOMREQUEST => 'POST',
//     CURLOPT_POSTFIELDS => json_encode([
//         "languages" => ["en-US"],
//         "maxIdleTime" => 600,
//         "rtcConfig" => [
//             "channelName" => $instancechannele,
//             "subBotUid" => "1",   // You can replace these UIDs and tokens with real ones
//             "subBotToken" => "{{subBotToken}}",  // Replace with actual token
//             "pubBotUid" => "2",   // Replace with actual UID
//             "pubBotToken" => "{{pubBotToken}}",  // Replace with actual token
//             "subscribeAudioUids" => ["3"]
//         ]
//     ]),
//     CURLOPT_HTTPHEADER => array(
//         'Content-Type: application/json',
//         'Authorization: agora token="' . $token . '"'
//     ),
// ));

// $response2 = curl_exec($curl);

// // Check for errors
// if ($response2 === false) {
//     echo "cURL Error: " . curl_error($curl);
//     exit;
// } else {
//     echo "Speech-to-Text Task Response: " . $response2;  // Output the response
// }

// // Close cURL session
// curl_close($curl);
?>



<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Agora Web SDK Voice with Speech-to-Text</title>
    <script src="https://cdn.agora.io/sdk/release/AgoraRTC_N.js"></script>
    <script src="https://download.agora.io/sdk/release/AgoraRTC_N.js"></script>
    
</head>
<body>
    <h2>Agora Web SDK Voice Quickstart with Speech-to-Text</h2>

    <div>
        <button type="button" id="join">Join</button>
        <button type="button" id="leave">Leave</button>
    </div>

    <h3>Transcription</h3>
    <div id="sttText">Transcription will appear here...</div>

    <script>
        let rtc = {
            localAudioTrack: null,
            client: null,
            speechToTextClient: null
        };

        let options = {
            appId: "fd7716a6e1394250b5a12dd2012d6068", // Your Agora App ID
            channel: "abc",      // Channel name
            token: null, // Temp token, can be null for basic auth
            uid: 123456,          // User ID
        };

        // Initialize Agora RTC client and STT client
        function initializeClient() {
            rtc.client = AgoraRTC.createClient({ mode: "rtc", codec: "vp8" });
            rtc.speechToTextClient = AgoraRTC.createSpeechToTextClient(); // Create STT client
            setupEventListeners();
        }

        // Handle events for speech-to-text
        function setupSpeechToTextEvents() {
            rtc.speechToTextClient.on("speech-to-text-result", (result) => {
                console.log("Received STT Result: ", result);
                document.getElementById("sttText").innerText = result.transcript;
            });
        }

        // Handle remote user events
        function setupEventListeners() {
            rtc.client.on("user-published", async (user, mediaType) => {
                await rtc.client.subscribe(user, mediaType);
                console.log("subscribe success");
                if (mediaType === "audio") {
                    const remoteAudioTrack = user.audioTrack;
                    remoteAudioTrack.play();
                }
            });

            rtc.client.on("user-unpublished", async (user) => {
                await rtc.client.unsubscribe(user);
            });
        }

        // Join the channel and publish local audio
        async function joinChannel() {
            await rtc.client.join(options.appId, options.channel, options.token, options.uid);
            await publishLocalAudio();
            console.log("Publish success!");
        }

        // Publish local audio track
        async function publishLocalAudio() {
            rtc.localAudioTrack = await AgoraRTC.createMicrophoneAudioTrack();
            await rtc.client.publish([rtc.localAudioTrack]);
            
            // Start Speech-to-Text on the local audio track
            rtc.speechToTextClient.start(rtc.localAudioTrack);
        }

        // Leave the channel and clean up
        async function leaveChannel() {
            rtc.localAudioTrack.close(); // Stop local audio
            await rtc.client.leave();    // Leave the channel
            console.log("Left the channel.");

            // Stop Speech-to-Text
            rtc.speechToTextClient.stop();
        }

        // Set up button click handlers
        function setupButtonHandlers() {
            document.getElementById("join").onclick = joinChannel;
            document.getElementById("leave").onclick = leaveChannel;
        }

        // Start the call
        function startBasicCall() {
            initializeClient();
            setupSpeechToTextEvents();
            window.onload = setupButtonHandlers;
        }

        startBasicCall();
    </script>
</body>
</html>  -->





<!-- 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agora Real-Time Speech-to-Text</title>

    
    <script src="https://cdn.agora.io/sdk/release/AgoraRTC_N.js"></script>

    <style>
        body { font-family: Arial, sans-serif; text-align: center; margin: 20px; }
        #transcription { margin-top: 20px; padding: 10px; border: 1px solid #ddd; width: 60%; margin: auto; }
    </style>
</head>
<body>

    <h2>Agora Speech-to-Text (No Token)</h2>
    <button onclick="startCall()">Start Call</button>
    <button onclick="leaveCall()">Leave Call</button>

    <h3>Live Transcription:</h3>
    <div id="transcription">Waiting for speech...</div>

    <script>
        let client;
        let localAudioTrack;
        let ws;

        const APP_ID = "81b6f2a723814c0184c4f956c81c50ec";  // Replace with your Agora App ID
        const CHANNEL_NAME = "test_channel"; // Replace with your channel name
        const TOKEN = null;  // Set to null for App ID authentication mode
        const PROJECT_ID = "81b6f2a723814c0184c4f956c81c50ec";  // Replace with your Agora Project ID

        async function startCall() {
            client = AgoraRTC.createClient({ mode: "rtc", codec: "vp8" });

            await client.join(APP_ID, CHANNEL_NAME, TOKEN, null);
            localAudioTrack = await AgoraRTC.createMicrophoneAudioTrack();
            await client.publish([localAudioTrack]);

            console.log("Joined channel and streaming audio...");

            startSTT();
        }

        function startSTT() {
            let ws = new WebSocket(`wss://api.agora.io/v1/projects/${PROJECT_ID}/rtsc/speech-to-text`);

ws.onopen = function() {
    console.log("✅ WebSocket is open.");
};

ws.onerror = function(error) {
    console.error("❌ WebSocket error:", error);
};

ws.onclose = function() {
    console.log("❌ WebSocket closed.");
};


            // ws = new WebSocket(`wss://api.agora.io/v1/projects/${PROJECT_ID}/rtsc/speech-to-text`);

            // ws.onopen = () => {
            //     console.log("Connected to Agora STT WebSocket");
            //     localAudioTrack.pipe(ws);
            // };

            // ws.onmessage = (event) => {
            //     const response = JSON.parse(event.data);
            //     if (response.transcription) {
            //         document.getElementById("transcription").innerText = response.transcription;
            //     }
            // };

            // ws.onerror = (error) => {
            //     console.error("WebSocket Error:", error);
            // };

            // ws.onclose = () => {
            //     console.log("WebSocket Disconnected");
            // };
        }

        function leaveCall() {
            if (localAudioTrack) {
                localAudioTrack.stop();
                localAudioTrack.close();
            }
            if (client) {
                client.leave();
            }
            if (ws) {
                ws.close();
            }
            document.getElementById("transcription").innerText = "Waiting for speech...";
            console.log("Left the call");
        }
    </script>

</body>
</html> -->