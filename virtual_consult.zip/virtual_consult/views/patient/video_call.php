<!DOCTYPE html>
<html lang="en">

<head>
    <noscript>
        <meta http-equiv="refresh" runat="server" id="mtaJSCheck" content="0;<?php echo base_url() ?>error.php" />
    </noscript>
    <link rel="icon" href="<?php echo base_url() ?>assets/images/favicon.png" type="image/png" />
    <link rel="shortcut icon" href="<?php echo base_url() ?>assets/images/favicon.png">
    <meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' />
    <meta charset="UTF-8" />
    <meta name="description" content="Medcallz:EVERY PATIENT.EVERY DOCTOR" />
    <meta name="keywords" content="Medcallz" />
    <meta name="author" content="Medcallz" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title><?php echo $title . ' | '.$this->lang->line('Medcallz'); ?> </title>
    <!--- Style --->
    <link href="<?php echo base_url(); ?>assets/css/virtual_consult/style.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url(); ?>assets/css/v3/commonstyle.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url(); ?>assets/css/virtual_consult/responsive.css" rel="stylesheet" type="text/css" />
     <!--- Js --->
    <script src="<?php echo base_url(); ?>assets/plugins/jquery/jquery-2.1.4.min.js"></script>
</head>

<body>
    <!--desktop view-->
    <section class="video-call-section">
        <div class="container">
            <div class="video-call-desktop-minimize-wrap">
                <button class="video-call-desktop-minimize-btn">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M6 9L12 15L18 9" stroke="#B1B2BC" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                </button>
            </div>
            <div class="video-call-section-grid">
                <div class="video-call-container">
                    <!-- without Transcription-->
                    <div class="video-call-inner-container-wrap video-call-inner-container-without-transcription">
                        <div class="video-call-timer-wrap">
                            <div class="video-call-timer-user-details">
                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-video-call.png"
                                    alt="user img">
                                <p>Mrs. Samantha Wid</p>
                            </div>
                            <div class="video-call-timer-user-time">
                                <p>11:05</p>
                            </div>
                        </div>
                        <div class="video-call-main-wrap">
                            <div class="video-call-desktop-video-container">
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/video-call-img.png" alt=""
                            class="dummy-video-call-img">
                            
                     
                            <!--screen share-->
                            <div class="video-call-screen-share-desktop">
                                <p class="video-call-screen-share-user-name">Mrs. Samantha Wid</p>
                                    <div class="video-call-screen-share-desktop-center">
                                        <div>
                                    <p>You are currently presenting your screen</p><div class="video-call-screen-stop-btn-wrap custome-checkbox-container">
                                        <label class="video-call-screen-stop-btn" for="stop-persenting">
                                    
                                        <div class="video-call-transcript-checkbox">
                                            <input type="checkbox" id="stop-persenting" name="stop-persenting">
                                            <span class="checkmark"></span>
                                        </div>
                                        Stop persenting
                                        </label>
                                    </div>
                                    </div>
                                </div>
                            </div>
                            <!--hide video-->
                            <div class="video-call-video-hide-desktop">
                                <p class="video-call-screen-share-user-name">Mrs. Samantha Wid</p>
                                <div class="video-call-video-hide-desktop-center">
                                    <div class="video-call-video-hide-desktop-user-wrap">
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/patient-mobile-call-img.jpg" alt="">
                                    </div>
                                    <p>Marthe Slyvester</p>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div class="video-call-caller-wrap">
                        <span class="microphone-off-icon show">
                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/microphone-off-icon.svg" alt="microphonr off icon">
                            </span>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/videocallreciever.png" alt=""
                            class="dummy-video-call-img">
                            <div class="video-call-screen-share-caller-wrap">
                                <div class="video-call-screen-share-caller-center">
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-mobile-call-img.jpg" alt="">
                                    <p>You</p>
                                </div>
                            </div>
                            <div class="video-call-video-hide-caller-wrap">
                                <div class="video-call-screen-share-caller-center">
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-mobile-call-img.jpg" alt="">
                                    <p>You</p>
                                </div>
                            </div>
                        </div>
                        <!--multiple peoples desktop-->
                        <div class="multiple-calls-grid-two-desktop" style="display:none">
                            <div class="multiple-calls-grid-desktop">
                                <p class="multiple-calls-grid-user-name">Maxie Maclaine</p>
                            </div>
                            <div class="multiple-calls-grid-desktop">
                                <p class="multiple-calls-grid-user-name">You</p>
                            </div>
                        </div>
                        <div class="multiple-calls-grid-three-desktop" style="display:none">
                            <div class="multiple-calls-grid-desktop">
                                <p class="multiple-calls-grid-user-name">Maxie Maclaine</p>
                            </div>
                            <div class="multiple-calls-grid-desktop">
                                <p class="multiple-calls-grid-user-name">Robinet Mish</p>
                            </div>
                            <div class="multiple-calls-grid-desktop">
                                <p class="multiple-calls-grid-user-name">You</p>
                            </div>
                        </div>
                        <div class="multiple-calls-grid-four-desktop" style="display:none">
                            <div class="multiple-calls-grid-desktop">
                                <p class="multiple-calls-grid-user-name">Maxie Maclaine</p>
                            </div>
                            <div class="multiple-calls-grid-desktop">
                                <p class="multiple-calls-grid-user-name">Robinet Mish</p>
                            </div>
                            <div class="multiple-calls-grid-desktop">
                                <p class="multiple-calls-grid-user-name">Jack</p>
                            </div>
                            <div class="multiple-calls-grid-desktop">
                                <p class="multiple-calls-grid-user-name">You</p>
                            </div>
                        </div>
                        <div class="multiple-calls-grid-five-desktop" style="display:none">
                            <div class="multiple-calls-grid-desktop">
                                <p class="multiple-calls-grid-user-name">Maxie Maclaine</p>
                            </div>
                            <div class="multiple-calls-grid-desktop">
                                <p class="multiple-calls-grid-user-name">Robinet Mish</p>
                            </div>
                            <div class="multiple-calls-grid-desktop">
                                <p class="multiple-calls-grid-user-name">Maxie Maclaine</p>
                            </div>
                           
                            <div class="multiple-calls-grid-desktop">
                                <p class="multiple-calls-grid-user-name">Jack</p>
                            </div>
                            <div class="multiple-calls-grid-desktop">
                                <p class="multiple-calls-grid-user-name">You</p>
                            </div>
                        </div>
                        <div class="multiple-calls-grid-six-desktop" style="display:none">
                            <div class="multiple-calls-grid-desktop">
                                <p class="multiple-calls-grid-user-name">Maxie Maclaine</p>
                            </div>
                            <div class="multiple-calls-grid-desktop">
                                <p class="multiple-calls-grid-user-name">Robinet Mish</p>
                            </div>
                            <div class="multiple-calls-grid-desktop">
                                <p class="multiple-calls-grid-user-name">Maxie Maclaine</p>
                            </div>
                            <div class="multiple-calls-grid-desktop">
                                <p class="multiple-calls-grid-user-name">Robinet Mish</p>
                            </div>
                            <div class="multiple-calls-grid-desktop">
                                <p class="multiple-calls-grid-user-name">Jack</p>
                            </div>
                            <div class="multiple-calls-grid-desktop">
                                <p class="multiple-calls-grid-user-name">You</p>
                            </div>
                        </div>
                        <!--multiple peoples desktop end-->
                    </div> 
                 
                    <!--with Transcription-->
                    <div class="video-call-inner-container-wrap video-call-inner-container-with-transcription">
                        <div class="video-call-timer-wrap">
                            <div class="video-call-timer-user-details">
                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-video-call.png"
                                    alt="user img">
                                <p>Mrs. Samantha Wid</p>
                            </div>
                            <div class="video-call-timer-user-time">
                                <p>11:05</p>
                            </div>
                        </div>
                        <div class="video-call-inner-container-with-transcription-flex-window">
                            <div class="video-call-inner-container-with-transcription-caller-wrap">
                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/video-call-img.png" alt=""
                                    class="dummy-video-call-img">
                            </div>
                            <div class="video-call-inner-container-with-transcription-receiver-wrap">
                                <!-- <img src="<?php echo base_url(); ?>assets/images/virtual_consult/videocallreciever.png" alt=""
                                class="dummy-video-call-img"> -->
                                 <!--more people screen-->
                            <div class="video-call-section-mobile-receiver-with-transcription-more-people">
                                <div class="transcription-more-people-center">
                                <ul class="transcription-more-people-list">
                                    <li>
                                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-mobile-call-img.jpg" alt="user">
                                    </li>
                                    <li>
                                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg02.png" alt="user">
                                    </li>
                                    <li>
                                        <div class="transcription-more-people-list-wrap">
                                            +2
                                        </div>
                                    </li>                                    
                                </ul>
                                <p>+2 participant</p>
                                </div>
                            </div>
                            </div>
                        </div>    
                        <div class="video-call-inner-container-transcription-wrap">
                            <div class="video-call-transcription-wrap">
                                <div class="video-call-transcription-head">
                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/voice-translation-animation-blue.svg" alt="voice translation icon">
                                    <h6>Transcription</h6>
                                </div>
                                <div class="video-call-transcription-body">
                                    <ul class="video-call-transcription-list">
                                        <li><span>User1:</span>
                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
                                        </li>
                                        <li><span>User1:</span>Lorem ipsum dolor sit amet</li>
                                        <li><span>User1:</span>Lorem ipsum dolor sit amet</li>
                                        <li><span>User1:</span>Lorem ipsum dolor sit amet</li>
                                        <li><span>User1:</span>Lorem ipsum dolor sit amet</li>
                                        <li><span>User1:</span>Lorem ipsum dolor sit amet</li>
                                        <li><span>User1:</span>Lorem ipsum dolor sit amet</li>
                                        <li><span>User1:</span>Lorem ipsum dolor sit amet</li>
                                        <li><span>User1:</span>Lorem ipsum dolor sit amet</li>
                                        <li><span>User1:</span>Lorem ipsum dolor sit amet</li>
                                    </ul>
                                </div>
                            </div>
                            <div class="video-call-translation-wrap">
                                 <div class="video-call-translation-head">
                                    <div class="video-call-translation-head-left">
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/translation-icon.svg" alt="translation icon">
                                        <h6>Transcription</h6>
                                    </div>
                                    <div class="video-call-translation-head-right">
                                        <select class="input-text-style">
                                            <option>English</option>
                                        </select>
                                        <div class="video-call-translation-head-right-icon">
                                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M3.33398 7.99967H12.6673M12.6673 7.99967L8.00065 3.33301M12.6673 7.99967L8.00065 12.6663" stroke="#667085" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                        </div>
                                        <select class="input-text-style">
                                            <option>Chinese</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="video-call-transcription-body">
                                    <ul class="video-call-transcription-list">
                                        <li><span>User1:</span>
                                        打印和排版行业的虚拟文本只是“Lorem Ipsum”。自16世纪以来，“Lorem Ipsum”一直是该行业的标准虚拟文本。                                        </li>
                                        <li><span>User1:</span>打印和排版行业的虚拟文本只是“Lorem Ipsum”</li>
                                        <li><span>User1:</span>打印和排版行业的虚拟文本只是“Lorem Ipsum”</li>
                                        <li><span>User1:</span>打印和排版行业的虚拟文本只是“Lorem Ipsum”</li>
                                        <li><span>User1:</span>打印和排版行业的虚拟文本只是“Lorem Ipsum”</li>
                                        <li><span>User1:</span>打印和排版行业的虚拟文本只是“Lorem Ipsum”</li>
                                        <li><span>User1:</span>打印和排版行业的虚拟文本只是“Lorem Ipsum”</li>
                                        <li><span>User1:</span>打印和排版行业的虚拟文本只是“Lorem Ipsum”</li>
                                        <li><span>User1:</span>打印和排版行业的虚拟文本只是“Lorem Ipsum”</li>
                                        <li><span>User1:</span>打印和排版行业的虚拟文本只是“Lorem Ipsum”</li>
                                    </ul>
                                </div>
                            </div>
                        </div>                      
                    </div>
                    <div class="video-call-action-buttons-wrap video-call-action-buttons-full-width">
                
                        <div class="video-call-action-buttons-center">
                            <ul>
                                <li>
                                    <button type="button" class="video-call-action-round-btn video-call-voice-mute-btn-desktop">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_13307_26490)">
                                            <path d="M12.4993 7.83366V4.16699C12.4993 2.78628 11.3801 1.66699 9.99935 1.66699C9.018 1.66699 8.16872 2.23242 7.75952 3.05527M9.99935 15.8337V18.3337M9.99935 15.8337C6.77769 15.8337 4.16602 13.222 4.16602 10.0003V8.33366M9.99935 15.8337C13.221 15.8337 15.8327 13.222 15.8327 10.0003V8.33366M6.66602 18.3337H13.3327M1.66602 1.66699L18.3327 18.3337M9.99935 12.5003C8.61864 12.5003 7.49935 11.381 7.49935 10.0003V7.50033L11.7682 11.767C11.3157 12.2201 10.6902 12.5003 9.99935 12.5003Z" stroke="#344054" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                            </g>
                                            <defs>
                                            <clipPath id="clip0_13307_26490">
                                            <rect width="20" height="20" fill="white"/>
                                            </clipPath>
                                            </defs>
                                        </svg>
                                    </button>
                                </li>
                                <li>
                                    <button type="button" class="video-call-action-round-btn video-call-video-hide-btn-desktop">
                                    <svg class="video-call-hide-icon-desktop" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_13307_12315)">
                                        <path d="M4.16602 4.16699C2.7853 4.16699 1.66602 5.28628 1.66602 6.66699V13.3337C1.66602 14.7144 2.7853 15.8337 4.16602 15.8337H11.666C12.7932 15.8337 13.7462 15.0876 14.0581 14.0624M14.166 10.0003L17.1946 6.97173C17.5516 6.61475 17.7301 6.43626 17.8833 6.4242C18.0163 6.41373 18.1462 6.46756 18.2329 6.56898C18.3327 6.68587 18.3327 6.93829 18.3327 7.44313V12.5575C18.3327 13.0624 18.3327 13.3148 18.2329 13.4317C18.1462 13.5331 18.0163 13.5869 17.8833 13.5765C17.7301 13.5644 17.5516 13.3859 17.1946 13.0289L14.166 10.0003ZM14.166 10.0003V8.16699C14.166 6.76686 14.166 6.0668 13.8935 5.53202C13.6538 5.06161 13.2714 4.67916 12.801 4.43948C12.2662 4.16699 11.5661 4.16699 10.166 4.16699H7.91602M1.66602 1.66699L18.3327 18.3337" stroke="#344054" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                        </g>
                                        <defs>
                                        <clipPath id="clip0_13307_12315">
                                        <rect width="20" height="20" fill="white"/>
                                        </clipPath>
                                        </defs>
                                        </svg>
                                    </button>
                                </li>
                                <li>
                                    <button type="button" class="video-call-action-round-btn video-call-screen-share-btn-desktop">
                                    <svg  width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M4.16602 15C2.7853 15 1.66602 13.8807 1.66602 12.5V6.5C1.66602 5.09987 1.66602 4.3998 1.9385 3.86502C2.17818 3.39462 2.56063 3.01217 3.03104 2.77248C3.56582 2.5 4.26588 2.5 5.66602 2.5H14.3327C15.7328 2.5 16.4329 2.5 16.9677 2.77248C17.4381 3.01217 17.8205 3.39462 18.0602 3.86502C18.3327 4.3998 18.3327 5.09987 18.3327 6.5V12.5C18.3327 13.8807 17.2134 15 15.8327 15M7.25604 17.5H12.7427C13.1967 17.5 13.4237 17.5 13.5383 17.4074C13.6379 17.3269 13.695 17.2051 13.693 17.0771C13.6908 16.9298 13.5455 16.7554 13.2548 16.4065L10.5115 13.1146C10.3356 12.9035 10.2477 12.798 10.1424 12.7595C10.05 12.7257 9.94868 12.7257 9.85631 12.7595C9.75102 12.798 9.66308 12.9035 9.4872 13.1146L6.7439 16.4065C6.45322 16.7554 6.30789 16.9298 6.30566 17.0771C6.30373 17.2051 6.36079 17.3269 6.4604 17.4074C6.57497 17.5 6.802 17.5 7.25604 17.5Z" stroke="#344054" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                    
                                    </button>
                                </li>
                                <li>
                                    <button type="button" class="video-call-action-round-btn">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M13.3333 6.66667L17.5 2.5M17.5 2.5H13.3333M17.5 2.5V6.66667M6.66667 6.66667L2.5 2.5M2.5 2.5L2.5 6.66667M2.5 2.5L6.66667 2.5M6.66667 13.3333L2.5 17.5M2.5 17.5H6.66667M2.5 17.5L2.5 13.3333M13.3333 13.3333L17.5 17.5M17.5 17.5V13.3333M17.5 17.5H13.3333" stroke="#344054" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                    </button>
                                </li>
                                <li>
                                    <button type="button" class="end-video-call-btn">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M17.499 2.5L12.499 7.5M12.499 2.5L17.499 7.5M8.52155 11.5526C7.52023 10.5512 6.72958 9.41904 6.14958 8.21102C6.09969 8.10712 6.07475 8.05516 6.05558 7.98942C5.98748 7.75579 6.0364 7.46891 6.17807 7.27105C6.21794 7.21537 6.26557 7.16774 6.36083 7.07248C6.65217 6.78115 6.79784 6.63548 6.89308 6.48899C7.25224 5.93659 7.25224 5.22443 6.89308 4.67203C6.79784 4.52554 6.65217 4.37988 6.36083 4.08854L6.19844 3.92615C5.75557 3.48328 5.53414 3.26184 5.29632 3.14156C4.82335 2.90233 4.2648 2.90233 3.79183 3.14156C3.55401 3.26184 3.33258 3.48328 2.88971 3.92615L2.75835 4.05751C2.31699 4.49886 2.09632 4.71954 1.92778 5.01956C1.74076 5.35249 1.60629 5.86956 1.60743 6.25141C1.60845 6.59554 1.67521 6.83072 1.80871 7.30109C2.52619 9.82892 3.87992 12.2142 5.8699 14.2042C7.85988 16.1942 10.2452 17.5479 12.773 18.2654C13.2434 18.3989 13.4786 18.4657 13.8227 18.4667C14.2045 18.4678 14.7216 18.3333 15.0545 18.1463C15.3546 17.9778 15.5752 17.7571 16.0166 17.3158L16.148 17.1844C16.5908 16.7415 16.8123 16.5201 16.9325 16.2823C17.1718 15.8093 17.1718 15.2508 16.9325 14.7778C16.8123 14.54 16.5908 14.3185 16.148 13.8757L15.9856 13.7133C15.6942 13.4219 15.5486 13.2763 15.4021 13.181C14.8497 12.8219 14.1375 12.8219 13.5851 13.181C13.4386 13.2763 13.293 13.4219 13.0016 13.7133C12.9064 13.8085 12.8587 13.8562 12.8031 13.896C12.6052 14.0377 12.3183 14.0866 12.0847 14.0185C12.0189 13.9994 11.967 13.9744 11.8631 13.9245C10.6551 13.3445 9.52286 12.5539 8.52155 11.5526Z" stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>End Call
                                    </button>
                                </li>
                            <ul>
                        </div>
                        
                    </div>
                </div>
                <div class="video-chat-container">
                    <div class="video-chat-container-head">
                        <div class="video-chat-container-head-img">
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-video-call.png"
                                alt="" class="dummy-video-call-img">
                            <span class="avaliable-dot"></span>
                        </div>
                        <div class="video-chat-container-head-content">
                            <h6>Mrs. Samantha Wid</h6>
                            <a>View patient profile</a>
                        </div>
                    </div>
                    <div class="video-chat-container-body">
                        <ul class="video-chat-chatbox">
                            <li class="chat-incoming">
                                Hi!<br>how are you today? Do you have a cough?
                                <span class="video-chat-chatbox-time">2:20pm</span>
                            </li>
                            <li class="chat-outgoing">
                                I am suffering from cough and fever.
                                <span class="video-chat-chatbox-time">2:21pm</span>
                            </li>
                            <li class="chat-incoming">
                                Hi!<br>how are you today? Do you have a cough?
                                <span class="video-chat-chatbox-time">2:20pm</span>
                            </li>
                            <li class="chat-outgoing">
                                I am suffering from cough and fever.
                                <span class="video-chat-chatbox-time">2:21pm</span>
                            </li>
                            <li class="chat-incoming">
                                Hi!<br>how are you today? Do you have a cough?
                                <span class="video-chat-chatbox-time">2:20pm</span>
                            </li>
                            <li class="chat-incoming">
                                Hi!<br>how are you today? Do you have a cough?
                                <span class="video-chat-chatbox-time">2:20pm</span>
                            </li>
                            <li class="chat-outgoing">
                                I am suffering from cough and fever.
                                <span class="video-chat-chatbox-time">2:21pm</span>
                            </li>
                            <li class="chat-incoming">
                                Hi!<br>how are you today? Do you have a cough?
                                <span class="video-chat-chatbox-time">2:20pm</span>
                            </li>
                            <li class="chat-outgoing">
                                I am suffering from cough and fever.
                                <span class="video-chat-chatbox-time">2:21pm</span>
                            </li>
                            <li class="chat-incoming">
                                Hi!<br>how are you today? Do you have a cough?
                                <span class="video-chat-chatbox-time">2:20pm</span>
                            </li>
                            <li class="chat-outgoing">
                                I am suffering from cough and fever.
                                <span class="video-chat-chatbox-time">2:21pm</span>
                            </li>
                            <li class="chat-incoming">
                                Hi!<br>how are you today? Do you have a cough?
                                <span class="video-chat-chatbox-time">2:20pm</span>
                            </li>
                            <li class="chat-outgoing">
                                I am suffering from cough and fever.
                                <span class="video-chat-chatbox-time">2:21pm</span>
                            </li>
                            <li class="chat-incoming">
                                <div class="typing-indicator">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </div>
                            </li>
                        </ul>
                        
                    </div>
                    <div class="video-chat-type-container">
                            <div class="video-chat-typing-input">
                                <input type="text" placeholder="Start typing here...">
                                <button class="send-message"><svg width="24" height="25" viewBox="0 0 24 25" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M24 12.9273C23.9734 13.3845 23.8171 13.8247 23.5493 14.1963C23.2815 14.5678 22.9134 14.8554 22.488 15.0253L3.24267 24.6479C2.82666 24.8679 2.36525 24.9883 1.89479 24.9996C1.60801 25.0061 1.32373 24.9449 1.06508 24.8209C0.806423 24.6968 0.580698 24.5135 0.406262 24.2858C0.189394 23.9635 0.0546572 23.593 0.0137987 23.2067C-0.0270599 22.8204 0.0272002 22.4299 0.171848 22.0694L2.34017 14.8377C2.41508 14.5978 2.46227 14.35 2.48082 14.0993H14.3539C14.6647 14.0993 14.9628 13.9758 15.1827 13.756C15.4025 13.5362 15.5259 13.2381 15.5259 12.9273C15.5259 12.6164 15.4025 12.3183 15.1827 12.0985C14.9628 11.8787 14.6647 11.7552 14.3539 11.7552H2.48082C2.46103 11.5047 2.41386 11.2571 2.34017 11.0168L0.171848 3.78513C0.026796 3.42487 -0.027683 3.03454 0.0131853 2.64833C0.0540536 2.26213 0.189022 1.89184 0.406262 1.56992C0.753792 1.17447 1.23365 0.919385 1.75583 0.852493C2.27802 0.785601 2.80668 0.9115 3.24267 1.20658L22.4892 10.8293C22.9144 10.9992 23.2824 11.2868 23.5499 11.6584C23.8175 12.03 23.9736 12.4701 24 12.9273Z"
                                            fill="#1B71BA" />
                                    </svg></button>
                            </div>
                            <div class="video-chat-typing-attachment">
                                <button type="button" class="video-chat-attachment-toggle-btn"><svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M9.99935 11.751C10.4596 11.751 10.8327 11.3779 10.8327 10.9176C10.8327 10.4574 10.4596 10.0843 9.99935 10.0843C9.53911 10.0843 9.16602 10.4574 9.16602 10.9176C9.16602 11.3779 9.53911 11.751 9.99935 11.751Z" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M9.99935 5.91764C10.4596 5.91764 10.8327 5.54455 10.8327 5.08431C10.8327 4.62407 10.4596 4.25098 9.99935 4.25098C9.53911 4.25098 9.16602 4.62407 9.16602 5.08431C9.16602 5.54455 9.53911 5.91764 9.99935 5.91764Z" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M9.99935 17.5843C10.4596 17.5843 10.8327 17.2112 10.8327 16.751C10.8327 16.2907 10.4596 15.9176 9.99935 15.9176C9.53911 15.9176 9.16602 16.2907 9.16602 16.751C9.16602 17.2112 9.53911 17.5843 9.99935 17.5843Z" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg></button>
                                <div class="video-chat-typing-attachment-content">
                                    <ul>
                                        <li>
                                            <a href="#">
                                            <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M1.66602 7.33644C1.66602 6.09298 2.67404 5.08496 3.9175 5.08496C4.56357 5.08496 5.13715 4.67154 5.34146 4.05863L5.41602 3.83496C5.45117 3.72948 5.46875 3.67675 5.48756 3.62996C5.72772 3.03256 6.29051 2.62693 6.93319 2.58801C6.98353 2.58496 7.03912 2.58496 7.1503 2.58496H12.8484C12.9596 2.58496 13.0152 2.58496 13.0655 2.58801C13.7082 2.62693 14.271 3.03256 14.5111 3.62996C14.5299 3.67675 14.5475 3.72948 14.5827 3.83496L14.6572 4.05863C14.8615 4.67154 15.4351 5.08496 16.0812 5.08496C17.3247 5.08496 18.3327 6.09298 18.3327 7.33644V14.4183C18.3327 15.8184 18.3327 16.5185 18.0602 17.0533C17.8205 17.5237 17.4381 17.9061 16.9677 18.1458C16.4329 18.4183 15.7328 18.4183 14.3327 18.4183H5.66602C4.26588 18.4183 3.56582 18.4183 3.03104 18.1458C2.56063 17.9061 2.17818 17.5237 1.9385 17.0533C1.66602 16.5185 1.66602 15.8184 1.66602 14.4183V7.33644Z" stroke="#667085" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                                <path d="M9.99935 14.6683C12.0704 14.6683 13.7493 12.9894 13.7493 10.9183C13.7493 8.84723 12.0704 7.16829 9.99935 7.16829C7.92828 7.16829 6.24935 8.84723 6.24935 10.9183C6.24935 12.9894 7.92828 14.6683 9.99935 14.6683Z" stroke="#667085" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                Camera
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                            <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M3.55943 18.1912L9.05654 12.6941C9.38656 12.3641 9.55156 12.1991 9.74184 12.1373C9.9092 12.0829 10.0895 12.0829 10.2569 12.1373C10.4471 12.1991 10.6121 12.3641 10.9422 12.6941L16.4026 18.1546M11.666 13.418L14.0565 11.0274C14.3866 10.6974 14.5516 10.5324 14.7418 10.4706C14.9092 10.4162 15.0895 10.4162 15.2569 10.4706C15.4471 10.5324 15.6121 10.6974 15.9422 11.0274L18.3327 13.418M8.33268 8.41797C8.33268 9.33844 7.58649 10.0846 6.66602 10.0846C5.74554 10.0846 4.99935 9.33844 4.99935 8.41797C4.99935 7.49749 5.74554 6.7513 6.66602 6.7513C7.58649 6.7513 8.33268 7.49749 8.33268 8.41797ZM5.66602 18.418H14.3327C15.7328 18.418 16.4329 18.418 16.9677 18.1455C17.4381 17.9058 17.8205 17.5233 18.0602 17.0529C18.3327 16.5182 18.3327 15.8181 18.3327 14.418V7.41797C18.3327 6.01784 18.3327 5.31777 18.0602 4.78299C17.8205 4.31259 17.4381 3.93014 16.9677 3.69045C16.4329 3.41797 15.7328 3.41797 14.3327 3.41797H5.66602C4.26588 3.41797 3.56582 3.41797 3.03104 3.69045C2.56063 3.93014 2.17818 4.31259 1.9385 4.78299C1.66602 5.31777 1.66602 6.01784 1.66602 7.41797V14.418C1.66602 15.8181 1.66602 16.5182 1.9385 17.0529C2.17818 17.5233 2.56063 17.9058 3.03104 18.1455C3.56582 18.418 4.26588 18.418 5.66602 18.418Z" stroke="#667085" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                                Gallery
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                            <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M17.6261 10.0004L10.1131 17.5134C8.40458 19.222 5.63448 19.222 3.92594 17.5134C2.2174 15.8049 2.2174 13.0348 3.92594 11.3263L11.4389 3.81326C12.578 2.67423 14.4247 2.67423 15.5637 3.81326C16.7028 4.95229 16.7028 6.79902 15.5637 7.93805L8.34536 15.1564C7.77584 15.7259 6.85248 15.7259 6.28296 15.1564C5.71345 14.5869 5.71345 13.6635 6.28296 13.094L12.6175 6.75953" stroke="#667085" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                File
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                            <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <g clip-path="url(#clip0_13353_24751)">
                                                <path d="M10.0007 11.7516C11.3814 11.7516 12.5007 10.6323 12.5007 9.25163C12.5007 7.87092 11.3814 6.75163 10.0007 6.75163C8.61994 6.75163 7.50065 7.87092 7.50065 9.25163C7.50065 10.6323 8.61994 11.7516 10.0007 11.7516Z" stroke="#667085" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                                <path d="M10.0007 19.2516C13.334 15.9183 16.6673 12.9335 16.6673 9.25163C16.6673 5.56973 13.6825 2.58496 10.0007 2.58496C6.31875 2.58496 3.33398 5.56973 3.33398 9.25163C3.33398 12.9335 6.66732 15.9183 10.0007 19.2516Z" stroke="#667085" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                                </g>
                                                <defs>
                                                <clipPath id="clip0_13353_24751">
                                                <rect width="20" height="20" fill="white" transform="translate(0 0.917969)"/>
                                                </clipPath>
                                                </defs>
                                                </svg>
                                                Location
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </section>

    <!--mobile view-->
    <section class="video-call-section-mobile">
        <div class="video-call-section-mobile-wrap">
            <div class="video-call-section-mobile-inner">
                <div class="video-call-section-mobile-without-transcription">
                    <div class="video-call-section-mobile-caller-wrap">
                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/patient-mobile-call-img.jpg" alt="">
                        
                    </div>
                    <div class="video-call-section-mobile-receiver-wrap">
                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-mobile-call-img.jpg" alt="">
                        <span class="microphone-off-icon">
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/microphone-off-icon.svg" alt="microphonr off icon">
                        </span>
                    </div>
                </div>
                <!--multiple people-->
                <!-- <div class="video-call-section-mobile-without-transcription-multiple-calls">
                    <div class="multiple-calls-grid-three" style="display:none">
                        <div class="multiple-calls-grid-col">
                            <p class="multiple-calls-grid-user-name">Maxie Maclaine</p>
                        </div>
                        <div class="multiple-calls-grid-col">
                            <p class="multiple-calls-grid-user-name">Robinet Mish</p>
                        </div>
                        <div class="multiple-calls-grid-col">
                            <p class="multiple-calls-grid-user-name">You</p>
                        </div>
                    </div>
                    <div class="multiple-calls-grid-four" style="display:none;">
                        <div class="multiple-calls-grid-col">
                            <p class="multiple-calls-grid-user-name">Maxie Maclaine</p>
                        </div>
                        <div class="multiple-calls-grid-col">
                            <p class="multiple-calls-grid-user-name">Robinet Mish</p>
                        </div>
                        <div class="multiple-calls-grid-col">
                            <p class="multiple-calls-grid-user-name">Ali Dudman</p>
                        </div>
                        <div class="multiple-calls-grid-col">
                            <p class="multiple-calls-grid-user-name">You</p>
                        </div>
                    </div>
                    <div class="multiple-calls-grid-five" style="display:none">
                        <div class="multiple-calls-grid-col">
                            <p class="multiple-calls-grid-user-name">Maxie Maclaine</p>
                        </div>
                        <div class="multiple-calls-grid-col">
                            <p class="multiple-calls-grid-user-name">Robinet Mish</p>
                        </div>
                        <div class="multiple-calls-grid-col">
                            <p class="multiple-calls-grid-user-name">Ali Dudman</p>
                        </div>
                        <div class="multiple-calls-grid-col">
                            <p class="multiple-calls-grid-user-name">You</p>
                        </div>
                        <div class="multiple-calls-grid-col">
                            <p class="multiple-calls-grid-user-name">You</p>
                        </div>
                    </div>
                    <div class="multiple-calls-grid-six" style="display:none">
                        <div class="multiple-calls-grid-col">
                            <p class="multiple-calls-grid-user-name">Maxie Maclaine</p>
                        </div>
                        <div class="multiple-calls-grid-col">
                            <p class="multiple-calls-grid-user-name">Robinet Mish</p>
                        </div>
                        <div class="multiple-calls-grid-col">
                            <p class="multiple-calls-grid-user-name">Ali Dudman</p>
                        </div>
                        <div class="multiple-calls-grid-col">
                            <p class="multiple-calls-grid-user-name">You</p>
                        </div>
                        <div class="multiple-calls-grid-col">
                            <p class="multiple-calls-grid-user-name">You</p>
                        </div>
                        <div class="multiple-calls-grid-col">
                            <p class="multiple-calls-grid-user-name">You</p>
                        </div>
                    </div>
                </div> -->
               

                 <!--screen share -->
                 <div class="video-call-screen-share">
                    <div class="video-call-section-mobile-caller-wrap">
                        <div>
                        <p>You are currently presenting your screen<p>
                        <div class="video-call-screen-stop-btn-wrap custome-checkbox-container">
                            <label class="video-call-screen-stop-btn" for="stop-persenting">
                           
                            <div class="video-call-transcript-checkbox">
                                <input type="checkbox" id="stop-persenting" name="stop-persenting">
                                <span class="checkmark"></span>
                            </div>
                            Stop persenting
                            </label>
                        </div>
                        </div>
                    </div>
                    <div class="video-call-section-mobile-receiver-wrap">
                        <div class="video-call-screen-receiver-center">
                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-mobile-call-img.jpg" alt="">
                        <p>You</p>
                        </div>
                    </div>
                </div>
                <!--screen end share -->
                <!--screen mute -->
                <div class="video-call-mute-screen">
                    <div class="video-call-section-mobile-caller-wrap">
                        <div class="mute-call-caller-flex">
                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/patient-mobile-call-img.jpg" alt="">
                            <p>Marthe Slyvester<p>
                            <span class="microphone-off-icon">
                            <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g id="microphone-off-01" clip-path="url(#clip0_13419_27997)">
                            <path id="Icon" d="M7.5 4.7V2.5C7.5 1.67157 6.82843 1 6 1C5.41119 1 4.90162 1.33926 4.6561 1.83297M6 9.5V11M6 9.5C4.067 9.5 2.5 7.933 2.5 6V5M6 9.5C7.933 9.5 9.5 7.933 9.5 6V5M4 11H8M1 1L11 11M6 7.5C5.17157 7.5 4.5 6.82843 4.5 6V4.5L7.0613 7.06002C6.7898 7.33184 6.41454 7.5 6 7.5Z" stroke="white" stroke-width="0.835" stroke-linecap="round" stroke-linejoin="round"/>
                            </g>
                            <defs>
                            <clipPath id="clip0_13419_27997">
                            <rect width="12" height="12" fill="white"/>
                            </clipPath>
                            </defs>
                            </svg>
                        </span>
                        </div>
                    </div>
                    <div class="video-call-section-mobile-receiver-wrap">
                        <div class="video-call-screen-receiver-center">
                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-mobile-call-img.jpg" alt="">
                        <p>You</p>
                        <span class="microphone-off-icon">
                            <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g id="microphone-off-01" clip-path="url(#clip0_13419_27997)">
                            <path id="Icon" d="M7.5 4.7V2.5C7.5 1.67157 6.82843 1 6 1C5.41119 1 4.90162 1.33926 4.6561 1.83297M6 9.5V11M6 9.5C4.067 9.5 2.5 7.933 2.5 6V5M6 9.5C7.933 9.5 9.5 7.933 9.5 6V5M4 11H8M1 1L11 11M6 7.5C5.17157 7.5 4.5 6.82843 4.5 6V4.5L7.0613 7.06002C6.7898 7.33184 6.41454 7.5 6 7.5Z" stroke="white" stroke-width="0.835" stroke-linecap="round" stroke-linejoin="round"/>
                            </g>
                            <defs>
                            <clipPath id="clip0_13419_27997">
                            <rect width="12" height="12" fill="white"/>
                            </clipPath>
                            </defs>
                            </svg>
                        </span>
                        </div>
                    </div>
                </div>
                <!--screen end mute -->
                <div class="video-call-section-mobile-head">
                    <a href="#" class="video-call-mobile-round-btn">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M3.33333 11.6667H8.33333M8.33333 11.6667V16.6667M8.33333 11.6667L2.5 17.5M16.6667 8.33333H11.6667M11.6667 8.33333V3.33333M11.6667 8.33333L17.5 2.5" stroke="white" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    </a>
                    <p>Marthe Slyvester</p>
                   <p></p>
                    <div class="microphone-off-head-icon-wrap">
                    <span class="microphone-off-icon">
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/microphone-off-icon.svg" alt="microphonr off icon">
                        </span>
                    </div>
                </div>
                <div class="video-call-section-mobile-right">
                    <a href="#" class="video-call-mobile-round-btn">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_13353_9194)">
                    <path d="M15.8333 3.33333H15.4167L13.6667 0.999167C13.1967 0.373333 12.4492 0 11.6675 0H8.33417C7.5525 0 6.805 0.373333 6.33417 1L4.58417 3.33333H4.1675C1.86917 3.33333 0 5.2025 0 7.5V15.8333C0 18.1308 1.86917 20 4.16667 20H15.8333C18.1308 20 20 18.1308 20 15.8333V7.5C20 5.2025 18.1308 3.33333 15.8333 3.33333ZM7.66583 2C7.8225 1.79083 8.0725 1.66667 8.33333 1.66667H11.6667C11.9275 1.66667 12.1767 1.79083 12.3333 1.99917L13.3333 3.33333H6.66667L7.66583 2ZM18.3333 15.8333C18.3333 17.2117 17.2117 18.3333 15.8333 18.3333H4.16667C2.78833 18.3333 1.66667 17.2117 1.66667 15.8333V7.5C1.66667 6.12167 2.78833 5 4.16667 5H15.8333C17.2117 5 18.3333 6.12167 18.3333 7.5V15.8333ZM15 7.5V9.16667C15 10.0858 14.2525 10.8333 13.3333 10.8333H11.6667C11.2067 10.8333 10.8333 10.4608 10.8333 10C10.8333 9.53917 11.2067 9.16667 11.6667 9.16667H12.2025C11.6017 8.63833 10.82 8.33333 10 8.33333C8.67417 8.33333 7.475 9.11833 6.94417 10.3333C6.80667 10.6467 6.50083 10.8333 6.18 10.8333C6.06833 10.8333 5.955 10.8117 5.84667 10.7633C5.425 10.5792 5.2325 10.0875 5.41667 9.66667C6.21333 7.84417 8.0125 6.66667 10 6.66667C11.2433 6.66667 12.4275 7.135 13.3333 7.94333V7.5C13.3333 7.03917 13.7067 6.66667 14.1667 6.66667C14.6267 6.66667 15 7.03917 15 7.5ZM14.5833 13.6667C13.7867 15.4892 11.9875 16.6667 10 16.6667C8.77167 16.6667 7.6 16.21 6.69917 15.42V15.8333C6.69917 16.2942 6.32583 16.6667 5.86583 16.6667C5.40583 16.6667 5.0325 16.2942 5.0325 15.8333V14.1667C5.0325 13.2475 5.78 12.5 6.69917 12.5H8.33333C8.79333 12.5 9.16667 12.8725 9.16667 13.3333C9.16667 13.7942 8.79333 14.1667 8.33333 14.1667H7.7975C8.39833 14.695 9.18 15 10 15C11.3258 15 12.525 14.215 13.0558 13C13.2408 12.5775 13.7317 12.385 14.1533 12.57C14.575 12.7542 14.7675 13.2458 14.5833 13.6667Z" fill="white"/>
                    </g>
                    <defs>
                    <clipPath id="clip0_13353_9194">
                    <rect width="20" height="20" fill="white"/>
                    </clipPath>
                    </defs>
                    </svg>
                    </a>
                   
                </div>
                <div class="video-call-section-mobile-bottom">
                    <ul>
                        
                        <li>
                            <a href="#" class="video-call-mobile-round-btn video-call-screen-share-btn">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M5 18C3.34315 18 2 16.6569 2 15V7.8C2 6.11984 2 5.27976 2.32698 4.63803C2.6146 4.07354 3.07354 3.6146 3.63803 3.32698C4.27976 3 5.11984 3 6.8 3H17.2C18.8802 3 19.7202 3 20.362 3.32698C20.9265 3.6146 21.3854 4.07354 21.673 4.63803C22 5.27976 22 6.11984 22 7.8V15C22 16.6569 20.6569 18 19 18M8.70803 21H15.292C15.8368 21 16.1093 21 16.2467 20.8889C16.3663 20.7923 16.4347 20.6461 16.4324 20.4925C16.4298 20.3157 16.2554 20.1064 15.9065 19.6879L12.6146 15.7375C12.4035 15.4842 12.298 15.3576 12.1716 15.3114C12.0608 15.2709 11.9392 15.2709 11.8284 15.3114C11.702 15.3576 11.5965 15.4842 11.3854 15.7375L8.09346 19.6879C7.74465 20.1064 7.57024 20.3157 7.56758 20.4925C7.56526 20.6461 7.63373 20.7923 7.75326 20.8889C7.89075 21 8.16318 21 8.70803 21Z" stroke="white" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="video-call-mobile-round-btn video-call-mute-btn">
                            <svg class="video-call-mute-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M19 10V12C19 15.866 15.866 19 12 19M5 10V12C5 15.866 8.13401 19 12 19M12 19V22M8 22H16M12 15C10.3431 15 9 13.6569 9 12V5C9 3.34315 10.3431 2 12 2C13.6569 2 15 3.34315 15 5V12C15 13.6569 13.6569 15 12 15Z" stroke="white" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <svg class="video-call-unmute-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M15 9.4V5C15 3.34315 13.6569 2 12 2C10.8224 2 9.80325 2.67852 9.3122 3.66593M12 19V22M12 19C8.13401 19 5 15.866 5 12V10M12 19C15.866 19 19 15.866 19 12V10M8 22H16M2 2L22 22M12 15C10.3431 15 9 13.6569 9 12V9L14.1226 14.12C13.5796 14.6637 12.8291 15 12 15Z" stroke="white" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="video-call-mobile-round-btn video-call-hide-btn">
                            <svg class="video-call-hide-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M22 8.93137C22 8.32555 22 8.02265 21.8802 7.88238C21.7763 7.76068 21.6203 7.69609 21.4608 7.70865C21.2769 7.72312 21.0627 7.93731 20.6343 8.36569L17 12L20.6343 15.6343C21.0627 16.0627 21.2769 16.2769 21.4608 16.2914C21.6203 16.3039 21.7763 16.2393 21.8802 16.1176C22 15.9774 22 15.6744 22 15.0686V8.93137Z" stroke="white" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M2 9.8C2 8.11984 2 7.27976 2.32698 6.63803C2.6146 6.07354 3.07354 5.6146 3.63803 5.32698C4.27976 5 5.11984 5 6.8 5H12.2C13.8802 5 14.7202 5 15.362 5.32698C15.9265 5.6146 16.3854 6.07354 16.673 6.63803C17 7.27976 17 8.11984 17 9.8V14.2C17 15.8802 17 16.7202 16.673 17.362C16.3854 17.9265 15.9265 18.3854 15.362 18.673C14.7202 19 13.8802 19 12.2 19H6.8C5.11984 19 4.27976 19 3.63803 18.673C3.07354 18.3854 2.6146 17.9265 2.32698 17.362C2 16.7202 2 15.8802 2 14.2V9.8Z" stroke="white" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <svg class="video-call-unhide-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M5 5C3.34315 5 2 6.34315 2 8V16C2 17.6569 3.34315 19 5 19H14C15.3527 19 16.4962 18.1048 16.8705 16.8745M17 12L20.6343 8.36569C21.0627 7.93731 21.2769 7.72312 21.4608 7.70865C21.6203 7.69609 21.7763 7.76068 21.8802 7.88238C22 8.02265 22 8.32556 22 8.93137V15.0686C22 15.6744 22 15.9774 21.8802 16.1176C21.7763 16.2393 21.6203 16.3039 21.4608 16.2914C21.2769 16.2769 21.0627 16.0627 20.6343 15.6343L17 12ZM17 12V9.8C17 8.11984 17 7.27976 16.673 6.63803C16.3854 6.07354 15.9265 5.6146 15.362 5.32698C14.7202 5 13.8802 5 12.2 5H9.5M2 2L22 22" stroke="white" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="video-call-mobile-round-btn video-chat-icon-btn">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8 9.5H12M8 13H15M12 21C16.9706 21 21 16.9706 21 12C21 7.02944 16.9706 3 12 3C7.02944 3 3 7.02944 3 12C3 13.1971 3.23374 14.3397 3.65806 15.3845C3.73927 15.5845 3.77988 15.6845 3.798 15.7653C3.81572 15.8443 3.8222 15.9028 3.82221 15.9839C3.82222 16.0667 3.80718 16.1569 3.77711 16.3374L3.18413 19.8952C3.12203 20.2678 3.09098 20.4541 3.14876 20.5888C3.19933 20.7067 3.29328 20.8007 3.41118 20.8512C3.54589 20.909 3.73218 20.878 4.10476 20.8159L7.66265 20.2229C7.84309 20.1928 7.9333 20.1778 8.01613 20.1778C8.09715 20.1778 8.15566 20.1843 8.23472 20.202C8.31554 20.2201 8.41552 20.2607 8.61549 20.3419C9.6603 20.7663 10.8029 21 12 21Z" stroke="white" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="video-call-mobile-round-btn active-video-call-mobile-btn">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M4.85864 6C6.67357 4.14864 9.20268 3 12.0001 3C14.7975 3 17.3266 4.14864 19.1415 6M16.4723 9C15.3736 7.7725 13.777 7 12 7C10.223 7 8.62647 7.7725 7.52783 9M12 17C13.5105 17 14.9608 17.2576 16.3094 17.7313C16.3542 17.747 16.3767 17.7549 16.412 17.7705C16.7326 17.9118 16.9788 18.2591 17.0058 18.6084C17.0088 18.647 17.0088 18.6811 17.0088 18.7494C17.0088 18.9821 17.0088 19.0985 17.0185 19.1965C17.1122 20.1457 17.8631 20.8966 18.8123 20.9903C18.9103 21 19.0267 21 19.2594 21H19.5044C19.965 21 20.1952 21 20.3868 20.9622C21.1829 20.8053 21.8053 20.1829 21.9622 19.3868C22 19.1952 22 18.965 22 18.5044V18.3062C22 17.831 22 17.5933 21.9493 17.3209C21.8358 16.7119 21.3933 15.9583 20.9166 15.5624C20.7035 15.3854 20.5589 15.3048 20.2698 15.1435C17.822 13.7781 15.0019 13 12 13C8.99812 13 6.17797 13.7781 3.73021 15.1435C3.4411 15.3048 3.29654 15.3854 3.0834 15.5624C2.60675 15.9583 2.16421 16.7119 2.05074 17.3209C2 17.5933 2 17.831 2 18.3062V18.5044C2 18.965 2 19.1952 2.03776 19.3868C2.19469 20.1829 2.81709 20.8053 3.61321 20.9622C3.80476 21 4.03504 21 4.4956 21H4.74057C4.97332 21 5.0897 21 5.18773 20.9903C6.13689 20.8966 6.8878 20.1457 6.98152 19.1965C6.9912 19.0985 6.9912 18.9821 6.9912 18.7494C6.9912 18.6811 6.9912 18.647 6.99418 18.6084C7.02122 18.2591 7.2674 17.9118 7.58798 17.7705C7.62335 17.7549 7.64577 17.747 7.69061 17.7313C9.03921 17.2576 10.4895 17 12 17Z" stroke="white" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>  
            <!--cht screen mobile-->
            <div class="video-call-section-chat-screen-mobile">
                <div class="video-call-section-chat-screen-mobile">
                <div class="video-chat-container-head">
                        <button type="button" class="chat-back-button">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M15.8327 10.0003H4.16602M4.16602 10.0003L9.99935 15.8337M4.16602 10.0003L9.99935 4.16699" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        </button>
                        <div class="video-chat-container-head-img">
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-video-call.png"
                                alt="" class="dummy-video-call-img">
                            <span class="avaliable-dot"></span>
                        </div>
                        <div class="video-chat-container-head-content">
                            <h6>Mrs. Samantha Wid</h6>
                        </div>
                    </div>
                    <div class="video-chat-container-body">
                        <ul class="video-chat-chatbox">
                            <li class="chat-incoming">
                                Hi!<br>how are you today? Do you have a cough?
                                <span class="video-chat-chatbox-time">2:20pm</span>
                            </li>
                            <li class="chat-outgoing">
                                I am suffering from cough and fever.
                                <span class="video-chat-chatbox-time">2:21pm</span>
                            </li>
                            <li class="chat-incoming">
                                Hi!<br>how are you today? Do you have a cough?
                                <span class="video-chat-chatbox-time">2:20pm</span>
                            </li>
                            <li class="chat-outgoing">
                                I am suffering from cough and fever.
                                <span class="video-chat-chatbox-time">2:21pm</span>
                            </li>
                            <li class="chat-incoming">
                                Hi!<br>how are you today? Do you have a cough?
                                <span class="video-chat-chatbox-time">2:20pm</span>
                            </li>
                            <li class="chat-incoming">
                                Hi!<br>how are you today? Do you have a cough?
                                <span class="video-chat-chatbox-time">2:20pm</span>
                            </li>
                            <li class="chat-outgoing">
                                I am suffering from cough and fever.
                                <span class="video-chat-chatbox-time">2:21pm</span>
                            </li>
                            <li class="chat-incoming">
                                Hi!<br>how are you today? Do you have a cough?
                                <span class="video-chat-chatbox-time">2:20pm</span>
                            </li>
                            <li class="chat-outgoing">
                                I am suffering from cough and fever.
                                <span class="video-chat-chatbox-time">2:21pm</span>
                            </li>
                            <li class="chat-incoming">
                                Hi!<br>how are you today? Do you have a cough?
                                <span class="video-chat-chatbox-time">2:20pm</span>
                            </li>
                            <li class="chat-outgoing">
                                I am suffering from cough and fever.
                                <span class="video-chat-chatbox-time">2:21pm</span>
                            </li>
                            <li class="chat-incoming">
                                Hi!<br>how are you today? Do you have a cough?
                                <span class="video-chat-chatbox-time">2:20pm</span>
                            </li>
                            <li class="chat-outgoing">
                                I am suffering from cough and fever.
                                <span class="video-chat-chatbox-time">2:21pm</span>
                            </li>
                            <li class="chat-incoming">
                                <div class="typing-indicator">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </div>
                            </li>
                        </ul>
                        
                    </div>
                    <div class="video-chat-type-container">
                            <div class="video-chat-typing-input">
                                <input type="text" placeholder="Start typing here...">
                                <button class="send-message"><svg width="24" height="25" viewBox="0 0 24 25" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M24 12.9273C23.9734 13.3845 23.8171 13.8247 23.5493 14.1963C23.2815 14.5678 22.9134 14.8554 22.488 15.0253L3.24267 24.6479C2.82666 24.8679 2.36525 24.9883 1.89479 24.9996C1.60801 25.0061 1.32373 24.9449 1.06508 24.8209C0.806423 24.6968 0.580698 24.5135 0.406262 24.2858C0.189394 23.9635 0.0546572 23.593 0.0137987 23.2067C-0.0270599 22.8204 0.0272002 22.4299 0.171848 22.0694L2.34017 14.8377C2.41508 14.5978 2.46227 14.35 2.48082 14.0993H14.3539C14.6647 14.0993 14.9628 13.9758 15.1827 13.756C15.4025 13.5362 15.5259 13.2381 15.5259 12.9273C15.5259 12.6164 15.4025 12.3183 15.1827 12.0985C14.9628 11.8787 14.6647 11.7552 14.3539 11.7552H2.48082C2.46103 11.5047 2.41386 11.2571 2.34017 11.0168L0.171848 3.78513C0.026796 3.42487 -0.027683 3.03454 0.0131853 2.64833C0.0540536 2.26213 0.189022 1.89184 0.406262 1.56992C0.753792 1.17447 1.23365 0.919385 1.75583 0.852493C2.27802 0.785601 2.80668 0.9115 3.24267 1.20658L22.4892 10.8293C22.9144 10.9992 23.2824 11.2868 23.5499 11.6584C23.8175 12.03 23.9736 12.4701 24 12.9273Z"
                                            fill="#1B71BA" />
                                    </svg></button>
                            </div>
                            <div class="video-chat-typing-attachment">
                                <button type="button" class="video-chat-attachment-toggle-btn"><svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M9.99935 11.751C10.4596 11.751 10.8327 11.3779 10.8327 10.9176C10.8327 10.4574 10.4596 10.0843 9.99935 10.0843C9.53911 10.0843 9.16602 10.4574 9.16602 10.9176C9.16602 11.3779 9.53911 11.751 9.99935 11.751Z" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M9.99935 5.91764C10.4596 5.91764 10.8327 5.54455 10.8327 5.08431C10.8327 4.62407 10.4596 4.25098 9.99935 4.25098C9.53911 4.25098 9.16602 4.62407 9.16602 5.08431C9.16602 5.54455 9.53911 5.91764 9.99935 5.91764Z" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M9.99935 17.5843C10.4596 17.5843 10.8327 17.2112 10.8327 16.751C10.8327 16.2907 10.4596 15.9176 9.99935 15.9176C9.53911 15.9176 9.16602 16.2907 9.16602 16.751C9.16602 17.2112 9.53911 17.5843 9.99935 17.5843Z" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg></button>
                                <div class="video-chat-typing-attachment-content">
                                    <ul>
                                        <li>
                                            <a href="#">
                                            <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M1.66602 7.33644C1.66602 6.09298 2.67404 5.08496 3.9175 5.08496C4.56357 5.08496 5.13715 4.67154 5.34146 4.05863L5.41602 3.83496C5.45117 3.72948 5.46875 3.67675 5.48756 3.62996C5.72772 3.03256 6.29051 2.62693 6.93319 2.58801C6.98353 2.58496 7.03912 2.58496 7.1503 2.58496H12.8484C12.9596 2.58496 13.0152 2.58496 13.0655 2.58801C13.7082 2.62693 14.271 3.03256 14.5111 3.62996C14.5299 3.67675 14.5475 3.72948 14.5827 3.83496L14.6572 4.05863C14.8615 4.67154 15.4351 5.08496 16.0812 5.08496C17.3247 5.08496 18.3327 6.09298 18.3327 7.33644V14.4183C18.3327 15.8184 18.3327 16.5185 18.0602 17.0533C17.8205 17.5237 17.4381 17.9061 16.9677 18.1458C16.4329 18.4183 15.7328 18.4183 14.3327 18.4183H5.66602C4.26588 18.4183 3.56582 18.4183 3.03104 18.1458C2.56063 17.9061 2.17818 17.5237 1.9385 17.0533C1.66602 16.5185 1.66602 15.8184 1.66602 14.4183V7.33644Z" stroke="#667085" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                                <path d="M9.99935 14.6683C12.0704 14.6683 13.7493 12.9894 13.7493 10.9183C13.7493 8.84723 12.0704 7.16829 9.99935 7.16829C7.92828 7.16829 6.24935 8.84723 6.24935 10.9183C6.24935 12.9894 7.92828 14.6683 9.99935 14.6683Z" stroke="#667085" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                Camera
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                            <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M3.55943 18.1912L9.05654 12.6941C9.38656 12.3641 9.55156 12.1991 9.74184 12.1373C9.9092 12.0829 10.0895 12.0829 10.2569 12.1373C10.4471 12.1991 10.6121 12.3641 10.9422 12.6941L16.4026 18.1546M11.666 13.418L14.0565 11.0274C14.3866 10.6974 14.5516 10.5324 14.7418 10.4706C14.9092 10.4162 15.0895 10.4162 15.2569 10.4706C15.4471 10.5324 15.6121 10.6974 15.9422 11.0274L18.3327 13.418M8.33268 8.41797C8.33268 9.33844 7.58649 10.0846 6.66602 10.0846C5.74554 10.0846 4.99935 9.33844 4.99935 8.41797C4.99935 7.49749 5.74554 6.7513 6.66602 6.7513C7.58649 6.7513 8.33268 7.49749 8.33268 8.41797ZM5.66602 18.418H14.3327C15.7328 18.418 16.4329 18.418 16.9677 18.1455C17.4381 17.9058 17.8205 17.5233 18.0602 17.0529C18.3327 16.5182 18.3327 15.8181 18.3327 14.418V7.41797C18.3327 6.01784 18.3327 5.31777 18.0602 4.78299C17.8205 4.31259 17.4381 3.93014 16.9677 3.69045C16.4329 3.41797 15.7328 3.41797 14.3327 3.41797H5.66602C4.26588 3.41797 3.56582 3.41797 3.03104 3.69045C2.56063 3.93014 2.17818 4.31259 1.9385 4.78299C1.66602 5.31777 1.66602 6.01784 1.66602 7.41797V14.418C1.66602 15.8181 1.66602 16.5182 1.9385 17.0529C2.17818 17.5233 2.56063 17.9058 3.03104 18.1455C3.56582 18.418 4.26588 18.418 5.66602 18.418Z" stroke="#667085" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                                Gallery
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                            <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M17.6261 10.0004L10.1131 17.5134C8.40458 19.222 5.63448 19.222 3.92594 17.5134C2.2174 15.8049 2.2174 13.0348 3.92594 11.3263L11.4389 3.81326C12.578 2.67423 14.4247 2.67423 15.5637 3.81326C16.7028 4.95229 16.7028 6.79902 15.5637 7.93805L8.34536 15.1564C7.77584 15.7259 6.85248 15.7259 6.28296 15.1564C5.71345 14.5869 5.71345 13.6635 6.28296 13.094L12.6175 6.75953" stroke="#667085" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                File
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                            <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <g clip-path="url(#clip0_13353_24751)">
                                                <path d="M10.0007 11.7516C11.3814 11.7516 12.5007 10.6323 12.5007 9.25163C12.5007 7.87092 11.3814 6.75163 10.0007 6.75163C8.61994 6.75163 7.50065 7.87092 7.50065 9.25163C7.50065 10.6323 8.61994 11.7516 10.0007 11.7516Z" stroke="#667085" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                                <path d="M10.0007 19.2516C13.334 15.9183 16.6673 12.9335 16.6673 9.25163C16.6673 5.56973 13.6825 2.58496 10.0007 2.58496C6.31875 2.58496 3.33398 5.56973 3.33398 9.25163C3.33398 12.9335 6.66732 15.9183 10.0007 19.2516Z" stroke="#667085" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                                </g>
                                                <defs>
                                                <clipPath id="clip0_13353_24751">
                                                <rect width="20" height="20" fill="white" transform="translate(0 0.917969)"/>
                                                </clipPath>
                                                </defs>
                                                </svg>
                                                Location
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
            <!--cht screen mobile end-->          
        </div>
    </section>
    <!--more video call mobile option modal-->
<div class="modal more-video-call-mobile-option-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">More</h1>
                <span class="closecurrentpopup"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round"></path>
                    </svg></span>
        </div>
        <div class="modal-body">
            <div class="more-video-call-mobile-option-modal-wrap">              
                <ul>
                    <li>
                        <a href="#">Voice to text & translate</a>
                    </li>
                    <li>
                        <a href="<?php echo base_url();?>virtual_consult/health_provider/consultation_notes">Consult notes</a>
                    </li>
                    <li>
                        <a href="<?php echo base_url();?>virtual_consult/patient/history">Medical history</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
  </div>
  <!--First time when they click on voice to text modal-->
  <div class="modal first-time-voice-text-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Have you obtained consent to transcribe?</h1>
                <span class="closecurrentpopup"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round"></path>
                    </svg></span>
        </div>
        <div class="modal-body">
            <div class="first-time-voice-text-modal-wrap">              
                <p>You must obtain patient consent to use this transcription tool.</p>
                <p>Conversations are encrypted and transcribed in real-time to help with your clinical notes. By default, Medcallz will not save audio.</p>
                <a href="<?php echo base_url();?>medcallz_transcription">How do l tell my patients about Medcallz?</a>
            </div>
        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">  
                <button type="button" class="unfilled-button closecurrentpopup">No</button>             
                <button type="button" class="primary-button">Yes, begin</button>
            </div>
        </div> 
    </div>
  </div>
   <!--First time when they click on voice to text modal-->
   <div class="modal add-people-to-call-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Add to call</h1>
                <span class="closecurrentpopup"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round"></path>
                    </svg></span>
        </div>
        <div class="modal-body">
            <div class="add-people-to-call-modal-wrap">              
                <input type="search" placeholder="Search..." class="input-search-style">
                <ul class="add-people-checkbox-list">
                    <li>
                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-mobile-call-img.jpg" class="avatar" alt="user">
                        <span>Anett Jirus</span>
                        <span class="checkmark">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M16.6673 5L7.50065 14.1667L3.33398 10" stroke="#1B71B8" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg></span>
                    </li>
                    <li>
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-mobile-call-img.jpg" class="avatar" alt="user">
                    <span>Claudina Crommett</span>
                        <span class="checkmark">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M16.6673 5L7.50065 14.1667L3.33398 10" stroke="#1B71B8" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg></span>
                    </li>
                    <li>
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-mobile-call-img.jpg" class="avatar" alt="user">
                    <span>Kellby Vasilchikov</span>
                        <span class="checkmark">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M16.6673 5L7.50065 14.1667L3.33398 10" stroke="#1B71B8" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg></span>
                    </li>
                    <li>
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-mobile-call-img.jpg" class="avatar" alt="user">
                    <span>Olivia Brown</span>
                        <span class="checkmark">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M16.6673 5L7.50065 14.1667L3.33398 10" stroke="#1B71B8" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg></span>
                    </li>
                    <li>
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-mobile-call-img.jpg" class="avatar" alt="user">
                    <span>Kellby Vasilchikov</span>
                        <span class="checkmark">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M16.6673 5L7.50065 14.1667L3.33398 10" stroke="#1B71B8" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg></span>
                    </li>
                    <li>
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-mobile-call-img.jpg" class="avatar" alt="user">
                    <span>Olivia Brown</span>
                        <span class="checkmark">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M16.6673 5L7.50065 14.1667L3.33398 10" stroke="#1B71B8" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg></span>
                    </li>
                    <li>
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-mobile-call-img.jpg" class="avatar" alt="user">
                    <span>Kellby Vasilchikov</span>
                        <span class="checkmark">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M16.6673 5L7.50065 14.1667L3.33398 10" stroke="#1B71B8" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg></span>
                    </li>
                    <li>
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-mobile-call-img.jpg" class="avatar" alt="user">
                    <span>Olivia Brown</span>
                        <span class="checkmark">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M16.6673 5L7.50065 14.1667L3.33398 10" stroke="#1B71B8" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg></span>
                    </li>
                    <li>
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-mobile-call-img.jpg" class="avatar" alt="user">
                    <span>Kellby Vasilchikov</span>
                        <span class="checkmark">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M16.6673 5L7.50065 14.1667L3.33398 10" stroke="#1B71B8" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg></span>
                    </li>
                    <li>
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-mobile-call-img.jpg" class="avatar" alt="user">
                    <span>Olivia Brown</span>
                        <span class="checkmark">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M16.6673 5L7.50065 14.1667L3.33398 10" stroke="#1B71B8" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg></span>
                    </li>
                    <li>
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-mobile-call-img.jpg" class="avatar" alt="user">
                    <span>Kellby Vasilchikov</span>
                        <span class="checkmark">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M16.6673 5L7.50065 14.1667L3.33398 10" stroke="#1B71B8" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg></span>
                    </li>
                    <li>
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-mobile-call-img.jpg" class="avatar" alt="user">
                    <span>Olivia Brown</span>
                        <span class="checkmark">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M16.6673 5L7.50065 14.1667L3.33398 10" stroke="#1B71B8" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg></span>
                    </li>
                    <li>
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-mobile-call-img.jpg" class="avatar" alt="user">
                    <span>Kellby Vasilchikov</span>
                        <span class="checkmark">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M16.6673 5L7.50065 14.1667L3.33398 10" stroke="#1B71B8" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg></span>
                    </li>
                    <li>
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctor-mobile-call-img.jpg" class="avatar" alt="user">
                    <span>Olivia Brown</span>
                        <span class="checkmark">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M16.6673 5L7.50065 14.1667L3.33398 10" stroke="#1B71B8" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg></span>
                    </li>
                </ul>
            </div>
        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">  
                <button type="button" class="unfilled-button closecurrentpopup">Cancel</button>             
                <button type="button" class="primary-button">Add to call (1)</button>
            </div>
        </div> 
    </div>
  </div>
  <!---modal script-->
<script>
    function customAlerts(selector, action = "open", contentData = '') {
        if (action == "open") {
            $(selector).addClass('show-modal');
            $("body").addClass('modal-open');
        } else {
            $(selector).removeClass('show-modal');
            $("body").removeClass('modal-open');
        }
    }
    $(".more-video-call-mobile-option-modal-trigger").click(function() {
        customAlerts(".more-video-call-mobile-option-modal", "open");
    });
    $(".add-person-video-call-btn").click(function() {
        customAlerts(".add-people-to-call-modal", "open");
    });
    
    $(document).on("click", ".closecurrentpopup", function() {
        $(this).parents('.modal').removeClass('show-modal');
        $("body").removeClass('modal-open');
    });
</script>
    <script>
        $(document).ready(function() {
            var videotogglebtn = true;
            $('.video-chat-attachment-toggle-btn').click(function() { 
            $('.video-chat-attachment-toggle-btn').not(this).removeClass('video-chat-attachment-toggle-btn-active')
            $(this).toggleClass('video-chat-attachment-toggle-btn-active');
            videotogglebtn = false;
            });

            $("html").click(function() {
                if (videotogglebtn) {
                $(".video-chat-attachment-toggle-btn").removeClass('video-chat-attachment-toggle-btn-active');
                }
                videotogglebtn = true;
            });
        });

        $(document).ready(function() {         
    $("#voice-transcript").click(function(event) {             
        if ($(this).is(":checked")) { 
            $(".video-call-inner-container-without-transcription").hide();             
            $(".video-call-inner-container-with-transcription").show();  
            $(".video-call-transcript-btn-language").hide(); 
                      
        } else { 
            $(".video-call-inner-container-without-transcription").show();             
            $(".video-call-inner-container-with-transcription").hide();
            $(".video-call-transcript-btn-language").show();             
        }
    });         
});
    </script>

<script>
$(document).ready(function () {
    $(".video-call-section-mobile-tabs-list a").click(function (e) {
        e.preventDefault();

        let tabId = $(this).attr("href");

        $(".video-call-section-mobile-tabs").removeClass("active");
        $(tabId).addClass("active");

        $(".video-call-section-mobile-tabs-list li").removeClass("active");
        $(this).parent().addClass("active");
    });
});
</script>
<script>
 $(document).ready(function () {
    $(".video-call-mobile-translation-btn").click(function (e) {
        $(".video-call-section-mobile-with-transcription").toggle();
        $(".video-call-section-mobile-without-transcription").toggle();
        $(".video-call-section-mobile-head p").toggle();
        $(this).toggleClass("active-video-call-mobile-btn");
    });
});
</script>
<script>
    $(document).ready(function () {
    $(".video-chat-icon-btn").click(function (e) {
        $(".video-call-section-chat-screen-mobile").show();
        $(".video-call-section-mobile-inner").hide();
    });
    $(".chat-back-button").click(function (e) {
        $(".video-call-section-mobile-inner").show();
        $(".video-call-section-chat-screen-mobile").hide();
    });    
});
$(document).ready(function () {
    $(".video-call-hide-btn").click(function(){
        $(".video-call-mute-screen").toggle();
        $(".video-call-hide-btn").toggleClass("active-video-call-mobile-btn");
        $(".video-call-section-mobile-without-transcription").toggle();
    }); 
});
$(document).ready(function () {
    $(".video-call-screen-share-btn").click(function(){
        $(".video-call-screen-share").toggle();
        $(".video-call-screen-share-btn").toggleClass("active-video-call-mobile-btn");
        $(".video-call-section-mobile-without-transcription").toggle();
    }); 
});
$(document).ready(function () {
    $(".video-call-mute-btn").click(function(){
        $(".video-call-mute-btn").toggleClass("active-video-call-mobile-btn");
        $(".microphone-off-head-icon-wrap").toggleClass("show");
        $(".video-call-section-mobile-receiver-wrap .microphone-off-icon").toggleClass("show");
    }); 
});
//* desktop*//
$(document).ready(function () {
    $(".video-call-screen-share-btn-desktop").click(function(){
        $(".video-call-screen-share-btn-desktop").toggleClass("active-video-call-desktop-btn");
        $(".video-call-timer-wrap").toggle();
        $(".video-call-main-wrap .dummy-video-call-img").toggle();
        $(".video-call-screen-share-desktop").toggle();
        $(".video-call-caller-wrap .dummy-video-call-img").toggle();
        $(".video-call-screen-share-caller-wrap").toggleClass("show-screen-caller-wrap");
    }); 
});
$(document).ready(function () {
    $(".video-call-video-hide-btn-desktop").click(function(){
        $(".video-call-video-hide-btn-desktop").toggleClass("active-video-call-desktop-btn");
        $(".video-call-timer-wrap").toggle();
        $(".video-call-main-wrap .dummy-video-call-img").toggle();
        $(".video-call-video-hide-desktop").toggleClass("show-video-call-video-hide-desktop");;
        $(".video-call-caller-wrap .dummy-video-call-img").toggle();
        $(".video-call-screen-share-caller-wrap").toggleClass("show-screen-caller-wrap");
    }); 
});
$(document).ready(function () {
    $(".video-call-voice-mute-btn-desktop").click(function(){
        $(".video-call-voice-mute-btn-desktop").toggleClass("active-video-call-desktop-btn");
        $(".video-call-caller-wrap .microphone-off-icon").toggleClass("show-microphone-off-icon");
    }); 
});
</script>
<script>
     $(document).ready(function () {
        $(".add-people-checkbox-list li").click(function () {
            $(this).toggleClass("selected");
        });
    });
</script>
</body>
</html>