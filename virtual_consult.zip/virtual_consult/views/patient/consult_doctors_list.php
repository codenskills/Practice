<section class="consult-now-section">
    <div class="container">
        <div class="consult-now-heading-wrap">
            <h2 class="consult-now-heading"><?php echo $this->lang->line('medical_services'); ?></h2>
        </div>
        <?php 
        $decryptedParam = decryptParam($_GET['data']);
        parse_str($decryptedParam, $params); // Convert back to an array
       // print_r($params);
        
        ?>
        <?php if(isset($params['response_doctor']) && $params['response_doctor']==0){ ?>
        <div class="cancel-consultation-message-wrap">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M17.501 2.5L12.501 7.5M12.501 2.5L17.501 7.5M8.5235 11.5526C7.52219 10.5512 6.73153 9.41904 6.15153 8.21102C6.10164 8.10712 6.0767 8.05516 6.05753 7.98942C5.98943 7.75579 6.03835 7.46891 6.18003 7.27105C6.21989 7.21537 6.26752 7.16774 6.36278 7.07248C6.65412 6.78115 6.79979 6.63548 6.89503 6.48899C7.25419 5.93659 7.25419 5.22443 6.89503 4.67203C6.79979 4.52554 6.65412 4.37988 6.36278 4.08854L6.20039 3.92615C5.75752 3.48328 5.53609 3.26184 5.29827 3.14156C4.8253 2.90233 4.26675 2.90233 3.79378 3.14156C3.55596 3.26184 3.33453 3.48328 2.89166 3.92615L2.7603 4.05751C2.31895 4.49886 2.09827 4.71954 1.92973 5.01956C1.74271 5.35249 1.60825 5.86956 1.60938 6.25141C1.61041 6.59554 1.67716 6.83072 1.81067 7.30109C2.52814 9.82892 3.88187 12.2142 5.87185 14.2042C7.86184 16.1942 10.2471 17.5479 12.775 18.2654C13.2453 18.3989 13.4805 18.4657 13.8246 18.4667C14.2065 18.4678 14.7236 18.3333 15.0565 18.1463C15.3565 17.9778 15.5772 17.7571 16.0186 17.3158L16.1499 17.1844C16.5928 16.7415 16.8142 16.5201 16.9345 16.2823C17.1737 15.8093 17.1737 15.2508 16.9345 14.7778C16.8142 14.54 16.5928 14.3185 16.1499 13.8757L15.9875 13.7133C15.6962 13.4219 15.5505 13.2763 15.404 13.181C14.8516 12.8219 14.1395 12.8219 13.5871 13.181C13.4406 13.2763 13.2949 13.4219 13.0036 13.7133C12.9083 13.8085 12.8607 13.8562 12.805 13.896C12.6072 14.0377 12.3203 14.0866 12.0866 14.0185C12.0209 13.9994 11.9689 13.9744 11.865 13.9245C10.657 13.3445 9.52482 12.5539 8.5235 11.5526Z" stroke="#DC6803" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <div class="cancel-consultation-message-inner-wrap">
                <p><?= $this->lang->line('no_response_doctor') ?></p>
                <a href="javascript:void(0)" class="cancel-consultation-modal-trigger"><?= $this->lang->line('no_response_btn') ?></a>
            </div>
        </div>
        <?php }else{ ?>
        <div class="consult-time-doctor-online-wrap">
            <div class="consult-service-top-inner-wrap">
                <div class="consult-service-top-back-icon">
                    <a href="<?php echo base_url("virtual_consult/patient/consult_now"); ?>"><svg width="20" height="20"
                            viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M15.8337 10.0001H4.16699M4.16699 10.0001L10.0003 15.8334M4.16699 10.0001L10.0003 4.16675"
                                stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg></a>
                </div>
                <div class="consult-now-round-icon-wrap">
                    <img src="<?= @$service->icon ?>" alt="<?= @$service->name; ?>">
                </div>
                <div class="consult-service-top-content">
                    <h6><?= $service->name; ?></h6>
                    <p><?= $service->description; ?></p>
                </div>
            </div>
        </div>
        <?php } ?>
       
        <div class="consult-now-doctors-wrap">
            <?php
            if (count($doctor_list) > 0) { ?>
                <h6 class="consult-now-heading"><?= $this->lang->line('choose_doctor_hp') ?></h6>
                <ul class="doctors-list">
                    <?php
                    foreach ($doctor_list as $rec) {
                        // echo "<pre>";print_r($rec);
                        ?>
                        <li>
                            <div class="doctors-list-wrap <?php if (isset($rec['avatar2'])) {
                                echo 'no-doctor-image-main-wrap';
                            } ?>">
                                <!-- <button type="button" class="like-btn">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M7.52144 2.30229C7.6751 1.991 7.75193 1.83535 7.85623 1.78562C7.94697 1.74236 8.0524 1.74236 8.14315 1.78562C8.24744 1.83535 8.32427 1.991 8.47793 2.30229L9.93572 5.2556C9.98108 5.3475 10.0038 5.39345 10.0369 5.42913C10.0663 5.46072 10.1015 5.48631 10.1406 5.5045C10.1847 5.52503 10.2354 5.53244 10.3368 5.54726L13.5977 6.02389C13.9411 6.07408 14.1127 6.09917 14.1922 6.18304C14.2613 6.25601 14.2938 6.35628 14.2807 6.45593C14.2656 6.57047 14.1413 6.69153 13.8927 6.93367L11.534 9.23103C11.4604 9.30264 11.4237 9.33845 11.4 9.38106C11.379 9.41878 11.3655 9.46022 11.3603 9.50309C11.3544 9.5515 11.3631 9.60208 11.3804 9.70324L11.937 12.9482C11.9957 13.2904 12.025 13.4615 11.9699 13.5631C11.9219 13.6514 11.8366 13.7134 11.7377 13.7317C11.6241 13.7528 11.4704 13.672 11.1631 13.5104L8.24793 11.9773C8.1571 11.9295 8.11168 11.9057 8.06384 11.8963C8.02147 11.888 7.9779 11.888 7.93554 11.8963C7.88769 11.9057 7.84228 11.9295 7.75145 11.9773L4.83629 13.5104C4.52895 13.672 4.37528 13.7528 4.26166 13.7317C4.1628 13.7134 4.07749 13.6514 4.0295 13.5631C3.97434 13.4615 4.00369 13.2904 4.06239 12.9482L4.61893 9.70324C4.63628 9.60208 4.64496 9.5515 4.63909 9.50309C4.63389 9.46022 4.62042 9.41878 4.59941 9.38106C4.57569 9.33845 4.53893 9.30264 4.4654 9.23103L2.10671 6.93367C1.85812 6.69153 1.73382 6.57047 1.71869 6.45593C1.70553 6.35628 1.73804 6.25601 1.80717 6.18304C1.88663 6.09917 2.05832 6.07408 2.4017 6.02389L5.66255 5.54726C5.76396 5.53244 5.81466 5.52503 5.85882 5.5045C5.89792 5.48631 5.93312 5.46072 5.96247 5.42913C5.99561 5.39345 6.01829 5.3475 6.06366 5.2556L7.52144 2.30229Z"
                                            stroke="white" stroke-opacity="0.6" stroke-width="1.336" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg>
                                </button> -->
                                <?php
                                if (isset($rec['avatar2'])) { ?>
                                    <div class="no-doctor-image-wrap">
                                        <p><?= $rec['avatar2'] ?></p>
                                    </div>
                                <?php } else { ?>
                                    <img src="<?= $rec['avatar'] ?>" alt="<?= $rec['avatar_alt'] ?>"
                                        class="img-responsive doctor-img">
                                <?php }
                                ?>
                                <div class="doctors-data">
                                    <div class="doctor-data-bottom-wrap">
                                        <label class="online"><span class="dot-label"></span>
                                            <p>Online</p>
                                        </label>
                                        <div class="doctor-name-share-wrap">
                                            <h4 class="doctors-name" style="cursor:pointer;"
                                                onclick='showDoctorDetail(<?= $rec["hp_id"] ?>)'><?= $rec['full_hp_name'] ?>
                                            </h4>
                                            <button class="share-doctor-modal-trigger"
                                                onclick="openShareModal('<?= @$rec['hp_share_url'] ?>')"><svg width="21"
                                                    height="20" viewBox="0 0 21 20" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M18.1259 10.5062C18.3294 10.3318 18.4311 10.2446 18.4684 10.1409C18.5011 10.0498 18.5011 9.9502 18.4684 9.85914C18.4311 9.75539 18.3294 9.6682 18.1259 9.49383L11.067 3.44331C10.7168 3.14315 10.5417 2.99306 10.3935 2.98939C10.2646 2.98619 10.1416 3.04279 10.0602 3.14269C9.96647 3.25764 9.96647 3.48825 9.96647 3.94948V7.52886C8.18757 7.84007 6.55947 8.74146 5.34956 10.0949C4.03049 11.5704 3.30083 13.48 3.2998 15.4591V15.9691C4.17426 14.9157 5.26606 14.0638 6.50044 13.4716C7.58872 12.9495 8.76515 12.6403 9.96647 12.5588V16.0505C9.96647 16.5117 9.96647 16.7424 10.0602 16.8573C10.1416 16.9572 10.2646 17.0138 10.3935 17.0106C10.5417 17.0069 10.7168 16.8569 11.067 16.5567L18.1259 10.5062Z"
                                                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></button>
                                        </div>

                                        <ul class="doctors-specifications-list">
                                            <?php if (!empty($rec['specialiy_name'])) { ?>
                                                <li>
                                                    <div class="doctors-specifications-list-wrap">
                                                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/stethoscope.svg"
                                                            alt="stethoscope">
                                                        <h6><?= $rec['specialiy_name'] ?></h6>
                                                    </div>
                                                </li>
                                            <?php } ?>
                                            <?php if (!empty($rec['state_name'])) { ?>
                                                <li>
                                                    <div class="doctors-specifications-list-wrap">
                                                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/marker-pin.svg"
                                                            alt="stethoscope">
                                                        <h6><?= $rec['state_name'] ?></h6>
                                                    </div>
                                                </li>
                                            <?php } ?>
                                            <?php if (!empty($rec['lang_name'])) { ?>
                                                <li>
                                                    <div class="doctors-specifications-list-wrap">
                                                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/language-icon.svg"
                                                            alt="language">
                                                        <h6><?= $rec['lang_name'] ?>
                                                        </h6>
                                                    </div>
                                                </li>
                                            <?php } ?>
                                        </ul>
                                    </div>
                                    <div class="d-flex j">
                                        <?php if($params['med_ser_id']!=""){ ?> 
                                            <a class="book-btn" med_ser_id="<?= $service->id ?>" onclick="reAssignHPByPateint(<?php echo $params['med_ser_id']; ?>,<?= $rec['user_id'] ?>)"><?php echo $this->lang->line('select'); ?>
                                            <svg width="16" height="12" viewBox="0 0 16 12" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path d="M1.33301 6H14.6663M14.6663 6L9.66634 1M14.6663 6L9.66634 11"
                                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg>
                                        </a>
                                        <?php }else{ ?> 
                                        <a class="book-btn consultnowbtn<?= $rec['user_id'] ?>" service_type="0" service_id="<?= $service->id ?>"
                                            hp_name="<?= $rec['full_hp_name'] ?>" hp_user_id="<?= $rec['user_id'] ?>"
                                            onclick="payment_summary_popup(this)"><?php echo $this->lang->line('consult_now'); ?>
                                            <svg width="16" height="12" viewBox="0 0 16 12" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path d="M1.33301 6H14.6663M14.6663 6L9.66634 1M14.6663 6L9.66634 11"
                                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg>
                                        </a>
                                        <?php } ?>
                                        
                                    </div>
                                    <!-- <div class="d-flex j">
                                        <a class="book-btnn"
                                            onclick="OpenPaymentModal(<?= $rec['user_id'] ?>,<?= $service->id ?>,'<?= $rec['full_hp_name'] ?>')">Custom<?php //echo $this->lang->line('consult_now'); ?><svg
                                                width="16" height="12" viewBox="0 0 16 12" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path d="M1.33301 6H14.6663M14.6663 6L9.66634 1M14.6663 6L9.66634 11"
                                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg></a>
                                            <br/><br/>
                                        <a class="book-btnn"
                                            onclick="payment_summary_popup(<?= $rec['user_id'] ?>,<?= $service->id ?>,'<?= $rec['full_hp_name'] ?>')">Stripe Host<?php //echo $this->lang->line('consult_now'); ?><svg
                                                width="16" height="12" viewBox="0 0 16 12" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path d="M1.33301 6H14.6663M14.6663 6L9.66634 1M14.6663 6L9.66634 11"
                                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg></a><br/><br/>
                                            <a class="book-btnn"
                                            onclick="payment_summary_popup(<?= $rec['user_id'] ?>,<?= $service->id ?>,'<?= $rec['full_hp_name'] ?>')">EMbeded<?php //echo $this->lang->line('consult_now'); ?><svg
                                                width="16" height="12" viewBox="0 0 16 12" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path d="M1.33301 6H14.6663M14.6663 6L9.66634 1M14.6663 6L9.66634 11"
                                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg></a>
                                    </div> -->
                                </div>
                            </div>
                        </li>
                    <?php }
                    ?>
                </ul>
                <div><?php echo $pagination; ?></div>
                <!-- <div class="pagination-row-responsive">
                    <button type="button" class="pagination-button-responsive"><svg width="14" height="14"
                            viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M12.8337 6.99996H1.16699M1.16699 6.99996L7.00033 12.8333M1.16699 6.99996L7.00033 1.16663"
                                stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                    </button>
                    <p>page <span>1</span> of <span>10</span></p>
                    <button type="button" class="pagination-button-responsive"><svg width="14" height="14"
                            viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M1.1665 6.99996H12.8332M12.8332 6.99996L6.99984 1.16663M12.8332 6.99996L6.99984 12.8333"
                                stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>

                    </button>
                </div> -->
            </div>
        <?php } else { ?>
            <div class="no-doctors-container">
                <div class="no-doctors-section">
                    <img src="<?php echo base_url(); ?>assets/images/v3/no-result-img.png" alt="no result image">
                    <h5><?= $this->lang->line('no_doctors_available') ?? ""  ; ?></h5>
                    <p><?= $this->lang->line('no_doctors_available_description') ?? ""  ; ?></p>
                </div>
            </div>

        <?php } ?>
    </div>
</section>
<!-- choose payment method modal-->
<!-- <div class="modal consult-now-choose-payment-method-modal show-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Medical Certificate</h5>
            <span onclick="closecurrentpopup('hp_id',this)">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round"></path>
                </svg>
            </span>
        </div>
        <div class="modal-body">
            <div class="consult-choose-payment-method-modal-wrap">
                <h4>Choose payment method</h4>
                <ul class="consult-choose-payment-method-list list-style-none">
                   
                    <li class="consult-choose-payment-method-list-wrap">
                        <button class="consult-choose-payment-button " onclick="payment_summary('cc_dc_pay')">
                            <div class="consult-choose-payment-icon">
                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/stripe-icon.svg"
                                    alt="payment-icon">
                            </div>
                            <div class="consult-choose-payment-content">
                            Stripe (Credit card, Google Pay)
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path d="M6 12L10 8L6 4" stroke="#667085" stroke-width="1.33333"
                                        stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                        </button>
                    </li> 
                    <li class="consult-choose-payment-method-list-wrap">
                        <button class="consult-choose-payment-button" onclick="payment_summary('paypal_pay')">
                            <div class="consult-choose-payment-icon">
                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/paypal.svg"
                                    alt="payment-icon">
                            </div>
                            <div class="consult-choose-payment-content">
                                PayPal
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path d="M6 12L10 8L6 4" stroke="#667085" stroke-width="1.33333"
                                        stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                        </button>
                    </li>
                   
                </ul>
            </div>
        </div>
    </div>
</div> -->
<!-- payment success modal-->
<div class="modal show consult-payment-success-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading"><?= @$service->name; ?></h5>
            <span class="closecurrentpopup">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round"></path>
                </svg>
            </span>
        </div>
        <div class="modal-body">
            <div class="consult-payment-success-modal-wrap">
                <div class="consult-payment-success-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M9 12L11 14L15.5 9.5M9.2019 20.6009C9.52965 20.5575 9.86073 20.6464 10.1218 20.8475L11.3251 21.7708C11.7228 22.0764 12.2761 22.0764 12.6727 21.7708L13.9215 20.812C14.1548 20.6331 14.4492 20.5542 14.7403 20.5931L16.3024 20.7986C16.799 20.8642 17.2779 20.5875 17.4701 20.1242L18.0712 18.6709C18.1834 18.3987 18.3989 18.1832 18.6711 18.0709L20.1243 17.4698C20.5876 17.2787 20.8643 16.7988 20.7987 16.3021L20.601 14.7966C20.5576 14.4688 20.6465 14.1377 20.8476 13.8766L21.7709 12.6733C22.0764 12.2755 22.0764 11.7222 21.7709 11.3256L20.812 10.0767C20.6332 9.84339 20.5543 9.54896 20.5932 9.25785L20.7987 7.69568C20.8643 7.19902 20.5876 6.72015 20.1243 6.52793L18.6711 5.92684C18.3989 5.81462 18.1834 5.59907 18.0712 5.32685L17.4701 3.87356C17.279 3.41024 16.799 3.13358 16.3024 3.19913L14.7403 3.40468C14.4492 3.44468 14.1548 3.36579 13.9226 3.18802L12.6738 2.22916C12.2761 1.92361 11.7228 1.92361 11.3262 2.22916L10.0774 3.18802C9.84407 3.36579 9.54965 3.44468 9.25856 3.40691L7.69647 3.20136C7.19984 3.1358 6.721 3.41246 6.52879 3.87578L5.92884 5.32907C5.81552 5.60018 5.59998 5.81573 5.32889 5.92906L3.87568 6.52904C3.41238 6.72126 3.13574 7.20013 3.20129 7.69679L3.40683 9.25897C3.4446 9.55007 3.36572 9.8445 3.18796 10.0767L2.22915 11.3256C1.92362 11.7233 1.92362 12.2767 2.22915 12.6733L3.18796 13.9222C3.36683 14.1555 3.44571 14.4499 3.40683 14.741L3.20129 16.3032C3.13574 16.7999 3.41238 17.2787 3.87568 17.471L5.32889 18.0721C5.60109 18.1843 5.81663 18.3998 5.92884 18.672L6.5299 20.1253C6.721 20.5887 7.20096 20.8653 7.69758 20.7998L9.2019 20.6009Z"
                            stroke="#079455" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </div>
                <p><?= $this->lang->line('payment_success_desc')??"" ?></p>
            </div>
            <div class="consult-payment-success-button">
                <a href="javascript:void(0)" class="primary-button start-consultation-button"><?= $this->lang->line('start_consultation')??"" ?></a>
                <a class="primary-button download-invoice-button" onclick="download_invoice(this)" data-payment-id="">
                    <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M3.83341 13.5352C2.82843 12.8625 2.16675 11.7168 2.16675 10.4167C2.16675 8.46369 3.65967 6.85941 5.56653 6.68281C5.95659 4.31011 8.01695 2.5 10.5001 2.5C12.9832 2.5 15.0436 4.31011 15.4336 6.68281C17.3405 6.85941 18.8334 8.46369 18.8334 10.4167C18.8334 11.7168 18.1717 12.8625 17.1667 13.5352M7.16675 14.1667L10.5001 17.5M10.5001 17.5L13.8334 14.1667M10.5001 17.5V10"
                            stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                    <?= $this->lang->line('download_invoice')??"" ?>                    
                </a>
                <a class="unfilled-button"><?= $this->lang->line('past_consults')??"" ?></a>
            </div>
        </div>
    </div>
</div>
<!-- payment unsuccess modal-->
<div class="modal consult-payment-unsuccess-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading"><?= @$service->name; ?></h5>
            <span class="closecurrentpopup">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round"></path>
                </svg>
            </span>
        </div>
        <div class="modal-body">
            <div class="consult-payment-success-modal-wrap">
                <div class="consult-payment-unsuccess-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M12 8V12M12 16H12.01M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z"
                            stroke="#D92D20" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </div>
                <p><?= $this->lang->line('payment_fail_description')??"" ?></p>
            </div>
            <div class="consult-payment-success-button">
            <a class="primary-button retry_btn"  onclick="retry_payment('')" id="retryBtn"><?= $this->lang->line('try_again')??"" ?></a>
                <!-- <a class="primary-button retry_btn" onclick="retry_payment(<?php echo $_GET['hpuserid']??'' ?>)"><?= $this->lang->line('try_again')??"" ?></a> -->
                <!-- <a class="unfilled-button"
                    onclick="closecurrentpopup('payment_method',this,'consult-now-choose-payment-method-modal')"><svg
                        width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M15.8334 10.0003H4.16675M4.16675 10.0003L10.0001 15.8337M4.16675 10.0003L10.0001 4.16699"
                            stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>Change payment method</a> -->
            </div>
        </div>
    </div>
</div>
<!-- payment Summary modal-->
<div class="modal consult-payment-summary-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading"><?= @$service->name; ?></h5>
            <span onclick="closecurrentpopup(false,this)">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round"></path>
                </svg>
            </span>
        </div>
        <div class="modal-body">
            <div class="consult-payment-summary-modal-wrap">
                <div class="hold-disclaimer">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M9.99935 13.3334V10.0001M9.99935 6.66675H10.0077M18.3327 10.0001C18.3327 14.6025 14.6017 18.3334 9.99935 18.3334C5.39698 18.3334 1.66602 14.6025 1.66602 10.0001C1.66602 5.39771 5.39698 1.66675 9.99935 1.66675C14.6017 1.66675 18.3327 5.39771 18.3327 10.0001Z"
                            stroke="#1B71B8" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                    <p class=""><?= $this->lang->line('hold_disclaimer_desc')??"" ?> </p>                        
                </div>
                <h4><?= $this->lang->line('total')??"" ?></h4>
                <div class="consult-payment-summary-flex">
                    <p class="strong-para"><?= $this->lang->line('subtotal')??"" ?></p>
                    <p class="strong-para" id="sub_total"></p>
                </div>

                <div class="consult-payment-summary-flex">
                    <p><?= $this->lang->line('selected_service')??"" ?></p>
                    <input type="hidden" id="service_category_id" />
                    <p id="service_name"></p>
                </div>
                <div class="consult-payment-summary-flex">
                    <p><?= $this->lang->line('health_provider_name')??"" ?></p>
                    <p id="hp_name"></p>
                </div>
                <div class="consult-payment-summary-flex">
                    <p><?= $this->lang->line('service_fee_title')??"" ?></p>
                    <p id="service_fee"></p>
                </div>
                <div class="consult-payment-summary-flex">
                    <p><?= $this->lang->line('tax_title')??"" ?></p>
                    <p id="tax"></p>
                </div>
                <div class="consult-payment-summary-flex">
                    <p><?= $this->lang->line('platform_fee_title')??"" ?><span>(<?= $this->lang->line('platform_fee_title_2')??"" ?>)</span></p>
                    <p id="platform_fee"></p>
                </div>
                <div class="consult-payment-summary-total">
                    <p class="strong-para"><?= $this->lang->line('total')??"" ?> <?= $this->lang->line('amount')??"" ?></p>
                    <p class="strong-para" id="total_amount"></p>
                </div>
                <div class="consult-payment-summary-redirect-text">
                    <p><?= $this->lang->line('payment_redirect_desc')??"" ?></p>
                </div>
                <div class="consult-payment-method-buttons-flex">
                    <label for="payment_method_0" class="outline-button">
                        <input type="radio" id="payment_method_0" name="payment_method" value="0"  onclick="createPaymentIntentStripePaypal()" />
                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/stripe.svg" alt="stripe icon">
                        <?= $this->lang->line('pay_stripe')??"" ?>
                    </label>
                    <label for="payment_method_1" class="paypal-button">
                        <input type="radio" id="payment_method_1" name="payment_method" value="1" onclick="createPaymentIntentStripePaypal()" />
                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/paypal-btn-icon.svg" alt="paypal icon">
                    </label>
                </div>
                <div class="consult-payment-method-stripe">
                <p><?= $this->lang->line('available_payment_method')??"" ?></p>
                    <ul>
                        <li>
                            <div class="consult-payment-method-stripe-wrap">
                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/mastercard.svg" alt="mastercard icon">
                            </div>
                        </li>
                        <li>
                            <div class="consult-payment-method-stripe-wrap">
                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/visa-payment-icon.svg" alt="visa icon">
                            </div>
                        </li>
                        <li>
                            <div class="consult-payment-method-stripe-wrap">
                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/googlepay-icon.svg" alt="googlepay icon">
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        

        <!-- <div class="consult-payment-success-button consult-payment-button">


            <a class="outline-button payment_button" id="apple_pay">Pay via
                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/applepay-icon.svg" alt="applepay-icon">
            </a>
            <a class="unfilled-button"
                onclick="closecurrentpopup('payment_method',this,'consult-now-choose-payment-method-modal')"><svg
                    width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M15.8334 10.0003H4.16675M4.16675 10.0003L10.0001 15.8337M4.16675 10.0003L10.0001 4.16699"
                        stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
                </svg>Change payment method</a>
        </div> -->

    </div>
</div>
</div>
<!--doctor details modal-->
<div class="modal doctor-detail-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading"><?php echo $this->lang->line('details'); ?></h5>
            <span class="closecurrentpopup">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round"></path>
                </svg>
            </span>
        </div>
        <div class="modal-body">
            <div class="modal-doctor-profile">
                <div class="modal-doctor-profile-img">
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg02.png"
                        alt="patient photo" id="doctor_image">
                    <p id="doctor_image_name"></p>
                    <span class="online-icon availability-icon"></span>
                </div>
                <div class="modal-doctor-profile-info">
                    <h6 id="doctor_name"></h6>
                    <p id="doctor_speciality"></p>
                </div>
            </div>
            <h5 class="modal-sub-heading"><?php echo $this->lang->line('location'); ?></h5>
            <p class="modal-para" id="doctor_location"></p>
            <h5 class="modal-sub-heading"><?php echo $this->lang->line('qualification'); ?></h5>
            <p class="modal-para" id="doctor_qualification"></p>
            <h5 class="modal-sub-heading"><?php echo $this->lang->line('description'); ?></h5>
            <p class="modal-para" id="doctor_desc"></p>
        </div>
    </div>
</div>

<!--share doctor modal-->
<div class="modal share-doctor-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading"><?php echo $this->lang->line('share'); ?></h5>
            <span class="closecurrentpopup"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round"></path>
                </svg></span>
        </div>
        <div class="modal-body">
            <div class="share-doctor-modal-wrap">
                <input type="text" id="share_url" class="share-doctor-input-style">
                <button class="share-doctor-input-copy"><svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_10110_81059)">
                            <path
                                d="M4.16675 12.5001C3.39018 12.5001 3.00189 12.5001 2.69561 12.3732C2.28723 12.2041 1.96277 11.8796 1.79362 11.4712C1.66675 11.1649 1.66675 10.7767 1.66675 10.0001V4.33341C1.66675 3.39999 1.66675 2.93328 1.8484 2.57676C2.00819 2.26316 2.26316 2.00819 2.57676 1.8484C2.93328 1.66675 3.39999 1.66675 4.33341 1.66675H10.0001C10.7767 1.66675 11.1649 1.66675 11.4712 1.79362C11.8796 1.96277 12.2041 2.28723 12.3732 2.69561C12.5001 3.00189 12.5001 3.39018 12.5001 4.16675M10.1667 18.3334H15.6667C16.6002 18.3334 17.0669 18.3334 17.4234 18.1518C17.737 17.992 17.992 17.737 18.1518 17.4234C18.3334 17.0669 18.3334 16.6002 18.3334 15.6667V10.1667C18.3334 9.23333 18.3334 8.76662 18.1518 8.4101C17.992 8.09649 17.737 7.84153 17.4234 7.68174C17.0669 7.50008 16.6002 7.50008 15.6667 7.50008H10.1667C9.23333 7.50008 8.76662 7.50008 8.4101 7.68174C8.09649 7.84153 7.84153 8.09649 7.68174 8.4101C7.50008 8.76662 7.50008 9.23333 7.50008 10.1667V15.6667C7.50008 16.6002 7.50008 17.0669 7.68174 17.4234C7.84153 17.737 8.09649 17.992 8.4101 18.1518C8.76662 18.3334 9.23333 18.3334 10.1667 18.3334Z"
                                stroke="#344054" stroke-width="1.66667" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </g>
                        <defs>
                            <clipPath id="clip0_10110_81059">
                                <rect width="20" height="20" fill="white" />
                            </clipPath>
                        </defs>
                    </svg><?php echo $this->lang->line('copy'); ?></button>
            </div>
        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">
                <button type="button"
                    class="closecurrentpopup unfilled-button"><?php echo $this->lang->line('close'); ?></button>
            </div>
        </div>
    </div>
    <div class="copy-to-clipboard">
        <div class="copy-to-clipboard-icon-text-wrap">
            <div class="copy-success-icon">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M13.3334 4L6.00008 11.3333L2.66675 8" stroke="#079455" stroke-width="1.33333"
                        stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </div>
            <p><?php echo $this->lang->line('copied_to_clipboard'); ?></p>
        </div>
        <button class="close-copy-to-clipboard-btn">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M15 5L5 15M5 5L15 15" stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                    stroke-linejoin="round" />
            </svg>
        </button>
    </div>
</div>

<!-- waiting room  modal-->
<div class="modal consult-waiting-room-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading"><?= $this->lang->line('waiting_room')??"" ?></h5>
            <span class="closecurrentpopup">
                <a href="<?php echo base_url(); ?>virtual_consult/patient/online_waiting_room">
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round"></path>
                    </svg>
                </a>
            </span>
        </div>
        <div class="modal-body">
            <div class="consult-waiting-room-modal-wrap">
                <svg class="loading-spinner" width="32px" height="32px" viewBox="0 0 72 72"
                    xmlns="http://www.w3.org/2000/svg">
                    <circle class="path" fill="none" stroke="#082237" stroke-width="6" stroke-linecap="round" cx="36"
                        cy="36" r="30"></circle>
                </svg>
                <p><?= $this->lang->line('waiting_room_desc')??"" ?> </p>
                <span><?= $this->lang->line('waiting_room_desc_2')??"" ?></span>
            </div>
        </div>
    </div>
</div>
<!-- cancel consultation modal-->
<div class="modal cancel-consultation-modal alert-modal-style">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading"><?= $this->lang->line('confirmation')??"" ?></h5>
            <span class="closecurrentpopup">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round"></path>
                </svg>
            </span>
        </div>
        <div class="modal-body">
            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/alert-icon.svg" alt="alert icon">
            <p><?= $this->lang->line('confirmation_desc')??"" ?></p>
        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">
                <button type="button" class="dangor-button" onclick="cancelRefundMedicalService(<?php echo $params['med_ser_id']??'' ?>)"><?= $this->lang->line('confirmation_yes')??"" ?></button>
                <button type="button" class="closecurrentpopup unfilled-button"><?= $this->lang->line('confirmation_no')??"" ?></button>
            </div>
        </div>
    </div>
</div>



<div class="modal join-success-modal">
	<div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Success</h5>
            <span class="close-success-button">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
            </span>
        </div>
        <div class="modal-body">
            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/success-icon.svg" alt="success icon">
            <p class="success-text"></p>
        </div>  
        <div class="modal-footer">
            <div class="flex-modal-button">               
                <button type="button" class="close-success-button unfilled-button">Close</button>
            </div>
        </div>      
	</div>
</div>

<?php   $session_id = $_GET['token'] ?? null; ?>
<?php 
$accessToken="A21AAJTDWp9m3XrgjUQJjW3Lik252LRlHcDz7n1KppPDp1FZIW1mGbbgIG0fKGNa0wE0UT6F-AHJSVWqGBsdL_DnEaw3YOQWw";
$ch = curl_init("https://api.sandbox.paypal.com/v2/checkout/orders/$session_id/capture");
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "Authorization: Bearer $accessToken"
]);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);

$paymentData = json_decode($response, true);
//var_dump($paymentData); // Check if status is "COMPLETED"

?>
<script>
    // $(".consult-payment-success-modal-trigger").click(function () {
    //     customAlerts(".consult-payment-success-modal", "open");
    //     customAlerts(".consult-payment-summary-modal", "close");
    // });

    $(".cancel-consultation-modal-trigger").click(function () {
        customAlerts(".cancel-consultation-modal", "open");
    });
    //const stripe = Stripe('pk_test_51QiWwAGfcoZoVJhZ0JFlY6VEwvDs45EmQYRgOm38FgDHCiuxDJfozv5u2OpT2rYl1Vng860ZPQe17wnrMKFW9xCj00FDgl9y55');
    var payment_session = <?= json_encode($session_id); ?>;
    if (payment_session && payment_session.trim() !== "") {
        show_loader()
        setTimeout(function() {            
            checkPaymentStatus(payment_session);
        },1500)
    }    
</script>

<!-- <audio id="ringtone" src="http://commondatastorage.googleapis.com/codeskulptor-demos/DDR_assets/Kangaroo_MusiQue_-_The_Neverwritten_Role_Playing_Game.mp3" preload="auto"></audio>

<button onclick="onCallReceived()">Simulate Incoming Call</button>
<button onclick="stopRingtone()">Stop Ringtone</button>

<script>
    const ringtone = document.getElementById('ringtone');

    function playRingtone() {
        ringtone.loop = true; // Keep looping until stopped
        ringtone.play().catch(error => console.log("Autoplay blocked:", error));
    }

    function stopRingtone() {
        ringtone.pause();
        ringtone.currentTime = 0; // Reset to the beginning
    }

    function onCallReceived() {
        playRingtone();
    }

    // Ensure user interaction first
    document.addEventListener("click", () => {
        ringtone.muted = false; // Unmute if needed
    }, { once: true });
</script> -->
