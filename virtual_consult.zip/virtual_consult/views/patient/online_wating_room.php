<section class="patient-appointments-sec">
    <div class="container">
        <div class="patient-appointment-header">
            <div class="patient-appointment-header-text">
                <h2 class="heading-main">Appointments</h2>
            </div>
            <ul class="patient-appointment-header-menu">
                <li>
                    <a class="patient-appointment-menu-button"
                        href="<?php echo base_url(); ?>virtual_consult/patient/search">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M17.5 17.5L12.5001 12.5M14.1667 8.33333C14.1667 11.555 11.555 14.1667 8.33333 14.1667C5.11167 14.1667 2.5 11.555 2.5 8.33333C2.5 5.11167 5.11167 2.5 8.33333 2.5C11.555 2.5 14.1667 5.11167 14.1667 8.33333Z"
                                stroke="#667085" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        Search
                    </a>
                </li>
                <li>
                    <a class="patient-appointment-menu-button"
                        href="<?php echo base_url(); ?>virtual_consult/patient/favourites">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M9.40156 2.8778C9.59363 2.48869 9.68967 2.29413 9.82004 2.23197C9.93347 2.17789 10.0653 2.17789 10.1787 2.23197C10.3091 2.29413 10.4051 2.48869 10.5972 2.8778L12.4194 6.56944C12.4761 6.68432 12.5045 6.74176 12.5459 6.78635C12.5826 6.82584 12.6266 6.85783 12.6754 6.88056C12.7306 6.90623 12.794 6.91549 12.9208 6.93402L16.9968 7.5298C17.4261 7.59253 17.6407 7.6239 17.74 7.72874C17.8264 7.81995 17.8671 7.94529 17.8506 8.06985C17.8317 8.21302 17.6763 8.36436 17.3656 8.66702L14.4172 11.5387C14.3253 11.6282 14.2794 11.673 14.2497 11.7263C14.2235 11.7734 14.2066 11.8252 14.2001 11.8788C14.1928 11.9393 14.2036 12.0025 14.2253 12.129L14.921 16.1851C14.9944 16.6129 15.031 16.8269 14.9621 16.9538C14.9021 17.0642 14.7955 17.1417 14.6719 17.1646C14.5299 17.1909 14.3378 17.0899 13.9536 16.8879L10.3097 14.9716C10.1961 14.9119 10.1394 14.882 10.0796 14.8703C10.0266 14.8599 9.97213 14.8599 9.91918 14.8703C9.85937 14.882 9.8026 14.9119 9.68906 14.9716L6.04512 16.8879C5.66095 17.0899 5.46886 17.1909 5.32683 17.1646C5.20325 17.1417 5.09662 17.0642 5.03663 16.9538C4.96768 16.8269 5.00437 16.6129 5.07774 16.1851L5.77342 12.129C5.79511 12.0025 5.80595 11.9393 5.79862 11.8788C5.79212 11.8252 5.77528 11.7734 5.74902 11.7263C5.71937 11.673 5.67341 11.6282 5.5815 11.5387L2.63315 8.66702C2.3224 8.36436 2.16703 8.21302 2.14812 8.06985C2.13167 7.94529 2.17231 7.81995 2.25872 7.72874C2.35804 7.6239 2.57266 7.59253 3.00189 7.5298L7.07794 6.93402C7.2047 6.91549 7.26808 6.90623 7.32328 6.88056C7.37215 6.85783 7.41615 6.82584 7.45284 6.78635C7.49427 6.74176 7.52262 6.68432 7.57933 6.56944L9.40156 2.8778Z"
                                stroke="#667085" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        Favourites
                    </a>
                </li>
                <li>
                    <a class="patient-appointment-menu-button active"
                        href="<?php echo base_url(); ?>virtual_consult/patient/online_waiting_room">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M17.5 8.33342H2.5M13.3333 1.66675V5.00008M6.66667 1.66675V5.00008M7.5 13.3334L9.16667 15.0001L12.9167 11.2501M6.5 18.3334H13.5C14.9001 18.3334 15.6002 18.3334 16.135 18.0609C16.6054 17.8212 16.9878 17.4388 17.2275 16.9684C17.5 16.4336 17.5 15.7335 17.5 14.3334V7.33342C17.5 5.93328 17.5 5.23322 17.2275 4.69844C16.9878 4.22803 16.6054 3.84558 16.135 3.6059C15.6002 3.33341 14.9001 3.33341 13.5 3.33341H6.5C5.09987 3.33341 4.3998 3.33341 3.86502 3.6059C3.39462 3.84558 3.01217 4.22803 2.77248 4.69844C2.5 5.23322 2.5 5.93328 2.5 7.33341V14.3334C2.5 15.7335 2.5 16.4336 2.77248 16.9684C3.01217 17.4388 3.39462 17.8212 3.86502 18.0609C4.3998 18.3334 5.09987 18.3334 6.5 18.3334Z"
                                stroke="#344054" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <span>Online</span> waiting room
                    </a>
                </li>
                <li>
                    <a class="patient-appointment-menu-button"
                        href="<?php echo base_url(); ?>virtual_consult/patient/history">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M18.9166 11.25L17.2505 9.58333L15.5833 11.25M17.5 10C17.5 14.1421 14.1421 17.5 10 17.5C5.85786 17.5 2.5 14.1421 2.5 10C2.5 5.85786 5.85786 2.5 10 2.5C12.7516 2.5 15.1571 3.98178 16.4621 6.19091M10 5.83333V10L12.5 11.6667"
                                stroke="#667085" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>History
                    </a>
                </li>
            </ul>
        </div>
        <div class="patient-appointment-flex">
            <div class="patient-appointment-filters-div">
                <h6 class="filter-text">Filters</h6>
                <div class="responsive-filter-bar">
                    <h6 class="filter-text-responsive"><svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M5 10H15M2.5 5H17.5M7.5 15H12.5" stroke="#101828" stroke-width="1.66667"
                                stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        Filters</h6>
                    <svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 1.5L6 6.5L11 1.5" stroke="#98A2B3" stroke-width="1.66667" stroke-linecap="round"
                            stroke-linejoin="round" />
                    </svg>
                </div>
                <div class="overlay-responsive"></div>
                <ul class="filter-list">
                    <div class="res-close-btn">
                        <button type="button" class="close-filter-list close-filter-btn"><svg width="24" height="24"
                                viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M18 6L6 18M6 6L18 18" stroke="#344054" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg></button>
                    </div>
                    <h6 class="filter-text-responsive">Filters</h6>
                    <div class="patient-appointment-filters-search">
                        <input type="text" class="input-search-style" placeholder="Health provider name">
                    </div>
                    <li class="active-drop">
                        <div class="drop-down-filters toggle-drop-btn show-filter-list">
                            <h5>Status of appointment</h5>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg" alt="icon">
                        </div>
                        <div class="drop-filters-content">
                            <div class="drop-checkbox-wrap">
                                <form>
                                    <div class="form-group">
                                        <input type="checkbox" id="atall">
                                        <label for="atall">All appointments (7)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="atfture">
                                        <label for="atfture">Future (1)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="atpast">
                                        <label for="atpast">Past (3)</label>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </li>
                    <hr>
                    <li>
                        <div class="drop-down-filters toggle-drop-btn">
                            <h5>Consultation type</h5>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg" alt="icon">
                        </div>
                        <div class="drop-filters-content">
                            <div class="drop-checkbox-wrap">
                                <form>
                                    <div class="form-group">
                                        <input type="checkbox" id="stsall">
                                        <label for="stsall">All (4)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="stsacnf">
                                        <label for="stsacnf">Online (Consult now) (2)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="stsapst">
                                        <label for="stsapst">Online (2)</label>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </li>
                    <hr>
                    <li>
                        <div class="drop-down-filters toggle-drop-btn">
                            <h5>Specialities</h5>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg" alt="icon">
                        </div>
                        <div class="drop-filters-content">
                            <input type="text" placeholder="Search..." class="specialities-search">
                            <div class="drop-checkbox-wrap">
                                <form>
                                    <div class="form-group">
                                        <input type="checkbox" id="allspecialities">
                                        <label for="allspecialities">All specialities (20)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Cardiology">
                                        <label for="Cardiology">Cardiology (8)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Dermatology">
                                        <label for="Dermatology">Dermatology (15)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Gastroenterology">
                                        <label for="Gastroenterology">Gastroenterology (3)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Hematology">
                                        <label for="Hematology">Hematology (10)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Nephrology">
                                        <label for="Nephrology">Nephrology (5)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Neurology">
                                        <label for="Neurology">Neurology (12)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Oncology">
                                        <label for="Oncology">Oncology (18)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Pediatrics">
                                        <label for="Pediatrics">Oncology (18)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Pediatrics">
                                        <label for="Pediatrics">Pediatrics (2)</label>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </li>
                    <div class="res-filter-apply-btn-wrap">
                        <button type="button" class="res-apply-btn">Apply filters <span>(2)</span></button>
                    </div>
                </ul>
            </div>
            <div class="patient-appointment-list-div">

                <div class="result-text">
                    <p><?php echo count($online_waiting_list); ?> todal appointmentcc</p>
                </div>
                <!-- <div class="no-fav-wrap">
                    <h6 class="small-sub-heading">No Upcoming Appointments</h6>
                    <p class="sub-para">You don't have any appointments scheduled at the <br>moment.</p>
                </div> -->
                <?php if (count($online_waiting_list) > 0) { ?>

                    <ul class="patient-hp-appointment-list">
                        <?php foreach ($online_waiting_list as $rec) {// echo "<pre>";print_r($rec); ?>
                            <li>
                                <div class="online-waiting-room-list-wrap">
                                    <div class="online-waiting-room-list-left">
                                        <div class="patient-hp-appointment-datetime">
                                            <svg class="loading-spinner" width="32px" height="32px" viewBox="0 0 72 72"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <circle class="path" fill="none" stroke="blue" stroke-width="6"
                                                    stroke-linecap="round" cx="36" cy="36" r="30"></circle>
                                            </svg>
                                            <div class="patient-hp-appointment-datetime-text">
                                                <div class="center-align res-patient-hp-time-flex-wrap">
                                                    <div class="res-patient-hp-time-flex">
                                                        <p>Waiting time</p>
                                                        <h6 class="patient-hp-appointment-time">19 min</h6>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="online-waiting-room-list-right">
                                        <div class="patient-hp-appointment-doctor-type">
                                            <div class="patient-hp-appointment-doctor-profile">
                                                <div class="patient-hp-appointment-doctor-profile-img">
                                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctordummy-img.png"
                                                        alt="doctor photo">
                                                </div>
                                                <div class="patient-hp-appointment-doctor-profile-info">
                                                    <h6>Orelia Espada</h6>
                                                    <p>Cardiologist</p>
                                                </div>
                                            </div>
                                            <div class="patient-hp-appointment-doctor-consultation-type">
                                                <p class="patient-hp-appointment-small-para-style">Consultation type</p>
                                                <p class="patient-hp-appointment-large-para-style">Online (Consult Now)</p>

                                            </div>
                                            <div class="patient-hp-appointment-cancel-reason">
                                                <p class="patient-hp-appointment-small-para-style">Reason of Appointment</p>
                                                <p class="patient-hp-appointment-large-para-style">Medical certificate</p>
                                            </div>
                                        </div>
                                        <div class="patient-hp-appointment-list-buttons">
                                            <button type="button"
                                                class="patient-hp-appointment-outline-button cancel-appointment-list-modal-trigger outline-button">Cancel
                                                appointment</button>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        <?php } ?>
                    </ul>
                    <div><?php echo $pagination; ?></div>
                <?php } else { ?>
                    <div class="no-more-appointment">
                        <p class="sub-para">No more upcoming appointments</p>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
</section>
<!--cancel appointment-confirmation-modal-->
<div class="modal cancel-appointment-list-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Please provide reason for cancellation</h1>
                <span class="close-button"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round"></path>
                    </svg></span>
        </div>
        <div class="modal-body">
            <div class="cancel-appointment-list-wrap">
                <textarea name="cancel-message" class="text-area-style" id="cancel-message"></textarea>
            </div>

        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">
                <button type="button" class="primary-button dangerstyle">Cancel appointment</button>
                <button type="button" class="close-button unfilled-button">Close</button>
            </div>
        </div>

    </div>
</div>
<!--calling modal-->
<div class="modal calling-modal show-modall">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Incoming call...</h1>
                <span class="closecurrentpopup"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round"></path>
                    </svg></span>
        </div>
        <div class="modal-body">
            <div class="calling-modal-wrap">
                <div class="calling-modal-header">
                    <div class="calling-user-info">
                        <div class="calling-user-image">
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/calling-user.png"
                                alt="user" />
                        </div>
                        <div class="calling-user-name">
                            <h6>Dr. Olivia Rhye</h6>
                            <p>Cardiologist</p>
                        </div>
                    </div>
                    <div class="calling-loader-wrapp">
                        <div class="calling-loader-line"></div>
                        <div class="calling-loader-line"></div>
                        <div class="calling-loader-line"></div>
                    </div>
                </div>
                <div class="patient-side-calling-button-flex">
                    <button class="primary-button dangerstyle"><svg width="21" height="20" viewBox="0 0 21 20"
                            fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M4.55017 5C6.06261 3.4572 8.1702 2.5 10.5014 2.5C12.8325 2.5 14.9401 3.4572 16.4526 5M14.2282 7.5C13.3126 6.47708 11.9822 5.83333 10.5013 5.83333C9.02051 5.83333 7.69003 6.47708 6.7745 7.5M10.5013 14.1667C11.76 14.1667 12.9686 14.3813 14.0925 14.7761C14.1298 14.7892 14.1485 14.7958 14.178 14.8087C14.4451 14.9265 14.6503 15.216 14.6728 15.507C14.6753 15.5391 14.6753 15.5676 14.6753 15.6245C14.6753 15.8184 14.6753 15.9154 14.6834 15.9971C14.7615 16.7881 15.3872 17.4138 16.1782 17.4919C16.2599 17.5 16.3569 17.5 16.5508 17.5H16.755C17.1388 17.5 17.3307 17.5 17.4903 17.4685C18.1537 17.3378 18.6724 16.8191 18.8032 16.1557C18.8346 15.996 18.8346 15.8041 18.8346 15.4203V15.2552C18.8346 14.8591 18.8346 14.6611 18.7924 14.4341C18.6978 13.9265 18.329 13.2985 17.9318 12.9687C17.7542 12.8212 17.6337 12.754 17.3928 12.6196C15.353 11.4817 13.0029 10.8333 10.5013 10.8333C7.99974 10.8333 5.64961 11.4817 3.60981 12.6196C3.36888 12.754 3.24842 12.8212 3.0708 12.9687C2.67359 13.2985 2.30481 13.9265 2.21025 14.4341C2.16797 14.6611 2.16797 14.8591 2.16797 15.2552V15.4203C2.16797 15.8041 2.16797 15.996 2.19943 16.1557C2.33021 16.8191 2.84888 17.3378 3.51231 17.4685C3.67194 17.5 3.86384 17.5 4.24764 17.5H4.45177C4.64574 17.5 4.74272 17.5 4.82441 17.4919C5.61538 17.4138 6.24113 16.7881 6.31924 15.9971C6.3273 15.9154 6.3273 15.8184 6.3273 15.6245C6.3273 15.5676 6.3273 15.5391 6.32979 15.507C6.35232 15.216 6.55747 14.9265 6.82462 14.8087C6.85409 14.7958 6.87277 14.7892 6.91014 14.7761C8.03398 14.3813 9.24257 14.1667 10.5013 14.1667Z"
                                stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>Decline</button>
                    <button class="primary-button successstyle"><svg width="20" height="20" viewBox="0 0 20 20"
                            fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_13628_27419)">
                                <path
                                    d="M11.7074 4.99999C12.5213 5.15879 13.2694 5.55687 13.8558 6.14327C14.4422 6.72967 14.8403 7.47771 14.9991 8.29166M11.7074 1.66666C13.3985 1.85452 14.9754 2.6118 16.1793 3.81416C17.3831 5.01652 18.1424 6.5925 18.3324 8.28332M8.52155 11.5525C7.52023 10.5512 6.72958 9.41903 6.14958 8.21101C6.09969 8.10711 6.07475 8.05515 6.05558 7.98941C5.98748 7.75578 6.0364 7.4689 6.17807 7.27104C6.21794 7.21536 6.26557 7.16773 6.36083 7.07247C6.65217 6.78114 6.79784 6.63547 6.89308 6.48898C7.25224 5.93658 7.25224 5.22442 6.89308 4.67202C6.79784 4.52553 6.65217 4.37987 6.36083 4.08853L6.19844 3.92614C5.75557 3.48327 5.53414 3.26183 5.29632 3.14155C4.82335 2.90232 4.2648 2.90232 3.79183 3.14155C3.55401 3.26183 3.33258 3.48327 2.88971 3.92614L2.75835 4.0575C2.31699 4.49885 2.09632 4.71953 1.92778 5.01955C1.74076 5.35248 1.60629 5.86955 1.60743 6.2514C1.60845 6.59553 1.67521 6.83071 1.80871 7.30108C2.52619 9.82891 3.87992 12.2142 5.8699 14.2042C7.85988 16.1942 10.2452 17.5479 12.773 18.2654C13.2434 18.3989 13.4786 18.4656 13.8227 18.4667C14.2045 18.4678 14.7216 18.3333 15.0545 18.1463C15.3546 17.9778 15.5752 17.7571 16.0166 17.3158L16.148 17.1844C16.5908 16.7415 16.8123 16.5201 16.9325 16.2823C17.1718 15.8093 17.1718 15.2507 16.9325 14.7778C16.8123 14.54 16.5908 14.3185 16.148 13.8757L15.9856 13.7133C15.6942 13.4219 15.5486 13.2763 15.4021 13.181C14.8497 12.8219 14.1375 12.8219 13.5851 13.181C13.4386 13.2763 13.293 13.4219 13.0016 13.7133C12.9064 13.8085 12.8587 13.8562 12.8031 13.896C12.6052 14.0377 12.3183 14.0866 12.0847 14.0185C12.0189 13.9994 11.967 13.9744 11.8631 13.9245C10.6551 13.3445 9.52286 12.5539 8.52155 11.5525Z"
                                    stroke="white" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </g>
                            <defs>
                                <clipPath id="clip0_13628_27419">
                                    <rect width="20" height="20" fill="white" />
                                </clipPath>
                            </defs>
                        </svg>Accept</button>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal calling-modal-mobile">
    <div class="modal-content">
            <div class="calling-modal-modal-wrap">
                <div class="calling-modal-modal-top">
                    <div class="calling-modal-modal-top-image">
                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/logomark.svg" alt="logo">
                    </div> 
                    <div class="calling-modal-modal-top-content">
                        <h6>Dr. Samantha Smith</h6>
                        <p>Medcallz</p>
                    </div>   
                </div>
                <div class="calling-modal-answer-buttons">
                    <div class="calling-modal-reject-button">
                        <button class="calling-modal-button-style" type="button">
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/call-decline-icon.svg" alt="logo">
                        </button>
                        <p>Decline</p>
                    </div>
                    <div class="calling-modal-accept-button">
                    <button class="calling-modal-button-style"type="button">
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/call-accept-icon.svg" alt="logo">
                        </button>
                        <p>Accept</p>
                    </div>
                </div>
            </div>
    </div>
</div>
<script>

    function customAlerts(selector, action = "open", contentData = '') {
        if (action == "open") {
            $(selector).addClass('show-modal');
            $("body").addClass('modal-open');
        } else {
            $(selector).removeClass('show-modal');
            $("body").removeClass('modal-open');
        }
    }
    $(".cancel-appointment-list-modal-trigger").click(function () {
        customAlerts(".cancel-appointment-list-modal", "open");
    });

    $(document).on("click", ".closecurrentpopup", function () {
        $(this).parents('.modal').removeClass('show-modal');
        $("body").removeClass('modal-open');
    });
</script>
<script>
    $(document).ready(function () {
        $(window).scroll(function () {
            var scroll = $(window).scrollTop();
            if (scroll >= 100) {
                $(".patient-appointment-filters-div").addClass("sticky-filter");
            } else {
                $(".patient-appointment-filters-div").removeClass("sticky-filter");
            }
        });
    });
</script>