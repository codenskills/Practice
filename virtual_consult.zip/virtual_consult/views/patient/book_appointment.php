<section class="appointments-steps book-step-1">
        <div class="container">
            <div class="steps-container-wrap">
                <a href="<?php echo base_url();?>virtual_consult/patient/search" class="outline-button"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12.8337 7H1.16699M1.16699 7L7.00033 12.8333M1.16699 7L7.00033 1.16666" stroke="#344054" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    Back to health providers</a>
                    <div class="steps-profile-head">
                        <div class="flex-row-center">
                                <div class="modal-doctor-profile-img">
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg02.png" alt="patient photo">
                                </div>
                                <div class="modal-doctor-profile-info">
                                    <h6>Dr. Olivia Rhye</h6>
                                    <p>Cardiologist</p>
                                </div>
                        </div>
                        <p class="steps-count-text">Step <span>1</span> of <span>2</span></p>
                    </div>
                    <div class="type-of-consult-wrap step-border border-radius steps-sec-padd">
                        <h5 class="steps-sub-heading">Type of consult</h5>
                        <div class="flex-row">
                            <label class="custom-radio-container">Online
                                <input type="radio" checked="checked" name="type-of-consult">
                                <span class="radio-checkmark"></span>
                              </label>
                              <label class="custom-radio-container">Home visit
                                <input type="radio" name="type-of-consult">
                                <span class="radio-checkmark"></span>
                              </label>
                              <label class="custom-radio-container">Clinic
                                <input type="radio" name="type-of-consult">
                                <span class="radio-checkmark"></span>
                              </label>
                        </div>
                    </div>
                    <div class="date-time-picker-wrap step-border border-radius steps-sec-padd steps-mt">
                        <h5 class="steps-sub-heading">Date and time</h5>
                        <div class="date-time-picker-row">
                            <div class="date-picker-wrap">
                                <p class="steps-sub-para font-500">Date</p>
                                <div class="datepicker-wrap">
                                <input type="text" id="booking-date-datepicker" class="date" readonly="readonly" placeholder="9/02/2024">
                                <svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M1 1.5L6 6.5L11 1.5" stroke="#667085" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                  </svg>
                                  
                              </div>
                            </div>
                            <div class="selected-date-time-wrap">
                                <p class="steps-sub-para font-500">Selected date and time</p>
                                <ul>
                                    <li>
                                        <svg width="14" height="16" viewBox="0 0 14 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M13 6.66668H1M9.66667 1.33334V4.00001M4.33333 1.33334V4.00001M4.2 14.6667H9.8C10.9201 14.6667 11.4802 14.6667 11.908 14.4487C12.2843 14.2569 12.5903 13.951 12.782 13.5747C13 13.1468 13 12.5868 13 11.4667V5.86668C13 4.74657 13 4.18652 12.782 3.7587C12.5903 3.38237 12.2843 3.07641 11.908 2.88466C11.4802 2.66668 10.9201 2.66668 9.8 2.66668H4.2C3.0799 2.66668 2.51984 2.66668 2.09202 2.88466C1.71569 3.07641 1.40973 3.38237 1.21799 3.7587C1 4.18652 1 4.74657 1 5.86668V11.4667C1 12.5868 1 13.1468 1.21799 13.5747C1.40973 13.951 1.71569 14.2569 2.09202 14.4487C2.51984 14.6667 3.0799 14.6667 4.2 14.6667Z" stroke="#475467" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                            07-07-2023
                                    </li>
                                    <li>
                                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_2827_15152)">
                                            <path d="M7.99967 4.00001V8.00001L10.6663 9.33334M14.6663 8.00001C14.6663 11.6819 11.6816 14.6667 7.99967 14.6667C4.31778 14.6667 1.33301 11.6819 1.33301 8.00001C1.33301 4.31811 4.31778 1.33334 7.99967 1.33334C11.6816 1.33334 14.6663 4.31811 14.6663 8.00001Z" stroke="#475467" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                            </g>
                                            <defs>
                                            <clipPath id="clip0_2827_15152">
                                            <rect width="16" height="16" fill="white"/>
                                            </clipPath>
                                            </defs>
                                            </svg>
                                            01:00 PM
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="tabs">
                            <div class="tab-buttons tabs-carousel owl-carousel owl-theme">
                                <div class="item"><button class="tab-button active" data-tab="1">
                                    <span>Today<span class="slot-text slot-green">20 slots available</span></span>
                                </button></div>
                                <div class="item"> <button class="tab-button" data-tab="2">
                                    <span>Sat, 13 Apr<span class="slot-text slot-orange">4 slots available</span></span>
                                </button></div>
                                <div class="item"><button class="tab-button" data-tab="3">
                                    <span>Sun, 14 Apr<span class="slot-text">0 slots available</span></span>
                                </button></div>
                            </div>
                            <div class="tab-contents">
                                <div class="tab-content" data-tab="1">
                                    <div class="slot-availability-table-wrap">
                                        <div class="slot-availability-table-left-wrap">
                                            <p class="steps-sub-para font-500"><svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M3 17H1M5.31412 11.3141L3.8999 9.8999M16.6858 11.3141L18.1 9.8999M21 17H19M6 17C6 14.2386 8.23858 12 11 12C13.7614 12 16 14.2386 16 17M21 21H1M15 5L11 1M11 1L7 5M11 1V8" stroke="#F79009" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                Morning</p>
                                        </div>
                                        <div class="slot-availability-table-right-wrap">
                                            <ul class="custom-radio-type-btn">
                                                <li>
                                                  <input type="radio" id="mt1" name="slot-availability" />
                                                  <label for="mt1">8:00 AM</label>
                                                </li>
                                                <li>
                                                  <input type="radio" id="mt2" name="slot-availability" />
                                                  <label for="mt2">8:15 AM</label>
                                                </li>
                                                <li>
                                                  <input type="radio" id="mt3" name="slot-availability" />
                                                  <label for="mt3">8:30 AM</label>
                                                </li>
                                                <li>
                                                    <input type="radio" id="mt4" name="slot-availability" />
                                                    <label for="mt4">8:45 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="mt5" name="slot-availability" />
                                                    <label for="mt5">9:00 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="mt6" name="slot-availability" />
                                                    <label for="mt6">9:15 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="mt1" name="slot-availability" />
                                                    <label for="mt1">9:30 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="mt7" name="slot-availability" />
                                                    <label for="mt7">9:45 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="mt8" name="slot-availability" />
                                                    <label for="mt8">10:00 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="mt9" name="slot-availability" />
                                                    <label for="mt9">10:15 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="mt10" name="slot-availability" />
                                                    <label for="mt10">10:30 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="mt11" name="slot-availability" />
                                                    <label for="mt11">10:45 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="mt12" name="slot-availability" />
                                                    <label for="mt12">11:00 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="mt13" name="slot-availability" />
                                                    <label for="mt13">11:15 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="mt14" name="slot-availability" />
                                                    <label for="mt14">11:30 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="mt15" name="slot-availability" />
                                                    <label for="mt15">11:45 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="mt16" name="slot-availability" />
                                                    <label for="mt16">12:00 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="mt17" name="slot-availability" />
                                                    <label for="mt17">12:15 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="mt18" name="slot-availability" />
                                                    <label for="mt18">12:30 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="mt19" name="slot-availability" />
                                                    <label for="mt19">12:45 AM</label>
                                                  </li>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="slot-availability-table-wrap slot-afternoon">
                                        <div class="slot-availability-table-left-wrap">
                                            <p class="steps-sub-para font-500"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M12 2V4M12 20V22M4 12H2M6.31412 6.31412L4.8999 4.8999M17.6859 6.31412L19.1001 4.8999M6.31412 17.69L4.8999 19.1042M17.6859 17.69L19.1001 19.1042M22 12H20M17 12C17 14.7614 14.7614 17 12 17C9.23858 17 7 14.7614 7 12C7 9.23858 9.23858 7 12 7C14.7614 7 17 9.23858 17 12Z" stroke="#FDE272" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                
                                                Afternoon</p>
                                        </div>
                                        <div class="slot-availability-table-right-wrap">
                                            <ul class="custom-radio-type-btn">
                                                <li>
                                                  <input type="radio" id="at1" name="slot-availability" />
                                                  <label for="at1">1:00 PM</label>
                                                </li>
                                                <li>
                                                  <input type="radio" id="at2" name="slot-availability" />
                                                  <label for="at2">1:15 PM</label>
                                                </li>
                                                <li>
                                                  <input type="radio" id="at3" name="slot-availability" />
                                                  <label for="at3">1:30 PM</label>
                                                </li>
                                                <li>
                                                    <input type="radio" id="at4" name="slot-availability" />
                                                    <label for="at4">1:45 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="at5" name="slot-availability" />
                                                    <label for="at5">2:00 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="at6" name="slot-availability" />
                                                    <label for="at6">2:15 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="at7" name="slot-availability" />
                                                    <label for="at7">2:30 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="at8" name="slot-availability" />
                                                    <label for="at8">2:45 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="at9" name="slot-availability" />
                                                    <label for="at9">3:45 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="at10" name="slot-availability" />
                                                    <label for="at10">4:00 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="at11" name="slot-availability" />
                                                    <label for="at11">4:15 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="at12" name="slot-availability" />
                                                    <label for="at12">4:30 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="at13" name="slot-availability" />
                                                    <label for="at13">4:45 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="at14" name="slot-availability" />
                                                    <label for="at14">5:00 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="at15" name="slot-availability" />
                                                    <label for="at15">5:15 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="at16" name="slot-availability" />
                                                    <label for="at16">5:30 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="at17" name="slot-availability" />
                                                    <label for="at17">5:45 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="at18" name="slot-availability" />
                                                    <label for="at18">6:00 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="at19" name="slot-availability" />
                                                    <label for="at19">6:15 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="at20" name="slot-availability" />
                                                    <label for="at20">6:30 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="at21" name="slot-availability" />
                                                    <label for="at21">6:45 PM</label>
                                                  </li>
                                                  
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="slot-availability-table-wrap slot-evening">
                                        <div class="slot-availability-table-left-wrap">
                                            <p class="steps-sub-para font-500"><svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M3 17H1M5.31412 11.3141L3.8999 9.8999M16.6858 11.3141L18.1 9.8999M21 17H19M6 17C6 14.2386 8.23858 12 11 12C13.7614 12 16 14.2386 16 17M21 21H1M15 4L11 8M11 8L7 4M11 8V1" stroke="#B54708" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                
                                                Evening</p>
                                        </div>
                                        <div class="slot-availability-table-right-wrap">
                                            <ul class="custom-radio-type-btn">
                                                <li>
                                                    <input type="radio" id="et1" name="slot-availability" />
                                                    <label for="et1">7:00 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="et2" name="slot-availability" />
                                                    <label for="et2">7:15 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="et3" name="slot-availability" />
                                                    <label for="et3">7:30 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="et4" name="slot-availability" />
                                                    <label for="et4">7:45 PM</label>
                                                  </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-content" data-tab="2">
                                    <div class="slot-availability-table-wrap">
                                        <div class="slot-availability-table-left-wrap">
                                            <p class="steps-sub-para font-500"><svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M3 17H1M5.31412 11.3141L3.8999 9.8999M16.6858 11.3141L18.1 9.8999M21 17H19M6 17C6 14.2386 8.23858 12 11 12C13.7614 12 16 14.2386 16 17M21 21H1M15 5L11 1M11 1L7 5M11 1V8" stroke="#F79009" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                Morning</p>
                                        </div>
                                        <div class="slot-availability-table-right-wrap">
                                            <ul class="custom-radio-type-btn">
                                                <li>
                                                  <input type="radio" id="a" name="slot-availability" />
                                                  <label for="a">8:00 AM</label>
                                                </li>
                                                <li>
                                                  <input type="radio" id="b" name="slot-availability" />
                                                  <label for="b">8:15 AM</label>
                                                </li>
                                                <li>
                                                  <input type="radio" id="c" name="slot-availability" />
                                                  <label for="c">8:30 AM</label>
                                                </li>
                                                <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">8:45 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">9:00 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">9:15 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">9:30 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">9:45 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">10:00 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">10:15 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">10:30 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">10:45 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">11:00 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">11:15 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">11:30 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">11:45 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">12:00 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">12:15 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">12:30 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">12:45 AM</label>
                                                  </li>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="slot-availability-table-wrap slot-afternoon">
                                        <div class="slot-availability-table-left-wrap">
                                            <p class="steps-sub-para font-500"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M12 2V4M12 20V22M4 12H2M6.31412 6.31412L4.8999 4.8999M17.6859 6.31412L19.1001 4.8999M6.31412 17.69L4.8999 19.1042M17.6859 17.69L19.1001 19.1042M22 12H20M17 12C17 14.7614 14.7614 17 12 17C9.23858 17 7 14.7614 7 12C7 9.23858 9.23858 7 12 7C14.7614 7 17 9.23858 17 12Z" stroke="#FDE272" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                
                                                Afternoon</p>
                                        </div>
                                        <div class="slot-availability-table-right-wrap">
                                            <ul class="custom-radio-type-btn">
                                                <li>
                                                  <input type="radio" id="a" name="slot-availability" />
                                                  <label for="a">1:00 PM</label>
                                                </li>
                                                <li>
                                                  <input type="radio" id="b" name="slot-availability" />
                                                  <label for="b">1:15 PM</label>
                                                </li>
                                                <li>
                                                  <input type="radio" id="c" name="slot-availability" />
                                                  <label for="c">1:30 PM</label>
                                                </li>
                                                <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">1:45 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">2:00 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">2:15 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">2:30 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">2:45 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">3:45 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">4:00 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">4:15 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">4:30 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">4:45 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">5:00 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">5:15 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">5:30 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">5:45 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">6:00 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">6:15 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">6:30 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">6:45 PM</label>
                                                  </li>
                                                  
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="slot-availability-table-wrap slot-evening">
                                        <div class="slot-availability-table-left-wrap">
                                            <p class="steps-sub-para font-500"><svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M3 17H1M5.31412 11.3141L3.8999 9.8999M16.6858 11.3141L18.1 9.8999M21 17H19M6 17C6 14.2386 8.23858 12 11 12C13.7614 12 16 14.2386 16 17M21 21H1M15 4L11 8M11 8L7 4M11 8V1" stroke="#B54708" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                
                                                Evening</p>
                                        </div>
                                        <div class="slot-availability-table-right-wrap">
                                            <ul class="custom-radio-type-btn">
                                                <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">7:00 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">7:15 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">7:30 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">7:45 PM</label>
                                                  </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-content" data-tab="3">
                                    <div class="slot-availability-table-wrap">
                                        <div class="slot-availability-table-left-wrap">
                                            <p class="steps-sub-para font-500"><svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M3 17H1M5.31412 11.3141L3.8999 9.8999M16.6858 11.3141L18.1 9.8999M21 17H19M6 17C6 14.2386 8.23858 12 11 12C13.7614 12 16 14.2386 16 17M21 21H1M15 5L11 1M11 1L7 5M11 1V8" stroke="#F79009" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                Morning</p>
                                        </div>
                                        <div class="slot-availability-table-right-wrap">
                                            <ul class="custom-radio-type-btn">
                                                <li>
                                                  <input type="radio" id="a" name="slot-availability" />
                                                  <label for="a">8:00 AM</label>
                                                </li>
                                                <li>
                                                  <input type="radio" id="b" name="slot-availability" />
                                                  <label for="b">8:15 AM</label>
                                                </li>
                                                <li>
                                                  <input type="radio" id="c" name="slot-availability" />
                                                  <label for="c">8:30 AM</label>
                                                </li>
                                                <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">8:45 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">9:00 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">9:15 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">9:30 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">9:45 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">10:00 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">10:15 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">10:30 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">10:45 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">11:00 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">11:15 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">11:30 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">11:45 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">12:00 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">12:15 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">12:30 AM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">12:45 AM</label>
                                                  </li>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="slot-availability-table-wrap slot-afternoon">
                                        <div class="slot-availability-table-left-wrap">
                                            <p class="steps-sub-para font-500"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M12 2V4M12 20V22M4 12H2M6.31412 6.31412L4.8999 4.8999M17.6859 6.31412L19.1001 4.8999M6.31412 17.69L4.8999 19.1042M17.6859 17.69L19.1001 19.1042M22 12H20M17 12C17 14.7614 14.7614 17 12 17C9.23858 17 7 14.7614 7 12C7 9.23858 9.23858 7 12 7C14.7614 7 17 9.23858 17 12Z" stroke="#FDE272" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                
                                                Afternoon</p>
                                        </div>
                                        <div class="slot-availability-table-right-wrap">
                                            <ul class="custom-radio-type-btn">
                                                <li>
                                                  <input type="radio" id="a" name="slot-availability" />
                                                  <label for="a">1:00 PM</label>
                                                </li>
                                                <li>
                                                  <input type="radio" id="b" name="slot-availability" />
                                                  <label for="b">1:15 PM</label>
                                                </li>
                                                <li>
                                                  <input type="radio" id="c" name="slot-availability" />
                                                  <label for="c">1:30 PM</label>
                                                </li>
                                                <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">1:45 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">2:00 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">2:15 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">2:30 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">2:45 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">3:45 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">4:00 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">4:15 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">4:30 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">4:45 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">5:00 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">5:15 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">5:30 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">5:45 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">6:00 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="a" name="slot-availability" />
                                                    <label for="a">6:15 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="b" name="slot-availability" />
                                                    <label for="b">6:30 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">6:45 PM</label>
                                                  </li>
                                                  
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="slot-availability-table-wrap slot-evening">
                                        <div class="slot-availability-table-left-wrap">
                                            <p class="steps-sub-para font-500"><svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M3 17H1M5.31412 11.3141L3.8999 9.8999M16.6858 11.3141L18.1 9.8999M21 17H19M6 17C6 14.2386 8.23858 12 11 12C13.7614 12 16 14.2386 16 17M21 21H1M15 4L11 8M11 8L7 4M11 8V1" stroke="#B54708" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                
                                                Evening</p>
                                        </div>
                                        <div class="slot-availability-table-right-wrap">
                                            <ul class="custom-radio-type-btn">
                                                <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">7:00 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">7:15 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">7:30 PM</label>
                                                  </li>
                                                  <li>
                                                    <input type="radio" id="c" name="slot-availability" />
                                                    <label for="c">7:45 PM</label>
                                                  </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="booking-cansulation-wrap step-border border-radius steps-sec-padd steps-mt">
                        <h5 class="steps-sub-heading">Reason for consultation</h5>
                        <ul class="custom-radio-type-btn">
                            <li>
                              <input type="radio" id="carer-certificate-reason" name="reason-for-consultation" />
                              <label for="carer-certificate-reason">Carer Certificate</label>
                            </li>
                            <li>
                              <input type="radio" id="scan-request-reason" name="reason-for-consultation" />
                              <label for="scan-request-reason">Imaging/scan request</label>
                            </li>
                            <li>
                              <input type="radio" id="medical-certificate-reason" name="reason-for-consultation" />
                              <label for="medical-certificate-reason">Medical certificate</label>
                            </li>
                            <li>
                              <input type="radio" id="medical-consult-reason" name="reason-for-consultation" />
                              <label for="medical-consult-reason">Medical consult</label>
                            </li>
                            <li>
                              <input type="radio" id="medicolegal-reason" name="reason-for-consultation" />
                              <label for="medicolegal-reason">Medicolegal</label>
                            </li>  
                            <li>
                                <input type="radio" id="blood-test-request" name="reason-for-consultation" />
                                <label for="blood-test-request">Pathology/blood test request</label>
                              </li>   
                              <li>
                                <input type="radio" id="presciption-scripts" name="reason-for-consultation" />
                                <label for="presciption-scripts">Presciption scripts</label>
                              </li>
                              <li>
                                <input type="radio" id="special-referral" name="reason-for-consultation" />
                                <label for="special-referral">Special referral</label>
                              </li>
                              <li>
                                <input type="radio" id="other-reason" name="reason-for-consultation" />
                                <label for="other-reason">Other</label>
                              </li>                        
                          </ul>
                          <div class="questionnaire-wrap">
                            <div class="drop-down-filters questionnaire-toggle-drop-btn">
                                <h5>Questionnaire</h5>
                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/questionnaire-down.svg" alt="icon">
                            </div>
                            <div class="drop-filters-content questionnaire-toggle-drop-content">
                                <ul class="questionnaire-list">
                                    <li>
                                        <div class="questionnaire-list-wrap">
                                            <div class="questionnaire-list-icon">
                                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M7.57533 7.49996C7.77125 6.94302 8.15795 6.47338 8.66695 6.17424C9.17596 5.87509 9.7744 5.76574 10.3563 5.86555C10.9382 5.96536 11.466 6.2679 11.8462 6.71957C12.2264 7.17124 12.4345 7.74289 12.4337 8.33329C12.4337 9.99996 9.93366 10.8333 9.93366 10.8333M10.0003 14.1666H10.0087M18.3337 9.99996C18.3337 14.6023 14.6027 18.3333 10.0003 18.3333C5.39795 18.3333 1.66699 14.6023 1.66699 9.99996C1.66699 5.39759 5.39795 1.66663 10.0003 1.66663C14.6027 1.66663 18.3337 5.39759 18.3337 9.99996Z" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                                    </svg>
                                                    
                                            </div>
                                            <div class="questionnaire-list-content">
                                                <label class="steps-sub-para">Are you allergic to any medications?</label>
                                                <input type="text" class="input-text-style" placeholder="Answer...">
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="questionnaire-list-wrap">
                                            <div class="questionnaire-list-icon">
                                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M7.57533 7.49996C7.77125 6.94302 8.15795 6.47338 8.66695 6.17424C9.17596 5.87509 9.7744 5.76574 10.3563 5.86555C10.9382 5.96536 11.466 6.2679 11.8462 6.71957C12.2264 7.17124 12.4345 7.74289 12.4337 8.33329C12.4337 9.99996 9.93366 10.8333 9.93366 10.8333M10.0003 14.1666H10.0087M18.3337 9.99996C18.3337 14.6023 14.6027 18.3333 10.0003 18.3333C5.39795 18.3333 1.66699 14.6023 1.66699 9.99996C1.66699 5.39759 5.39795 1.66663 10.0003 1.66663C14.6027 1.66663 18.3337 5.39759 18.3337 9.99996Z" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                                    </svg>
                                                    
                                            </div>
                                            <div class="questionnaire-list-content">
                                                <label class="steps-sub-para">Are you allergic to any substance/ medications? What happens when u are exposed to each substance/medication? (Example: Penicillin causes anaphylaxis)?</label>
                                                <input type="text" class="input-text-style" placeholder="Answer...">
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="questionnaire-list-wrap">
                                            <div class="questionnaire-list-icon">
                                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M7.57533 7.49996C7.77125 6.94302 8.15795 6.47338 8.66695 6.17424C9.17596 5.87509 9.7744 5.76574 10.3563 5.86555C10.9382 5.96536 11.466 6.2679 11.8462 6.71957C12.2264 7.17124 12.4345 7.74289 12.4337 8.33329C12.4337 9.99996 9.93366 10.8333 9.93366 10.8333M10.0003 14.1666H10.0087M18.3337 9.99996C18.3337 14.6023 14.6027 18.3333 10.0003 18.3333C5.39795 18.3333 1.66699 14.6023 1.66699 9.99996C1.66699 5.39759 5.39795 1.66663 10.0003 1.66663C14.6027 1.66663 18.3337 5.39759 18.3337 9.99996Z" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                                    </svg>
                                                    
                                            </div>
                                            <div class="questionnaire-list-content">
                                                <label class="steps-sub-para">Describe your symptoms that you are experiencing at the moment?</label>
                                                <input type="text" class="input-text-style" placeholder="Answer...">
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="questionnaire-list-wrap">
                                            <div class="questionnaire-list-icon">
                                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M7.57533 7.49996C7.77125 6.94302 8.15795 6.47338 8.66695 6.17424C9.17596 5.87509 9.7744 5.76574 10.3563 5.86555C10.9382 5.96536 11.466 6.2679 11.8462 6.71957C12.2264 7.17124 12.4345 7.74289 12.4337 8.33329C12.4337 9.99996 9.93366 10.8333 9.93366 10.8333M10.0003 14.1666H10.0087M18.3337 9.99996C18.3337 14.6023 14.6027 18.3333 10.0003 18.3333C5.39795 18.3333 1.66699 14.6023 1.66699 9.99996C1.66699 5.39759 5.39795 1.66663 10.0003 1.66663C14.6027 1.66663 18.3337 5.39759 18.3337 9.99996Z" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                                    </svg>
                                                    
                                            </div>
                                            <div class="questionnaire-list-content">
                                                <label class="steps-sub-para">Do you drink alcohol? How many standard drinks do you drink a week?</label>
                                                <input type="text" class="input-text-style" placeholder="Answer...">
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="questionnaire-list-wrap">
                                            <div class="questionnaire-list-icon">
                                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M7.57533 7.49996C7.77125 6.94302 8.15795 6.47338 8.66695 6.17424C9.17596 5.87509 9.7744 5.76574 10.3563 5.86555C10.9382 5.96536 11.466 6.2679 11.8462 6.71957C12.2264 7.17124 12.4345 7.74289 12.4337 8.33329C12.4337 9.99996 9.93366 10.8333 9.93366 10.8333M10.0003 14.1666H10.0087M18.3337 9.99996C18.3337 14.6023 14.6027 18.3333 10.0003 18.3333C5.39795 18.3333 1.66699 14.6023 1.66699 9.99996C1.66699 5.39759 5.39795 1.66663 10.0003 1.66663C14.6027 1.66663 18.3337 5.39759 18.3337 9.99996Z" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                                    </svg>
                                                    
                                            </div>
                                            <div class="questionnaire-list-content">
                                                <label class="steps-sub-para">Do you elicit any illegal substances?</label>
                                                <input type="text" class="input-text-style" placeholder="Answer...">
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                          </div>
                    </div>
                    <div class="upload-files-wrap step-border border-radius steps-sec-padd steps-mt">
                        <h5 class="steps-sub-heading mb-0">Upload files</h5>
                        <p class="steps-sub-para">Please upload relevant reports/files/referrals/forms for health provider to view during consultation.</p>
                        <div class="booking-appointment-file-upload-wrap">
                            <input id="file-upload" type="file" name="fileUpload" />
                            <label for="file-upload" id="file-drag">
                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/upload-icon.svg" alt="upload icon">
                                <span>Click to upload</span> or drag and drop<br>SVG, PNG, JPG or GIF (max. 800x400px)
                            </label>
                        </div>
                        <ul class="booking-appointment-file-upload-results">
                           <li>
                                <div class="booking-appointment-file-upload-result-wrap">
                                    <div class="file-upload-icon-type-wrap">
                                        <div class="icon-wrap">
                                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/svg-file-icon.svg" alt="svg icon">
                                        </div>
                                        <p>File1.svg<span>(250 kb)</span></p>
                                    </div>
                                    <div class="remove-upload-list-wrap">
                                        <a class="remove-upload-button tooltip"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M13.3333 5.00008V4.33341C13.3333 3.39999 13.3333 2.93328 13.1517 2.57676C12.9919 2.26316 12.7369 2.00819 12.4233 1.8484C12.0668 1.66675 11.6001 1.66675 10.6667 1.66675H9.33333C8.39991 1.66675 7.9332 1.66675 7.57668 1.8484C7.26308 2.00819 7.00811 2.26316 6.84832 2.57676C6.66667 2.93328 6.66667 3.39999 6.66667 4.33341V5.00008M8.33333 9.58342V13.7501M11.6667 9.58342V13.7501M2.5 5.00008H17.5M15.8333 5.00008V14.3334C15.8333 15.7335 15.8333 16.4336 15.5608 16.9684C15.3212 17.4388 14.9387 17.8212 14.4683 18.0609C13.9335 18.3334 13.2335 18.3334 11.8333 18.3334H8.16667C6.76654 18.3334 6.06647 18.3334 5.53169 18.0609C5.06129 17.8212 4.67883 17.4388 4.43915 16.9684C4.16667 16.4336 4.16667 15.7335 4.16667 14.3334V5.00008" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                        <span class="tooltiptext">Delete</span>
                                      </a>
                                    </div>
                                </div>
                           </li>
                           <li>
                                <div class="booking-appointment-file-upload-result-wrap">
                                    <div class="file-upload-icon-type-wrap">
                                        <div class="icon-wrap">
                                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/png-file-icon.svg" alt="png icon">
                                        </div>
                                        <p>File2.png<span>(250 kb)</span></p>
                                    </div>
                                    <div class="remove-upload-list-wrap">
                                        <a class="remove-upload-button tooltip"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M13.3333 5.00008V4.33341C13.3333 3.39999 13.3333 2.93328 13.1517 2.57676C12.9919 2.26316 12.7369 2.00819 12.4233 1.8484C12.0668 1.66675 11.6001 1.66675 10.6667 1.66675H9.33333C8.39991 1.66675 7.9332 1.66675 7.57668 1.8484C7.26308 2.00819 7.00811 2.26316 6.84832 2.57676C6.66667 2.93328 6.66667 3.39999 6.66667 4.33341V5.00008M8.33333 9.58342V13.7501M11.6667 9.58342V13.7501M2.5 5.00008H17.5M15.8333 5.00008V14.3334C15.8333 15.7335 15.8333 16.4336 15.5608 16.9684C15.3212 17.4388 14.9387 17.8212 14.4683 18.0609C13.9335 18.3334 13.2335 18.3334 11.8333 18.3334H8.16667C6.76654 18.3334 6.06647 18.3334 5.53169 18.0609C5.06129 17.8212 4.67883 17.4388 4.43915 16.9684C4.16667 16.4336 4.16667 15.7335 4.16667 14.3334V5.00008" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                        <span class="tooltiptext">Delete</span>
                                      </a>
                                    </div>
                                </div>
                           </li>
                           <li>
                                <div class="booking-appointment-file-upload-result-wrap">
                                    <div class="file-upload-icon-type-wrap">
                                        <div class="icon-wrap">
                                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/jpg-file-icon.svg" alt="jpg icon">
                                        </div>
                                        <p>File3.jpg<span>(250 kb)</span></p>
                                    </div>
                                    <div class="remove-upload-list-wrap">
                                        <a class="remove-upload-button tooltip"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M13.3333 5.00008V4.33341C13.3333 3.39999 13.3333 2.93328 13.1517 2.57676C12.9919 2.26316 12.7369 2.00819 12.4233 1.8484C12.0668 1.66675 11.6001 1.66675 10.6667 1.66675H9.33333C8.39991 1.66675 7.9332 1.66675 7.57668 1.8484C7.26308 2.00819 7.00811 2.26316 6.84832 2.57676C6.66667 2.93328 6.66667 3.39999 6.66667 4.33341V5.00008M8.33333 9.58342V13.7501M11.6667 9.58342V13.7501M2.5 5.00008H17.5M15.8333 5.00008V14.3334C15.8333 15.7335 15.8333 16.4336 15.5608 16.9684C15.3212 17.4388 14.9387 17.8212 14.4683 18.0609C13.9335 18.3334 13.2335 18.3334 11.8333 18.3334H8.16667C6.76654 18.3334 6.06647 18.3334 5.53169 18.0609C5.06129 17.8212 4.67883 17.4388 4.43915 16.9684C4.16667 16.4336 4.16667 15.7335 4.16667 14.3334V5.00008" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                        <span class="tooltiptext">Delete</span>
                                      </a>
                                    </div>
                                </div>
                           </li>
                           <li>
                                <div class="booking-appointment-file-upload-result-wrap">
                                    <div class="file-upload-icon-type-wrap">
                                        <div class="icon-wrap">
                                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/pdf-file-icon.svg" alt="pdf icon">
                                        </div>
                                        <p>File4.pdf<span>(250 kb)</span></p>
                                    </div>
                                    <div class="remove-upload-list-wrap">
                                        <a class="remove-upload-button tooltip"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M13.3333 5.00008V4.33341C13.3333 3.39999 13.3333 2.93328 13.1517 2.57676C12.9919 2.26316 12.7369 2.00819 12.4233 1.8484C12.0668 1.66675 11.6001 1.66675 10.6667 1.66675H9.33333C8.39991 1.66675 7.9332 1.66675 7.57668 1.8484C7.26308 2.00819 7.00811 2.26316 6.84832 2.57676C6.66667 2.93328 6.66667 3.39999 6.66667 4.33341V5.00008M8.33333 9.58342V13.7501M11.6667 9.58342V13.7501M2.5 5.00008H17.5M15.8333 5.00008V14.3334C15.8333 15.7335 15.8333 16.4336 15.5608 16.9684C15.3212 17.4388 14.9387 17.8212 14.4683 18.0609C13.9335 18.3334 13.2335 18.3334 11.8333 18.3334H8.16667C6.76654 18.3334 6.06647 18.3334 5.53169 18.0609C5.06129 17.8212 4.67883 17.4388 4.43915 16.9684C4.16667 16.4336 4.16667 15.7335 4.16667 14.3334V5.00008" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                        <span class="tooltiptext">Delete</span>
                                      </a>
                                    </div>
                                </div>
                           </li>
                        </ul>
                    </div>
                    <div class="steps-terms-condition step-border border-radius steps-sec-padd steps-mt">
                        <h5 class="steps-sub-heading">Pharmacy</h5>
                        <input type="text" class="steps-search-bar" placeholder="Address / Name / Postal code of nearest pharmacy"/>
                        <a href="#" class="add-pharmacy-btn"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M7.00033 1.16675V12.8334M1.16699 7.00008H12.8337" stroke="#165A93" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            Add pharmacy</a>
                    </div>
                    <div class="steps-terms-condition step-border border-radius steps-sec-padd steps-mt">
                        <h5 class="steps-sub-heading">Terms & conditions</h5>
                        <form>
                            <div class="custom-square-checkbox">
                                <input type="checkbox" id="term1">
                                <label for="term1"><div>Agree to terms<br><p>I have read and agree to the <a href="#" target="_blank">Privacy Policy</a>, <a href="#" target="_blank">Terms of Service</a> and Patient <a href="#" target="_blank">Responsibility Agreement</a></p></div></label>
                            </div>
                            <div class="custom-square-checkbox">
                                <input type="checkbox" id="term2">
                                <label for="term2">I assign my right to benefits to the Practitioner who rendered the services.</label>
                            </div>
                            <div class="custom-square-checkbox">
                                <input type="checkbox" id="term3">
                                <label for="term3">I offer to assign my right to benefits to the approved Pathology/Radiology Practitioner who will render the requested pathology/radiology services.</label>
                            </div>
                        </form>
                    </div>
            </div>
        </div>
        <div class="steps-footer">
          <div class="flex-modal-button">
              <a class="outline-button canceltrigger">Cancel</a>
              <a href="javascript:void(0)" data-targe="#tg-2" class="primary-button" id="proceed-payment-button">Proceed to payment</a>
          </div>
  </div>
    </section>
	<section class="appointments-steps book-step-2" id="tg-2">
    <div class="container">
      <div class="steps-container-wrap">
        <a href="<?php echo base_url();?>virtual_consult/patient/search" class="outline-button"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
            xmlns="http://www.w3.org/2000/svg">
            <path d="M12.8337 7H1.16699M1.16699 7L7.00033 12.8333M1.16699 7L7.00033 1.16666" stroke="#344054"
              stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
          </svg>
          Back to health providers</a>
        <div class="steps-profile-head">
          <div class="flex-row-center">
            <div class="modal-doctor-profile-img">
              <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg02.png" alt="patient photo">
            </div>
            <div class="modal-doctor-profile-info">
              <h6>Dr. Olivia Rhye</h6>
              <p>Cardiologist</p>
            </div>
          </div>
          <p class="steps-count-text">Step <span>2</span> of <span>2</span></p>
        </div>
        <div class="appointment-details-wrap step-border border-radius steps-sec-padd">
          <h5 class="steps-sub-heading">Appointment details</h5>
          <div class="appointment-details-row">
            <div class="date-picker-wrap">
              <p class="steps-sub-para">Type of consult</p>
              <div class="flex-row">
                <label class="custom-radio-container">Online
                  <input type="radio" checked="checked" name="radio">
                  <span class="radio-checkmark"></span>
                </label>
                <label class="custom-radio-container">Home visit
                  <input type="radio" name="radio">
                  <span class="radio-checkmark"></span>
                </label>
                <label class="custom-radio-container">Clinic
                  <input type="radio" name="radio">
                  <span class="radio-checkmark"></span>
                </label>
              </div>
            </div>
            <div class="selected-date-time-wrap">
              <p class="steps-sub-para">Selected date and time</p>
              <ul>
                <li>
                  <svg width="14" height="16" viewBox="0 0 14 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M13 6.66668H1M9.66667 1.33334V4.00001M4.33333 1.33334V4.00001M4.2 14.6667H9.8C10.9201 14.6667 11.4802 14.6667 11.908 14.4487C12.2843 14.2569 12.5903 13.951 12.782 13.5747C13 13.1468 13 12.5868 13 11.4667V5.86668C13 4.74657 13 4.18652 12.782 3.7587C12.5903 3.38237 12.2843 3.07641 11.908 2.88466C11.4802 2.66668 10.9201 2.66668 9.8 2.66668H4.2C3.0799 2.66668 2.51984 2.66668 2.09202 2.88466C1.71569 3.07641 1.40973 3.38237 1.21799 3.7587C1 4.18652 1 4.74657 1 5.86668V11.4667C1 12.5868 1 13.1468 1.21799 13.5747C1.40973 13.951 1.71569 14.2569 2.09202 14.4487C2.51984 14.6667 3.0799 14.6667 4.2 14.6667Z"
                      stroke="#475467" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round" />
                  </svg>
                  07-07-2023
                </li>
                <li>
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_2827_15152)">
                      <path
                        d="M7.99967 4.00001V8.00001L10.6663 9.33334M14.6663 8.00001C14.6663 11.6819 11.6816 14.6667 7.99967 14.6667C4.31778 14.6667 1.33301 11.6819 1.33301 8.00001C1.33301 4.31811 4.31778 1.33334 7.99967 1.33334C11.6816 1.33334 14.6663 4.31811 14.6663 8.00001Z"
                        stroke="#475467" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round" />
                    </g>
                    <defs>
                      <clipPath id="clip0_2827_15152">
                        <rect width="16" height="16" fill="white" />
                      </clipPath>
                    </defs>
                  </svg>
                  01:00 PM
                </li>
                <li>
                  <a href="#">
                    <svg width="18" height="17" viewBox="0 0 18 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path
                        d="M8.99998 15.6667H16.5M1.5 15.6667H2.89545C3.3031 15.6667 3.50693 15.6667 3.69874 15.6206C3.8688 15.5798 4.03138 15.5124 4.1805 15.4211C4.34869 15.318 4.49282 15.1739 4.78107 14.8856L15.25 4.41666C15.9404 3.72631 15.9404 2.60702 15.25 1.91666C14.5597 1.22631 13.4404 1.22631 12.75 1.91666L2.28105 12.3856C1.9928 12.6739 1.84867 12.818 1.7456 12.9862C1.65422 13.1353 1.58688 13.2979 1.54605 13.4679C1.5 13.6598 1.5 13.8636 1.5 14.2712V15.6667Z"
                        stroke="#165A93" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
                    </svg></a>

                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="date-time-picker-wrap step-border border-radius steps-sec-padd steps-mt">
          <h5 class="steps-sub-heading">Type of services</h5>
          <ul class="typ-services-list">
            <li>
              <div class="services-quantity-wrap">
                <div class="service-name">
                  <p class="steps-sub-para">Services</p>
                  <p class="steps-sub-para color-black">Online video consultation ( Medical certificate, Carer
                    certificate, Imaging/Investigation, Pathology request, Referral request etc)</p>
                </div>
                <div class="services-price-details">
                  <div class="service-price-wrap">
                    <p class="steps-sub-para">Price</p>
                    <input type="text" value="$100" class="input-text-style" disabled>
                  </div>
                  <div class="service-quantity-wrap">
                    <p class="steps-sub-para">Qty</p>
                    <select class="input-text-style">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                  </div>
                  <div class="total-price-wrap">
                    <p class="steps-sub-para font-500">Total Price</p>
                    <input type="text" value="$100" class="input-text-style" disabled>
                  </div>
                </div>
              </div>
            </li>
            <li>
              <div class="services-quantity-wrap">
                <div class="service-name">
                  <p class="steps-sub-para color-black">Service 2</p>
                </div>
                <div class="services-price-details">
                  <div class="service-price-wrap">
                    <p class="steps-sub-para step-responsive-label">Price</p>
                    <input type="text" value="$100" class="input-text-style" disabled>
                  </div>
                  <div class="service-quantity-wrap">
                    <p class="steps-sub-para step-responsive-label">Qty</p>
                    <select class="input-text-style">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                  </div>
                  <div class="total-price-wrap">
                    <p class="steps-sub-para font-500 step-responsive-label">Total Price</p>
                    <input type="text" value="$100" class="input-text-style" disabled>
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <div class="summary-wrap step-border border-radius steps-sec-padd steps-mt">
          <h5 class="steps-sub-heading">Summary</h5>
          <a class="coupon-text">I have a coupon</a>
          <div class="coupon-div">
            <input type="text" class="input-text-style" placeholder="Enter code">
            <button type="submit" class="primary-button">Apply</button>
          </div>
          <ul class="summary-list nopadd list-style-none">
            <li>
              <p class="steps-sub-para color-black pb-xl">Sub total</p>
              <p class="steps-sub-para color-black pb-xl summary-list-subtotal-text">$200</p>
            </li>
            <li>
              <p class="steps-sub-para">Online video consultation ( Medical certificate, Carer certificate,
                Imaging/Investigation, Pathology request, Referral request etc)</p>
              <p class="steps-sub-para">$100</p>
            </li>
            <li>
              <p class="steps-sub-para">Service 2</p>
              <p class="steps-sub-para">$100</p>
            </li>
            <li>
              <p class="steps-sub-para">Internet handling fee<br><span>(Non-refundable processing fees)</span>
                <p class="steps-sub-para">$10</p>
            </li>
          </ul>
          <div class="final-summary">
            <p class="steps-sub-para">Total amount</p>
            <p class="steps-sub-para">$210</p>
          </div>
        </div>
        <div class="insurance-subsidy-wrap step-border border-radius steps-sec-padd steps-mt">
          <div class="custom-square-checkbox">
            <input type="checkbox" id="medicare-subsity">
            <label for="medicare-subsity">Medicare/Private insurance subsidy</label>
          </div>
          <div class="insurance-subsity-form-content">
            <p class="steps-sub-para">I (Miss Danny Smith) hereby electronically signed and agree to the assignment of
              the Medicare/Public or Private health insurance benefit directly to the provider (Mr. Shaun Millern) for
              this consultation on 05-07-2023 and 23:25 PM Asia/Singapore.</p>
            <div class="insurance-subsity-form-wrap">
              <div class="insurance-form-group">
                <label class="steps-sub-para font-500">Medicare (Public Health) number</label>
                <input type="text" class="input-text-style">
              </div>
              <div class="insurance-form-group">
                <label class="steps-sub-para font-500">Medicare expiry</label>
                <div class="datepicker-wrap">
                <input type="text" id="medical-expiry-datepicker" class="date" readonly="readonly" placeholder="9/02/2024">
                  <svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M1 1.5L6 6.5L11 1.5" stroke="#667085" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                  </div>
              </div>
              <div class="insurance-form-group">
                <label class="steps-sub-para font-500">Medicare individual reference number (IRN)</label>
                <input type="text" class="input-text-style">
              </div>
              <div class="insurance-form-group">
                <label class="steps-sub-para font-500">Dva / Veteran number</label>
                <input type="text" class="input-text-style">
              </div>
              <div class="insurance-form-group">
                <label class="steps-sub-para font-500">Private insurance company name</label>
                <input type="text" class="input-text-style">
              </div>
              <div class="insurance-form-group">
                <label class="steps-sub-para font-500">Private insurance issue date</label>
                <div class="datepicker-wrap">
                <input type="text" id="private-insurance-datepicker" class="date" readonly="readonly" placeholder="9/02/2024">
                  <svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M1 1.5L6 6.5L11 1.5" stroke="#667085" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    </div>
              </div>
              <div class="insurance-form-group">
                <label class="steps-sub-para font-500">Private insurance number</label>
                <input type="text" class="input-text-style">
              </div>
            </div>
          </div>
        </div>
        <div class="payment-method-wrap step-border border-radius steps-sec-padd steps-mt">
          <h5 class="steps-sub-heading">How would you like to pay?</h5>
          <ul class="payment-method-list nopadd list-style-none">
            <li class="step-border border-radius step-border">
              <label class="custom-radio-container payment-method-list-padd">
                <div class="payment-radio-flex">
                  <div class="payment-icon"><img src="<?php echo base_url(); ?>assets/images/virtual_consult/mastercard.svg" alt="payment-icon"></div>Credit / Debit /
                  Visa
                </div>
                <input type="radio" value="card" name="payment" class="card-radio">
                <span class="radio-checkmark"></span>
              </label>
              <div class="card-details-dropdown">
                <div class="card-from-group">
                  <label class="steps-sub-para font-500">Name on card</label>
                  <input type="text" class="input-text-style">
                </div>
                <div class="card-from-group">
                  <label class="steps-sub-para font-500">Card number</label>
                  <input type="text" class="input-text-style card-number">
                  <div class="card-icon mastercard"></div>
                  <!--change class to visacard for visa icon-->
                </div>
                <div class="card-from-group">
                  <label class="steps-sub-para font-500">CVC</label>
                  <input type="text" class="input-text-style" placeholder="Please enter the three-digit code">
                </div>
                <div class="card-from-group">
                  <label class="steps-sub-para font-500">Expiration date</label>
                  <div class="exipry-date-flex-select">
                    <div class="expiry-to">
                    <select class="input-text-style">
                      <option>01</option>
                      <option>02</option>
                      <option>03</option>
                      <option>04</option>
                      <option>05</option>
                      <option>06</option>
                      <option>07</option>
                      <option>08</option>
                      <option>09</option>
                      <option>10</option>
                      <option>11</option>
                      <option>12</option>
                    </select>
                    </div>
                    <div class="expiry-from">
                    <select class="input-text-style">
                      <option>2024</option>
                      <option>2025</option>
                      <option>2026</option>
                      <option>2027</option>
                    </select>
                  </div>
                  </div>
                </div>
              </div>
            </li>
            <li class="step-border border-radius step-border">
              <label class="custom-radio-container payment-method-list-padd">
                <div class="payment-radio-flex">
                  <div class="payment-icon"><img src="<?php echo base_url(); ?>assets/images/virtual_consult/paypal.svg" alt="payment-icon"></div>PayPal
                </div>
                <input type="radio" value="PayPal" name="payment" class="card-radio">
                <span class="radio-checkmark"></span>
              </label>
            </li>
            <li class="step-border border-radius step-border">
              <label class="custom-radio-container payment-method-list-padd">
                <div class="payment-radio-flex">
                  <div class="payment-icon"><img src="<?php echo base_url(); ?>assets/images/virtual_consult/applepay.svg" alt="payment-icon"></div>Apple Pay
                </div>
                <input type="radio" value="apple-pay" name="payment" class="card-radio">
                <span class="radio-checkmark"></span>
              </label>
            </li>
            <li class="step-border border-radius step-border">
              <label class="custom-radio-container payment-method-list-padd">
                <div class="payment-radio-flex">
                  <div class="payment-icon"><img src="<?php echo base_url(); ?>assets/images/virtual_consult/googlepay.svg" alt="payment-icon"></div>Google Pay
                </div>
                <input type="radio" value="google-pay" name="payment" class="card-radio">
                <span class="radio-checkmark"></span>
              </label>
            </li>
            <li class="step-border border-radius step-border">
              <label class="custom-radio-container payment-method-list-padd">
                <div class="payment-radio-flex">
                  <div class="payment-icon"><img src="<?php echo base_url(); ?>assets/images/virtual_consult/wechat.svg" alt="payment-icon"></div>WeChat Pay
                </div>
                <input type="radio" value="wechat-pay" name="payment" class="card-radio">
                <span class="radio-checkmark"></span>
              </label>
            </li>
            <li class="step-border border-radius step-border">
              <label class="custom-radio-container payment-method-list-padd">
                <div class="payment-radio-flex">
                  <div class="payment-icon"><img src="<?php echo base_url(); ?>assets/images/virtual_consult/alipay.svg" alt="payment-icon"></div>Alipay
                </div>
                <input type="radio" value="alipay" name="payment" class="card-radio">
                <span class="radio-checkmark"></span>
              </label>
            </li>
          </ul>
          <div class="stripe-payment-logos">
            <div class="stripe-logo">
              <img src="<?php echo base_url(); ?>assets/images/virtual_consult/stripe.svg" alt="stripe logo">
            </div>
            <div class="stripe-secure-logos">
              <p>Secure payments powered by <a href="#">stripe</a></p>
              <ul class="list-style-none nopadd nomargin">
                <li>
                  <img src="<?php echo base_url(); ?>assets/images/virtual_consult/pcisecuritystandards-icon.svg" alt="stripe secure icon">
                </li>
                <li>
                  <img src="<?php echo base_url(); ?>assets/images/virtual_consult/sslsecure.svg" alt="stripe secure icon">
                </li>
                <li>
                  <img src="<?php echo base_url(); ?>assets/images/virtual_consult/visa.svg" alt="stripe secure icon">
                </li>
                <li>
                  <img src="<?php echo base_url(); ?>assets/images/virtual_consult/mastercard-secure.svg" alt="stripe secure icon">
                </li>
                <li>
                  <img src="<?php echo base_url(); ?>assets/images/virtual_consult/american-express.svg" alt="stripe secure icon">
                </li>
                <li>
                  <img src="<?php echo base_url(); ?>assets/images/virtual_consult/gpaysecure.svg" alt="stripe secure icon">
                </li>
                <li>
                  <img src="<?php echo base_url(); ?>assets/images/virtual_consult/apple-pay-secure.svg" alt="stripe secure icon">
                </li>
                <li>
                  <img src="<?php echo base_url(); ?>assets/images/virtual_consult/paypal-secure.svg" alt="stripe secure icon">
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="steps-footer">
      <div class="flex-modal-button">
        <a class="outline-button canceltrigger">Cancel</a>
        <a href="javascript:void(0)" id="checkout-button" class="primary-button">Checkout & Finalize</a>
      </div>
  </section>
  <section class="appointments-steps book-step-final">
        <div class="container">
          <div class="steps-container-wrap">
            <div class="confirmation-wrap step-border border-radius steps-sec-padd">
              <img src="<?php echo base_url(); ?>assets/images/virtual_consult/confirmation.svg" alt="confirmation icon">
              <span class="inprocess-text">
                2.2 AUD is on hold
              </span>
              <h6 class="steps-sub-heading mb-0">Consultation request sent successfully!</h6>
              <p class="steps-sub-para mb-0">You will only be charged when the consultation is completed.</p>
              <div class="steps-footer noborder">
                <div class="flex-modal-button">
                    
                    <a href="#" class="primary-button">See my appointments</a>
                    <a href="<?php echo base_url();?>virtual_consult/patient/search" class="outline-button noborder"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12.8337 7H1.16699M1.16699 7L7.00033 12.8333M1.16699 7L7.00033 1.16666" stroke="#344054" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                        Back to health providers</a>
                </div>
        </div>
            </div>
          </div>
        </div>
    </section>
   <!--cancel details modal-->
 <div class="modal cancel-modal">
  <div class="modal-content">
      <div class="modal-head">
          <h5 class="modal-heading">Appointment cancelled</h1>
              <span class="close-button"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                      xmlns="http://www.w3.org/2000/svg">
                      <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                          stroke-linejoin="round"></path>
                  </svg></span>
      </div>
      <div class="modal-body">
          <div class="cancel-modal-wrap">
            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg02.png" alt="doctor image">
            <h6 class="modal-doctor-name">Dr. Odele Camerana</h6>
            <p class="modal-para">Apologizes for canceling the appointment due to urgent matters. Please reschedule for a later time.</p>
          </div>
          
      </div>
      <div class="modal-footer">
          <div class="flex-modal-button">
              <button type="button" class="close-button unfilled-button">Cancel</button>
              <a href="#" class="primary-button">Book earliest appointment</a>
          </div>
      </div>

  </div>
</div>

<script>
  $(document).ready(function() {
	const tabButtons = document.querySelectorAll('.tab-button');
	const tabContents = document.querySelectorAll('.tab-content');
	const tabButtonsContainer = document.querySelector('.tab-buttons');
  
  tabButtons.forEach(button => {
	  button.addEventListener('click', function () {
		const tab = this.getAttribute('data-tab');
  
		tabButtons.forEach(btn => btn.classList.remove('active'));
		tabContents.forEach(content => content.classList.remove('active'));
  
		this.classList.add('active');
		document.querySelector(`.tab-content[data-tab="${tab}"]`).classList.add('active');
  
		document.querySelector('.tab-contents').scrollTo({ top: 0, behavior: 'smooth' });
	  });
	});
  
    tabButtons[0].classList.add('active');
	tabContents[0].classList.add('active');
});	
</script>
<script>
  $(".questionnaire-toggle-drop-btn").click(function(){
	$(this).toggleClass("hideshow-questionnaire");
});
</script>