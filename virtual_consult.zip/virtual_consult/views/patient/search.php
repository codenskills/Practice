<section id="patients-appointments">
    <div class="container">
        <div class="appointment-header">
            <div class="appointment-text">
                <h4 class="heading-main">Appointments</h4>
            </div>
            <ul class="patient-appointment-header-menu">
                <li>
                    <a class="patient-appointment-menu-button active"
                        href="<?php echo base_url();?>virtual_consult/patient/search"><svg width="20" height="20"
                            viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M17.5 17.5L12.5001 12.5M14.1667 8.33333C14.1667 11.555 11.555 14.1667 8.33333 14.1667C5.11167 14.1667 2.5 11.555 2.5 8.33333C2.5 5.11167 5.11167 2.5 8.33333 2.5C11.555 2.5 14.1667 5.11167 14.1667 8.33333Z"
                                stroke="#667085" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>Search</a>
                </li>
                <li>
                    <a class="patient-appointment-menu-button"
                        href="<?php echo base_url();?>virtual_consult/patient/favourites"><svg width="20" height="20"
                            viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M9.40156 2.8778C9.59363 2.48869 9.68967 2.29413 9.82004 2.23197C9.93347 2.17789 10.0653 2.17789 10.1787 2.23197C10.3091 2.29413 10.4051 2.48869 10.5972 2.8778L12.4194 6.56944C12.4761 6.68432 12.5045 6.74176 12.5459 6.78635C12.5826 6.82584 12.6266 6.85783 12.6754 6.88056C12.7306 6.90623 12.794 6.91549 12.9208 6.93402L16.9968 7.5298C17.4261 7.59253 17.6407 7.6239 17.74 7.72874C17.8264 7.81995 17.8671 7.94529 17.8506 8.06985C17.8317 8.21302 17.6763 8.36436 17.3656 8.66702L14.4172 11.5387C14.3253 11.6282 14.2794 11.673 14.2497 11.7263C14.2235 11.7734 14.2066 11.8252 14.2001 11.8788C14.1928 11.9393 14.2036 12.0025 14.2253 12.129L14.921 16.1851C14.9944 16.6129 15.031 16.8269 14.9621 16.9538C14.9021 17.0642 14.7955 17.1417 14.6719 17.1646C14.5299 17.1909 14.3378 17.0899 13.9536 16.8879L10.3097 14.9716C10.1961 14.9119 10.1394 14.882 10.0796 14.8703C10.0266 14.8599 9.97213 14.8599 9.91918 14.8703C9.85937 14.882 9.8026 14.9119 9.68906 14.9716L6.04512 16.8879C5.66095 17.0899 5.46886 17.1909 5.32683 17.1646C5.20325 17.1417 5.09662 17.0642 5.03663 16.9538C4.96768 16.8269 5.00437 16.6129 5.07774 16.1851L5.77342 12.129C5.79511 12.0025 5.80595 11.9393 5.79862 11.8788C5.79212 11.8252 5.77528 11.7734 5.74902 11.7263C5.71937 11.673 5.67341 11.6282 5.5815 11.5387L2.63315 8.66702C2.3224 8.36436 2.16703 8.21302 2.14812 8.06985C2.13167 7.94529 2.17231 7.81995 2.25872 7.72874C2.35804 7.6239 2.57266 7.59253 3.00189 7.5298L7.07794 6.93402C7.2047 6.91549 7.26808 6.90623 7.32328 6.88056C7.37215 6.85783 7.41615 6.82584 7.45284 6.78635C7.49427 6.74176 7.52262 6.68432 7.57933 6.56944L9.40156 2.8778Z"
                                stroke="#667085" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>Favourites</a>
                </li>
                <li>
                    <a class="patient-appointment-menu-button"
                        href="<?php echo base_url();?>virtual_consult/patient/online_waiting_room"><svg width="20"
                            height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M17.5 8.33342H2.5M13.3333 1.66675V5.00008M6.66667 1.66675V5.00008M7.5 13.3334L9.16667 15.0001L12.9167 11.2501M6.5 18.3334H13.5C14.9001 18.3334 15.6002 18.3334 16.135 18.0609C16.6054 17.8212 16.9878 17.4388 17.2275 16.9684C17.5 16.4336 17.5 15.7335 17.5 14.3334V7.33342C17.5 5.93328 17.5 5.23322 17.2275 4.69844C16.9878 4.22803 16.6054 3.84558 16.135 3.6059C15.6002 3.33341 14.9001 3.33341 13.5 3.33341H6.5C5.09987 3.33341 4.3998 3.33341 3.86502 3.6059C3.39462 3.84558 3.01217 4.22803 2.77248 4.69844C2.5 5.23322 2.5 5.93328 2.5 7.33341V14.3334C2.5 15.7335 2.5 16.4336 2.77248 16.9684C3.01217 17.4388 3.39462 17.8212 3.86502 18.0609C4.3998 18.3334 5.09987 18.3334 6.5 18.3334Z"
                                stroke="#344054" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round" />
                        </svg><span>Online</span> waiting room</a>
                </li>
                <li>
                    <a class="patient-appointment-menu-button"
                        href="<?php echo base_url();?>virtual_consult/patient/history"><svg width="20" height="20"
                            viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M18.9166 11.25L17.2505 9.58333L15.5833 11.25M17.5 10C17.5 14.1421 14.1421 17.5 10 17.5C5.85786 17.5 2.5 14.1421 2.5 10C2.5 5.85786 5.85786 2.5 10 2.5C12.7516 2.5 15.1571 3.98178 16.4621 6.19091M10 5.83333V10L12.5 11.6667"
                                stroke="#667085" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>History</a>
                </li>
            </ul>
        </div>
        <div class="p-filters-contain">
            <div class="p-filters">
                <h6 class="filter-text">Filters</h6>
                <div class="responsive-filter-bar">
                    <h6 class="filter-text-responsive"><svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M5 10H15M2.5 5H17.5M7.5 15H12.5" stroke="#101828" stroke-width="1.66667"
                                stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        Filters</h6>
                    <svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 1.5L6 6.5L11 1.5" stroke="#98A2B3" stroke-width="1.66667" stroke-linecap="round"
                            stroke-linejoin="round" />
                    </svg>
                </div>
                <div class="overlay-responsive"></div>
                <ul class="filter-list">
                    <div class="res-close-btn">
                        <button type="button" class="close-filter-list close-filter-btn"><svg width="24" height="24"
                                viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M18 6L6 18M6 6L18 18" stroke="#344054" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg></button>
                    </div>
                    <h6 class="filter-text-responsive">Filters</h6>
                    <li class="active-drop">
                        <div class="drop-down-filters toggle-drop-btn show-filter-list">
                            <h5>Specialities</h5>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg" alt="icon">
                        </div>
                        <div class="drop-filters-content">
                            <input type="text" placeholder="Search..." class="specialities-search">
                            <div class="drop-checkbox-wrap">
                                <form>
                                    <div class="form-group">
                                        <input type="checkbox" id="allspecialities">
                                        <label for="allspecialities">All specialities (20)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Cardiology">
                                        <label for="Cardiology">Cardiology (8)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Dermatology">
                                        <label for="Dermatology">Dermatology (15)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Gastroenterology">
                                        <label for="Gastroenterology">Gastroenterology (3)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Hematology">
                                        <label for="Hematology">Hematology (10)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Nephrology">
                                        <label for="Nephrology">Nephrology (5)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Neurology">
                                        <label for="Neurology">Neurology (12)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Oncology">
                                        <label for="Oncology">Oncology (18)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Pediatrics">
                                        <label for="Pediatrics">Pediatrics (2)</label>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </li>
                    <hr>
                    <li>
                        <div class="drop-down-filters toggle-drop-btn">
                            <h5>States</h5>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg" alt="icon">
                        </div>
                        <div class="drop-filters-content">
                            <div class="drop-checkbox-wrap">
                                <form>
                                    <div class="form-group">
                                        <input type="checkbox" id="allstate">
                                        <label for="allstate">All states (8)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Australian">
                                        <label for="Australian">Australian Capital Territory (3)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="NewSouth">
                                        <label for="NewSouth">New South Wales (10)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Northern">
                                        <label for="Northern">Northern Territory (5)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Queensland">
                                        <label for="Queensland">Queensland (13)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="SouthAustralia">
                                        <label for="SouthAustralia">South Australia (32)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Tasmania">
                                        <label for="Tasmania">Tasmania (0)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Victoria">
                                        <label for="Victoria">Victoria (2)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Western">
                                        <label for="Western">Western Australia (8)</label>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </li>
                    <hr>
                    <li>
                        <div class="drop-down-filters toggle-drop-btn">
                            <h5>Status</h5>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg" alt="icon">
                        </div>
                        <div class="drop-filters-content">
                            <div class="drop-checkbox-wrap">
                                <form>
                                    <div class="form-group">
                                        <input type="checkbox" id="allstatus">
                                        <label for="allstatus">All status (2)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="onlinestatus">
                                        <label for="onlinestatus">Online (85)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="offlinestatus">
                                        <label for="offlinestatus">Offline (110)</label>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </li>
                    <hr>
                    <div class="res-filter-apply-btn-wrap">
                        <button type="button" class="res-apply-btn">Apply filters <span>(2)</span></button>
                    </div>
                </ul>

            </div>
            <div class="doctors-list-container">
                <div class="d-flex-row">
                    <div class="result-text">
                        <p>204 health provider</p>
                    </div>
                    <div class="health-provider-serch-bar">
                        <input type="text" placeholder="Health provider name">
                    </div>
                </div>
                <ul class="doctors-list">
                    <li>
                        <div class="doctors-list-wrap">
                            <button type="button" class="like-btn">
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M7.52144 2.30229C7.6751 1.991 7.75193 1.83535 7.85623 1.78562C7.94697 1.74236 8.0524 1.74236 8.14315 1.78562C8.24744 1.83535 8.32427 1.991 8.47793 2.30229L9.93572 5.2556C9.98108 5.3475 10.0038 5.39345 10.0369 5.42913C10.0663 5.46072 10.1015 5.48631 10.1406 5.5045C10.1847 5.52503 10.2354 5.53244 10.3368 5.54726L13.5977 6.02389C13.9411 6.07408 14.1127 6.09917 14.1922 6.18304C14.2613 6.25601 14.2938 6.35628 14.2807 6.45593C14.2656 6.57047 14.1413 6.69153 13.8927 6.93367L11.534 9.23103C11.4604 9.30264 11.4237 9.33845 11.4 9.38106C11.379 9.41878 11.3655 9.46022 11.3603 9.50309C11.3544 9.5515 11.3631 9.60208 11.3804 9.70324L11.937 12.9482C11.9957 13.2904 12.025 13.4615 11.9699 13.5631C11.9219 13.6514 11.8366 13.7134 11.7377 13.7317C11.6241 13.7528 11.4704 13.672 11.1631 13.5104L8.24793 11.9773C8.1571 11.9295 8.11168 11.9057 8.06384 11.8963C8.02147 11.888 7.9779 11.888 7.93554 11.8963C7.88769 11.9057 7.84228 11.9295 7.75145 11.9773L4.83629 13.5104C4.52895 13.672 4.37528 13.7528 4.26166 13.7317C4.1628 13.7134 4.07749 13.6514 4.0295 13.5631C3.97434 13.4615 4.00369 13.2904 4.06239 12.9482L4.61893 9.70324C4.63628 9.60208 4.64496 9.5515 4.63909 9.50309C4.63389 9.46022 4.62042 9.41878 4.59941 9.38106C4.57569 9.33845 4.53893 9.30264 4.4654 9.23103L2.10671 6.93367C1.85812 6.69153 1.73382 6.57047 1.71869 6.45593C1.70553 6.35628 1.73804 6.25601 1.80717 6.18304C1.88663 6.09917 2.05832 6.07408 2.4017 6.02389L5.66255 5.54726C5.76396 5.53244 5.81466 5.52503 5.85882 5.5045C5.89792 5.48631 5.93312 5.46072 5.96247 5.42913C5.99561 5.39345 6.01829 5.3475 6.06366 5.2556L7.52144 2.30229Z"
                                        stroke="white" stroke-opacity="0.6" stroke-width="1.336" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>
                            </button>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg1.jpg"
                                alt="doctor image" class="img-responsive doctor-img">
                            <div class="doctors-data">
                                <div class="doctor-data-bottom-wrap">
                                    <label class="online"><span class="dot-label"></span>
                                        <p>Online</p>
                                    </label>
                                    <div class="doctor-name-share-wrap">
                                        <h4 class="doctors-name doctor-detail-trigger">Alasteir Whitechurch</h4>
                                        <button class="share-doctor-modal-trigger"><svg width="21" height="20"
                                                viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M18.1259 10.5062C18.3294 10.3318 18.4311 10.2446 18.4684 10.1409C18.5011 10.0498 18.5011 9.9502 18.4684 9.85914C18.4311 9.75539 18.3294 9.6682 18.1259 9.49383L11.067 3.44331C10.7168 3.14315 10.5417 2.99306 10.3935 2.98939C10.2646 2.98619 10.1416 3.04279 10.0602 3.14269C9.96647 3.25764 9.96647 3.48825 9.96647 3.94948V7.52886C8.18757 7.84007 6.55947 8.74146 5.34956 10.0949C4.03049 11.5704 3.30083 13.48 3.2998 15.4591V15.9691C4.17426 14.9157 5.26606 14.0638 6.50044 13.4716C7.58872 12.9495 8.76515 12.6403 9.96647 12.5588V16.0505C9.96647 16.5117 9.96647 16.7424 10.0602 16.8573C10.1416 16.9572 10.2646 17.0138 10.3935 17.0106C10.5417 17.0069 10.7168 16.8569 11.067 16.5567L18.1259 10.5062Z"
                                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg></button>
                                    </div>
                                    <ul class="doctors-specifications-list">
                                        <li>
                                            <div class="doctors-specifications-list-wrap">
                                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/stethoscope.svg"
                                                    alt="stethoscope">
                                                <h6>Cardiologist</h6>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="doctors-specifications-list-wrap">
                                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/marker-pin.svg"
                                                    alt="stethoscope">
                                                <h6>Australian Capital Territory</h6>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <a href="<?php echo base_url();?>virtual_consult/patient/book_appointment"
                                    class="book-btn">Book appointment<svg width="16" height="12" viewBox="0 0 16 12"
                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1.33301 6H14.6663M14.6663 6L9.66634 1M14.6663 6L9.66634 11"
                                            stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg></a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="doctors-list-wrap">
                            <button type="button" class="like-btn">
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M7.52144 2.30229C7.6751 1.991 7.75193 1.83535 7.85623 1.78562C7.94697 1.74236 8.0524 1.74236 8.14315 1.78562C8.24744 1.83535 8.32427 1.991 8.47793 2.30229L9.93572 5.2556C9.98108 5.3475 10.0038 5.39345 10.0369 5.42913C10.0663 5.46072 10.1015 5.48631 10.1406 5.5045C10.1847 5.52503 10.2354 5.53244 10.3368 5.54726L13.5977 6.02389C13.9411 6.07408 14.1127 6.09917 14.1922 6.18304C14.2613 6.25601 14.2938 6.35628 14.2807 6.45593C14.2656 6.57047 14.1413 6.69153 13.8927 6.93367L11.534 9.23103C11.4604 9.30264 11.4237 9.33845 11.4 9.38106C11.379 9.41878 11.3655 9.46022 11.3603 9.50309C11.3544 9.5515 11.3631 9.60208 11.3804 9.70324L11.937 12.9482C11.9957 13.2904 12.025 13.4615 11.9699 13.5631C11.9219 13.6514 11.8366 13.7134 11.7377 13.7317C11.6241 13.7528 11.4704 13.672 11.1631 13.5104L8.24793 11.9773C8.1571 11.9295 8.11168 11.9057 8.06384 11.8963C8.02147 11.888 7.9779 11.888 7.93554 11.8963C7.88769 11.9057 7.84228 11.9295 7.75145 11.9773L4.83629 13.5104C4.52895 13.672 4.37528 13.7528 4.26166 13.7317C4.1628 13.7134 4.07749 13.6514 4.0295 13.5631C3.97434 13.4615 4.00369 13.2904 4.06239 12.9482L4.61893 9.70324C4.63628 9.60208 4.64496 9.5515 4.63909 9.50309C4.63389 9.46022 4.62042 9.41878 4.59941 9.38106C4.57569 9.33845 4.53893 9.30264 4.4654 9.23103L2.10671 6.93367C1.85812 6.69153 1.73382 6.57047 1.71869 6.45593C1.70553 6.35628 1.73804 6.25601 1.80717 6.18304C1.88663 6.09917 2.05832 6.07408 2.4017 6.02389L5.66255 5.54726C5.76396 5.53244 5.81466 5.52503 5.85882 5.5045C5.89792 5.48631 5.93312 5.46072 5.96247 5.42913C5.99561 5.39345 6.01829 5.3475 6.06366 5.2556L7.52144 2.30229Z"
                                        stroke="white" stroke-opacity="0.6" stroke-width="1.336" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>
                            </button>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg02.png"
                                alt="doctor image" class="img-responsive doctor-img">
                            <div class="doctors-data">
                                <div class="doctor-data-bottom-wrap">
                                    <label class="offline"><span class="dot-label"></span>
                                        <p>Offline</p>
                                    </label>
                                    <div class="doctor-name-share-wrap">
                                        <h4 class="doctors-name doctor-detail-trigger">Alasteir Whitechurch</h4>
                                        <button class="share-doctor-modal-trigger"><svg width="21" height="20"
                                                viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M18.1259 10.5062C18.3294 10.3318 18.4311 10.2446 18.4684 10.1409C18.5011 10.0498 18.5011 9.9502 18.4684 9.85914C18.4311 9.75539 18.3294 9.6682 18.1259 9.49383L11.067 3.44331C10.7168 3.14315 10.5417 2.99306 10.3935 2.98939C10.2646 2.98619 10.1416 3.04279 10.0602 3.14269C9.96647 3.25764 9.96647 3.48825 9.96647 3.94948V7.52886C8.18757 7.84007 6.55947 8.74146 5.34956 10.0949C4.03049 11.5704 3.30083 13.48 3.2998 15.4591V15.9691C4.17426 14.9157 5.26606 14.0638 6.50044 13.4716C7.58872 12.9495 8.76515 12.6403 9.96647 12.5588V16.0505C9.96647 16.5117 9.96647 16.7424 10.0602 16.8573C10.1416 16.9572 10.2646 17.0138 10.3935 17.0106C10.5417 17.0069 10.7168 16.8569 11.067 16.5567L18.1259 10.5062Z"
                                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg></button>
                                    </div>
                                    <ul class="doctors-specifications-list">
                                        <li>
                                            <div class="doctors-specifications-list-wrap">
                                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/stethoscope.svg"
                                                    alt="stethoscope">
                                                <h6>Cardiologist</h6>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="doctors-specifications-list-wrap">
                                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/marker-pin.svg"
                                                    alt="stethoscope">
                                                <h6>Australian Capital Territory</h6>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <a href="<?php echo base_url();?>virtual_consult/patient/book_appointment"
                                    class="book-btn">Book appointment<svg width="16" height="12" viewBox="0 0 16 12"
                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1.33301 6H14.6663M14.6663 6L9.66634 1M14.6663 6L9.66634 11"
                                            stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg></a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="doctors-list-wrap">
                            <button type="button" class="like-btn">
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M7.52144 2.30229C7.6751 1.991 7.75193 1.83535 7.85623 1.78562C7.94697 1.74236 8.0524 1.74236 8.14315 1.78562C8.24744 1.83535 8.32427 1.991 8.47793 2.30229L9.93572 5.2556C9.98108 5.3475 10.0038 5.39345 10.0369 5.42913C10.0663 5.46072 10.1015 5.48631 10.1406 5.5045C10.1847 5.52503 10.2354 5.53244 10.3368 5.54726L13.5977 6.02389C13.9411 6.07408 14.1127 6.09917 14.1922 6.18304C14.2613 6.25601 14.2938 6.35628 14.2807 6.45593C14.2656 6.57047 14.1413 6.69153 13.8927 6.93367L11.534 9.23103C11.4604 9.30264 11.4237 9.33845 11.4 9.38106C11.379 9.41878 11.3655 9.46022 11.3603 9.50309C11.3544 9.5515 11.3631 9.60208 11.3804 9.70324L11.937 12.9482C11.9957 13.2904 12.025 13.4615 11.9699 13.5631C11.9219 13.6514 11.8366 13.7134 11.7377 13.7317C11.6241 13.7528 11.4704 13.672 11.1631 13.5104L8.24793 11.9773C8.1571 11.9295 8.11168 11.9057 8.06384 11.8963C8.02147 11.888 7.9779 11.888 7.93554 11.8963C7.88769 11.9057 7.84228 11.9295 7.75145 11.9773L4.83629 13.5104C4.52895 13.672 4.37528 13.7528 4.26166 13.7317C4.1628 13.7134 4.07749 13.6514 4.0295 13.5631C3.97434 13.4615 4.00369 13.2904 4.06239 12.9482L4.61893 9.70324C4.63628 9.60208 4.64496 9.5515 4.63909 9.50309C4.63389 9.46022 4.62042 9.41878 4.59941 9.38106C4.57569 9.33845 4.53893 9.30264 4.4654 9.23103L2.10671 6.93367C1.85812 6.69153 1.73382 6.57047 1.71869 6.45593C1.70553 6.35628 1.73804 6.25601 1.80717 6.18304C1.88663 6.09917 2.05832 6.07408 2.4017 6.02389L5.66255 5.54726C5.76396 5.53244 5.81466 5.52503 5.85882 5.5045C5.89792 5.48631 5.93312 5.46072 5.96247 5.42913C5.99561 5.39345 6.01829 5.3475 6.06366 5.2556L7.52144 2.30229Z"
                                        stroke="white" stroke-opacity="0.6" stroke-width="1.336" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>
                            </button>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg03.png"
                                alt="doctor image" class="img-responsive doctor-img">
                            <div class="doctors-data">
                                <div class="doctor-data-bottom-wrap">
                                    <label class="online"><span class="dot-label"></span>
                                        <p>Online</p>
                                    </label>
                                    <div class="doctor-name-share-wrap">
                                        <h4 class="doctors-name doctor-detail-trigger">Alasteir Whitechurch</h4>
                                        <button class="share-doctor-modal-trigger"><svg width="21" height="20"
                                                viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M18.1259 10.5062C18.3294 10.3318 18.4311 10.2446 18.4684 10.1409C18.5011 10.0498 18.5011 9.9502 18.4684 9.85914C18.4311 9.75539 18.3294 9.6682 18.1259 9.49383L11.067 3.44331C10.7168 3.14315 10.5417 2.99306 10.3935 2.98939C10.2646 2.98619 10.1416 3.04279 10.0602 3.14269C9.96647 3.25764 9.96647 3.48825 9.96647 3.94948V7.52886C8.18757 7.84007 6.55947 8.74146 5.34956 10.0949C4.03049 11.5704 3.30083 13.48 3.2998 15.4591V15.9691C4.17426 14.9157 5.26606 14.0638 6.50044 13.4716C7.58872 12.9495 8.76515 12.6403 9.96647 12.5588V16.0505C9.96647 16.5117 9.96647 16.7424 10.0602 16.8573C10.1416 16.9572 10.2646 17.0138 10.3935 17.0106C10.5417 17.0069 10.7168 16.8569 11.067 16.5567L18.1259 10.5062Z"
                                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg></button>
                                    </div>
                                    <ul class="doctors-specifications-list">
                                        <li>
                                            <div class="doctors-specifications-list-wrap">
                                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/stethoscope.svg"
                                                    alt="stethoscope">
                                                <h6>Cardiologist</h6>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="doctors-specifications-list-wrap">
                                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/marker-pin.svg"
                                                    alt="stethoscope">
                                                <h6>Australian Capital Territory</h6>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <a href="<?php echo base_url();?>virtual_consult/patient/book_appointment"
                                    class="book-btn">Book appointment<svg width="16" height="12" viewBox="0 0 16 12"
                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1.33301 6H14.6663M14.6663 6L9.66634 1M14.6663 6L9.66634 11"
                                            stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg></a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="doctors-list-wrap">
                            <button type="button" class="like-btn">
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M7.52144 2.30229C7.6751 1.991 7.75193 1.83535 7.85623 1.78562C7.94697 1.74236 8.0524 1.74236 8.14315 1.78562C8.24744 1.83535 8.32427 1.991 8.47793 2.30229L9.93572 5.2556C9.98108 5.3475 10.0038 5.39345 10.0369 5.42913C10.0663 5.46072 10.1015 5.48631 10.1406 5.5045C10.1847 5.52503 10.2354 5.53244 10.3368 5.54726L13.5977 6.02389C13.9411 6.07408 14.1127 6.09917 14.1922 6.18304C14.2613 6.25601 14.2938 6.35628 14.2807 6.45593C14.2656 6.57047 14.1413 6.69153 13.8927 6.93367L11.534 9.23103C11.4604 9.30264 11.4237 9.33845 11.4 9.38106C11.379 9.41878 11.3655 9.46022 11.3603 9.50309C11.3544 9.5515 11.3631 9.60208 11.3804 9.70324L11.937 12.9482C11.9957 13.2904 12.025 13.4615 11.9699 13.5631C11.9219 13.6514 11.8366 13.7134 11.7377 13.7317C11.6241 13.7528 11.4704 13.672 11.1631 13.5104L8.24793 11.9773C8.1571 11.9295 8.11168 11.9057 8.06384 11.8963C8.02147 11.888 7.9779 11.888 7.93554 11.8963C7.88769 11.9057 7.84228 11.9295 7.75145 11.9773L4.83629 13.5104C4.52895 13.672 4.37528 13.7528 4.26166 13.7317C4.1628 13.7134 4.07749 13.6514 4.0295 13.5631C3.97434 13.4615 4.00369 13.2904 4.06239 12.9482L4.61893 9.70324C4.63628 9.60208 4.64496 9.5515 4.63909 9.50309C4.63389 9.46022 4.62042 9.41878 4.59941 9.38106C4.57569 9.33845 4.53893 9.30264 4.4654 9.23103L2.10671 6.93367C1.85812 6.69153 1.73382 6.57047 1.71869 6.45593C1.70553 6.35628 1.73804 6.25601 1.80717 6.18304C1.88663 6.09917 2.05832 6.07408 2.4017 6.02389L5.66255 5.54726C5.76396 5.53244 5.81466 5.52503 5.85882 5.5045C5.89792 5.48631 5.93312 5.46072 5.96247 5.42913C5.99561 5.39345 6.01829 5.3475 6.06366 5.2556L7.52144 2.30229Z"
                                        stroke="white" stroke-opacity="0.6" stroke-width="1.336" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>
                            </button>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg04.png"
                                alt="doctor image" class="img-responsive doctor-img">
                            <div class="doctors-data">
                                <div class="doctor-data-bottom-wrap">
                                    <label class="online"><span class="dot-label"></span>
                                        <p>Online</p>
                                    </label>
                                    <div class="doctor-name-share-wrap">
                                        <h4 class="doctors-name doctor-detail-trigger">Alasteir Whitechurch</h4>
                                        <button class="share-doctor-modal-trigger"><svg width="21" height="20"
                                                viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M18.1259 10.5062C18.3294 10.3318 18.4311 10.2446 18.4684 10.1409C18.5011 10.0498 18.5011 9.9502 18.4684 9.85914C18.4311 9.75539 18.3294 9.6682 18.1259 9.49383L11.067 3.44331C10.7168 3.14315 10.5417 2.99306 10.3935 2.98939C10.2646 2.98619 10.1416 3.04279 10.0602 3.14269C9.96647 3.25764 9.96647 3.48825 9.96647 3.94948V7.52886C8.18757 7.84007 6.55947 8.74146 5.34956 10.0949C4.03049 11.5704 3.30083 13.48 3.2998 15.4591V15.9691C4.17426 14.9157 5.26606 14.0638 6.50044 13.4716C7.58872 12.9495 8.76515 12.6403 9.96647 12.5588V16.0505C9.96647 16.5117 9.96647 16.7424 10.0602 16.8573C10.1416 16.9572 10.2646 17.0138 10.3935 17.0106C10.5417 17.0069 10.7168 16.8569 11.067 16.5567L18.1259 10.5062Z"
                                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg></button>
                                    </div>
                                    <ul class="doctors-specifications-list">
                                        <li>
                                            <div class="doctors-specifications-list-wrap">
                                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/stethoscope.svg"
                                                    alt="stethoscope">
                                                <h6>Cardiologist</h6>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="doctors-specifications-list-wrap">
                                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/marker-pin.svg"
                                                    alt="stethoscope">
                                                <h6>Australian Capital Territory</h6>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <a href="<?php echo base_url();?>virtual_consult/patient/book_appointment"
                                    class="book-btn">Book appointment<svg width="16" height="12" viewBox="0 0 16 12"
                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1.33301 6H14.6663M14.6663 6L9.66634 1M14.6663 6L9.66634 11"
                                            stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg></a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="doctors-list-wrap">
                            <button type="button" class="like-btn">
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M7.52144 2.30229C7.6751 1.991 7.75193 1.83535 7.85623 1.78562C7.94697 1.74236 8.0524 1.74236 8.14315 1.78562C8.24744 1.83535 8.32427 1.991 8.47793 2.30229L9.93572 5.2556C9.98108 5.3475 10.0038 5.39345 10.0369 5.42913C10.0663 5.46072 10.1015 5.48631 10.1406 5.5045C10.1847 5.52503 10.2354 5.53244 10.3368 5.54726L13.5977 6.02389C13.9411 6.07408 14.1127 6.09917 14.1922 6.18304C14.2613 6.25601 14.2938 6.35628 14.2807 6.45593C14.2656 6.57047 14.1413 6.69153 13.8927 6.93367L11.534 9.23103C11.4604 9.30264 11.4237 9.33845 11.4 9.38106C11.379 9.41878 11.3655 9.46022 11.3603 9.50309C11.3544 9.5515 11.3631 9.60208 11.3804 9.70324L11.937 12.9482C11.9957 13.2904 12.025 13.4615 11.9699 13.5631C11.9219 13.6514 11.8366 13.7134 11.7377 13.7317C11.6241 13.7528 11.4704 13.672 11.1631 13.5104L8.24793 11.9773C8.1571 11.9295 8.11168 11.9057 8.06384 11.8963C8.02147 11.888 7.9779 11.888 7.93554 11.8963C7.88769 11.9057 7.84228 11.9295 7.75145 11.9773L4.83629 13.5104C4.52895 13.672 4.37528 13.7528 4.26166 13.7317C4.1628 13.7134 4.07749 13.6514 4.0295 13.5631C3.97434 13.4615 4.00369 13.2904 4.06239 12.9482L4.61893 9.70324C4.63628 9.60208 4.64496 9.5515 4.63909 9.50309C4.63389 9.46022 4.62042 9.41878 4.59941 9.38106C4.57569 9.33845 4.53893 9.30264 4.4654 9.23103L2.10671 6.93367C1.85812 6.69153 1.73382 6.57047 1.71869 6.45593C1.70553 6.35628 1.73804 6.25601 1.80717 6.18304C1.88663 6.09917 2.05832 6.07408 2.4017 6.02389L5.66255 5.54726C5.76396 5.53244 5.81466 5.52503 5.85882 5.5045C5.89792 5.48631 5.93312 5.46072 5.96247 5.42913C5.99561 5.39345 6.01829 5.3475 6.06366 5.2556L7.52144 2.30229Z"
                                        stroke="white" stroke-opacity="0.6" stroke-width="1.336" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>
                            </button>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg05.png"
                                alt="doctor image" class="img-responsive doctor-img">
                            <div class="doctors-data">
                                <div class="doctor-data-bottom-wrap">
                                    <label class="online"><span class="dot-label"></span>
                                        <p>Online</p>
                                    </label>
                                    <div class="doctor-name-share-wrap">
                                        <h4 class="doctors-name doctor-detail-trigger">Alasteir Whitechurch</h4>
                                        <button class="share-doctor-modal-trigger"><svg width="21" height="20"
                                                viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M18.1259 10.5062C18.3294 10.3318 18.4311 10.2446 18.4684 10.1409C18.5011 10.0498 18.5011 9.9502 18.4684 9.85914C18.4311 9.75539 18.3294 9.6682 18.1259 9.49383L11.067 3.44331C10.7168 3.14315 10.5417 2.99306 10.3935 2.98939C10.2646 2.98619 10.1416 3.04279 10.0602 3.14269C9.96647 3.25764 9.96647 3.48825 9.96647 3.94948V7.52886C8.18757 7.84007 6.55947 8.74146 5.34956 10.0949C4.03049 11.5704 3.30083 13.48 3.2998 15.4591V15.9691C4.17426 14.9157 5.26606 14.0638 6.50044 13.4716C7.58872 12.9495 8.76515 12.6403 9.96647 12.5588V16.0505C9.96647 16.5117 9.96647 16.7424 10.0602 16.8573C10.1416 16.9572 10.2646 17.0138 10.3935 17.0106C10.5417 17.0069 10.7168 16.8569 11.067 16.5567L18.1259 10.5062Z"
                                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg></button>
                                    </div>
                                    <ul class="doctors-specifications-list">
                                        <li>
                                            <div class="doctors-specifications-list-wrap">
                                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/stethoscope.svg"
                                                    alt="stethoscope">
                                                <h6>Cardiologist</h6>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="doctors-specifications-list-wrap">
                                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/marker-pin.svg"
                                                    alt="stethoscope">
                                                <h6>Australian Capital Territory</h6>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <a href="<?php echo base_url();?>virtual_consult/patient/book_appointment"
                                    class="book-btn">Book appointment<svg width="16" height="12" viewBox="0 0 16 12"
                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1.33301 6H14.6663M14.6663 6L9.66634 1M14.6663 6L9.66634 11"
                                            stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg></a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="doctors-list-wrap">
                            <button type="button" class="like-btn">
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M7.52144 2.30229C7.6751 1.991 7.75193 1.83535 7.85623 1.78562C7.94697 1.74236 8.0524 1.74236 8.14315 1.78562C8.24744 1.83535 8.32427 1.991 8.47793 2.30229L9.93572 5.2556C9.98108 5.3475 10.0038 5.39345 10.0369 5.42913C10.0663 5.46072 10.1015 5.48631 10.1406 5.5045C10.1847 5.52503 10.2354 5.53244 10.3368 5.54726L13.5977 6.02389C13.9411 6.07408 14.1127 6.09917 14.1922 6.18304C14.2613 6.25601 14.2938 6.35628 14.2807 6.45593C14.2656 6.57047 14.1413 6.69153 13.8927 6.93367L11.534 9.23103C11.4604 9.30264 11.4237 9.33845 11.4 9.38106C11.379 9.41878 11.3655 9.46022 11.3603 9.50309C11.3544 9.5515 11.3631 9.60208 11.3804 9.70324L11.937 12.9482C11.9957 13.2904 12.025 13.4615 11.9699 13.5631C11.9219 13.6514 11.8366 13.7134 11.7377 13.7317C11.6241 13.7528 11.4704 13.672 11.1631 13.5104L8.24793 11.9773C8.1571 11.9295 8.11168 11.9057 8.06384 11.8963C8.02147 11.888 7.9779 11.888 7.93554 11.8963C7.88769 11.9057 7.84228 11.9295 7.75145 11.9773L4.83629 13.5104C4.52895 13.672 4.37528 13.7528 4.26166 13.7317C4.1628 13.7134 4.07749 13.6514 4.0295 13.5631C3.97434 13.4615 4.00369 13.2904 4.06239 12.9482L4.61893 9.70324C4.63628 9.60208 4.64496 9.5515 4.63909 9.50309C4.63389 9.46022 4.62042 9.41878 4.59941 9.38106C4.57569 9.33845 4.53893 9.30264 4.4654 9.23103L2.10671 6.93367C1.85812 6.69153 1.73382 6.57047 1.71869 6.45593C1.70553 6.35628 1.73804 6.25601 1.80717 6.18304C1.88663 6.09917 2.05832 6.07408 2.4017 6.02389L5.66255 5.54726C5.76396 5.53244 5.81466 5.52503 5.85882 5.5045C5.89792 5.48631 5.93312 5.46072 5.96247 5.42913C5.99561 5.39345 6.01829 5.3475 6.06366 5.2556L7.52144 2.30229Z"
                                        stroke="white" stroke-opacity="0.6" stroke-width="1.336" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>
                            </button>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg06.png"
                                alt="doctor image" class="img-responsive doctor-img">
                            <div class="doctors-data">
                                <div class="doctor-data-bottom-wrap">
                                    <label class="online"><span class="dot-label"></span>
                                        <p>Online</p>
                                    </label>
                                    <div class="doctor-name-share-wrap">
                                        <h4 class="doctors-name doctor-detail-trigger">Alasteir Whitechurch</h4>
                                        <button class="share-doctor-modal-trigger"><svg width="21" height="20"
                                                viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M18.1259 10.5062C18.3294 10.3318 18.4311 10.2446 18.4684 10.1409C18.5011 10.0498 18.5011 9.9502 18.4684 9.85914C18.4311 9.75539 18.3294 9.6682 18.1259 9.49383L11.067 3.44331C10.7168 3.14315 10.5417 2.99306 10.3935 2.98939C10.2646 2.98619 10.1416 3.04279 10.0602 3.14269C9.96647 3.25764 9.96647 3.48825 9.96647 3.94948V7.52886C8.18757 7.84007 6.55947 8.74146 5.34956 10.0949C4.03049 11.5704 3.30083 13.48 3.2998 15.4591V15.9691C4.17426 14.9157 5.26606 14.0638 6.50044 13.4716C7.58872 12.9495 8.76515 12.6403 9.96647 12.5588V16.0505C9.96647 16.5117 9.96647 16.7424 10.0602 16.8573C10.1416 16.9572 10.2646 17.0138 10.3935 17.0106C10.5417 17.0069 10.7168 16.8569 11.067 16.5567L18.1259 10.5062Z"
                                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg></button>
                                    </div>
                                    <ul class="doctors-specifications-list">
                                        <li>
                                            <div class="doctors-specifications-list-wrap">
                                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/stethoscope.svg"
                                                    alt="stethoscope">
                                                <h6>Cardiologist</h6>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="doctors-specifications-list-wrap">
                                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/marker-pin.svg"
                                                    alt="stethoscope">
                                                <h6>Australian Capital Territory</h6>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <a href="<?php echo base_url();?>virtual_consult/patient/book_appointment"
                                    class="book-btn">Book appointment<svg width="16" height="12" viewBox="0 0 16 12"
                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1.33301 6H14.6663M14.6663 6L9.66634 1M14.6663 6L9.66634 11"
                                            stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg></a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="doctors-list-wrap">
                            <button type="button" class="like-btn">
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M7.52144 2.30229C7.6751 1.991 7.75193 1.83535 7.85623 1.78562C7.94697 1.74236 8.0524 1.74236 8.14315 1.78562C8.24744 1.83535 8.32427 1.991 8.47793 2.30229L9.93572 5.2556C9.98108 5.3475 10.0038 5.39345 10.0369 5.42913C10.0663 5.46072 10.1015 5.48631 10.1406 5.5045C10.1847 5.52503 10.2354 5.53244 10.3368 5.54726L13.5977 6.02389C13.9411 6.07408 14.1127 6.09917 14.1922 6.18304C14.2613 6.25601 14.2938 6.35628 14.2807 6.45593C14.2656 6.57047 14.1413 6.69153 13.8927 6.93367L11.534 9.23103C11.4604 9.30264 11.4237 9.33845 11.4 9.38106C11.379 9.41878 11.3655 9.46022 11.3603 9.50309C11.3544 9.5515 11.3631 9.60208 11.3804 9.70324L11.937 12.9482C11.9957 13.2904 12.025 13.4615 11.9699 13.5631C11.9219 13.6514 11.8366 13.7134 11.7377 13.7317C11.6241 13.7528 11.4704 13.672 11.1631 13.5104L8.24793 11.9773C8.1571 11.9295 8.11168 11.9057 8.06384 11.8963C8.02147 11.888 7.9779 11.888 7.93554 11.8963C7.88769 11.9057 7.84228 11.9295 7.75145 11.9773L4.83629 13.5104C4.52895 13.672 4.37528 13.7528 4.26166 13.7317C4.1628 13.7134 4.07749 13.6514 4.0295 13.5631C3.97434 13.4615 4.00369 13.2904 4.06239 12.9482L4.61893 9.70324C4.63628 9.60208 4.64496 9.5515 4.63909 9.50309C4.63389 9.46022 4.62042 9.41878 4.59941 9.38106C4.57569 9.33845 4.53893 9.30264 4.4654 9.23103L2.10671 6.93367C1.85812 6.69153 1.73382 6.57047 1.71869 6.45593C1.70553 6.35628 1.73804 6.25601 1.80717 6.18304C1.88663 6.09917 2.05832 6.07408 2.4017 6.02389L5.66255 5.54726C5.76396 5.53244 5.81466 5.52503 5.85882 5.5045C5.89792 5.48631 5.93312 5.46072 5.96247 5.42913C5.99561 5.39345 6.01829 5.3475 6.06366 5.2556L7.52144 2.30229Z"
                                        stroke="white" stroke-opacity="0.6" stroke-width="1.336" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>
                            </button>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg07.png"
                                alt="doctor image" class="img-responsive doctor-img">
                            <div class="doctors-data">
                                <div class="doctor-data-bottom-wrap">
                                    <label class="online"><span class="dot-label"></span>
                                        <p>Online</p>
                                    </label>
                                    <div class="doctor-name-share-wrap">
                                        <h4 class="doctors-name doctor-detail-trigger">Alasteir Whitechurch</h4>
                                        <button class="share-doctor-modal-trigger"><svg width="21" height="20"
                                                viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M18.1259 10.5062C18.3294 10.3318 18.4311 10.2446 18.4684 10.1409C18.5011 10.0498 18.5011 9.9502 18.4684 9.85914C18.4311 9.75539 18.3294 9.6682 18.1259 9.49383L11.067 3.44331C10.7168 3.14315 10.5417 2.99306 10.3935 2.98939C10.2646 2.98619 10.1416 3.04279 10.0602 3.14269C9.96647 3.25764 9.96647 3.48825 9.96647 3.94948V7.52886C8.18757 7.84007 6.55947 8.74146 5.34956 10.0949C4.03049 11.5704 3.30083 13.48 3.2998 15.4591V15.9691C4.17426 14.9157 5.26606 14.0638 6.50044 13.4716C7.58872 12.9495 8.76515 12.6403 9.96647 12.5588V16.0505C9.96647 16.5117 9.96647 16.7424 10.0602 16.8573C10.1416 16.9572 10.2646 17.0138 10.3935 17.0106C10.5417 17.0069 10.7168 16.8569 11.067 16.5567L18.1259 10.5062Z"
                                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg></button>
                                    </div>
                                    <ul class="doctors-specifications-list">
                                        <li>
                                            <div class="doctors-specifications-list-wrap">
                                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/stethoscope.svg"
                                                    alt="stethoscope">
                                                <h6>Cardiologist</h6>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="doctors-specifications-list-wrap">
                                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/marker-pin.svg"
                                                    alt="stethoscope">
                                                <h6>Australian Capital Territory</h6>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <a href="<?php echo base_url();?>virtual_consult/patient/book_appointment"
                                    class="book-btn">Book appointment<svg width="16" height="12" viewBox="0 0 16 12"
                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1.33301 6H14.6663M14.6663 6L9.66634 1M14.6663 6L9.66634 11"
                                            stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg></a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="doctors-list-wrap">
                            <button type="button" class="like-btn">
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M7.52144 2.30229C7.6751 1.991 7.75193 1.83535 7.85623 1.78562C7.94697 1.74236 8.0524 1.74236 8.14315 1.78562C8.24744 1.83535 8.32427 1.991 8.47793 2.30229L9.93572 5.2556C9.98108 5.3475 10.0038 5.39345 10.0369 5.42913C10.0663 5.46072 10.1015 5.48631 10.1406 5.5045C10.1847 5.52503 10.2354 5.53244 10.3368 5.54726L13.5977 6.02389C13.9411 6.07408 14.1127 6.09917 14.1922 6.18304C14.2613 6.25601 14.2938 6.35628 14.2807 6.45593C14.2656 6.57047 14.1413 6.69153 13.8927 6.93367L11.534 9.23103C11.4604 9.30264 11.4237 9.33845 11.4 9.38106C11.379 9.41878 11.3655 9.46022 11.3603 9.50309C11.3544 9.5515 11.3631 9.60208 11.3804 9.70324L11.937 12.9482C11.9957 13.2904 12.025 13.4615 11.9699 13.5631C11.9219 13.6514 11.8366 13.7134 11.7377 13.7317C11.6241 13.7528 11.4704 13.672 11.1631 13.5104L8.24793 11.9773C8.1571 11.9295 8.11168 11.9057 8.06384 11.8963C8.02147 11.888 7.9779 11.888 7.93554 11.8963C7.88769 11.9057 7.84228 11.9295 7.75145 11.9773L4.83629 13.5104C4.52895 13.672 4.37528 13.7528 4.26166 13.7317C4.1628 13.7134 4.07749 13.6514 4.0295 13.5631C3.97434 13.4615 4.00369 13.2904 4.06239 12.9482L4.61893 9.70324C4.63628 9.60208 4.64496 9.5515 4.63909 9.50309C4.63389 9.46022 4.62042 9.41878 4.59941 9.38106C4.57569 9.33845 4.53893 9.30264 4.4654 9.23103L2.10671 6.93367C1.85812 6.69153 1.73382 6.57047 1.71869 6.45593C1.70553 6.35628 1.73804 6.25601 1.80717 6.18304C1.88663 6.09917 2.05832 6.07408 2.4017 6.02389L5.66255 5.54726C5.76396 5.53244 5.81466 5.52503 5.85882 5.5045C5.89792 5.48631 5.93312 5.46072 5.96247 5.42913C5.99561 5.39345 6.01829 5.3475 6.06366 5.2556L7.52144 2.30229Z"
                                        stroke="white" stroke-opacity="0.6" stroke-width="1.336" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>
                            </button>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg08.png"
                                alt="doctor image" class="img-responsive doctor-img">
                            <div class="doctors-data">
                                <div class="doctor-data-bottom-wrap">
                                    <label class="online"><span class="dot-label"></span>
                                        <p>Online</p>
                                    </label>
                                    <div class="doctor-name-share-wrap">
                                        <h4 class="doctors-name doctor-detail-trigger">Alasteir Whitechurch</h4>
                                        <button class="share-doctor-modal-trigger"><svg width="21" height="20"
                                                viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M18.1259 10.5062C18.3294 10.3318 18.4311 10.2446 18.4684 10.1409C18.5011 10.0498 18.5011 9.9502 18.4684 9.85914C18.4311 9.75539 18.3294 9.6682 18.1259 9.49383L11.067 3.44331C10.7168 3.14315 10.5417 2.99306 10.3935 2.98939C10.2646 2.98619 10.1416 3.04279 10.0602 3.14269C9.96647 3.25764 9.96647 3.48825 9.96647 3.94948V7.52886C8.18757 7.84007 6.55947 8.74146 5.34956 10.0949C4.03049 11.5704 3.30083 13.48 3.2998 15.4591V15.9691C4.17426 14.9157 5.26606 14.0638 6.50044 13.4716C7.58872 12.9495 8.76515 12.6403 9.96647 12.5588V16.0505C9.96647 16.5117 9.96647 16.7424 10.0602 16.8573C10.1416 16.9572 10.2646 17.0138 10.3935 17.0106C10.5417 17.0069 10.7168 16.8569 11.067 16.5567L18.1259 10.5062Z"
                                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg></button>
                                    </div>
                                    <ul class="doctors-specifications-list">
                                        <li>
                                            <div class="doctors-specifications-list-wrap">
                                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/stethoscope.svg"
                                                    alt="stethoscope">
                                                <h6>Cardiologist</h6>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="doctors-specifications-list-wrap">
                                                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/marker-pin.svg"
                                                    alt="stethoscope">
                                                <h6>Australian Capital Territory</h6>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <a href="<?php echo base_url();?>virtual_consult/patient/book_appointment"
                                    class="book-btn">Book appointment<svg width="16" height="12" viewBox="0 0 16 12"
                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1.33301 6H14.6663M14.6663 6L9.66634 1M14.6663 6L9.66634 11"
                                            stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg></a>
                            </div>
                        </div>
                    </li>   
                </ul>
                <div class="pagination-row">
                    <div class="left-pagination">
                        <button type="button" class="pagination-button"><svg width="14" height="14" viewBox="0 0 14 14"
                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M12.8337 6.99996H1.16699M1.16699 6.99996L7.00033 12.8333M1.16699 6.99996L7.00033 1.16663"
                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>
                            Previous</button>
                    </div>
                    <div class="center-pagination">
                        <ul class="pagination-number">
                            <li>
                                <button type="button" active>1</button>
                            </li>
                            <li>
                                <button type="button">2</button>
                            </li>
                            <li>
                                <button type="button">3</button>
                            </li>
                            <li>
                                <button type="button">...</button>
                            </li>
                            <li>
                                <button type="button">8</button>
                            </li>
                            <li>
                                <button type="button">9</button>
                            </li>
                            <li>
                                <button type="button">10</button>
                            </li>
                        </ul>
                    </div>
                    <div class="right-pagination">
                        <button type="button" class="pagination-button">Next<svg width="14" height="14"
                                viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M1.1665 6.99996H12.8332M12.8332 6.99996L6.99984 1.16663M12.8332 6.99996L6.99984 12.8333"
                                    stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>

                        </button>
                    </div>
                </div>
                <div class="pagination-row-responsive">
                    <button type="button" class="pagination-button-responsive"><svg width="14" height="14"
                            viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M12.8337 6.99996H1.16699M1.16699 6.99996L7.00033 12.8333M1.16699 6.99996L7.00033 1.16663"
                                stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                    </button>
                    <p>page <span>1</span> of <span>10</span></p>
                    <button type="button" class="pagination-button-responsive"><svg width="14" height="14"
                            viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M1.1665 6.99996H12.8332M12.8332 6.99996L6.99984 1.16663M12.8332 6.99996L6.99984 12.8333"
                                stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>

                    </button>
                </div>
            </div>
        </div>
    </div>
</section>

<!--doctor details modal-->
<div class="modal doctor-detail-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Details</h1>
                <span class="close-button"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round"></path>
                    </svg></span>
        </div>
        <div class="modal-body">
            <div class="modal-doctor-profile">
                <div class="modal-doctor-profile-img">
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctorimg02.png"
                        alt="patient photo">
                    <span class="online-icon availability-icon"></span>
                </div>
                <div class="modal-doctor-profile-info">
                    <h6>Dr. Shaun Miller</h6>
                    <p>General Practitioner – Fellow, Cardiology</p>
                </div>
            </div>
            <h5 class="modal-sub-heading">Location</h5>
            <p class="modal-para">Australia</p>
            <h5 class="modal-sub-heading">Qualification</h5>
            <p class="modal-para">B-Tech, B-Tech Hounors, M-Tech, MDS</p>
            <h5 class="modal-sub-heading">Description</h5>
            <p class="modal-para">Introducing Dr. Shaun Miller, a respected General Practitioner and Cardiology
                Fellow based in Australia. With qualifications including B-Tech, B-Tech Honors, M-Tech, and MDS, Dr.
                Miller is dedicated to delivering comprehensive and compassionate care to his patients. His
                expertise in cardiology combined with his commitment to patient well-being makes him a trusted
                healthcare provider in his community.</p>
        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">
                <button type="button" class="close-button unfilled-button">Close</button>
                <a href="<?php echo base_url();?>virtual_consult/patient/book_appointment" class="primary-button">Book
                    appointment</a>
            </div>
        </div>

    </div>
</div>

<!--Appointment Summary modal-->
<div class="modal view-deatils-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Appointment Summary</h1>
                <span class="close-button"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round"></path>
                    </svg></span>
        </div>
        <div class="modal-body">
            <div class="appointment-summary-modal-wrap">
                <h5 class="steps-sub-heading">Reason for consultation</h5>
                <ul class="custom-radio-type-btn">
                    <li>
                        <input type="radio" id="carer-certificate" name="carer-certificate" checked>
                        <label for="carer-certificate">Carer Certificate</label>
                    </li>
                    <li>
                        <input type="radio" id="medical-consult" name="medical-consult" checked>
                        <label for="medical-consult">Imaging/scan request</label>
                    </li>
                </ul>
                <div class="questionnaire-wrap">
                    <div class="drop-down-filters toggle-drop-btn show-filter-dropdown">
                        <h5>Questionnaire</h5>
                        <img src="<?php echo base_url(); ?>assets/images/virtual_consult/questionnaire-down.svg"
                            alt="icon">
                    </div>
                    <div class="drop-filters-content">
                        <h5 class="steps-sub-heading"> Selected service(s)</h5>
                        <ul class="summary-list nopadd list-style-none">

                            <li>
                                <p class="steps-sub-para">Online video consultation ( Medical certificate, Carer
                                    certificate, Imaging/Investigation, Pathology request, Referral request etc)<br>1 x
                                    $100</p>
                                <p class="steps-sub-para">$100</p>
                            </li>
                        </ul>
                        <h5 class="steps-sub-heading"> Pharmacy</h5>
                        <input class="input-text-style"
                            placeholder=" Pharmacy 777 Lynwood, Lynwood Village Shopping Centre, Shop 6-9, 6 Lynwood Avenue, LYNWOOD, WA, 6147"
                            disabled>
                        <ul class="summary-list nopadd list-style-none">
                            <li>
                                <p class="steps-sub-para color-black">Subtotal</p>
                                <p class="steps-sub-para color-black">$200</p>
                            </li>
                            <li>
                                <p class="steps-sub-para">Online video consultation ( Medical certificate, Carer
                                    certificate,
                                    Imaging/Investigation, Pathology request, Referral request etc)</p>
                                <p class="steps-sub-para">$100</p>
                            </li>
                            <li>
                                <p class="steps-sub-para">Service 2</p>
                                <p class="steps-sub-para">$100</p>
                            </li>
                            <li>
                                <p class="steps-sub-para">Internet handling fee<br><span>(Non-refundable processing
                                        fees)</span>
                                </p>
                                <p class="steps-sub-para">$10</p>
                            </li>
                        </ul>
                        <div class="final-summary">
                            <p class="steps-sub-para">Total amount</p>
                            <p class="steps-sub-para">$210</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">
                <button type="button" class="close-button unfilled-button">Close</button>
            </div>
        </div>

    </div>
</div>

<!--Appointment edit details modal-->
<div class="modal edit-deatils-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Request new date or time</h1>
                <span class="close-button"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round"></path>
                    </svg></span>
        </div>
        <div class="modal-body">
            <div class="date-time-picker-wrap">
                <h5 class="steps-sub-heading">Date and time</h5>
                <div class="date-time-picker-row">
                    <div class="date-picker-wrap">
                        <p class="steps-sub-para font-500">Date</p>
                        <div class="datepicker-wrap">
                            <input type="text" id="appointment-edit-date-datepicker" class="date" readonly="readonly"
                                placeholder="9/02/2024">
                            <svg width="12" height="8" viewBox="0 0 12 8" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5" stroke="#667085" stroke-width="1.66667"
                                    stroke-linecap="round" stroke-linejoin="round" />
                            </svg>

                        </div>
                    </div>
                    <div class="selected-date-time-wrap">
                        <p class="steps-sub-para font-500">Selected date and time</p>
                        <ul>
                            <li>
                                <svg width="14" height="16" viewBox="0 0 14 16" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M13 6.66668H1M9.66667 1.33334V4.00001M4.33333 1.33334V4.00001M4.2 14.6667H9.8C10.9201 14.6667 11.4802 14.6667 11.908 14.4487C12.2843 14.2569 12.5903 13.951 12.782 13.5747C13 13.1468 13 12.5868 13 11.4667V5.86668C13 4.74657 13 4.18652 12.782 3.7587C12.5903 3.38237 12.2843 3.07641 11.908 2.88466C11.4802 2.66668 10.9201 2.66668 9.8 2.66668H4.2C3.0799 2.66668 2.51984 2.66668 2.09202 2.88466C1.71569 3.07641 1.40973 3.38237 1.21799 3.7587C1 4.18652 1 4.74657 1 5.86668V11.4667C1 12.5868 1 13.1468 1.21799 13.5747C1.40973 13.951 1.71569 14.2569 2.09202 14.4487C2.51984 14.6667 3.0799 14.6667 4.2 14.6667Z"
                                        stroke="#475467" stroke-width="1.33" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>
                                07-07-2023
                            </li>
                            <li>
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <g clip-path="url(#clip0_2827_15152)">
                                        <path
                                            d="M7.99967 4.00001V8.00001L10.6663 9.33334M14.6663 8.00001C14.6663 11.6819 11.6816 14.6667 7.99967 14.6667C4.31778 14.6667 1.33301 11.6819 1.33301 8.00001C1.33301 4.31811 4.31778 1.33334 7.99967 1.33334C11.6816 1.33334 14.6663 4.31811 14.6663 8.00001Z"
                                            stroke="#475467" stroke-width="1.33" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_2827_15152">
                                            <rect width="16" height="16" fill="white" />
                                        </clipPath>
                                    </defs>
                                </svg>
                                01:00 PM
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="modal-tabs">
                    <div class="modal-tabs-buttons tabs-carousel owl-carousel owl-theme">
                        <div class="item"><button class="modal-tab-button" data-tab="5">
                                <span>Today<span class="slot-text slot-green">20 slots available</span></span>
                            </button></div>
                        <div class="item"> <button class="modal-tab-button" data-tab="6">
                                <span>Sat, 13 Apr<span class="slot-text slot-orange">4 slots available</span></span>
                            </button></div>
                        <div class="item"><button class="modal-tab-button" data-tab="7">
                                <span>Sun, 14 Apr<span class="slot-text">0 slots available</span></span>
                            </button></div>
                    </div>
                    <div class="modal-tab-contents">
                        <div class="modal-tab-content" data-tab="5">
                            <div class="slot-availability-table-wrap">
                                <div class="slot-availability-table-left-wrap">
                                    <p class="steps-sub-para font-500"><svg width="22" height="22" viewBox="0 0 22 22"
                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M3 17H1M5.31412 11.3141L3.8999 9.8999M16.6858 11.3141L18.1 9.8999M21 17H19M6 17C6 14.2386 8.23858 12 11 12C13.7614 12 16 14.2386 16 17M21 21H1M15 5L11 1M11 1L7 5M11 1V8"
                                                stroke="#F79009" stroke-width="2" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                        </svg>
                                        Morning</p>
                                </div>
                                <div class="slot-availability-table-right-wrap">
                                    <ul class="custom-radio-type-btn">
                                        <li>
                                            <input type="radio" id="mt1" name="slot-availability" />
                                            <label for="mt1">8:00 AM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="mt2" name="slot-availability" />
                                            <label for="mt2">8:15 AM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="mt3" name="slot-availability" />
                                            <label for="mt3">8:30 AM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="mt4" name="slot-availability" />
                                            <label for="mt4">8:45 AM</label>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="slot-availability-table-wrap slot-afternoon">
                                <div class="slot-availability-table-left-wrap">
                                    <p class="steps-sub-para font-500"><svg width="24" height="24" viewBox="0 0 24 24"
                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12 2V4M12 20V22M4 12H2M6.31412 6.31412L4.8999 4.8999M17.6859 6.31412L19.1001 4.8999M6.31412 17.69L4.8999 19.1042M17.6859 17.69L19.1001 19.1042M22 12H20M17 12C17 14.7614 14.7614 17 12 17C9.23858 17 7 14.7614 7 12C7 9.23858 9.23858 7 12 7C14.7614 7 17 9.23858 17 12Z"
                                                stroke="#FDE272" stroke-width="2" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                        </svg>

                                        Afternoon</p>
                                </div>
                                <div class="slot-availability-table-right-wrap">
                                    <ul class="custom-radio-type-btn">
                                        <li>
                                            <input type="radio" id="at1" name="slot-availability" />
                                            <label for="at1">1:00 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="at2" name="slot-availability" />
                                            <label for="at2">1:15 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="at3" name="slot-availability" />
                                            <label for="at3">1:30 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="at4" name="slot-availability" />
                                            <label for="at4">1:45 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="at5" name="slot-availability" />
                                            <label for="at5">2:00 PM</label>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="slot-availability-table-wrap slot-evening">
                                <div class="slot-availability-table-left-wrap">
                                    <p class="steps-sub-para font-500"><svg width="22" height="22" viewBox="0 0 22 22"
                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M3 17H1M5.31412 11.3141L3.8999 9.8999M16.6858 11.3141L18.1 9.8999M21 17H19M6 17C6 14.2386 8.23858 12 11 12C13.7614 12 16 14.2386 16 17M21 21H1M15 4L11 8M11 8L7 4M11 8V1"
                                                stroke="#B54708" stroke-width="2" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                        </svg>

                                        Evening</p>
                                </div>
                                <div class="slot-availability-table-right-wrap">
                                    <ul class="custom-radio-type-btn">
                                        <li>
                                            <input type="radio" id="et1" name="slot-availability" />
                                            <label for="et1">7:00 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="et2" name="slot-availability" />
                                            <label for="et2">7:15 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="et3" name="slot-availability" />
                                            <label for="et3">7:30 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="et4" name="slot-availability" />
                                            <label for="et4">7:45 PM</label>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="modal-tab-content" data-tab="6">
                            <div class="slot-availability-table-wrap">
                                <div class="slot-availability-table-left-wrap">
                                    <p class="steps-sub-para font-500"><svg width="22" height="22" viewBox="0 0 22 22"
                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M3 17H1M5.31412 11.3141L3.8999 9.8999M16.6858 11.3141L18.1 9.8999M21 17H19M6 17C6 14.2386 8.23858 12 11 12C13.7614 12 16 14.2386 16 17M21 21H1M15 5L11 1M11 1L7 5M11 1V8"
                                                stroke="#F79009" stroke-width="2" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                        </svg>
                                        Morning</p>
                                </div>
                                <div class="slot-availability-table-right-wrap">
                                    <ul class="custom-radio-type-btn">
                                        <li>
                                            <input type="radio" id="mt1" name="slot-availability" />
                                            <label for="mt1">8:00 AM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="mt2" name="slot-availability" />
                                            <label for="mt2">8:15 AM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="mt3" name="slot-availability" />
                                            <label for="mt3">8:30 AM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="mt4" name="slot-availability" />
                                            <label for="mt4">8:45 AM</label>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="slot-availability-table-wrap slot-afternoon">
                                <div class="slot-availability-table-left-wrap">
                                    <p class="steps-sub-para font-500"><svg width="24" height="24" viewBox="0 0 24 24"
                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12 2V4M12 20V22M4 12H2M6.31412 6.31412L4.8999 4.8999M17.6859 6.31412L19.1001 4.8999M6.31412 17.69L4.8999 19.1042M17.6859 17.69L19.1001 19.1042M22 12H20M17 12C17 14.7614 14.7614 17 12 17C9.23858 17 7 14.7614 7 12C7 9.23858 9.23858 7 12 7C14.7614 7 17 9.23858 17 12Z"
                                                stroke="#FDE272" stroke-width="2" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                        </svg>

                                        Afternoon</p>
                                </div>
                                <div class="slot-availability-table-right-wrap">
                                    <ul class="custom-radio-type-btn">
                                        <li>
                                            <input type="radio" id="at1" name="slot-availability" />
                                            <label for="at1">1:00 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="at2" name="slot-availability" />
                                            <label for="at2">1:15 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="at3" name="slot-availability" />
                                            <label for="at3">1:30 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="at4" name="slot-availability" />
                                            <label for="at4">1:45 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="at5" name="slot-availability" />
                                            <label for="at5">2:00 PM</label>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="slot-availability-table-wrap slot-evening">
                                <div class="slot-availability-table-left-wrap">
                                    <p class="steps-sub-para font-500"><svg width="22" height="22" viewBox="0 0 22 22"
                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M3 17H1M5.31412 11.3141L3.8999 9.8999M16.6858 11.3141L18.1 9.8999M21 17H19M6 17C6 14.2386 8.23858 12 11 12C13.7614 12 16 14.2386 16 17M21 21H1M15 4L11 8M11 8L7 4M11 8V1"
                                                stroke="#B54708" stroke-width="2" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                        </svg>

                                        Evening</p>
                                </div>
                                <div class="slot-availability-table-right-wrap">
                                    <ul class="custom-radio-type-btn">
                                        <li>
                                            <input type="radio" id="et1" name="slot-availability" />
                                            <label for="et1">7:00 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="et2" name="slot-availability" />
                                            <label for="et2">7:15 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="et3" name="slot-availability" />
                                            <label for="et3">7:30 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="et4" name="slot-availability" />
                                            <label for="et4">7:45 PM</label>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="modal-tab-content" data-tab="7">
                            <div class="slot-availability-table-wrap">
                                <div class="slot-availability-table-left-wrap">
                                    <p class="steps-sub-para font-500"><svg width="22" height="22" viewBox="0 0 22 22"
                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M3 17H1M5.31412 11.3141L3.8999 9.8999M16.6858 11.3141L18.1 9.8999M21 17H19M6 17C6 14.2386 8.23858 12 11 12C13.7614 12 16 14.2386 16 17M21 21H1M15 5L11 1M11 1L7 5M11 1V8"
                                                stroke="#F79009" stroke-width="2" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                        </svg>
                                        Morning</p>
                                </div>
                                <div class="slot-availability-table-right-wrap">
                                    <ul class="custom-radio-type-btn">
                                        <li>
                                            <input type="radio" id="mt1" name="slot-availability" />
                                            <label for="mt1">8:00 AM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="mt2" name="slot-availability" />
                                            <label for="mt2">8:15 AM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="mt3" name="slot-availability" />
                                            <label for="mt3">8:30 AM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="mt4" name="slot-availability" />
                                            <label for="mt4">8:45 AM</label>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="slot-availability-table-wrap slot-afternoon">
                                <div class="slot-availability-table-left-wrap">
                                    <p class="steps-sub-para font-500"><svg width="24" height="24" viewBox="0 0 24 24"
                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12 2V4M12 20V22M4 12H2M6.31412 6.31412L4.8999 4.8999M17.6859 6.31412L19.1001 4.8999M6.31412 17.69L4.8999 19.1042M17.6859 17.69L19.1001 19.1042M22 12H20M17 12C17 14.7614 14.7614 17 12 17C9.23858 17 7 14.7614 7 12C7 9.23858 9.23858 7 12 7C14.7614 7 17 9.23858 17 12Z"
                                                stroke="#FDE272" stroke-width="2" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                        </svg>

                                        Afternoon</p>
                                </div>
                                <div class="slot-availability-table-right-wrap">
                                    <ul class="custom-radio-type-btn">
                                        <li>
                                            <input type="radio" id="at1" name="slot-availability" />
                                            <label for="at1">1:00 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="at2" name="slot-availability" />
                                            <label for="at2">1:15 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="at3" name="slot-availability" />
                                            <label for="at3">1:30 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="at4" name="slot-availability" />
                                            <label for="at4">1:45 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="at5" name="slot-availability" />
                                            <label for="at5">2:00 PM</label>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="slot-availability-table-wrap slot-evening">
                                <div class="slot-availability-table-left-wrap">
                                    <p class="steps-sub-para font-500"><svg width="22" height="22" viewBox="0 0 22 22"
                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M3 17H1M5.31412 11.3141L3.8999 9.8999M16.6858 11.3141L18.1 9.8999M21 17H19M6 17C6 14.2386 8.23858 12 11 12C13.7614 12 16 14.2386 16 17M21 21H1M15 4L11 8M11 8L7 4M11 8V1"
                                                stroke="#B54708" stroke-width="2" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                        </svg>

                                        Evening</p>
                                </div>
                                <div class="slot-availability-table-right-wrap">
                                    <ul class="custom-radio-type-btn">
                                        <li>
                                            <input type="radio" id="et1" name="slot-availability" />
                                            <label for="et1">7:00 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="et2" name="slot-availability" />
                                            <label for="et2">7:15 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="et3" name="slot-availability" />
                                            <label for="et3">7:30 PM</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="et4" name="slot-availability" />
                                            <label for="et4">7:45 PM</label>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal-footer">
            <div class="flex-modal-button">
                <button type="button" class="close-button unfilled-button">Close</button>
                <button type="button" class="primary-button">Save and send request</button>
            </div>
        </div>

    </div>
</div>
<!--My Appointment cancel modal-->
<div class="modal cancel-appointment-list-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Please provide reason for cancellation</h1>
                <span class="close-button"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round"></path>
                    </svg></span>
        </div>
        <div class="modal-body">
            <div class="cancel-appointment-list-wrap">
                <textarea name="cancel-message" class="text-area-style" id="cancel-message"></textarea>
            </div>

        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">
                <button type="button" class="primary-button dangerstyle">Cancel appointment</button>
                <button type="button" class="close-button unfilled-button">Close</button>
            </div>
        </div>

    </div>
</div>

<!--share doctor modal-->
<div class="modal share-doctor-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Share</h5>
            <span class="closecurrentpopup"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round"></path>
                </svg></span>
        </div>
        <div class="modal-body">
            <div class="share-doctor-modal-wrap">
                <input type="text" value="https://www.medcallz.com.au/health" class="share-doctor-input-style">
                <button class="share-doctor-input-copy"><svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_10110_81059)">
                            <path
                                d="M4.16675 12.5001C3.39018 12.5001 3.00189 12.5001 2.69561 12.3732C2.28723 12.2041 1.96277 11.8796 1.79362 11.4712C1.66675 11.1649 1.66675 10.7767 1.66675 10.0001V4.33341C1.66675 3.39999 1.66675 2.93328 1.8484 2.57676C2.00819 2.26316 2.26316 2.00819 2.57676 1.8484C2.93328 1.66675 3.39999 1.66675 4.33341 1.66675H10.0001C10.7767 1.66675 11.1649 1.66675 11.4712 1.79362C11.8796 1.96277 12.2041 2.28723 12.3732 2.69561C12.5001 3.00189 12.5001 3.39018 12.5001 4.16675M10.1667 18.3334H15.6667C16.6002 18.3334 17.0669 18.3334 17.4234 18.1518C17.737 17.992 17.992 17.737 18.1518 17.4234C18.3334 17.0669 18.3334 16.6002 18.3334 15.6667V10.1667C18.3334 9.23333 18.3334 8.76662 18.1518 8.4101C17.992 8.09649 17.737 7.84153 17.4234 7.68174C17.0669 7.50008 16.6002 7.50008 15.6667 7.50008H10.1667C9.23333 7.50008 8.76662 7.50008 8.4101 7.68174C8.09649 7.84153 7.84153 8.09649 7.68174 8.4101C7.50008 8.76662 7.50008 9.23333 7.50008 10.1667V15.6667C7.50008 16.6002 7.50008 17.0669 7.68174 17.4234C7.84153 17.737 8.09649 17.992 8.4101 18.1518C8.76662 18.3334 9.23333 18.3334 10.1667 18.3334Z"
                                stroke="#344054" stroke-width="1.66667" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </g>
                        <defs>
                            <clipPath id="clip0_10110_81059">
                                <rect width="20" height="20" fill="white" />
                            </clipPath>
                        </defs>
                    </svg>Copy</button>
            </div>
        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">
                <button type="button" class="closecurrentpopup unfilled-button">Close</button>
            </div>
        </div>
    </div>
    <div class="copy-to-clipboard">
        <div class="copy-to-clipboard-icon-text-wrap">
            <div class="copy-success-icon">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M13.3334 4L6.00008 11.3333L2.66675 8" stroke="#079455" stroke-width="1.33333"
                        stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </div>
            <p>Copied to clipboard</p>
        </div>
        <button class="close-copy-to-clipboard-btn">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M15 5L5 15M5 5L15 15" stroke="#475467" stroke-width="1.66667" stroke-linecap="round"
                    stroke-linejoin="round" />
            </svg>
        </button>
    </div>
</div>

<script>
    $(window).scroll(function() {
        var scroll = $(window).scrollTop();
        if (scroll >= 100) {
            $(".p-filters").addClass("sticky-filter");
        } else {
            $(".p-filters").removeClass("sticky-filter");
        }
    });
</script>

<script>
    function customAlerts(selector, action = "open", contentData = '') {
        if (contentData) {
            $(".alert_content").html(contentData);
        }
        if (action == "open") {
            $(selector).addClass('show-modal');
            $("body").addClass('modal-open');
        } else {
            $(selector).removeClass('show-modal');
            $("body").removeClass('modal-open');
        }
    }
    $(".share-doctor-modal-trigger").click(function() {
        customAlerts(".share-doctor-modal", "open");
    });
    $(document).on("click", ".closecurrentpopup", function() {
        $(this).parents('.modal').removeClass('show-modal');
        $("body").removeClass('modal-open');
    });
</script>
<script>
    $(".share-doctor-input-copy").click(function() {
        $(".copy-to-clipboard").addClass("show-copy-to-clipboard");
    });
    $(".close-copy-to-clipboard-btn").click(function() {
        $(".copy-to-clipboard").removeClass("show-copy-to-clipboard");
    });
</script>

<!--introduction slide modal-->
<!-- <div class="modal welcome-appintment-modal-slide show-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="welcome-slides-modal-heading">2/3</h5>
            <span class="close-welcome-appointment-modal"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round"></path>
                </svg></span>
        </div>
        <div class="modal-body">
            <div class="welcome-slides-modal-wrap">
                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/consult-now-slide2.png" alt="Consult Now">
                <h4><?php echo $this->lang->line('appointment_intro_heading'); ?></h4>
                <p><?php echo $this->lang->line('appointment_intro_para'); ?></p>
            </div>
        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">
                <a href="<?php echo base_url();?>virtual_consult/patient/consult_now" class="unfilled-button"><?php echo $this->lang->line('introduction_slide_back_btn'); ?></a>
                <a href="<?php echo base_url();?>virtual_consult/patient/medical_records" class="primary-button"><?php echo $this->lang->line('introduction_slide_next_btn'); ?> <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M4.66675 9.99999H16.3334M16.3334 9.99999L10.5001 4.16666M16.3334 9.99999L10.5001 15.8333" stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                </svg></a>
            </div>
        </div>
    </div>
</div>    
<script>
    $(document).ready(function() {
    $("body").addClass("show-appointment-welcome-slide");
	$(".close-welcome-appointment-modal").click(function() {
		$(".welcome-appintment-modal-slide").removeClass('show-modal');
        $("body").removeClassClass("show-appointment-welcome-slide");
	  });
});
</script> -->