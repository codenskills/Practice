<?php
$ci = &get_instance();
?>
<section class="consult-now-section">
    <div class="container">
        <div class="consult-now-heading-wrap">
            <h2 class="consult-now-heading"><?php echo $this->lang->line('consult_now'); ?></h2>
        </div>
        <div class="consult-time-doctor-online-wrap consult-now-head-width">
            <div class="consult-time-doctor-online-inner-wrap">
                <div class="consult-now-round-icon-wrap">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M23 9.24999C23.0021 8.74535 22.8653 8.24987 22.6045 7.81779C22.3438 7.38572 21.9692 7.03372 21.5218 6.80035C21.0743 6.56697 20.5713 6.46121 20.0678 6.49466C19.5642 6.5281 19.0796 6.69945 18.667 6.98996C18.2543 7.28046 17.9296 7.6789 17.7283 8.14166C17.527 8.60442 17.4569 9.11365 17.5257 9.61358C17.5945 10.1135 17.7995 10.5849 18.1184 10.976C18.4372 11.3672 18.8575 11.6631 19.3333 11.8313V15.6666C19.3333 17.1253 18.7539 18.5243 17.7224 19.5557C16.691 20.5872 15.292 21.1666 13.8333 21.1666C12.3746 21.1666 10.9757 20.5872 9.94424 19.5557C8.91279 18.5243 8.33333 17.1253 8.33333 15.6666V15.5933C9.85873 15.372 11.2537 14.6094 12.2634 13.4448C13.2732 12.2803 13.8304 10.7914 13.8333 9.24999V5.58333C13.8319 4.3682 13.3485 3.20326 12.4893 2.34403C11.6301 1.48481 10.4651 1.00146 9.24999 1C9.00688 1 8.77372 1.09658 8.60181 1.26849C8.4299 1.44039 8.33333 1.67355 8.33333 1.91667C8.33333 2.15978 8.4299 2.39294 8.60181 2.56485C8.77372 2.73675 9.00688 2.83333 9.24999 2.83333C9.97934 2.83333 10.6788 3.12306 11.1945 3.63879C11.7103 4.15451 12 4.85398 12 5.58333V9.24999C12 10.4656 11.5171 11.6314 10.6576 12.4909C9.79802 13.3504 8.63223 13.8333 7.41666 13.8333C6.20109 13.8333 5.0353 13.3504 4.17576 12.4909C3.31622 11.6314 2.83333 10.4656 2.83333 9.24999V5.58333C2.83333 4.85398 3.12306 4.15451 3.63879 3.63879C4.15451 3.12306 4.85398 2.83333 5.58333 2.83333C5.82644 2.83333 6.0596 2.73675 6.23151 2.56485C6.40342 2.39294 6.49999 2.15978 6.49999 1.91667C6.49999 1.67355 6.40342 1.44039 6.23151 1.26849C6.0596 1.09658 5.82644 1 5.58333 1C4.3682 1.00146 3.20326 1.48481 2.34403 2.34403C1.48481 3.20326 1.00146 4.3682 1 5.58333L1 9.24999C1.00295 10.7914 1.56017 12.2803 2.56992 13.4448C3.57967 14.6094 4.97459 15.372 6.49999 15.5933V15.6666C6.49999 17.6116 7.27261 19.4768 8.64788 20.8521C10.0231 22.2274 11.8884 23 13.8333 23C15.7782 23 17.6435 22.2274 19.0188 20.8521C20.394 19.4768 21.1666 17.6116 21.1666 15.6666V11.8313C21.701 11.6424 22.1639 11.293 22.4921 10.831C22.8202 10.3689 22.9976 9.81673 23 9.24999ZM20.25 10.1667C20.0687 10.1667 19.8915 10.1129 19.7407 10.0122C19.59 9.91145 19.4725 9.76828 19.4031 9.60078C19.3337 9.43328 19.3156 9.24897 19.3509 9.07116C19.3863 8.89334 19.4736 8.73001 19.6018 8.60181C19.73 8.47361 19.8933 8.38631 20.0711 8.35094C20.249 8.31557 20.4333 8.33372 20.6008 8.4031C20.7683 8.47248 20.9114 8.58997 21.0122 8.74072C21.1129 8.89146 21.1666 9.06869 21.1666 9.24999C21.1666 9.4931 21.0701 9.72626 20.8982 9.89817C20.7263 10.0701 20.4931 10.1667 20.25 10.1667Z"
                            fill="#1B71B8" />
                    </svg>
                </div>
                <div class="consult-now-time-online-content">
                    <h6><?php echo $this->lang->line('consult_now_online_doctor'); ?></h6>
                    <h4><?= @$online_doctor ?></h4>
                </div>
            </div>
        </div>
        <div class="consult-list-of-services-heading-wrap">
            <p class="consult-list-of-services-sub-heading"><?php echo $this->lang->line('list_of_services'); ?></p>
            <h5 class="consult-list-of-services-main-heading"><?php echo $this->lang->line('consultation_about'); ?></h5>
        </div>
        <div class="consult-list-of-services-wrap">
            <?php
            if(count($services_list) > 0 ){
                foreach($services_list as $res){
                    if(count(@$res['list']) == 0 ){
                        continue;
                    }
                    ?>

                    <p class="consult-cata-type-text"><?= @$res['name']?></p>
                                <div class="consult-list-of-services-list">
                                <?php
                                        if(count(@$res['list']) > 0 ){
                                            foreach($res['list'] as $rec){ ?>
                                                                <div class="consult-list-of-services-inner-wrap">
                                                                    <a href="javascript:void(0)" onClick="checkDoctors('<?=$ci->encryption->encode($rec->id)?>')">
                                                                    <div class="consult-list-of-services-inner-flex">
                                                                        <div class="consult-list-of-services-inner-content">
                                                                            <h6><?= @$rec->name ?></h6>
                                                                            <p><?= @$rec->description ?></p>
                                                                        </div>
                                                                        <div class="consult-now-round-icon-wrap">
                                                                            <img src="<?=$rec->icon?>" alt="<?= @$rec->name ?>">
                                                                        </div>
                                                                    </div>
                                                                    <div class="consult-now-button-wrap">
                                                                        <button><span><?php echo $this->lang->line('Consult_now'); ?></span><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path d="M4.16699 9.99984H15.8337M15.8337 9.99984L10.0003 4.1665M15.8337 9.99984L10.0003 15.8332" stroke="#667085" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                                                        </svg>
                                                                    </button>
                                                                    </div>
                                                                    </a>
                                                                </div>

                                            <?php }
                                        }else{ ?>
                                            <span> No Services Found</span>
                                        <?php  }
                                    ?>
                                </div>

                 <?php }
            }
            ?>
        </div>
    </div>
</section>
<!--introduction slide modal-->
<!-- <div class="modal welcome-consult-now-modal-slide show-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="welcome-slides-modal-heading">1/3</h5>
            <span class="close-welcome-consult-now-modal"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round"></path>
                </svg></span>
        </div>
        <div class="modal-body">
            <div class="welcome-slides-modal-wrap">
                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/consult-now-slide1.png" alt="Consult Now">
                <h4><?php echo $this->lang->line('consult_now_intro_heading'); ?></h4>
                <p><?php echo $this->lang->line('consult_now_intro_para'); ?></p>
            </div>
        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">
                <button type="button" class="close-welcome-consult-now-modal unfilled-button"><?php echo $this->lang->line('introduction_slide_skip_btn'); ?></button>
                <a href="<?php echo base_url();?>virtual_consult/patient/search" class="primary-button"><?php echo $this->lang->line('introduction_slide_next_btn'); ?> <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M4.66675 9.99999H16.3334M16.3334 9.99999L10.5001 4.16666M16.3334 9.99999L10.5001 15.8333" stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                </svg></a>
            </div>
        </div>
    </div>
</div>    
<script>
    $(document).ready(function() {
    $("body").addClass("show-consult-now-welcome-slide");
	$(".close-welcome-consult-now-modal").click(function() {
		$(".welcome-consult-now-modal-slide").removeClass('show-modal');
        $("body").removeClassClass("show-consult-now-welcome-slide");
	  });
});
</script> -->


