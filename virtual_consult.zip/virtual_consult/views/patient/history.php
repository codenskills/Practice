<section class="patient-appointments-sec">
    <div class="container">
        <div class="patient-appointment-header">
            <div class="patient-appointment-header-text">
                <h2 class="heading-main">Appointments</h2>
            </div>
            <ul class="patient-appointment-header-menu">
                <li>
                    <a class="patient-appointment-menu-button" href="<?php echo base_url();?>virtual_consult/patient/search"><svg width="20" height="20" viewBox="0 0 20 20"
                            fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M17.5 17.5L12.5001 12.5M14.1667 8.33333C14.1667 11.555 11.555 14.1667 8.33333 14.1667C5.11167 14.1667 2.5 11.555 2.5 8.33333C2.5 5.11167 5.11167 2.5 8.33333 2.5C11.555 2.5 14.1667 5.11167 14.1667 8.33333Z"
                                stroke="#667085" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>Search</a>
                </li>
                <li>
                    <a class="patient-appointment-menu-button" href="<?php echo base_url();?>virtual_consult/patient/favourites"><svg width="20" height="20" viewBox="0 0 20 20"
                            fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M9.40156 2.8778C9.59363 2.48869 9.68967 2.29413 9.82004 2.23197C9.93347 2.17789 10.0653 2.17789 10.1787 2.23197C10.3091 2.29413 10.4051 2.48869 10.5972 2.8778L12.4194 6.56944C12.4761 6.68432 12.5045 6.74176 12.5459 6.78635C12.5826 6.82584 12.6266 6.85783 12.6754 6.88056C12.7306 6.90623 12.794 6.91549 12.9208 6.93402L16.9968 7.5298C17.4261 7.59253 17.6407 7.6239 17.74 7.72874C17.8264 7.81995 17.8671 7.94529 17.8506 8.06985C17.8317 8.21302 17.6763 8.36436 17.3656 8.66702L14.4172 11.5387C14.3253 11.6282 14.2794 11.673 14.2497 11.7263C14.2235 11.7734 14.2066 11.8252 14.2001 11.8788C14.1928 11.9393 14.2036 12.0025 14.2253 12.129L14.921 16.1851C14.9944 16.6129 15.031 16.8269 14.9621 16.9538C14.9021 17.0642 14.7955 17.1417 14.6719 17.1646C14.5299 17.1909 14.3378 17.0899 13.9536 16.8879L10.3097 14.9716C10.1961 14.9119 10.1394 14.882 10.0796 14.8703C10.0266 14.8599 9.97213 14.8599 9.91918 14.8703C9.85937 14.882 9.8026 14.9119 9.68906 14.9716L6.04512 16.8879C5.66095 17.0899 5.46886 17.1909 5.32683 17.1646C5.20325 17.1417 5.09662 17.0642 5.03663 16.9538C4.96768 16.8269 5.00437 16.6129 5.07774 16.1851L5.77342 12.129C5.79511 12.0025 5.80595 11.9393 5.79862 11.8788C5.79212 11.8252 5.77528 11.7734 5.74902 11.7263C5.71937 11.673 5.67341 11.6282 5.5815 11.5387L2.63315 8.66702C2.3224 8.36436 2.16703 8.21302 2.14812 8.06985C2.13167 7.94529 2.17231 7.81995 2.25872 7.72874C2.35804 7.6239 2.57266 7.59253 3.00189 7.5298L7.07794 6.93402C7.2047 6.91549 7.26808 6.90623 7.32328 6.88056C7.37215 6.85783 7.41615 6.82584 7.45284 6.78635C7.49427 6.74176 7.52262 6.68432 7.57933 6.56944L9.40156 2.8778Z"
                                stroke="#667085" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>Favourites</a>
                </li>
                <li>
                    <a class="patient-appointment-menu-button" href="<?php echo base_url();?>virtual_consult/patient/online_waiting_room"><svg width="20" height="20" viewBox="0 0 20 20"
                            fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M17.5 8.33342H2.5M13.3333 1.66675V5.00008M6.66667 1.66675V5.00008M7.5 13.3334L9.16667 15.0001L12.9167 11.2501M6.5 18.3334H13.5C14.9001 18.3334 15.6002 18.3334 16.135 18.0609C16.6054 17.8212 16.9878 17.4388 17.2275 16.9684C17.5 16.4336 17.5 15.7335 17.5 14.3334V7.33342C17.5 5.93328 17.5 5.23322 17.2275 4.69844C16.9878 4.22803 16.6054 3.84558 16.135 3.6059C15.6002 3.33341 14.9001 3.33341 13.5 3.33341H6.5C5.09987 3.33341 4.3998 3.33341 3.86502 3.6059C3.39462 3.84558 3.01217 4.22803 2.77248 4.69844C2.5 5.23322 2.5 5.93328 2.5 7.33341V14.3334C2.5 15.7335 2.5 16.4336 2.77248 16.9684C3.01217 17.4388 3.39462 17.8212 3.86502 18.0609C4.3998 18.3334 5.09987 18.3334 6.5 18.3334Z"
                                stroke="#344054" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round" />
                        </svg><span>Online</span> waiting room</a>
                </li>
                <li>
                    <a class="patient-appointment-menu-button active" href="<?php echo base_url();?>virtual_consult/patient/history"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18.9166 11.25L17.2505 9.58333L15.5833 11.25M17.5 10C17.5 14.1421 14.1421 17.5 10 17.5C5.85786 17.5 2.5 14.1421 2.5 10C2.5 5.85786 5.85786 2.5 10 2.5C12.7516 2.5 15.1571 3.98178 16.4621 6.19091M10 5.83333V10L12.5 11.6667" stroke="#667085" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>History</a>
                </li>
            </ul>
        </div>
        <div class="patient-appointment-flex">
            <div class="patient-appointment-filters-div">
            <h6 class="filter-text">Filters</h6>               
                <div class="responsive-filter-bar">
                    <h6 class="filter-text-responsive"><svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M5 10H15M2.5 5H17.5M7.5 15H12.5" stroke="#101828" stroke-width="1.66667"
                                stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        Filters</h6>
                    <svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 1.5L6 6.5L11 1.5" stroke="#98A2B3" stroke-width="1.66667" stroke-linecap="round"
                            stroke-linejoin="round" />
                    </svg>
                </div>
                <div class="overlay-responsive"></div>
                <ul class="filter-list">               
                <div class="res-close-btn">
                        <button type="button" class="close-filter-list close-filter-btn"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M18 6L6 18M6 6L18 18" stroke="#344054" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg></button>
                    </div>
                    <h6 class="filter-text-responsive">Filters</h6>
                    <div class="patient-appointment-filters-search">
                        <input type="text" class="input-search-style" placeholder="Health provider name">
                    </div>
                    <li class="active-drop">
                        <div class="drop-down-filters toggle-drop-btn show-filter-list">
                            <h5>Status of appointment</h5>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg" alt="icon">
                        </div>
                        <div class="drop-filters-content">
                            <div class="drop-checkbox-wrap">
                                <form>
                                    <div class="form-group">
                                        <input type="checkbox" id="atall">
                                        <label for="atall">All appointments (7)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="atfture">
                                        <label for="atfture">Future (1)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="atpast">
                                        <label for="atpast">Past (3)</label>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </li>
                    <hr>
                    <li>
                        <div class="drop-down-filters toggle-drop-btn">
                            <h5>Consultation type</h5>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg" alt="icon">
                        </div>
                        <div class="drop-filters-content">
                            <div class="drop-checkbox-wrap">
                                <form>
                                    <div class="form-group">
                                        <input type="checkbox" id="stsall">
                                        <label for="stsall">All (4)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="stsacnf">
                                        <label for="stsacnf">Online (Consult now) (2)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="stsapst">
                                        <label for="stsapst">Online (2)</label>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </li>
                    <hr>
                    <li>
                        <div class="drop-down-filters toggle-drop-btn">
                            <h5>Specialities</h5>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg" alt="icon">
                        </div>
                        <div class="drop-filters-content">
                            <input type="text" placeholder="Search..." class="specialities-search">
                            <div class="drop-checkbox-wrap">
                                <form>
                                    <div class="form-group">
                                        <input type="checkbox" id="allspecialities">
                                        <label for="allspecialities">All specialities (20)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Cardiology">
                                        <label for="Cardiology">Cardiology (8)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Dermatology">
                                        <label for="Dermatology">Dermatology (15)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Gastroenterology">
                                        <label for="Gastroenterology">Gastroenterology (3)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Hematology">
                                        <label for="Hematology">Hematology (10)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Nephrology">
                                        <label for="Nephrology">Nephrology (5)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Neurology">
                                        <label for="Neurology">Neurology (12)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Oncology">
                                        <label for="Oncology">Oncology (18)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Pediatrics">
                                        <label for="Pediatrics">Oncology (18)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Pediatrics">
                                        <label for="Pediatrics">Pediatrics (2)</label>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </li>
                    <div class="res-filter-apply-btn-wrap">
                        <button type="button" class="res-apply-btn">Apply filters <span>(2)</span></button>
                    </div>
                </ul>
            </div>
            <div class="patient-appointment-list-div">
                <div class="result-text">
                    <p>2 result</p>
                </div>
                <ul class="patient-hp-appointment-list">
                    <li>
                        <div class="patient-hp-appointment-list-wrap step-border border-radius">
                            <div class="patient-hp-appointment-list-left">
                                <div class="patient-hp-appointment-datetime">
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/complete-appointment-icon.svg"
                                        alt="appointment icon">
                                    <div class="patient-hp-appointment-datetime-text">
                                        <div class="center-align">
                                        <p>09/03/2024, 09:00 AM AWST</p>
                                        <p class="patient-hp-appointment-complete-text">Completed</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="patient-hp-appointment-list-right">
                                <div class="patient-hp-appointment-doctor-type">
                                    <div class="patient-hp-appointment-doctor-profile">
                                        <div class="patient-hp-appointment-doctor-profile-img">
                                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctordummy-img.png"
                                                alt="doctor photo">
                                        </div>
                                        <div class="patient-hp-appointment-doctor-profile-info">
                                            <h6>Orelia Espada</h6>
                                            <p>Cardiologist</p>
                                        </div>
                                    </div>
                                    <div class="patient-hp-appointment-doctor-consultation-type">
                                        <p class="patient-hp-appointment-small-para-style">Consultation type</p>
                                        <p class="patient-hp-appointment-large-para-style">Online (Consult Now)</p>

                                    </div>
                                    <div class="patient-hp-appointment-cancel-reason">
                                        <p class="patient-hp-appointment-small-para-style">Reason of Appointment</p>
                                        <p class="patient-hp-appointment-large-para-style">Medical certificate</p>
                                    </div>
                                </div>
                                <div class="patient-hp-appointment-list-buttons">
                                    <button type="button" class="patient-hp-appointment-outline-button outline-button consultation-details-modal-trigger">View details</button>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="patient-hp-appointment-list-wrap step-border border-radius">
                            <div class="patient-hp-appointment-list-left">
                                <div class="patient-hp-appointment-datetime">
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/complete-appointment-icon.svg"
                                        alt="appointment icon">
                                    <div class="patient-hp-appointment-datetime-text">
                                        <div class="center-align">
                                        <p>09/03/2024, 09:00 AM AWST</p>
                                        <p class="patient-hp-appointment-complete-text">Completed</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="patient-hp-appointment-list-right">
                                <div class="patient-hp-appointment-doctor-type">
                                    <div class="patient-hp-appointment-doctor-profile">
                                        <div class="patient-hp-appointment-doctor-profile-img">
                                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctordummy-img.png"
                                                alt="doctor photo">
                                        </div>
                                        <div class="patient-hp-appointment-doctor-profile-info">
                                            <h6>Orelia Espada</h6>
                                            <p>Cardiologist</p>
                                        </div>
                                    </div>
                                    <div class="patient-hp-appointment-doctor-consultation-type">
                                        <p class="patient-hp-appointment-small-para-style">Consultation type</p>
                                        <p class="patient-hp-appointment-large-para-style">Online (Consult Now)</p>
                                    </div>
                                    <div class="patient-hp-appointment-cancel-reason">
                                        <p class="patient-hp-appointment-small-para-style">Reason of Appointment</p>
                                        <p class="patient-hp-appointment-large-para-style">Medical certificate</p>
                                    </div>
                                </div>
                                <div class="patient-hp-appointment-list-buttons">
                                    <button type="button" class="patient-hp-appointment-outline-button outline-button consultation-details-modal-trigger">View details</button>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>                
            </div>
        </div>
    </div>
</section>

<!-- Consultation details modal-->
<div class="modal consultation-details-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Consultation details</h5>
            <span class="closecurrentpopup">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round"></path>
                </svg>
            </span>
        </div>
        <div class="modal-body">
            <div class="consultation-details-top-wrap">
                <div class="consult-now-round-icon-wrap">
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/medical-certification-icon.svg" alt="Medical Certificate">
                </div>
                <p class="consultation-service-text">Medical Certificate</p>
                <div class="consultation-status-date-wrap">
                    <label class="complete-consultation-text">Completed</label>
                    <div class="consultation-status-round-dot"></div>
                     <p>2 Dec at 18:00</p>   
                </div>
            </div>
            <div class="consultation-price-details">
                <div class="consult-payment-summary-flex">
                    <p class="strong-para">Sub total</p>
                    <p class="strong-para">$200</p>
                </div>
                <div class="consult-payment-summary-flex">
                    <p>Online video consultation - Medical certificate</p>
                    <p>$100</p>
                </div>
                <div class="consult-payment-summary-flex">
                    <p>Internet handling fee<span>(Non-refundable processing fees)</span></p>
                    <p>$10</p>
                </div>
                <div class="consultation-price-total">
                    <p class="strong-para">Total amount</p>
                    <p class="strong-para">$110</p>
                </div>
            </div>
            <div class="consultation-documents-wrap">
                <p class="strong-para">Documents</p>
                <ul class="consultation-documents-lists">
                    <li>
                        <div class="consultation-documents-list-wrap">
                            <div class="consultation-documents-list-left">
                                <span>1</span>
                                <p>Imaging request</p>
                            </div>
                            <div class="consultation-documents-list-right">
                                <a href="#"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M3.33464 13.5352C2.32965 12.8625 1.66797 11.7168 1.66797 10.4167C1.66797 8.46369 3.16089 6.85941 5.06775 6.68281C5.45781 4.31011 7.51817 2.5 10.0013 2.5C12.4844 2.5 14.5448 4.31011 14.9349 6.68281C16.8417 6.85941 18.3346 8.46369 18.3346 10.4167C18.3346 11.7168 17.673 12.8625 16.668 13.5352M6.66797 14.1667L10.0013 17.5M10.0013 17.5L13.3346 14.1667M10.0013 17.5V10" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>Download</a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="consultation-documents-list-wrap">
                            <div class="consultation-documents-list-left">
                                <span>2</span>
                                <p>Medical certificate</p>
                            </div>
                            <div class="consultation-documents-list-right">
                                <a href="#"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M3.33464 13.5352C2.32965 12.8625 1.66797 11.7168 1.66797 10.4167C1.66797 8.46369 3.16089 6.85941 5.06775 6.68281C5.45781 4.31011 7.51817 2.5 10.0013 2.5C12.4844 2.5 14.5448 4.31011 14.9349 6.68281C16.8417 6.85941 18.3346 8.46369 18.3346 10.4167C18.3346 11.7168 17.673 12.8625 16.668 13.5352M6.66797 14.1667L10.0013 17.5M10.0013 17.5L13.3346 14.1667M10.0013 17.5V10" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>Download</a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="consultation-documents-list-wrap">
                            <div class="consultation-documents-list-left">
                                <span>3</span>
                                <p>Pathology request</p>
                            </div>
                            <div class="consultation-documents-list-right">
                                <a href="#"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M3.33464 13.5352C2.32965 12.8625 1.66797 11.7168 1.66797 10.4167C1.66797 8.46369 3.16089 6.85941 5.06775 6.68281C5.45781 4.31011 7.51817 2.5 10.0013 2.5C12.4844 2.5 14.5448 4.31011 14.9349 6.68281C16.8417 6.85941 18.3346 8.46369 18.3346 10.4167C18.3346 11.7168 17.673 12.8625 16.668 13.5352M6.66797 14.1667L10.0013 17.5M10.0013 17.5L13.3346 14.1667M10.0013 17.5V10" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>Download</a>
                            </div>
                        </div>
                    </li>
                </ul>   
            </div>
            <div class="consultation-details-cta-full-wrap">
                <a href="#" class="outline-button full-width-button"><svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M3.83464 13.5352C2.82965 12.8625 2.16797 11.7168 2.16797 10.4167C2.16797 8.46369 3.66089 6.85941 5.56775 6.68281C5.95781 4.31011 8.01817 2.5 10.5013 2.5C12.9844 2.5 15.0448 4.31011 15.4349 6.68281C17.3417 6.85941 18.8346 8.46369 18.8346 10.4167C18.8346 11.7168 18.173 12.8625 17.168 13.5352M7.16797 14.1667L10.5013 17.5M10.5013 17.5L13.8346 14.1667M10.5013 17.5V10" stroke="#344054" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>Invoice</a>
            </div>
            <div class="consultation-details-cta-wrap">
                <a href="#" class="outline-button"><svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8.0763 7.49984C8.27222 6.94289 8.65893 6.47326 9.16793 6.17411C9.67693 5.87497 10.2754 5.76562 10.8573 5.86543C11.4392 5.96524 11.967 6.26777 12.3472 6.71944C12.7274 7.17111 12.9355 7.74277 12.9346 8.33317C12.9346 9.99984 10.4346 10.8332 10.4346 10.8332M10.5013 14.1665H10.5096M18.8346 9.99984C18.8346 14.6022 15.1037 18.3332 10.5013 18.3332C5.89893 18.3332 2.16797 14.6022 2.16797 9.99984C2.16797 5.39746 5.89893 1.6665 10.5013 1.6665C15.1037 1.6665 18.8346 5.39746 18.8346 9.99984Z" stroke="#344054" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>Help - Contact Health Provider</a>
                <a href="#" class="outline-button">
                <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8.0763 7.49984C8.27222 6.94289 8.65893 6.47326 9.16793 6.17411C9.67693 5.87497 10.2754 5.76562 10.8573 5.86543C11.4392 5.96524 11.967 6.26777 12.3472 6.71944C12.7274 7.17111 12.9355 7.74277 12.9346 8.33317C12.9346 9.99984 10.4346 10.8332 10.4346 10.8332M10.5013 14.1665H10.5096M18.8346 9.99984C18.8346 14.6022 15.1037 18.3332 10.5013 18.3332C5.89893 18.3332 2.16797 14.6022 2.16797 9.99984C2.16797 5.39746 5.89893 1.6665 10.5013 1.6665C15.1037 1.6665 18.8346 5.39746 18.8346 9.99984Z" stroke="#344054" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    Help - Contact Medcallz Admin
                </a>
            </div>
        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">               
                <button type="button" class="closecurrentpopup unfilled-button">Close</button>
            </div>
        </div>   
    </div>    
</div>
<script>
    function customAlerts(selector, action = "open", contentData = '') {
        if (contentData) {
            $(".alert_content").html(contentData);
        }
        if (action == "open") {
            $(selector).addClass('show-modal');
            $("body").addClass('modal-open');
        } else {
            $(selector).removeClass('show-modal');
            $("body").removeClass('modal-open');
        }
    }
    $(".consultation-details-modal-trigger").click(function() {
        customAlerts(".consultation-details-modal", "open");
    });
    $(document).on("click", ".closecurrentpopup", function() {
        $(this).parents('.modal').removeClass('show-modal');
        $("body").removeClass('modal-open');
    });
</script>
<script>
    $(document).ready(function() {
	$(window).scroll(function () {
	    var scroll = $(window).scrollTop();
	    if (scroll >= 100) {
	    	$(".patient-appointment-filters-div").addClass("sticky-filter");
	    } else {
	    	$(".patient-appointment-filters-div").removeClass("sticky-filter");
	    }
    });
});
</script>