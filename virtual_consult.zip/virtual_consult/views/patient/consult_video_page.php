<link href="<?php echo base_url('assets/css/virtual_consult/style.css?v='.rand()); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url('assets/css/v3/commonstyle.css?v='.rand()); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url('assets/css/v2/style_common.css?v='.rand()); ?>" rel="stylesheet" type="text/css"/>
<input type="hidden" name="user_id_logged_d" id="logged_user_id_d" value="<?php echo $username; ?>">
<a class="j-user" data-id="<?php echo !empty($hp_info) ? $hp_info['video_id'] : ''; ?>" data-name="<?php echo !empty($hp_info) ? $hp_info['video_name'] : ''; ?>" data-login="<?php echo !empty($hp_info) ? $hp_info['video_username'] : ''; ?>" style="display:none"></a>
<div class="doctor video-call-section full-page" style="display:none">
    <div class="video-cont">
        <div class="video-cols row">
            <div class="videocall_container leftSidebar col-md-8 col-sm-8">
                <div class="wrapper j-wrapper">
                    <main class="app" id="app">
                        <div class="page">
                            <form class="hidden-form join j-join">
                                <div class="join__body">
                                    <div class="join__row">
                                        <input type="text" class="join__input j-join__username" name="username" value="<?php echo trim($patientname); ?>" readonly autocomplete="false">
                                        <input type="text" class="join__input j-join__login" name="login" value="<?php echo trim($username); ?>" readonly autocomplete="false">
                                        <input type="text" class="join__input j-join__emailaddress" name="emailaddress" value="<?php echo trim($emailaddress); ?>" readonly autocomplete="false">
                                    </div>
                                    <div class="join__row">
                                        <button type="submit" class="join__btn">
                                            <?php echo $this->lang->line('vmr_login_txt_btn'); ?>
                                        </button>
                                    </div>
                                </div>
                            </form>
                            <div class="dashboard j-dashboard"></div>
                        </div>
                    </main>
                </div>
            </div>
            <div class="chatting_container rytSidebar-wrap col-md-4 col-sm-4 fullheight">
                <div class="rytSidebar videoChatBar">
                    <div class="chat-title-bar">
                        <div class="chatdatesec-sl">
                            <span class="labe_duration"><?php echo $this->lang->line('date'); ?>:</span><?php echo ' '.date('d-m-Y'); ?>
                        </div>
                    </div>
                    <div class="chat-back-bar">
                        <div class="chatbackTitle">
                            <?php echo $this->lang->line('vmr_chat_back_title'); ?>
                        </div>
                    </div>
                    <div class="videoDoctorChatHead">
                        <div class="vdchat-doctor-img">
                            <div class="onlineUser"></div>
                            <div class="offlineUser"></div>
                            <img class="reciverImg_n" src="<?php echo !empty($hp_info['avatar']) ? $hp_info['avatar'] : base_url('assets/images/hp_images/doctor.png');?>" alt="Health Provider" title="Health Provider" onerror="this.onerror=null;this.src='<?php echo base_url('assets/images/hp_images/doctor.png'); ?>';">
                        </div>
                        <div class="vdchat-doctor-dis">
                            <h3 class="receiver_hp_name" style="margin-bottom:0">
                                <?php echo !empty($hp_info) ? $hp_info['full_hp_name'] : $this->lang->line('vmr_health_provider_h3'); ?>
                            </h3>
                        </div>
                    </div>
                    <div id="messageList" class="main docter-chat-group-sec fullheight"></div>
                    <div class="main-input-box bottom_fix_kb">
                        <form class="messageBox_form" action="" method="post">
                            <input type="hidden" id="edit_chat_id" value="" name="edit_chat_id" />
                            <input type="hidden" name="fromuser" id="fromuser" value=""/>
                            <input type="hidden" name="touser" id="touser" value="<?php echo $username; ?>"/> <!-- Logged -->
                            <input type="hidden" name="referId" id="referId" value="1" />
                            <div class="messagebox-position">
                                <textarea id="messageBox" class="form-control send-message focusable" rows="1" placeholder="<?php echo $this->lang->line('type_your_msg'); ?>" data-typed="<?php echo $this->tank_auth->ci->session->userdata['username']; ?>"></textarea>
                                <div class="send-message">
                                    <span>
                                        <a id="btnSendMessage" class="btnSendMessage" role="button">
                                            <i class="mdi mdi-send"></i>
                                        </a>
                                    </span>
                                </div>
                            </div>
                            <div class="dropdown sendDropWrap">
                                <button class="sendDropIcon dropdown-toggle" type="button" id="attachment-box" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="mdi mdi-dots-vertical"></i>
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="attachment-box">
                                    <li class="mbt-0">
                                        <a id="btnSendFiletoUser" class="btnimguploader" role="button">
                                            <i class="mdi mdi-attachment"></i>
                                            <span class="sendDropLabel">
                                                <?php echo $this->lang->line('vmr_add_file_span'); ?>
                                            </span>
                                        </a>
                                    </li>
                                    <li style="display:none;">
                                        <a  class="btnimguploader alert_chat_not" role="button">
                                            <i class="mdi mdi-bell"></i>
                                            <span class="sendDropLabel"><?php echo $this->lang->line('sms_ema_al'); ?></span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </form>
                        <form name="photo" id="imageUploadForm" enctype="multipart/form-data" method="post" style="display:none;">
                            <input type="hidden" name="fromuserimg" id="fromuserimg" />
                            <input type="hidden" name="touserimg" id="touserimg" />
                            <input type="file" name="img" id="uploadFiles">
                            <input type="submit" id="imageSubmitBtn" value="Upload" />
                        </form>
                    </div>
                </div>
                <div class="users-container"></div>
                <div class="chat-menu">
                    <input type="hidden" id="ap-id" value="<?php echo $enc_appit; ?>" title="Optional but Recommended!">
                    <input type="hidden" id="ap-id-decoded" value="<?php echo $appId; ?>" title="Recommended!">
                    <input type="hidden" id="call-type" value="<?php echo $callType; ?>" title="Recommended!">
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal show consult-waiting-room-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Waiting room</h5>
            <span class="closecurrentpopup">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round"></path>
                </svg>
            </span>
        </div>
        <div class="modal-body">
            <div class="consult-waiting-room-modal-wrap">
                <div class="consult-waiting-icon">
                   <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path class="consult-waiting-icon-path" d="M9 18.5H15M6.6 2H17.4C17.9601 2 18.2401 2 18.454 2.10899C18.6422 2.20487 18.7951 2.35785 18.891 2.54601C19 2.75992 19 3.03995 19 3.6V5.67452C19 6.1637 19 6.40829 18.9447 6.63846C18.8957 6.84254 18.8149 7.03763 18.7053 7.21657C18.5816 7.4184 18.4086 7.59135 18.0627 7.93726L15.1314 10.8686C14.7354 11.2646 14.5373 11.4627 14.4632 11.691C14.3979 11.8918 14.3979 12.1082 14.4632 12.309C14.5373 12.5373 14.7354 12.7354 15.1314 13.1314L18.0627 16.0627C18.4086 16.4086 18.5816 16.5816 18.7053 16.7834C18.8149 16.9624 18.8957 17.1575 18.9447 17.3615C19 17.5917 19 17.8363 19 18.3255V20.4C19 20.9601 19 21.2401 18.891 21.454C18.7951 21.6422 18.6422 21.7951 18.454 21.891C18.2401 22 17.9601 22 17.4 22H6.6C6.03995 22 5.75992 22 5.54601 21.891C5.35785 21.7951 5.20487 21.6422 5.10899 21.454C5 21.2401 5 20.9601 5 20.4V18.3255C5 17.8363 5 17.5917 5.05526 17.3615C5.10425 17.1575 5.18506 16.9624 5.29472 16.7834C5.4184 16.5816 5.59135 16.4086 5.93726 16.0627L8.86863 13.1314C9.26465 12.7354 9.46265 12.5373 9.53684 12.309C9.6021 12.1082 9.6021 11.8918 9.53684 11.691C9.46266 11.4627 9.26464 11.2646 8.86863 10.8686L5.93726 7.93726C5.59136 7.59136 5.4184 7.4184 5.29472 7.21657C5.18506 7.03763 5.10425 6.84254 5.05526 6.63846C5 6.40829 5 6.1637 5 5.67452V3.6C5 3.03995 5 2.75992 5.10899 2.54601C5.20487 2.35785 5.35785 2.20487 5.54601 2.10899C5.75992 2 6.03995 2 6.6 2Z" stroke="#667085" stroke-width="2"  stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </div>
                <p>Please wait while we connect you with a healthcare provider...</p>
                <div class="consult-expected-waiting-time">Expected waiting time: 5min</div>
            </div>
        </div>
    </div>
</div>
<div class="modal show consult-complete-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Consultation details</h5>
            <a class="closecurrentpopup" href="<?php echo !empty($service_id_enc) ? base_url('virtual_consult/patient/consult_doctors_list/'.$service_id_enc) : base_url('virtual_consult/patient/consult_now'); ?>">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
            </a>
        </div>
        <div class="modal-body">
            <div class="consult-complete-modal-wrap text-center">
                <div class="service-round-icon-wrap" style="margin:0 auto 15px auto">
                    <img src="<?php echo $service_info->icon ?? ''; ?>">
                </div>
                <h3 class="fw-500"><?php echo $service_info->name ?? ''; ?></h3>
                <div class="my-3">
                    <span class="completed-badge">Completed</span>
                    <span class="fw-500" style="color:#98A2B3">•</span>
                    <span class="fw-400" style="color:#667085"><?php echo date('j M'); ?> at <?php echo date('H:i'); ?></span>
                </div>
            </div>
            <div class="row color-082237 mb-2">
                <div class="col-md-9 fw-500">Sub total</div>
                <div class="col-md-3 text-right fw-500">$<?php echo round($payment_info->payment_payload->service_price,2); ?></div>
            </div>
            <div class="row color-475467 mb-2">
                <div class="col-md-9">Online video consultation - <?php echo $service_info->name ?? ''; ?></div>
                <div class="col-md-3 text-right">$<?php echo round($payment_info->payment_payload->service_price,2); ?></div>
            </div>
            <div class="row color-475467 mb-2">
                <div class="col-md-9">
                    <p class="mb-0">Internet handling fee</p>
                    <p class="mb-0 color-667085">(Non-refundable processing fees)</p>
                </div>
                <div class="col-md-3 text-right">$<?php echo round($payment_info->payment_payload->total_charges - $payment_info->payment_payload->service_price,2); ?></div>
            </div>
            <div class="total-amount">
                <div class="row color-082237">
                    <div class="col-md-9 fw-500">Total amount</div>
                    <div class="col-md-3 text-right fw-500">$<?php echo round($payment_info->amount,2); ?></div>
                </div>
            </div>
            <div class="documents">
                <div class="color-082237 mb-4">Documents</div>
                <?php for($i=0;$i < 3;$i++){ ?>
                    <div class="document-line">
                        <div>
                            <div class="document-number"><?php echo $i + 1; ?></div>
                            <div class="document-name"><?php echo ['Medical certificate','Imaging request','Pathology request'][$i]; ?></div>
                        </div>
                        <button type="button" class="unfilled-button">
                            <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.83341 13.5352C2.82843 12.8625 2.16675 11.7168 2.16675 10.4167C2.16675 8.46369 3.65967 6.85941 5.56653 6.68281C5.95659 4.31011 8.01695 2.5 10.5001 2.5C12.9832 2.5 15.0436 4.31011 15.4336 6.68281C17.3405 6.85941 18.8334 8.46369 18.8334 10.4167C18.8334 11.7168 18.1717 12.8625 17.1667 13.5352M7.16675 14.1667L10.5001 17.5M10.5001 17.5L13.8334 14.1667M10.5001 17.5V10" stroke="#344054" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" /></svg>
                            Download
                        </button>
                    </div>
                <?php } ?>
            </div>
            <div class="row mb-2">
                <div class="col-md-6">
                    <a class="outline-button download-invoice-button" style="width:100%" onclick="download_invoice(this)" data-payment-id="<?php echo $payment_id; ?>">
                        <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.83341 13.5352C2.82843 12.8625 2.16675 11.7168 2.16675 10.4167C2.16675 8.46369 3.65967 6.85941 5.56653 6.68281C5.95659 4.31011 8.01695 2.5 10.5001 2.5C12.9832 2.5 15.0436 4.31011 15.4336 6.68281C17.3405 6.85941 18.8334 8.46369 18.8334 10.4167C18.8334 11.7168 18.1717 12.8625 17.1667 13.5352M7.16675 14.1667L10.5001 17.5M10.5001 17.5L13.8334 14.1667M10.5001 17.5V10" stroke="#344054" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" /></svg>
                        Invoice
                    </a>
                </div>
                <div class="col-md-6">
                    <a class="outline-button download-invoice-button" style="width:100%">
                        <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8.0763 7.49984C8.27222 6.94289 8.65893 6.47326 9.16793 6.17411C9.67693 5.87497 10.2754 5.76562 10.8573 5.86543C11.4392 5.96524 11.967 6.26777 12.3472 6.71944C12.7274 7.17111 12.9355 7.74277 12.9346 8.33317C12.9346 9.99984 10.4346 10.8332 10.4346 10.8332M10.5013 14.1665H10.5096M18.8346 9.99984C18.8346 14.6022 15.1037 18.3332 10.5013 18.3332C5.89893 18.3332 2.16797 14.6022 2.16797 9.99984C2.16797 5.39746 5.89893 1.6665 10.5013 1.6665C15.1037 1.6665 18.8346 5.39746 18.8346 9.99984Z" stroke="#344054" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        Get help
                    </a>
                </div>
            </div>
        </div>
        <div class="modal-foot" style="padding:15px;border-top:1px solid #EAECF0">
            <a class="unfilled-button" href="<?php echo !empty($service_id_enc) ? base_url('virtual_consult/patient/consult_doctors_list/'.$service_id_enc) : base_url('virtual_consult/patient/consult_now'); ?>">Close</a>
        </div>
    </div>
</div>
<script>
    function customAlerts(selector, action = "open", contentData = '') {
        if (contentData) {
            $(".alert_content").html(contentData);
        }
        if (action == "open") {
            $(selector).addClass('show-modal');
            $("body").addClass('modal-open');
        } else {
            $(selector).removeClass('show-modal');
            $("body").removeClass('modal-open');
        }
    }
    $(".consult-payment-success-modal-trigger").click(function() {
        customAlerts(".consult-payment-success-modal", "open");
        customAlerts(".consult-payment-summary-modal", "close");
    });
</script>
<?php $this->load->view('inc/script_keyword_vmr'); ?>
<?php $this->load->view('inc/footer_vmr'); ?>
<footer></footer>
<script type="text/template" id="tpl_default">
    Logged in as <b><%= name %></b>
    <button class='fw-link j-logout'>Logout</button>
</script>
<script type="text/template" id="tpl_during_call">
    Login in as <b><%= name %></b>
</script>
<script type="text/template" id="tpl_device_not_found">
    Error: devices (camera or microphone) are not found.
    <span class="qb-text">Login in <b>as <%=name%></b></span>
    <button class='fw-link j-logout'>Logout</button>
</script>
<script type="text/template" id="tpl_call_status">
    <% if(typeof(users.accepted) !== 'undefined') { %>
    <%  _.each(users.accepted, function(el, i, list) { %>
    <% if(list.length === 1){ %>
    <b><%= el.full_name %></b> has accepted the call.
    <% } else { %>
    <% if( (i+1) === list.length) { %>
    <b><%= el.full_name %></b> have accepted the call.
    <% } else { %>
    <b><%= el.full_name %></b>,
    <% } %>
    <% } %>
    <% }); %>
    <% } %>
    <% if(typeof(users.rejected) !== 'undefined') { %>
    <%  _.each(users.rejected, function(el, i, list) { %>
    <% if(list.length === 1){ %>
    <b><%= el.full_name %></b> has rejecterd the call.
    <% } else { %>
    <% if( (i+1) === list.length) { %>
    <b><%= el.full_name %></b> have rejecterd the call.
    <% } else { %>
    <b><%= el.full_name %></b>,
    <% } %>
    <% } %>
    <% }); %>
    <% } %>
</script>
<script type="text/template" id="tpl_call_stop">
    Call is stopped.&emsp;
    Login&nbsp;in&nbsp;as&nbsp;<%=name%>
    <button class='fw-link j-logout'>Logout</button>
</script>
<script type="text/template" id="p2p_call_stop">
    <b><%=name%> has <%=reason%>.</b> Call is stopped.&emsp;
    Login&nbsp;in&nbsp;as&nbsp;<%=currentName%>
    <button class='fw-link j-logout'>Logout</button>
</script>
<script type="text/template" id="dashboard_tpl">
    <div class="state_board j-state_board"></div>
    <div class="dashboard__inner inner">
        <div style="display: none;" class="users j-users_wrap"></div>
        <div class="board clearfix j-board"></div>
    </div>
</script>
<script type="text/template" id="frames_tpl">
    <div class="frames">
        <div class="frames__main" id="">
            <div class="timeDocVidWrap">
                <div class="timeDocVidInnerWrap">
                    <div class="vidUserNameCol " id="">
                        <div class="vidUserProfImg" >
                            <img class="reciverImg_n" src="<?php echo base_url();?>assets/images/v2/our-team-04.jpg" alt="Profile Picture" >
                        </div>
                        <div class="vidUserProfName"></div>
                    </div>
                    <div class="frames__main_timer " id="timer"></div>
                </div>
            </div>

            <div class="qb-video" id="qb-video">
                <video id="main_video" class="frames__main_v qb-video_source" autoplay playsinline></video>
            </div>
        </div>

        <div  style="display:none;" class="frames__callees j-callees"></div>
    </div>

    <div class="caller">

        <h4 class="caller__name" style="display:none;">
            <b>You</b>
            <span class="j-caller_name">(<%= nameUser %>)</span>
        </h4>

        <div class="caller__frames_video" id="videoParentWrapper">
            <div class="qb-video" id="draggableVideoFrame">
                <video id="localVideo" class="qb-video_source" autoplay playsinline></video>
            </div>
        </div>
        <div class="caller__frames">
            <div class="caller__frames_acts caller_frames_custom chat-action-btns">
                     <div class="icon_tray_s_left icon_tray_main">
                    <button class="section_ara caller__frames_acts_btn j-caller__ctrl j-caller__ctrl_main audiomic" data-target="audio">
                       <span class="icon_span">
                            <span class="nt_act_block"><img class="" src="<?php echo base_url();?>assets/images/v2/microphone-on.svg" alt="Mute" title="Mute" /><p>Mute</p></span>
                            <span class="act_block"><img class="deskAudIcon" src="<?php echo base_url();?>assets/images/v2/microphone-off.svg" alt="Unmute" title="Unmute"><img class="mbAudIcon" src="<?php echo base_url();?>assets/images/v2/microphone-off.svg" alt="Unmute" title="Unmute"><p>Unmute</p></span>
                        </span>
                    </button>
                    <button class="section_ara caller__frames_acts_btn j-caller__ctrl j-caller__ctrl_main" data-target="video">
                         <span class="icon_span">
                            <span class=" nt_act_block"><img class="" src="<?php echo base_url();?>assets/images/v2/video-recorder-on.svg" alt="Start Video" title="Start Video" /><p>Stop Video</p></span>
                            <span class=" act_block"><img class="deskVideorecIcon" src="<?php echo base_url();?>assets/images/v2/video-recorder-off.svg" alt="Stop Video" title="Stop Video" /><img class="mbVideorecIcon" src="<?php echo base_url();?>assets/images/v2/video-recorder-off.svg" alt="Stop Video" title="Stop Video" /><p>Start Video</p></span>
                        </span>
                    </button>

                    <% if(navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) { %>
                        <button class="section_ara caller__frames_acts_btn j-caller__ctrl screen_sharing_b deskScreenIcon" data-target="screen">
                            <span class="icon_span">
                                <img class="" src="<?php echo base_url();?>assets/images/v2/laptopIcon-video.svg" alt="Screen" title="Screen" />
                            </span>
                        </button>
                    <% } %>



                        <button class="section_ara caller__frames_acts_btn j-caller__ctrl j-caller__ctrl_main camra_flip mbCamIcon ">
                            <span class="icon_span">
                                <span class="nt_act_block"><img class="" src="<?php echo base_url();?>assets/images/v2/camera-rotate.svg" alt="Camera Rotate" title="Camera Rotate" /></span>
                                <span class=" act_block"><img class="" src="<?php echo base_url();?>assets/images/v2/camera-rotate.svg" alt="Camera Rotate" title="Camera Rotate" /></span>
                            </span>
                        </button>

                    <button class="caller__frames_acts_btn_record j-record" alt="record video" style="display:none">
                    </button>

                    <div class="section_ara action_full_screen">
                        <a href="javascript:void(0)"  class="vscreen v_sl_screen" onclick="FullScreenHelper.request(document.getElementById('qb-video'));" alt="Full Screen" title="Full Screen"> <span class="icon_span"><i class=""><img class="" src="<?php echo base_url();?>assets/images/v2/fullscreen-icon.svg" alt="Full Screen" title="Full Screen" /><p>Full Screen</p></i></span></a>

                        <a href="javascript:void(0)"  class="vscreen_full" style="display: none;" alt="Full Screen" title="Full Screen"> <span class="icon_span"><i class="mdi mdi-fullscreen-exit"><p>Exit Full Screen</p></i></span></a>
                    </div>
                    <button class="section_ara caller__frames_acts_btn j-caller__ctrl j-caller__ctrl_main chatIconMob" data-target="chat">
                         <span class="icon_span">
                            <span class=" nt_act_block"><img class="" src="<?php echo base_url();?>assets/images/v2/message-text-circle.svg" alt="Chat Start" title="Chat Start" /><p>Stop Video</p></span>
                        </span>
                    </button>
                </div>
                <div class="icon_tray_s_right icon_tray_main">
                    <div class="caller__ctrl">
                        <button class="m-video-box caller__ctrl_btn j-actions m-video_call" data-call="video">
                            <span class="icon_span">
                                <p>
                                    <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M17.9998 2.5L12.9998 7.5M12.9998 2.5L17.9998 7.5M9.02228 11.5526C8.02097 10.5512 7.23031 9.41904 6.65031 8.21102C6.60042 8.10712 6.57548 8.05516 6.55631 7.98942C6.48821 7.75579 6.53713 7.46891 6.67881 7.27105C6.71867 7.21537 6.7663 7.16774 6.86156 7.07248C7.1529 6.78115 7.29857 6.63548 7.39381 6.48899C7.75297 5.93659 7.75297 5.22443 7.39381 4.67203C7.29857 4.52554 7.1529 4.37988 6.86156 4.08854L6.69917 3.92615C6.2563 3.48328 6.03487 3.26184 5.79705 3.14156C5.32408 2.90233 4.76553 2.90233 4.29256 3.14156C4.05474 3.26184 3.83331 3.48328 3.39044 3.92615L3.25908 4.05751C2.81773 4.49886 2.59705 4.71954 2.42851 5.01956C2.24149 5.35249 2.10703 5.86956 2.10816 6.25141C2.10918 6.59554 2.17594 6.83072 2.30944 7.30109C3.02692 9.82892 4.38065 12.2142 6.37063 14.2042C8.36061 16.1942 10.7459 17.5479 13.2737 18.2654C13.7441 18.3989 13.9793 18.4657 14.3234 18.4667C14.7053 18.4678 15.2224 18.3333 15.5553 18.1463C15.8553 17.9778 16.076 17.7571 16.5173 17.3158L16.6487 17.1844C17.0916 16.7415 17.313 16.5201 17.4333 16.2823C17.6725 15.8093 17.6725 15.2508 17.4333 14.7778C17.313 14.54 17.0916 14.3185 16.6487 13.8757L16.4863 13.7133C16.195 13.4219 16.0493 13.2763 15.9028 13.181C15.3504 12.8219 14.6383 12.8219 14.0858 13.181C13.9394 13.2763 13.7937 13.4219 13.5024 13.7133C13.4071 13.8085 13.3595 13.8562 13.3038 13.896C13.1059 14.0377 12.819 14.0866 12.5854 14.0185C12.5197 13.9994 12.4677 13.9744 12.3638 13.9245C11.1558 13.3445 10.0236 12.5539 9.02228 11.5526Z" stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                    <?php echo $this->lang->line('vmr_end_call_btn'); ?>
                                </p>
                                <!-- <i class="mdi mdi-phone-hangup"></i> -->
                            </span> </button>
                            <button class="caller__ctrl_btn j-actions m-audio_call" data-call="audio" style="display:none;" ></button>

                    </div>
                </div>

            </div>

            <div class="caller__frames_fl" style="display:none;">
                <select class="qb-select j-filter">
                    <option value="no">No Filter</option>
                    <option value="_1977">1977</option>
                    <option value="inkwell">inkwell</option>
                    <option value="moon">moon</option>
                    <option value="nashville">nashville</option>
                    <option value="slumber">slumber</option>
                    <option value="toaster">toaster</option>
                    <option value="walden">walden</option>
                </select>
            </div>

            <div class="caller__frames_bandwidth" style="display:none;">
                <select class="qb-select j-bandwidth">
                    <option value="">Standart</option>
                    <option value="2048">2048 kbps</option>
                    <option value="1024">1024 kbps</option>
                    <option value="512">512 kbps</option>
                    <option value="256">256 kbps</option>
                    <option value="128">128 kbps</option>
                </select>
            </div>

             <div class="caller__frames_media_source j-media_sources invisible" style="display:none;">
                <h4 class="source_label j-video_source_label">Video track:</h4>
                <select class="qb-select j-video_source"></select>

                <h4 class="source_label j-audio_source_label">Audio track:</h4>
                <select class="qb-select j-audio_source"></select>

                <button class="caller__ctrl_btn confirm_media j-confirm_media">Confirm</button>
            </div>
        </div>
    </div>
    <script>
        const draggable = document.getElementById('draggableVideoFrame');
        const parent = document.getElementById('videoParentWrapper');
        let isDragging = false;

        draggable.addEventListener('touchstart', onTouchStart);
        draggable.addEventListener('touchmove', onTouchMove);
        draggable.addEventListener('touchend', onTouchEnd);

        function onTouchStart(e) {
            e.preventDefault();
            isDragging = true;
        }

        function onTouchMove(e) {
            e.preventDefault();
            if (isDragging) {
                const rect = parent.getBoundingClientRect();
                let left = e.touches[0].clientX - rect.left - draggable.offsetWidth / 2;
                let top = e.touches[0].clientY - rect.top - draggable.offsetHeight / 2;
                left = Math.max(0, Math.min(left, parent.offsetWidth - draggable.offsetWidth));
                top = Math.max(0, Math.min(top, parent.offsetHeight - draggable.offsetHeight));
                draggable.style.left = `${left}px`;
                draggable.style.top = `${top}px`;
            }
        }

        function onTouchEnd() {
            isDragging = false;
        }

        draggable.addEventListener('mousedown', (e) => {
            isDragging = true;
            document.addEventListener('mousemove', onMouseMove);
            document.addEventListener('mouseup', onMouseUp);
        });

        // draggable.addEventListener('touchstart', (e) => {
        //     isDragging = true;
        //     document.addEventListener('touchmove', onTouchMove);
        //     document.addEventListener('touchend', onTouchEnd);
        // });

        // function onTouchMove(e) {

        //     if (isDragging) {
        //         console.log("dragging");
        //         document.getElementById('videoParentWrapper').classList.add('callDragStart');
        //         const rect = parent.getBoundingClientRect();
        //         console.log("rect:"+rect.left+rect.top);

        //         console.log("draggable:"+draggable.offsetWidth+draggable.offsetHeight);

        //         console.log("Client:"+e.clientX+e.clientY);

        //         let left = e.clientX - rect.left - draggable.offsetWidth / 2;
        //         let top = e.clientY - rect.top - draggable.offsetHeight / 2;
        //         left = Math.max(0, Math.min(left, parent.offsetWidth - draggable.offsetWidth));
        //         top = Math.max(0, Math.min(top, parent.offsetHeight - draggable.offsetHeight));
        //         draggable.style.left = `${left}px`;
        //         draggable.style.top = `${top}px`;

        //         console.log(left+"pxLeft");
        //         console.log(top+"pxTop");
        //     }
        // }

        // function onTouchEnd() {
        //     isDragging = false;
        //     document.removeEventListener('touchmove', onTouchMove);
        //     document.removeEventListener('touchend', onTouchEnd);
        // }

        function onMouseMove(e) {
            if (isDragging) {
                document.getElementById('videoParentWrapper').classList.add('callDragStart');
                const rect = parent.getBoundingClientRect();
                let left = e.clientX - rect.left - draggable.offsetWidth / 2;
                let top = e.clientY - rect.top - draggable.offsetHeight / 2;
                left = Math.max(0, Math.min(left, parent.offsetWidth - draggable.offsetWidth));
                top = Math.max(0, Math.min(top, parent.offsetHeight - draggable.offsetHeight));
                draggable.style.left = `${left}px`;
                draggable.style.top = `${top}px`;
            }
        }

        function onMouseUp() {
            isDragging = false;
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        }
    </script>
</script>

<script type="text/template" id="users_tpl">
    <div style="padding-bottom: 10px;">
        <input id="search_by_username" type="text" class="join__input j-join__username" style="height:50px" name="username" placeholder="Username" autofocus="" required="">
    </div>
    <div class="users__title" title="Choose a user to call">
        Choose a user to call
        <button class="users__refresh j-users__refresh" title="click to refresh">
            <svg width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg"
                 xmlns:xlink="http://www.w3.org/1999/xlink">
                <g id="UI" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <g id="Main" transform="translate(-435.000000, -178.000000)">
                        <g id="ic_refresh" transform="translate(431.000000, 174.000000)">
                            <g id="Icon-24px" sketch:type="MSShapeGroup">
                                <path d="M0,0 L24,0 L24,24 L0,24 L0,0 Z" id="Shape"></path>
                                <path d="M17.65,6.35 C16.2,4.9 14.21,4 12,4 C7.58,4 4.01,7.58 4.01,12 C4.01,16.42 7.58,20 12,20 C15.73,20 18.84,17.45 19.73,14 L17.65,14 C16.83,16.33 14.61,18 12,18 C8.69,18 6,15.31 6,12 C6,8.69 8.69,6 12,6 C13.66,6 15.14,6.69 16.22,7.78 L13,11 L20,11 L20,4 L17.65,6.35 L17.65,6.35 Z"
                                      id="Shape" fill="#808080"></path>
                            </g>
                        </g>
                    </g>
                </g>
            </svg>
        </button>
    </div>
    <div class="users__list j-users">
    </div>
</script>
<script type="text/template" id="user_tpl">
    <div class="users__item">
        <button class="users__user j-user" data-id="<%= id %>" data-login="<%= login %>" data-name="<%= full_name %>">
            <i class="user__icon"></i>
            <span class="user__name"><%= full_name %></span>
            <i class="users__btn_remove j-user-remove"></i>
        </button>
    </div>
</script>
<script type="text/template" id="callee_video">
    <div class="frames_callee callees__callee j-callee">
        <div class="frames_callee__inner">
            <p class="frames_callee__status j-callee_status_<%=userID%>">
                <%=state%>
            </p>

            <div class="qb-video">
                <video class="j-callees__callee__video qb-video_source"
                       id="remote_video_<%=userID%>"
                       data-user="<%=userID%>" autoplay playsinline>
                </video>
            </div>
        </div>

        <p class="frames_callee__name"><%=name%></p>

        <div class="frames_callee__bitrate">
            <span id="bitrate_<%=userID%>">0</span> kbps
        </div>
    </div>
</script>
<?php
$userId = $this->session->userdata['user_id'];
$hpInfo =  $this->mc_constants->userheaderInfo($userId);
$getImage = $hpInfo['image'];
$hpFullName =  trim($hpInfo['full_hp_name']);
if (!empty($getImage)) {
    $imageLoggedHp = base_url()."assets/images/hp_images/".$getImage;
}else{
    $imageLoggedHp = base_url()."assets/images/hp_images/doctor.png";
}
?>
<button type="button" style="display:none;" id="reject-call-by-doc" class="" data-backdrop="static" data-keyboard="false" data-toggle="modal" data-target="#reject-call"></button>
<div class="modal fade" id="reject-call" role="dialog">
    <div class="modal-dialog">
    <div class="modal-content call-receive-view new-change  v2callRecView">
        <div class="modal-header">
           <h4 class="modal-title">Calling...</h4>
        </div>
        <div class="modal-body">
            <div class="doc-wrap ini ">
                <p class="right">
                    <img src="<?php echo $imageLoggedHp;?>" alt="<?php echo $hpFullName;?>" title="<?php echo $hpFullName;?>">
                </p>
                <span class="doctorname namev2"><?php echo $hpFullName;?></span>
            </div>
             <div class="call_image ">
                <img src="<?php echo base_url();?>assets/images/v2/loaderBig.svg">
            </div>
            <div class="patient-wrap ini ">
                <p class="left">
                   <img class="reciverImg_n" src="<?php echo base_url();?>assets/images/medcalls/user-log.png" alt="" title="">
                </p>
                <span class="Patient-name namev2 receiver_hp_name">Dr.</span>
            </div>
        </div>
        <div class="modal-footer ">
            <div class="calling-btns calCanBtn">
                <a href="javascript:void(0)" class="reject-call j-actions hangup">
                    <span>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g id="phone-x"><g id="Solid"><path fill-rule="evenodd" clip-rule="evenodd" d="M18.0893 3.08934C18.4147 2.7639 18.4147 2.23626 18.0893 1.91083C17.7638 1.58539 17.2362 1.58539 16.9107 1.91083L15 3.82157L13.0893 1.91083C12.7638 1.58539 12.2362 1.58539 11.9107 1.91083C11.5853 2.23626 11.5853 2.7639 11.9107 3.08934L13.8215 5.00008L11.9107 6.91083C11.5853 7.23626 11.5853 7.7639 11.9107 8.08934C12.2362 8.41477 12.7638 8.41477 13.0893 8.08934L15 6.17859L16.9107 8.08934C17.2362 8.41477 17.7638 8.41477 18.0893 8.08934C18.4147 7.7639 18.4147 7.23626 18.0893 6.91083L16.1785 5.00008L18.0893 3.08934Z" fill="white"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M5.2817 14.7935C3.25344 12.7653 1.77859 10.2395 0.994771 7.48179C0.871848 7.04928 0.776527 6.71389 0.775157 6.25398C0.773592 5.72833 0.944849 5.0698 1.20229 4.61151C1.64502 3.82337 2.59566 2.81333 3.41676 2.39801C4.12622 2.03918 4.96405 2.03918 5.6735 2.39801C6.36988 2.75024 7.16868 3.56558 7.59278 4.21787C8.13153 5.04648 8.13153 6.11471 7.59278 6.94332C7.44842 7.16536 7.24264 7.37079 7.00376 7.60927C6.92937 7.68353 6.8475 7.73718 6.90187 7.85042C7.44172 8.97482 8.17796 10.0295 9.11186 10.9634C10.0458 11.8973 11.1004 12.6335 12.2248 13.1734C12.3412 13.2293 12.3889 13.1487 12.466 13.0715C12.7045 12.8326 12.9099 12.6268 13.1319 12.4825C13.9605 11.9437 15.0288 11.9437 15.8574 12.4825C16.5097 12.9066 17.325 13.7054 17.6772 14.4017C18.0361 15.1112 18.0361 15.949 17.6772 16.6585C17.265 17.4734 16.2632 18.4238 15.4637 18.873C15.0055 19.1304 14.3469 19.3017 13.8213 19.3001C13.3614 19.2987 13.026 19.2034 12.5935 19.0805C9.83578 18.2967 7.30994 16.8218 5.2817 14.7935Z" fill="white"></path>
                            </g></g>
                        </svg>
                        Cancel
                    </span>
                </a>
            </div>
        </div>
    </div>
    </div>
</div>
<button type="button" style="display:none;" id="cll" class="" data-toggle="modal" data-backdrop="static" data-keyboard="false" data-target="#income_call"></button>
<div class="modal fade desktophpcall" id="income_call" role="dialog" tabindex="-1" data-backdrop="static" data-keyboard="false">
    <div style="display:none;" class="a-t"></div>
    <div class="modal-dialog">
        <div class="modal-content call-receive-view v2callRecView vrtmetvid">
            <div class="modal-header">
                <h4 class="modal-title"><?php echo $this->lang->line('vmr_incoming_call_h4'); ?></h4>
            </div>
            <div class="modal-body">
                <div class="v2incImg">
                    <img id="doctor_image" class="" src="<?php echo base_url(); ?>assets/images/hp_images/doctor.png" alt="Health Provider" title="Health Provider" />
                </div>
                <div class="v2incName">
                    <span id="doctor-name" class="j-ic_initiator"></span>  &nbsp;<div class="isCall"><?php echo $this->lang->line('vmr_is_calling'); ?> <i><img src="<?php echo base_url(); ?>assets/images/v2/load.svg"></i></div>
                </div>
            </div>
            <div class="modal-footer">
                <div class="calling-btns calCanBtn">
                    <a href="javascript:void(0);" id="vend-call" class="vend-call v2endCall j-decline">
                        <span><?php echo $this->lang->line('vmr_call_cancel_btn'); ?></span>
                    </a>
                    <a target="javascript:void(0);" class="enter-room vpick-call v2pickCall j-accept">
                        <span>
                            <img src="<?php echo base_url(); ?>assets/images/v2/phoneSolid.svg" alt="Accept" title="Accept" />
                            <?php echo $this->lang->line('vmr_call_accept_btn'); ?>
                        </span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>