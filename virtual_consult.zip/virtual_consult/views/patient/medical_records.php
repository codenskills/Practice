<section class="patient-appointments-sec">
    <div class="container">
        <div class="patient-appointment-header">
            <div class="patient-appointment-header-text">
                <h2 class="heading-main">Records</h2>
            </div>
        </div>
        <div class="patient-appointment-flex">
            <div class="patient-appointment-filters-div">
            <h6 class="filter-text">Filters</h6>               
                <div class="responsive-filter-bar">
                    <h6 class="filter-text-responsive"><svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M5 10H15M2.5 5H17.5M7.5 15H12.5" stroke="#101828" stroke-width="1.66667"
                                stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        Filters</h6>
                    <svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 1.5L6 6.5L11 1.5" stroke="#98A2B3" stroke-width="1.66667" stroke-linecap="round"
                            stroke-linejoin="round" />
                    </svg>
                </div>
                <div class="overlay-responsive"></div>
                <ul class="filter-list">               
                <div class="res-close-btn">
                        <button type="button" class="close-filter-list close-filter-btn"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M18 6L6 18M6 6L18 18" stroke="#344054" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg></button>
                    </div>
                    <h6 class="filter-text-responsive">Filters</h6>
                    <div class="patient-appointment-filters-search">
                        <input type="text" class="input-search-style" placeholder="Health provider name">
                    </div>
                   
                    <li class="active-drop">
                        <div class="drop-down-filters toggle-drop-btn show-filter-list">
                            <h5>Consultation type</h5>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg" alt="icon">
                        </div>
                        <div class="drop-filters-content">
                            <div class="drop-checkbox-wrap">
                                <form>
                                    <div class="form-group">
                                        <input type="checkbox" id="stsall">
                                        <label for="stsall">All appointments (7)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="stsacnf">
                                        <label for="stsacnf">Online (Consult now) (2)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="stsapst">
                                        <label for="stsapst">Online (2)</label>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </li>
                    <hr>
                    <li>
                        <div class="drop-down-filters toggle-drop-btn">
                            <h5>Specialities</h5>
                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/chevron-up.svg" alt="icon">
                        </div>
                        <div class="drop-filters-content">
                            <input type="text" placeholder="Search..." class="specialities-search">
                            <div class="drop-checkbox-wrap">
                                <form>
                                    <div class="form-group">
                                        <input type="checkbox" id="allspecialities">
                                        <label for="allspecialities">All specialities (20)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Cardiology">
                                        <label for="Cardiology">Cardiology (8)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Dermatology">
                                        <label for="Dermatology">Dermatology (15)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Gastroenterology">
                                        <label for="Gastroenterology">Gastroenterology (3)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Hematology">
                                        <label for="Hematology">Hematology (10)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Nephrology">
                                        <label for="Nephrology">Nephrology (5)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Neurology">
                                        <label for="Neurology">Neurology (12)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Oncology">
                                        <label for="Oncology">Oncology (18)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Pediatrics">
                                        <label for="Pediatrics">Oncology (18)</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="Pediatrics">
                                        <label for="Pediatrics">Pediatrics (2)</label>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </li>
                    <div class="res-filter-apply-btn-wrap">
                        <button type="button" class="res-apply-btn">Apply filters <span>(2)</span></button>
                    </div>
                </ul>
            </div>
            <div class="patient-appointment-list-div">
                <div class="result-text">
                    <p>3 results</p>
                </div>
                <ul class="patient-hp-appointment-list">
                    <li>
                        <div class="patient-hp-appointment-list-wrap step-border border-radius">
                            <div class="patient-hp-appointment-list-left">
                                <div class="patient-hp-appointment-datetime">
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/complete-appointment-icon.svg"
                                        alt="appointment icon">
                                    <div class="patient-hp-appointment-datetime-text">
                                        <div class="center-align">
                                        <p>09/03/2024, 09:00 AM AWST</p>
                                        <p class="patient-hp-appointment-complete-text">Completed</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="patient-hp-appointment-list-right">
                                <div class="patient-hp-appointment-doctor-type">
                                    <div class="patient-hp-appointment-doctor-profile">
                                        <div class="patient-hp-appointment-doctor-profile-img">
                                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctordummy-img.png"
                                                alt="doctor photo">
                                        </div>
                                        <div class="patient-hp-appointment-doctor-profile-info">
                                            <h6>Orelia Espada</h6>
                                            <p>Cardiologist</p>
                                        </div>
                                    </div>
                                    <div class="patient-hp-appointment-doctor-consultation-type">
                                        <p class="patient-hp-appointment-small-para-style">Consultation type</p>
                                        <p class="patient-hp-appointment-large-para-style">Online (Consult Now)</p>

                                    </div>
                                    <div class="patient-hp-appointment-cancel-reason">
                                        <p class="patient-hp-appointment-small-para-style">Reason of Appointment</p>
                                        <p class="patient-hp-appointment-large-para-style">Medical certificate</p>
                                    </div>
                                </div>
                                <div class="patient-hp-appointment-list-buttons">
                                    <button type="button" class="patient-hp-appointment-outline-button outline-button consultation-details-modal-trigger">View details</button>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="patient-hp-appointment-list-wrap step-border border-radius">
                            <div class="patient-hp-appointment-list-left">
                                <div class="patient-hp-appointment-datetime">
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/complete-appointment-icon.svg"
                                        alt="appointment icon">
                                    <div class="patient-hp-appointment-datetime-text">
                                        <div class="center-align">
                                        <p>09/03/2024, 09:00 AM AWST</p>
                                        <p class="patient-hp-appointment-complete-text">Completed</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="patient-hp-appointment-list-right">
                                <div class="patient-hp-appointment-doctor-type">
                                    <div class="patient-hp-appointment-doctor-profile">
                                        <div class="patient-hp-appointment-doctor-profile-img">
                                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctordummy-img.png"
                                                alt="doctor photo">
                                        </div>
                                        <div class="patient-hp-appointment-doctor-profile-info">
                                            <h6>Orelia Espada</h6>
                                            <p>Cardiologist</p>
                                        </div>
                                    </div>
                                    <div class="patient-hp-appointment-doctor-consultation-type">
                                        <p class="patient-hp-appointment-small-para-style">Consultation type</p>
                                        <p class="patient-hp-appointment-large-para-style">Online (Consult Now)</p>
                                    </div>
                                    <div class="patient-hp-appointment-cancel-reason">
                                        <p class="patient-hp-appointment-small-para-style">Reason of Appointment</p>
                                        <p class="patient-hp-appointment-large-para-style">Medical certificate</p>
                                    </div>
                                </div>
                                <div class="patient-hp-appointment-list-buttons">
                                    <button type="button" class="patient-hp-appointment-outline-button outline-button consultation-details-modal-trigger">View details</button>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="patient-hp-appointment-list-wrap step-border border-radius">
                            <div class="patient-hp-appointment-list-left">
                                <div class="patient-hp-appointment-datetime">
                                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/complete-appointment-icon.svg"
                                        alt="appointment icon">
                                    <div class="patient-hp-appointment-datetime-text">
                                        <div class="center-align">
                                        <p>09/03/2024, 09:00 AM AWST</p>
                                        <p class="patient-hp-appointment-complete-text">Completed</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="patient-hp-appointment-list-right">
                                <div class="patient-hp-appointment-doctor-type">
                                    <div class="patient-hp-appointment-doctor-profile">
                                        <div class="patient-hp-appointment-doctor-profile-img">
                                            <img src="<?php echo base_url(); ?>assets/images/virtual_consult/doctordummy-img.png"
                                                alt="doctor photo">
                                        </div>
                                        <div class="patient-hp-appointment-doctor-profile-info">
                                            <h6>Orelia Espada</h6>
                                            <p>Cardiologist</p>
                                        </div>
                                    </div>
                                    <div class="patient-hp-appointment-doctor-consultation-type">
                                        <p class="patient-hp-appointment-small-para-style">Consultation type</p>
                                        <p class="patient-hp-appointment-large-para-style">Online (Consult Now)</p>
                                    </div>
                                    <div class="patient-hp-appointment-cancel-reason">
                                        <p class="patient-hp-appointment-small-para-style">Reason of Appointment</p>
                                        <p class="patient-hp-appointment-large-para-style">Medical certificate</p>
                                    </div>
                                </div>
                                <div class="patient-hp-appointment-list-buttons">
                                    <button type="button" class="patient-hp-appointment-outline-button outline-button consultation-details-modal-trigger">View details</button>
                                </div>
                            </div>
                        </div>
                    </li>
                 
                </ul>                
            </div>
        </div>
    </div>
</section>

<!-- Consultation details modal-->
<div class="modal consultation-details-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="modal-heading">Consultation details</h5>
            <span class="closecurrentpopup">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round"></path>
                </svg>
            </span>
        </div>
        <div class="modal-body">
            <div class="consultation-details-top-wrap">
                <div class="consult-now-round-icon-wrap">
                    <img src="<?php echo base_url(); ?>assets/images/virtual_consult/medical-certification-icon.svg" alt="Medical Certificate">
                </div>
                <p class="consultation-service-text">Medical Certificate</p>
                <div class="consultation-status-date-wrap">
                    <label class="complete-consultation-text">Completed</label>
                    <div class="consultation-status-round-dot"></div>
                     <p>2 Dec at 18:00</p>   
                </div>
            </div>
            <div class="consultation-price-details">
                <div class="consult-payment-summary-flex">
                    <p class="strong-para">Sub total</p>
                    <p class="strong-para">$200</p>
                </div>
                <div class="consult-payment-summary-flex">
                    <p>Online video consultation - Medical certificate</p>
                    <p>$100</p>
                </div>
                <div class="consult-payment-summary-flex">
                    <p>Internet handling fee<span>(Non-refundable processing fees)</span></p>
                    <p>$10</p>
                </div>
                <div class="consultation-price-total">
                    <p class="strong-para">Total amount</p>
                    <p class="strong-para">$110</p>
                </div>
            </div>
            <div class="consultation-documents-wrap">
                <p class="strong-para">Documents</p>
                <ul class="consultation-documents-lists">
                    <li>
                        <div class="consultation-documents-list-wrap">
                            <div class="consultation-documents-list-left">
                                <span>1</span>
                                <p>Imaging request</p>
                            </div>
                            <div class="consultation-documents-list-right">
                                <a href="#"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M3.33464 13.5352C2.32965 12.8625 1.66797 11.7168 1.66797 10.4167C1.66797 8.46369 3.16089 6.85941 5.06775 6.68281C5.45781 4.31011 7.51817 2.5 10.0013 2.5C12.4844 2.5 14.5448 4.31011 14.9349 6.68281C16.8417 6.85941 18.3346 8.46369 18.3346 10.4167C18.3346 11.7168 17.673 12.8625 16.668 13.5352M6.66797 14.1667L10.0013 17.5M10.0013 17.5L13.3346 14.1667M10.0013 17.5V10" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>Download</a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="consultation-documents-list-wrap">
                            <div class="consultation-documents-list-left">
                                <span>2</span>
                                <p>Medical certificate</p>
                            </div>
                            <div class="consultation-documents-list-right">
                                <a href="#"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M3.33464 13.5352C2.32965 12.8625 1.66797 11.7168 1.66797 10.4167C1.66797 8.46369 3.16089 6.85941 5.06775 6.68281C5.45781 4.31011 7.51817 2.5 10.0013 2.5C12.4844 2.5 14.5448 4.31011 14.9349 6.68281C16.8417 6.85941 18.3346 8.46369 18.3346 10.4167C18.3346 11.7168 17.673 12.8625 16.668 13.5352M6.66797 14.1667L10.0013 17.5M10.0013 17.5L13.3346 14.1667M10.0013 17.5V10" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>Download</a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="consultation-documents-list-wrap">
                            <div class="consultation-documents-list-left">
                                <span>3</span>
                                <p>Pathology request</p>
                            </div>
                            <div class="consultation-documents-list-right">
                                <a href="#"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M3.33464 13.5352C2.32965 12.8625 1.66797 11.7168 1.66797 10.4167C1.66797 8.46369 3.16089 6.85941 5.06775 6.68281C5.45781 4.31011 7.51817 2.5 10.0013 2.5C12.4844 2.5 14.5448 4.31011 14.9349 6.68281C16.8417 6.85941 18.3346 8.46369 18.3346 10.4167C18.3346 11.7168 17.673 12.8625 16.668 13.5352M6.66797 14.1667L10.0013 17.5M10.0013 17.5L13.3346 14.1667M10.0013 17.5V10" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>Download</a>
                            </div>
                        </div>
                    </li>
                </ul>   
            </div>
            <div class="consultation-details-cta-wrap">
                <a href="#" class="outline-button"><svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M3.83464 13.5352C2.82965 12.8625 2.16797 11.7168 2.16797 10.4167C2.16797 8.46369 3.66089 6.85941 5.56775 6.68281C5.95781 4.31011 8.01817 2.5 10.5013 2.5C12.9844 2.5 15.0448 4.31011 15.4349 6.68281C17.3417 6.85941 18.8346 8.46369 18.8346 10.4167C18.8346 11.7168 18.173 12.8625 17.168 13.5352M7.16797 14.1667L10.5013 17.5M10.5013 17.5L13.8346 14.1667M10.5013 17.5V10" stroke="#344054" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>Invoice</a>
                <a href="#" class="outline-button">
                <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8.0763 7.49984C8.27222 6.94289 8.65893 6.47326 9.16793 6.17411C9.67693 5.87497 10.2754 5.76562 10.8573 5.86543C11.4392 5.96524 11.967 6.26777 12.3472 6.71944C12.7274 7.17111 12.9355 7.74277 12.9346 8.33317C12.9346 9.99984 10.4346 10.8332 10.4346 10.8332M10.5013 14.1665H10.5096M18.8346 9.99984C18.8346 14.6022 15.1037 18.3332 10.5013 18.3332C5.89893 18.3332 2.16797 14.6022 2.16797 9.99984C2.16797 5.39746 5.89893 1.6665 10.5013 1.6665C15.1037 1.6665 18.8346 5.39746 18.8346 9.99984Z" stroke="#344054" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                Get help
                </a>
            </div>
        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">               
                <button type="button" class="closecurrentpopup unfilled-button">Close</button>
            </div>
        </div>   
    </div>    
</div>

<script>
    function customAlerts(selector, action = "open", contentData = '') {
        if (contentData) {
            $(".alert_content").html(contentData);
        }
        if (action == "open") {
            $(selector).addClass('show-modal');
            $("body").addClass('modal-open');
        } else {
            $(selector).removeClass('show-modal');
            $("body").removeClass('modal-open');
        }
    }
    $(".consultation-details-modal-trigger").click(function() {
        customAlerts(".consultation-details-modal", "open");
    });
    $(document).on("click", ".closecurrentpopup", function() {
        $(this).parents('.modal').removeClass('show-modal');
        $("body").removeClass('modal-open');
    });
</script>
<script>
    $(document).ready(function() {
	$(window).scroll(function () {
	    var scroll = $(window).scrollTop();
	    if (scroll >= 100) {
	    	$(".patient-appointment-filters-div").addClass("sticky-filter");
	    } else {
	    	$(".patient-appointment-filters-div").removeClass("sticky-filter");
	    }
    });
});
</script>
<!--introduction slide modal-->
<!-- <div class="modal welcome-records-modal-slide show-modal">
    <div class="modal-content">
        <div class="modal-head">
            <h5 class="welcome-slides-modal-heading">3/3</h5>
            <span class="close-welcome-slides-records-button"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 1L1 13M1 1L13 13" stroke="#344054" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round"></path>
                </svg></span>
        </div>
        <div class="modal-body">
            <div class="welcome-slides-modal-wrap">
                <img src="<?php echo base_url(); ?>assets/images/virtual_consult/consult-now-slide3.png" alt="Consult Now">
                <h4><?php echo $this->lang->line('medical_records_intro_heading'); ?> </h4>
                <p><?php echo $this->lang->line('medical_records_intro_para'); ?></p>
            </div>
        </div>
        <div class="modal-footer">
            <div class="flex-modal-button">
                <a href="<?php echo base_url();?>virtual_consult/patient/search" class="unfilled-button"><?php echo $this->lang->line('introduction_slide_back_btn'); ?></a>
                <button type="button" class="primary-button close-welcome-slides-records-button"><?php echo $this->lang->line('introduction_slide_end_tour_btn'); ?></button>
            </div>
        </div>
    </div>
</div>    
<script>
    $(document).ready(function() {
    $("body").addClass("show-consult-now-welcome-slide records-menu-highlight");
	$(".close-welcome-slides-records-button").click(function() {
		$(".welcome-records-modal-slide").removeClass('show-modal');
        $("body").removeClassClass("show-consult-now-welcome-slide records-menu-highlight");
	  });
});
</script> -->