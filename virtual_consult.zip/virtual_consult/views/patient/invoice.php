<!DOCTYPE html>
<html lang="en">
	<head>
		<noscript>
			<meta http-equiv="refresh" runat="server" id="mtaJSCheck" content="0;<?php echo base_url() ?>error.php" />
		</noscript>
		<link rel="icon" href="<?php echo base_url('assets/images/favicon.png'); ?>" type="image/png" />
		<link rel="shortcut icon" href="<?php echo base_url('assets/images/favicon.png'); ?>">
		<meta name='viewport' content='width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0' />
		<meta charset="UTF-8" />
		<meta name="description" content="Medcallz:EVERY PATIENT.EVERY DOCTOR" />
		<meta name="keywords" content="Medcallz" />
		<meta name="author" content="Medcallz" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<title>Download Invoice</title>
		<link href="<?php echo base_url('assets/css/virtual_consult/invoice.css'); ?>" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<div class="invoice-container">
			<div class="header">
				<div class="branding">
					<div class="logo">
						<img src="<?php echo base_url('assets/images/virtual_consult/logomark.svg'); ?>" alt="Medcallz">
					</div>
					<div class="banner">
						<h1 class="fw-600 color-244367">MEDCALLZ</h1>
						<p class="fw-400 color-1B71BA">EVERY PATIENT. EVERY DOCTOR</p>
					</div>
				</div>
			</div>
			<div class="invoice-body">
				<div class="invoice-details">
					<div>
						<div>
							<p class="fw-500">Billed to</p>
							<?php if(!empty($hp_info['full_hp_name'])){ ?>
								<p class="color-1A1C21 fw-600"><?php echo $hp_info['full_hp_name']; ?></p>
							<?php } ?>
							<?php if(!empty($hp_info['business_name'])){ ?>
								<p class="fw-400">Company name of Doctor:</p>
								<p class="fw-400 color-344054"><?php echo $hp_info['business_name']; ?></p>
							<?php } ?>
							<?php if(!empty($hp_info['business_regd_no'])){ ?>
								<p class="fw-400">Australian Business number (ABN):</p>
								<p class="fw-400 color-344054"><?php echo $hp_info['business_regd_no']; ?></p>
							<?php } ?>
						</div>
						<div>
							<p class="fw-500">Subject</p>
							<p class="color-1A1C21 fw-600">Online Consultation</p>
						</div>
					</div>
					<div>
						<div>
							<p class="fw-500">Invoice number</p>
							<p class="color-1A1C21 fw-600"><?php echo $invoice_no; ?></p>
						</div>
						<div>
							<p class="fw-500">Reference</p>
							<p class="color-1A1C21 fw-600"><?php echo $invoice_ref; ?></p>
						</div>
						<div>
							<p class="fw-500">Invoice date</p>
							<p class="color-1A1C21 fw-600"><?php echo date('d M, Y',strtotime($payment_info->created_at)); ?></p>
						</div>
					</div>
					<div>
						<div>
							<p class="fw-500">Invoice of (AUD)</p>
							<h3 class="color-1B71B8 fw-600">$<?php echo round($payment_info->amount,2); ?></h3>
						</div>
						<div>
							<p class="fw-500">Due Date</p>
							<p class="color-1A1C21 fw-600"><?php echo date('d M, Y',strtotime($payment_info->created_at)); ?></p>
						</div>
					</div>
				</div>
				<div class="item-details">
					<table>
						<thead>
							<tr>
								<th colspan="3">ITEM DETAIL</th>
								<th>QTY</th>
								<th>RATE</th>
								<th>AMOUNT</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td colspan="3">
									<p class="color-1A1C21 fw-600">
										Consultation
										<?php if(!empty($service_info->name)){ echo ' - '.$service_info->name; } ?>
									</p>
									<?php if(!empty($service_info->description)){ ?>
										<p class="fw-400"><?php echo $service_info->description; ?></p>
									<?php } ?>
								</td>
								<td>
									<p class="color-1A1C21 fw-500">1</p>
								</td>
								<td>
									<p class="color-1A1C21 fw-500">$<?php echo round($payment_info->amount,2); ?></p>
								</td>
								<td>
									<p class="color-1A1C21 fw-500">$<?php echo round($payment_info->amount,2); ?></p>
								</td>
							</tr>
						</tbody>
						<tfoot>
							<tr>
								<td colspan="3"></td>
								<td>
									<p class="color-1A1C21 fw-500">Subtotal</p>
								</td>
								<td></td>
								<td>
									<p class="color-1A1C21 fw-500">$<?php echo round($payment_info->amount,2); ?></p>
								</td>
							</tr>
							<tr>
								<td colspan="3"></td>
								<td>
									<p class="color-1A1C21 fw-500">TAX (0%)</p>
								</td>
								<td></td>
								<td>
									<p class="color-1A1C21 fw-500">0</p>
								</td>
							</tr>
							<tr>
								<td colspan="3"></td>
								<td>
									<p class="color-1A1C21 fw-700">Total</p>
								</td>
								<td></td>
								<td>
									<p class="color-1A1C21 fw-700">$<?php echo round($payment_info->amount,2); ?></p>
								</td>
							</tr>
						</tfoot>
					</table>
				</div>
				<div class="invoice-message">
					<p class="color-1A1C21 fw-600">Medcallz is not the seller of the service</p>
					<p class="color-1A1C21 fw-600">Thanks for using Medcallz.</p>
				</div>
			</div>
		</div>
		<script src="<?php echo base_url('assets/js/html2pdf/html2pdf.bundle.min.js'); ?>"></script>
		<script>
			window.onload = function(){
				var this_scale = Math.max(Math.floor(1920 / document.body.scrollWidth),1);
				html2pdf().set({
					margin:0,
					filename:'invoice.pdf',
					jsPDF:{
						unit:'px',
						format:[
							document.body.scrollHeight,
							document.body.scrollWidth
						],
					},
					html2canvas:{
						scale:this_scale,
						width:document.body.scrollWidth,
						height:document.body.scrollHeight,
					},
				}).from(document.body).save();
			};
		</script>
	</body>
</html>