<?php
class AgoraController extends CI_Controller {
    public function getToken() {
        
        $channelName = "81b6f2a723814c0184c4f956c81c50ec";//$this->input->get("channel"); // Get channel name from request
        if (!$channelName) {
            echo json_encode(["error" => "Channel name is required"]);
            return;
        }

      echo   $token = generateAgoraToken($channelName);
        echo json_encode(["token" => $token]);
    }
    public function videoCall() {
        $this->load->view('virtual_consult/agora/agora_video_call');
    }

    public function speakToText() {
        $this->load->view('virtual_consult/agora/speak_to_text');
    }
}
