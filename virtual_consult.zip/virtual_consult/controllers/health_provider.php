<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Health_provider extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
			
		$this->load->model('auth/tank_auth/users');
		$this->load->helper('url');
	}
	function glbl() // declare global functions and variables
    {
        
        /*------------- load useful libraries and helpers  --------------------*/
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->library('tank_auth');
        $this->load->library('encryption');
        $this->lang->load('tank_auth');
        $this->lang->load('universall');
        $this->load->library('mc_constants');
        
        if (!$this->tank_auth->is_logged_in()) {
            $this->mc_constants->redirect_session_fun();
            redirect('/clinic/login/');
        }

		$roleId = $this->tank_auth->ci->session->userdata['user_role'];
		if($roleId != 2){
			redirect('patient/login');
		}
    
        $userId = $this->tank_auth->ci->session->userdata['user_id'];
        $verif_check = $this->mc_constants->login_check_verif_header($userId);
        if($verif_check == 0){
            redirect('/auth/otp_verification/');
        }

        
        $config = array('userID'=>$userId);     
        $this->load->library('acl',$config);
        
        if($this->acl->hasPermission('clinic_access') != true){
            redirect('misc/error');
        }

        $previous_url = $this->session->userdata('previous_url');
        if( $previous_url){

            redirect($previous_url);
            
        }

    }
	
	// Appointment Section
	public function appointment_pending() {
		
		$data = $this->glbl();
		$data['title'] = "Appointments Pending";
		
        $data['css_files'] = [
            'assets/css/virtual_consult/owl.carousel.min.css',
			'assets/css/virtual_consult/datepicker-jquery-ui.css',
            'assets/css/virtual_consult/dataTables.min.css',
			'assets/css/virtual_consult/responsive.dataTables.css',
			'assets/css/virtual_consult/datatablestyle.css',
			'assets/css/virtual_consult/intlTelInput.css',
		];

        $data['js_files'] = [
            'assets/js/virtual_consult/owl.carousel.min.js',
			'assets/js/virtual_consult/datepicker-jquery-ui.min.js',
			'assets/js/virtual_consult/intlTelInput.js',
            'assets/js/virtual_consult/dataTables.min.js',
			'assets/js/virtual_consult/dataTables.responsive.min.js',
        ];	
		$this->load->view('inc/virtual_consult/header' , $data);
		$this->load->view('virtual_consult/health_provider/appointment-pending', $data);
     		
	}

    public function past_consult() {
		
		$data = $this->glbl();
		$data['title'] = "Appointments Pending";
		
        $data['css_files'] = [
            'assets/css/virtual_consult/owl.carousel.min.css',
			'assets/css/virtual_consult/datepicker-jquery-ui.css',
            'assets/css/virtual_consult/dataTables.min.css',
			'assets/css/virtual_consult/responsive.dataTables.css',
			'assets/css/virtual_consult/datatablestyle.css',
			'assets/css/virtual_consult/intlTelInput.css',
		];

        $data['js_files'] = [
            'assets/js/virtual_consult/owl.carousel.min.js',
			'assets/js/virtual_consult/datepicker-jquery-ui.min.js',
			'assets/js/virtual_consult/intlTelInput.js',
            'assets/js/virtual_consult/dataTables.min.js',
			'assets/js/virtual_consult/dataTables.responsive.min.js',
        ];	
		$this->load->view('inc/virtual_consult/header' , $data);
		$this->load->view('virtual_consult/health_provider/past-consult', $data);
     		
	}

	public function medical_history() {
		
		$data = $this->glbl();
		$data['title'] = "Medical History";
		
        $data['css_files'] = [
            'assets/css/virtual_consult/owl.carousel.min.css',
			'assets/css/virtual_consult/datepicker-jquery-ui.css',
            'assets/css/virtual_consult/dataTables.min.css',
			'assets/css/virtual_consult/responsive.dataTables.css',
			'assets/css/virtual_consult/datatablestyle.css',
			'assets/css/virtual_consult/intlTelInput.css',
		];

        $data['js_files'] = [
            'assets/js/virtual_consult/owl.carousel.min.js',
			'assets/js/virtual_consult/datepicker-jquery-ui.min.js',
			'assets/js/virtual_consult/intlTelInput.js',
            'assets/js/virtual_consult/dataTables.min.js',
			'assets/js/virtual_consult/dataTables.responsive.min.js',
        ];	
		$this->load->view('inc/virtual_consult/header' , $data);
		$this->load->view('virtual_consult/health_provider/medical_history', $data);
     		
	}

   	  // Consultation notes Section
	public function consultation_notes() {
		
		$data = $this->glbl();
		$data['title'] = "Video Consults";
		
		$data['css_files'] = [
            'assets/css/virtual_consult/intlTelInput.css',
			'assets/css/virtual_consult/datepicker-jquery-ui.css',
		];
		$data['js_files'] = [
            'assets/js/virtual_consult/intlTelInput.js',
			'assets/js/virtual_consult/datepicker-jquery-ui.min.js',
        ];	

		$this->load->view('inc/virtual_consult/header' , $data);
		$this->load->view('virtual_consult/health_provider/consultation-notes', $data);
     		
	}

	  // Video call Section
	  public function video_call() {
		
		$data = $this->glbl();
		$data['title'] = "Video Consults";
		
		$data['css_files'] = [
            'assets/css/virtual_consult/intlTelInput.css',
			'assets/css/virtual_consult/datepicker-jquery-ui.css',
		];
		$data['js_files'] = [
            'assets/js/virtual_consult/intlTelInput.js',
			'assets/js/virtual_consult/datepicker-jquery-ui.min.js',
        ];	

		$this->load->view('virtual_consult/health_provider/video_call', $data);
     		
	}


}
