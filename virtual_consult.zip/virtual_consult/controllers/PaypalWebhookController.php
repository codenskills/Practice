<?php
defined('BASEPATH') or exit('No direct script access allowed');

class PaypalWebhookController extends CI_Controller
{
    private $paypalClientId;
    private $paypalSecret;
    private $webhookId; // Your PayPal Webhook ID

    public function __construct()
    {
        parent::__construct();
        $this->config->set_item('log_threshold', 1);

        $this->load->model("virtual_consult/payments");

        // Set your PayPal API credentials
        $this->paypalClientId = PAYPAL_CLIENT_ID;
        $this->paypalSecret = PAYPAL_CLIENT_SECRET;
        $this->webhookId = PAYPAL_WEBHOOK_ID;
    }

    /**
     * Handle incoming PayPal webhook events.
     */
    public function index()
    {

        
        // Get raw POST data from PayPal
       echo  $rawData = file_get_contents('php://input');

        $headers = $this->input->request_headers();

        log_message('info', 'PayPal Webhook Received: ' . $rawData);

        // if (!$this->verifyWebhookSignature($headers, $rawData)) {
        //     log_message('error', 'Invalid PayPal Webhook Signature');
        //     http_response_code(400);
        //     exit('Invalid Webhook Signature');
        // }
       // print_r($rawData);die;
        $event = json_decode($rawData, true);
        $eventType = $event['event_type'] ?? '';

        switch ($eventType) {

            // case 'INVOICING.INVOICE.PAID':
            //     $this->handleInvoicePaid($event);
            //     break;

            case 'CHECKOUT.ORDER.APPROVED':
                $this->handleOrderApproved($event);
                break;

            case 'PAYMENT.CAPTURE.COMPLETED':
                $this->handlePaymentSuccess($event);
                break;

            case 'PAYMENT.CAPTURE.DENIED':
                $this->handlePaymentFailed($event);
                break;

            case 'PAYMENT.CAPTURE.REFUNDED':
                $this->handleRefund($event);
                break;

            default:
                log_message('info', 'Unhandled PayPal Webhook Event: ' . $eventType);
                break;
        }

        http_response_code(200);
    }

    /**
     * Verify PayPal Webhook Signature
     */
    private function verifyWebhookSignature($headers, $body)
    {
        $accessToken = $this->getAccessToken();
        if (!$accessToken) {
            error_log("PayPal Webhook: Failed to retrieve access token.");
            return false;
        }

        // Normalize headers to handle case sensitivity
        $headers = array_change_key_case($headers, CASE_UPPER);

        // Ensure event data is valid JSON
        $eventData = json_decode($body, true);
        if (!$eventData) {
            error_log("PayPal Webhook: Invalid JSON body.");
            return false;
        }

        // Prepare verification data
        $verificationData = [
            "auth_algo" => $headers['PAYPAL-AUTH-ALGO'] ?? '',
            "cert_url" => $headers['PAYPAL-CERT-URL'] ?? '',
            "transmission_id" => $headers['PAYPAL-TRANSMISSION-ID'] ?? '',
            "transmission_sig" => $headers['PAYPAL-TRANSMISSION-SIG'] ?? '',
            "transmission_time" => $headers['PAYPAL-TRANSMISSION-TIME'] ?? '',
            "webhook_id" => PAYPAL_WEBHOOK_ID,
            "webhook_event" => $eventData
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, PAYPAL_API_BASE_URL . "/v1/notifications/verify-webhook-signature");
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
            "Authorization: Bearer $accessToken"
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($verificationData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        curl_close($ch);

        $result = json_decode($response, true);
        return isset($result['verification_status']) && $result['verification_status'] === 'SUCCESS';
    }



    /**
     * Get PayPal API Access Token
     */
    private function getAccessToken()
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, PAYPAL_API_BASE_URL . "/v1/oauth2/token");
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Accept: application/json",
            "Accept-Language: en_US"
        ]);
        curl_setopt($ch, CURLOPT_USERPWD, PAYPAL_CLIENT_ID . ":" . PAYPAL_CLIENT_SECRET);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "grant_type=client_credentials");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        curl_close($ch);

        $result = json_decode($response, true);
        return $result['access_token'] ?? null;
    }


    /**
     * Handle PayPal Checkout Order Approved Event
     */
    private function handleOrderApproved($event)
    {
        log_message('info', 'Order Approved: ' . json_encode($event));
        echo ('Order Approved: ' . json_encode($event));
    }

    /**
     * Handle PayPal Payment Success
     */
    private function handlePaymentSuccess($event)
    {
        $payment = $event['resource'];
        $transactionId = $payment['id'];
        $amount = $payment['amount']['value'];
        $currency = $payment['amount']['currency_code'];

        log_message('info', "Payment Captured: Transaction ID $transactionId, Amount $amount $currency");
        echo ("Payment Captured: Transaction ID $transactionId, Amount $amount $currency");

        // Update Database
        //$this->payments->updatePaymentStatus($transactionId, 'paid');
    }

    /**
     * Handle PayPal Payment Failure
     */
    private function handlePaymentFailed($event)
    {
        $payment = $event['resource'];
        $transactionId = $payment['id'];

        log_message('error', "Payment Failed: Transaction ID $transactionId");
        echo ("Payment Failed: Transaction ID $transactionId");

        // Update Database
        //  $this->payments->updatePaymentStatus($transactionId, 'failed');
    }

    /**
     * Handle PayPal Refund Event
     */
    private function handleRefund($event)
    {
        $refund = $event['resource'];
        $transactionId = $refund['id'];
        $refundAmount = $refund['amount']['value'];

        log_message('info', "Payment Refunded: Transaction ID $transactionId, Amount Refunded $refundAmount");
        echo ("Payment Refunded: Transaction ID $transactionId, Amount Refunded $refundAmount");

        // Update Database
        //  $this->payments->updatePaymentStatus($transactionId, 'refunded');
    }
    
}
