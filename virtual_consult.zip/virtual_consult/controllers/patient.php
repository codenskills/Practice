<?php if (!defined('BASEPATH'))
	exit('No direct script access allowed');
class Patient extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('auth/tank_auth/users');
		$this->load->model("virtual_consult/mc_services");
		$this->load->model("virtual_consult/payments");
		$this->load->helper('url');
		$this->load->library('encryption');
	}
	function glbl() // declare global functions and variables
	{

		$this->load->helper(array('form', 'url', 'text'));
		$this->load->library('form_validation');
		$this->load->helper('security');
		$this->load->library('tank_auth');
		$this->load->library('encryption');

		$idiom = $this->session->userdata['site_lang'];
		$this->lang->load('patient/patient', $idiom);
		$this->lang->load('tank_auth', $idiom);
		$this->lang->load('universall', $idiom);
		$this->load->library('mc_constants');

		$userId = $this->tank_auth->ci->session->userdata['user_id'];
		if (empty($userId)) {
			$this->mc_constants->redirect_session_fun();
			redirect('patient/login');
		}
		$roleId = $this->tank_auth->ci->session->userdata['user_role'];
		if ($roleId != 4) {
			redirect('clinic/qrmessages');
		}
		$config = array('userID' => $userId);
		$this->load->library('acl', $config);

		if ($this->acl->hasPermission('patient_access') != true) {
			redirect('patient/login');
		}
	}

	// Appointment Section
	public function search()
	{

		$data = $this->glbl();
		$data['title'] = "Appointments";

		$this->load->view('inc/header_patient_new', $data);
		$this->load->view('virtual_consult/patient/search', $data);

	}

	// consult now Section
	public function consult_now()
	{

		$data = $this->glbl();

		$data['title'] = "Consult Now";

		$data["online_doctor"] = $this->mc_services->getOnlineDoctorsCount();

		$data["services_list"] = $this->mc_services->getServices(false, false);

		$this->load->view('inc/header_patient_new', $data);

		$this->load->view('virtual_consult/patient/consult_now', $data);

	}

	public function getLiveDoctorListCountByServiceId()
	{
		$postData = $this->input->post();
		$service_id = $this->encryption->decode($postData['service_id']);
		$res = $this->mc_services->getLiveDoctorListCountByServiceId($service_id);
		if ($res) {
			echo json_encode(["status" => true, "message" => ""]);
		} else {
			echo json_encode(["status" => false, "message" => $this->lang->line('consult_now_doctor_count')]);
		}

	}

	// Book Appointment Section
	public function book_appointment()
	{

		$data = $this->glbl();
		$data['title'] = "Book Appointment";

		$this->load->view('inc/header_patient_new', $data);
		$this->load->view('virtual_consult/patient/book_appointment', $data);

	}

	// Favourites Section
	public function favourites()
	{

		$data = $this->glbl();
		$data['title'] = "Favourites";

		$this->load->view('inc/header_patient_new', $data);
		$this->load->view('virtual_consult/patient/favourites', $data);

	}

	// Records
	public function medical_records()
	{

		$data = $this->glbl();
		$data['title'] = "Records";

		$this->load->view('inc/header_patient_new', $data);
		$this->load->view('virtual_consult/patient/medical_records', $data);

	}

	// Favourites Section
	public function consult_doctors_list($id)
	{
		$data = $this->glbl();
		$data['title'] = "Favourites";

		$this->mc_constants->makePatientOnlineLoggedVm();

		$encypted = $id;
		$id = $this->encryption->decode($id);
		$data["service"] = $this->mc_services->getServices($id, false);
		$this->load->library('pagination');

		$userid = $this->tank_auth->ci->session->userdata['user_id'];
		$username = $this->tank_auth->ci->session->userdata['username'];
		$data['username'] = $username;
		$data['patientname'] = $this->mc_constants->get_patient_data_username($username);
		$data['emailaddress'] = $this->mc_constants->get_email_by_userid($userid);

		$config['base_url'] = site_url('virtual_consult/patient/consult_doctors_list/' . $encypted); // The URL to link the pages
		$config['per_page'] = QR_LIMIT;
		$config['uri_segment'] = URI_SEGMENT;
		$page_no = $this->uri->segment(SEGMENT_NUMBER, SEGMENT_NUMBER_DEFAULT);
		$start = (max($page_no, 1) - 1) * $config['per_page'];
		$data["doctor_list"] = $this->mc_services->getLiveDoctorListByServiceId($id, $start, $config['per_page']);
		$config["total_rows"] = $this->mc_services->getLiveDoctorListCountByServiceId($id);
		$this->pagination->initialize($config);
		$data['pagination'] = $this->generate_custom_pagination($config["total_rows"], $config['per_page'], $page_no, $config['base_url']);
		// $data['pagination'] = $this->pagination->create_links();
		$this->load->view('inc/header_patient_new', $data);
		$this->load->view('virtual_consult/patient/consult_doctors_list', $data);
	}

	public function invoice($payment_id = '')
	{
		if (empty($payment_id)) {
			echo 'Some unknown error occured. Please try again.';
			exit;
		}
		$payment_info = $this->payments->getPaymentInfo($payment_id);
		if (!$payment_info) {
			echo 'Some unknown error occured. Please try again.';
			exit;
		}
		$payment_payload = $payment_info->payload;
		$payment_info->payment_payload = json_decode($payment_payload);
		$data['invoice_no'] = $this->generateInvoiceNumber($payment_id);
		$data['invoice_ref'] = $this->generateInvoiceRef($payment_id);
		$data['hp_info'] = $this->mc_services->getHpDetailByUserId($payment_info->hp_user_id);
		$data['service_info'] = $this->mc_services->getServices($payment_info->service_id);
		$data['payment_info'] = $payment_info;
		$this->load->view('virtual_consult/patient/invoice', $data);
	}

	public function live_consultation($payment_id)
	{
		$data = $this->glbl();
		$userid = $this->tank_auth->ci->session->userdata['user_id'];
		$username = $this->tank_auth->ci->session->userdata['username'];
		$data['payment_id'] = $payment_id;
		$data['title'] = 'Consultation';
		$data['username'] = $username;
		$data['patientname'] = $this->mc_constants->get_patient_data_username($username);
		$data['emailaddress'] = $this->mc_constants->get_email_by_userid($userid);
		$payment_info = $this->payments->getPaymentInfo($payment_id);
		$payment_payload = $payment_info->payload;
		$payment_info->payment_payload = json_decode($payment_payload);
		$hp_user_id = $payment_info->hp_user_id;
		$data['hp_info'] = $this->mc_services->getHpDetailByUserId($hp_user_id);
		$hp_user_info = $this->mc_constants->getUserData($data['hp_info']['user_id']);
		$data['hp_info']['video_id'] = $this->mc_constants->getQuickBloxUserListByLogin($hp_user_info['username']);
		$data['hp_info']['video_name'] = $this->mc_constants->get_hp_data_username($hp_user_info['username']);
		$data['hp_info']['video_username'] = $hp_user_info['username'];
		$data['service_info'] = $this->mc_services->getServices($payment_info->service_id);
		$data['service_id_enc'] = $this->encryption->encode($payment_info->service_id);
		$data['payment_info'] = $payment_info;
		$this->load->view('inc/header', $data);
		$this->load->view('virtual_consult/patient/consult_video_page', $data);
		return;
	}

	private function generateInvoiceNumber($payment_id)
	{
		return '#' . substr(strtoupper(md5(date('Y-m-d H'))), 0, 3) . '-' . sprintf('%03d', $payment_id) . '-01';
	}

	private function generateInvoiceRef($payment_id)
	{
		return 'INV-' . sprintf('%06d', $payment_id);
	}

	// Custom Pagination Function
	private function generate_custom_pagination($total_records, $per_page, $current_page, $base_url, $range = 2)
	{
		// Calculate total pages
		$total_pages = ceil($total_records / $per_page);

		// If there's only one page, no need for pagination
		if ($total_pages <= 1) {
			return '';  // No pagination needed
		}

		// Ensure current page is within bounds
		$current_page = max(1, min($current_page, $total_pages));

		// Start building pagination HTML
		$pagination = '<div class="pagination-row">';

		// Left Pagination (Previous Button)
		$pagination .= '<div class="left-pagination">';
		if ($current_page > 1) {
			$pagination .= '<button type="button" class="pagination-button" onclick="window.location=\'' . $base_url . '/' . ($current_page - 1) . '\'">
								<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
									<path d="M12.8337 6.99996H1.16699M1.16699 6.99996L7.00033 12.8333M1.16699 6.99996L7.00033 1.16663" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
								</svg>
								Previous
							</button>';
		} else {
			$pagination .= '<button type="button" class="pagination-button" disabled>Previous</button>';
		}
		$pagination .= '</div>';

		// Center Pagination (Page Numbers with Ellipses)
		$pagination .= '<div class="center-pagination"><ul class="pagination-number">';

		// Calculate the range of pages to display
		$start_page = max(1, $current_page - $range);
		$end_page = min($total_pages, $current_page + $range);

		// Display first page and ellipsis if needed
		if ($start_page > 3) {
			$pagination .= '<li><button type="button" onclick="window.location=\'' . $base_url . '/1\'">1</button></li>';
			$pagination .= '<li><button type="button" onclick="window.location=\'' . $base_url . '/2\'">2</button></li>';
			$pagination .= '<li><button type="button">...</button></li>';
		}

		// Generate page number buttons
		for ($i = $start_page; $i <= $end_page; $i++) {
			if ($i == $current_page) {
				$pagination .= '<li><button type="button" class="active">' . $i . '</button></li>';
			} else {
				$pagination .= '<li><button type="button" onclick="window.location=\'' . $base_url . '/' . $i . '\'">' . $i . '</button></li>';
			}
		}

		// Display last page and ellipsis if needed
		if ($end_page < $total_pages - 2) {
			$pagination .= '<li><button type="button">...</button></li>';
			$pagination .= '<li><button type="button" onclick="window.location=\'' . $base_url . '/' . ($total_pages - 1) . '\'">' . ($total_pages - 1) . '</button></li>';
			$pagination .= '<li><button type="button" onclick="window.location=\'' . $base_url . '/' . $total_pages . '\'">' . $total_pages . '</button></li>';
		}

		$pagination .= '</ul></div>';  // End center-pagination

		// Right Pagination (Next Button)
		$pagination .= '<div class="right-pagination">';
		if ($current_page < $total_pages) {
			$pagination .= '<button type="button" class="pagination-button" onclick="window.location=\'' . $base_url . '/' . ($current_page + 1) . '\'">
								Next
								<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
									<path d="M1.1665 6.99996H12.8332M12.8332 6.99996L6.99984 1.16663M12.8332 6.99996L6.99984 12.8333" stroke="#475467" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
								</svg>
							</button>';
		} else {
			$pagination .= '<button type="button" class="pagination-button" disabled>Next</button>';
		}
		$pagination .= '</div>';  // End right-pagination

		$pagination .= '</div>';  // End pagination-row

		return $pagination;
	}

	// Online waiting Section
	public function online_waiting_room()
	{

		$data = $this->glbl();
		$data['title'] = "Online Waiting Room";
		$this->load->library('pagination');

		$userId = $this->tank_auth->ci->session->userdata['user_id'];
		$config['base_url'] = site_url('virtual_consult/patient/online_waiting_room/');
		$config['per_page'] = QR_LIMIT;
		$config['uri_segment'] = URI_SEGMENT;
		$page_no = $this->uri->segment(SEGMENT_NUMBER, SEGMENT_NUMBER_DEFAULT);
		$start = (max($page_no, 1) - 1) * $config['per_page'];
		$data["online_waiting_list"] = $this->mc_services->patientAppointmentList($userId, $start, $config['per_page'], 0);
		$config["total_rows"] = $this->mc_services->totalPatientAppointmentList($userId, 0);
		$this->pagination->initialize($config);
		$data['pagination'] = $this->generate_custom_pagination($config["total_rows"], $config['per_page'], $page_no, $config['base_url']);

		$this->load->view('inc/header_patient_new', $data);
		$this->load->view('virtual_consult/patient/online_wating_room', $data);
	}

	// History Section
	public function history()
	{

		$data = $this->glbl();
		$data['title'] = "Appointment History";
		$userid = $this->tank_auth->ci->session->userdata['user_id'];
		$payment_history = $this->payments->getUserPaymentHistory($userid);
		/* print_r($payment_history);
			  die; */
		// fetch history here
		$this->load->view('inc/header_patient_new', $data);
		$this->load->view('virtual_consult/patient/history', $data);

	}

	// Video call Section
	public function video_call() {
		
		$data = $this->glbl();
		$data['title'] = "Video Consults";
		
		$data['css_files'] = [
            'assets/css/virtual_consult/intlTelInput.css',
			'assets/css/virtual_consult/datepicker-jquery-ui.css',
		];
		$data['js_files'] = [
            'assets/js/virtual_consult/intlTelInput.js',
			'assets/js/virtual_consult/datepicker-jquery-ui.min.js',
        ];	

		$this->load->view('virtual_consult/patient/video_call', $data);
     		
	}


	public function getServiceDetail()
	{
		$service_id = $this->input->post()['service_id'];
		$PLATFORM_FEE = getFormattedPrice(PLATFORM_FEE);
		$TAX = getFormattedPrice(TAX);
		if (isset($service_id)) {
			$service = $this->mc_services->getServices($service_id);
			if (empty($service)) {
				echo json_encode(["status" => false, "message" => "Sorry we are not offering this service for now"]);
				return;
			}
			echo json_encode(["status" => true, "message" => "", "data" => $service, "PLATFORM_FEE" => $PLATFORM_FEE, "TAX" => $TAX, "CURRENCY_SYMBOL" => CURRENCY_SYMBOL_NEW]);
			return;
		} else {
			echo json_encode(["status" => false, "message" => "Service ID can not be blank"]);
			return;
		}
	}
	public function getHpDetail()
	{
		$hp_id = $this->input->post()['hp_id'];
		if (isset($hp_id)) {
			$hp = $this->mc_services->getHpDetail($hp_id);
			if (empty($hp)) {
				echo json_encode(["status" => false, "message" => "Sorry we are not offering this service for now"]);
				return;
			}
			echo json_encode(["status" => true, "message" => "", "data" => $hp]);
			return;
		} else {
			echo json_encode(["status" => false, "message" => "HP ID can not be blank"]);
			return;
		}
	}
}
