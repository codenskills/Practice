<?php
defined('BASEPATH') or exit('No direct script access allowed');

class StripeWebhookController extends CI_Controller
{
    private $stripe;

    public function __construct()
    {
        parent::__construct();
        // Load Composer's autoloader if not already loaded.
        require_once APPPATH . '../vendor/autoload.php';
        $this->config->set_item('log_threshold', 1);

        $this->load->model("virtual_consult/payments");
        if (!defined('STRIPE_SECRET_KEY')) {
            die('STRIPE_SECRET_KEY is not defined!');
        }

        // Initialize Stripe client
        $this->stripe = new \Stripe\StripeClient(STRIPE_SECRET_KEY);
    }

    /**
     * Index method handles incoming Stripe webhook events.
     */
    public function index()
    {



        $endpoint_secret = STRIPE_WEBHOOK_KEY;
        $stripe_key = STRIPE_SECRET_KEY;


        $payload = @file_get_contents('php://input');
        $sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'];
        $event = null;
        // $payload = @file_get_contents('php://input');        
        // $sig_header = isset($_SERVER['HTTP_STRIPE_SIGNATURE']) ? $_SERVER['HTTP_STRIPE_SIGNATURE'] : '';        
        // $endpoint_secret = STRIPE_WEBHOOK_KEY;
        // error_log("Payload==========".$payload);
        // try {
        //     // Verify the webhook signature and construct the event
        //     $postData = \Stripe\Webhook::constructEvent($payload, $sig_header, $endpoint_secret);
        // } catch (\UnexpectedValueException $e) {           
        //     http_response_code(400);
        //     echo 'Invalid payload';
        //     exit();
        // } catch (\Stripe\Exception\SignatureVerificationException $e) {            
        //     http_response_code(400);
        //     echo 'Invalid signature';
        //     exit();
        // }
        error_reporting(E_ALL);
        ini_set('display_errors', 1);
        error_log($payload . '=StripePayload');
        $postData = json_decode($payload);
        // print_R($postData);
        switch ($postData->type) {

            case 'checkout.session.completed':
                $session = $postData->data->object;

                $this->handleCheckoutSessionCompleted($session);
                break;

            case 'checkout.session.expired':
                $session = $postData->data->object;
                $this->handleCheckoutSessionExpired($session);
                break;
            case 'charge.refunded':
                $session = $postData->data->object;
                $this->handleChargeRefunded($session);
                break;
            case 'payment_intent.payment_failed':
                $session = $postData->data->object;
                //  $this->handleCheckoutSessionCompleted($session);
                break;

            default:
                log_message('info', 'Received unhandled event type: ' . $postData->type);
                break;
        }

        http_response_code(200);
    }

    /**
     * Handle a completed Checkout Session event.
     *
     * @param \Stripe\Checkout\Session $object
     */
    protected function handleCheckoutSessionCompleted($object)
    {
        //print_r($object);
        // Example: Log the session details.
        log_message('info', 'Stripe Checkout session completed: ' . json_encode($object));



        $patient_user_id = isset($object->metadata->patient_user_id) ? (int) $object->metadata->patient_user_id : 0;
        $hp_user_id = isset($object->metadata->hp_user_id) ? (int) $object->metadata->hp_user_id : 0;
        $med_ser_log_id = isset($object->metadata->med_ser_log_id) ? (int) $object->metadata->med_ser_log_id : 0;

        $payment_intent = isset($object->payment_intent) ? $object->payment_intent : "";
        $mode = $object->mode; //subscription
        $amount = (isset($object->amount_total) && $object->amount_total > 0) ? $object->amount_total : 0;
        $amount = getFormattedPrice($amount / 100);

        $currency = $object->currency;
        $livemode = $object->livemode;
        $livemode = ($livemode) ? 1 : 0;
        $status = $object->status;
        $payment_status = $object->payment_status;
        $med_ser_log = $this->payments->getMedicalServiceLogsRow('id', $med_ser_log_id);
        if ($mode == 'payment') {
            if ($status == "complete" && $payment_status == "paid" && !empty($hp_user_id) && !empty($patient_user_id) && !empty($med_ser_log_id)) {

                if (!$med_ser_log) {
                    echo "Medical Service Logs ID Not Found";
                    http_response_code(400);
                    exit();
                }
                if (!$payment_intent || ($amount != $med_ser_log->total)) {
                    echo "Payment Intent or Amount not matched";
                    http_response_code(400);
                    exit();
                }

                $data = [
                    'patient_user_id' => $med_ser_log->patient_user_id,
                    'hp_user_id' => $med_ser_log->hp_user_id,
                    'service_id' => $med_ser_log->service_id,
                    'service_category_id' => $med_ser_log->service_category_id,
                    'service_type' => $med_ser_log->service_type,
                    'payment_method' => $med_ser_log->payment_method,
                    'service_price' => $med_ser_log->service_price,
                    'platform_fee' => $med_ser_log->platform_fee,
                    'tax' => $med_ser_log->tax,
                    'subtotal' => $med_ser_log->subtotal,
                    'total' => $med_ser_log->total,
                    'status' => 0, //$med_ser_log->status,
                    'ip' => $med_ser_log->ip,
                    //'payload' => $med_ser_log->payload,
                    // Link the record to its original log record ID
                    'medical_services_log_id' => $med_ser_log->id
                ];

                $med_ser_id = $this->payments->createMedicalService($data);

                if ($med_ser_id) {
                    $paymentIntentDtls = $this->stripe->paymentIntents->retrieve($payment_intent);
                    $paymentMethodType = null;
                    if (!empty($paymentIntentDtls->latest_charge)) {
                        $charge = $this->stripe->charges->retrieve($paymentIntentDtls->latest_charge);
                        if (!empty($charge->payment_method_details)) {
                            $paymentMethodType = $charge->payment_method_details->type;
                        }
                    }

                    $this->payments->updateMedicalServiceLogs('id', $med_ser_log->id, ['is_entry' => 1]);

                    $ms_hpassignid = $this->payments->createMedicalServiceHPAssign([
                        'patient_user_id' => $med_ser_log->patient_user_id,
                        'hp_user_id' => $med_ser_log->hp_user_id,
                        'medical_service_id' => $med_ser_id,
                        'status' => 0,
                    ]);
                    $ms_paymentid = $this->payments->createMedicalServicePayment([
                        'medical_service_id' => $med_ser_id,
                        'transaction_id' => $payment_intent,
                        'payment_method' => 'stripe',
                        'payment_method_type' => $paymentMethodType ?? null,
                        'total' => $med_ser_log->total,
                        'status' => 1,
                        'patient_user_id' => $med_ser_log->patient_user_id,
                        'service_id' => $med_ser_log->service_id,
                        'service_price' => $med_ser_log->service_price,
                        'platform_fee' => $med_ser_log->platform_fee,
                        'tax' => $med_ser_log->tax,
                        'subtotal' => $med_ser_log->subtotal,
                        'service_type' => $med_ser_log->service_type,
                    ]);
                    echo "Medical Service successfully created after session completion. 
                    mc_medical_services ID: $med_ser_id, 
                    mc_medical_services_hp_assign ID: $ms_hpassignid, 
                    mc_medical_services_payment ID: $ms_paymentid.";

                    //send alert to HP (Doctor)
                    $response = emitSocketEvent(
                        "HP_assign_status",
                        [
                            "hp_user_id" => $med_ser_log->hp_user_id,
                            "patient_user_id" => $med_ser_log->patient_user_id,
                            "hp_assign_status" => 0,
                            "med_ser_log_id" => $med_ser_log_id ?? "",
                            "med_ser_id" => $med_ser_id ?? "",
                            "ms_hpassignid" => $ms_hpassignid ?? "",
                            "ms_paymentid" => $ms_paymentid ?? "",
                            "url" => "",// will be blank 
                            "type" => "payment_complete", 
                            "timestamp" => date("Y-m-d H:i:s")
                        ]
                    );
                    // echo "Response from Node.js: " . $response; die;
                    http_response_code(200);
                    exit();
                } else {
                    echo "Failed to create Medical Service when checkout session completed.";
                    http_response_code(400);
                    exit();
                }
            }
            // elseif ($status == "failed" || $payment_status == "failed") {
            //     // Payment failed logic
            //     echo "Payment failed. Please try again.";
            //     http_response_code(400);
            //     exit();
            // }
            else {
                // Handle other cases if needed
                echo "Checkout session completed. Payment status or Medical Service Log ID is unclear.";
                http_response_code(400);
                exit();
            }
        } else {
            print ("Checkout session could not be completed. Please try again or contact support.");
            http_response_code(400);
            exit();
        }

    }

    /**
     * Handle a expired Checkout Session event.
     *
     * @param \Stripe\Checkout\Session $object
     */
    protected function handleCheckoutSessionExpired($object)
    {
        //print_r($object);die;
        // Example: Log the session details.
        log_message('info', 'Stripe Checkout session expired: ' . json_encode($object));


        $patient_user_id = isset($object->metadata->patient_user_id) ? (int) $object->metadata->patient_user_id : 0;
        $hp_user_id = isset($object->metadata->hp_user_id) ? (int) $object->metadata->hp_user_id : 0;
        $med_ser_log_id = isset($object->metadata->med_ser_log_id) ? (int) $object->metadata->med_ser_log_id : 0;


        $mode = $object->mode; //subscription
        $amount = (isset($object->amount_total) && $object->amount_total > 0) ? $object->amount_total : 0;
        $amount = getFormattedPrice($amount / 100);

        $currency = $object->currency;
        $livemode = $object->livemode;
        $livemode = ($livemode) ? 1 : 0;
        $status = $object->status;
        $payment_status = $object->payment_status;
        $med_ser_log = $this->payments->getMedicalServiceLogsRow('id', $med_ser_log_id);
        if ($mode == 'payment') {
            if ($status == "expired" && $payment_status == "unpaid" && !empty($hp_user_id) && !empty($patient_user_id) && !empty($med_ser_log_id)) {

                if (!$med_ser_log) {
                    echo "Medical Service Logs ID Not Found";
                    http_response_code(400);
                    exit();
                }
                $data = [
                    'patient_user_id' => $med_ser_log->patient_user_id,
                    'hp_user_id' => $med_ser_log->hp_user_id,
                    'service_id' => $med_ser_log->service_id,
                    'service_category_id' => $med_ser_log->service_category_id,
                    'service_type' => $med_ser_log->service_type,
                    'payment_method' => $med_ser_log->payment_method,
                    'service_price' => $med_ser_log->service_price,
                    'platform_fee' => $med_ser_log->platform_fee,
                    'tax' => $med_ser_log->tax,
                    'subtotal' => $med_ser_log->subtotal,
                    'total' => $med_ser_log->total,
                    'status' => 2, //$med_ser_log->status,
                    'ip' => $med_ser_log->ip,
                    'medical_services_log_id' => $med_ser_log->id
                ];

                $med_ser_id = $this->payments->createMedicalService($data);

                if ($med_ser_id) {

                    $this->payments->updateMedicalServiceLogs('id', $med_ser_log->id, ['is_entry' => 1]);
                    $ms_paymentid = $this->payments->createMedicalServicePayment([
                        'medical_service_id' => $med_ser_id,
                        'transaction_id' => $payment_intent ?? null,
                        'payment_method' => 'stripe',
                        'payment_method_type' => $paymentMethodType ?? null,
                        'total' => $med_ser_log->total,
                        'status' => 0,
                        'patient_user_id' => $med_ser_log->patient_user_id,
                        'service_id' => $med_ser_log->service_id,
                        'service_price' => $med_ser_log->service_price,
                        'platform_fee' => $med_ser_log->platform_fee,
                        'tax' => $med_ser_log->tax,
                        'subtotal' => $med_ser_log->subtotal,
                        'service_type' => $med_ser_log->service_type,
                    ]);

                    echo "Medical Service successfully created after session expiration. 
                    mc_medical_services ID: $med_ser_id, 
                    mc_medical_services_payment ID: $ms_paymentid.";
                    http_response_code(200);
                    exit();

                } else {
                    echo "Failed to create Medical Service when checkout session expired.";
                    http_response_code(400);
                    exit();
                }
            } else {
                // Handle other cases if needed
                echo "Checkout session expired. Payment status or Medical Service Log ID is unclear.";
                http_response_code(400);
                exit();
            }
        } else {
            print ("Unable to expire checkout session. Please try again or contact support.");
            http_response_code(400);
            exit();
        }

    }

    /**
     * Handle a Charge Refunded event.
     *
     * @param \Stripe\Charge $object
     */
    protected function handleChargeRefunded($object)
    {
        log_message('info', 'Stripe Charge refunded: ' . json_encode($object));

        $chargeId = $object->id;
        $transactionId = $object->payment_intent ?? $chargeId;
        $amountRefunded = $object->amount_refunded / 100;
        $status = $object->status;

        if ($status == 'succeeded' && $amountRefunded > 0 && $transactionId != "") {
            // Fetch payment details from the database
            $pmtdtls = $this->payments->getMedicalServicePaymentRow('transaction_id', $transactionId);

            if (!$pmtdtls) {
                log_message('error', "Refund transaction ID {$transactionId} not found.");
                http_response_code(400);
                echo 'Refund transaction id not found';
                exit();
            }

            // Update database records
            $pmtdtlsid = $pmtdtls->id;
            $medical_service_id = $pmtdtls->medical_service_id;

            $this->payments->updateMedicalService('id', $medical_service_id, ['status' => 3]);
            $this->payments->updateMedicalServicePayment('id', $pmtdtlsid, ['status' => 2]);

            log_message('info', "Refund successful for transaction ID: {$transactionId}");
            http_response_code(200);
            echo 'Refund Successfully';
            exit();
        } else {
            log_message('error', "Refund failed for Charge ID: {$chargeId}, Status: {$status}");
            http_response_code(400);
            echo 'charge.refunded Not Success';
            exit();
        }
    }

}

