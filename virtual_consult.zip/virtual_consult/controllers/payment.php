<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Payment extends CI_Controller
{
    private $publishable_key = STRIPE_PUBLISH_KEY,
    $secret_key = STRIPE_SECRET_KEY,
    $paypal_client_id = PAYPAL_CLIENT_ID,
    $paypal_client_secret = PAYPAL_CLIENT_SECRET,
    $paypal_url = "https://api-m.sandbox.paypal.com",
    $currency = 'aud';
    private $stripe;
    public function __construct()
    {
        parent::__construct();
        require APPPATH . '/third_party/stripe/init.php';
        $this->load->model("virtual_consult/payments");
        $this->load->model('auth/tank_auth/users');
        $this->load->library('tank_auth');
        \Stripe\Stripe::setApiKey($this->secret_key);
        $this->stripe = new \Stripe\StripeClient($this->secret_key);
    }

    function glbl() // declare global functions and variables
    {
        $idiom = $this->session->userdata['site_lang'];
        $this->load->helper(array('form', 'url', 'text'));
        $this->lang->load('form_validation', $idiom);
        $this->load->helper('security');
        $this->load->library('tank_auth');
        $this->load->library('encryption');


        $this->lang->load('patient/patient', $idiom);
        $this->lang->load('tank_auth', $idiom);
        $this->lang->load('universall', $idiom);
        $this->load->library('mc_constants');

        $userId = $this->tank_auth->ci->session->userdata['user_id'];
        if (empty($userId)) {
            $this->mc_constants->redirect_session_fun();
            redirect('patient/login');
        }
        $roleId = $this->tank_auth->ci->session->userdata['user_role'];
        if ($roleId != 4) {
            redirect('clinic/qrmessages');
        }
        $config = array('userID' => $userId);
        $this->load->library('acl', $config);

        if ($this->acl->hasPermission('patient_access') != true) {
            redirect('patient/login');
        }
    }

    // Create PaymentIntent with manual capture
    // public function create_intent() {
    //     $this->glbl();
    //     $inputValues = $this->getPayload();
    //     $payment_method = $inputValues['payment_method'];
    //     $p_info = $inputValues['p_info'];
    //     $amount  = (int)$p_info['total_charges'];
    //     $custom_payment_method = $p_info['payment_method'];

    //     $userId = $this->tank_auth->ci->session->userdata['user_id'];
    //     $customerId = $this->getCreateCustomerStripeID();
    //     try{
    //         $paymentMethod = $this->attachCustomerToPaymentMethod($payment_method,$customerId);
    //     }catch(Exception $e){
    //         echo json_encode(["status"=>false,'error'=>["message"=>$e->getMessage()]]);
    //         return;
    //     }
    //     $id = $this->createPaymentLogs($p_info,$userId,$amount);

    //     if(!isset($id)){
    //         echo json_encode(["status"=>false,"message"=>"Logs can not be created, please try again"]);
    //         return;
    //     }
    //     try {
    //         // Create a PaymentIntent with manual capture
    //         $paymentIntent = \Stripe\PaymentIntent::create([
    //             'amount' => $amount * 100,  // Amount in cents (e.g., $10.00 = 1000)
    //             'currency' => $this->currency,
    //             'payment_method' => $payment_method,
    //             "customer"=>$customerId,
    //             // 'confirmation_method' => 'manual',
    //             'capture_method' => 'automatic',  // Automatic capture (Capture instead of hold)
    //             'confirm' => true,  // Confirm the payment immediately,
    //             "automatic_payment_methods" => [
    //                 "enabled" => true,
    //                 "allow_redirects" => 'never'  // Prevent any redirect-based payment methods
    //             ],
    //             "off_session" => true
    //         ]);

    //         $this->payments->updatepaymentPaymentLogs([
    //             "response"=>json_encode($paymentIntent)
    //         ],$id);

    //         $save_detail = $p_info['save_detail'];
    //         if($save_detail){
    //             $this->payments->savePaymentInfo([
    //                 "type"=>$custom_payment_method,
    //                 "payment_method_id"=>$payment_method,
    //                 "user_id"=>$userId
    //             ]);
    //         }

    //         // Send the client secret to the frontend to confirm the payment
    //         echo json_encode([
    //             'client_secret' => $paymentIntent,
    //             "id"=>$id
    //         ]);
    //     }catch(\Stripe\Exception\CardException $e) {
    //         $this->payments->updatepaymentPaymentLogs([
    //             "status"=>"FAILED",
    //             "remarks"=>$e->getMessage()
    //         ],$id);
    //         echo json_encode(["status"=>false,'error'=>["message"=>$e->getMessage()]]);
    //         return;
    //     }catch (\Stripe\Exception\ApiErrorException $e) {
    //         $this->payments->updatepaymentPaymentLogs([
    //             "status"=>"FAILED",
    //             "remarks"=>$e->getMessage()
    //         ],$id);
    //         echo json_encode(["status"=>false,'error'=>["message"=>$e->getMessage()]]);
    //         return;
    //     }catch (\Exception $e) {
    //         $this->payments->updatepaymentPaymentLogs([
    //             "status"=>"FAILED",
    //             "remarks"=>$e->getMessage()
    //         ],$id);
    //         echo json_encode(["status"=>false,'error'=>["message"=>$e->getMessage()]]);
    //         return;
    //     }
    // }

    public function create_intent()
    {
        $this->glbl();
        $inputValues = $this->getPayload();
        $payment_method = $inputValues['payment_method'];
        $p_info = $inputValues['p_info'];
        $amount = (int) $p_info['total_charges'];
        $custom_payment_method = $p_info['payment_method'];

        $userId = $this->tank_auth->ci->session->userdata['user_id'];
        $customerId = $this->getCreateCustomerStripeID();
        try {
            $paymentMethod = $this->attachCustomerToPaymentMethod($payment_method, $customerId);
        } catch (Exception $e) {
            echo json_encode(["status" => false, 'error' => ["message" => $e->getMessage()]]);
            return;
        }
        $id = $this->createPaymentLogs($p_info, $userId, $amount);

        if (!isset($id)) {
            echo json_encode(["status" => false, "message" => "Logs can not be created, please try again"]);
            return;
        }
        try {
            $paymentIntent = \Stripe\PaymentIntent::create([
                'amount' => $amount * 100,
                'currency' => $this->currency,
                'payment_method' => $payment_method,
                "customer" => $customerId,
                'capture_method' => 'automatic',
                'confirm' => true,
                "automatic_payment_methods" => [
                    "enabled" => true,
                    "allow_redirects" => 'never'
                ],
                "off_session" => true
            ]);

            $this->payments->updatepaymentPaymentLogs([
                "response" => json_encode($paymentIntent)
            ], $id);

            $save_detail = $p_info['save_detail'];
            if ($save_detail) {
                $this->payments->savePaymentInfo([
                    "type" => $custom_payment_method,
                    "payment_method_id" => $payment_method,
                    "user_id" => $userId
                ]);
            }

            echo json_encode([
                'client_secret' => $paymentIntent,
                "id" => $id
            ]);
        } catch (\Stripe\Exception\CardException $e) {
            // Card errors (decline, insufficient funds, etc)
            $this->payments->updatepaymentPaymentLogs([
                "status" => "FAILED",
                "remarks" => $e->getMessage()
            ], $id);
            echo json_encode(["status" => false, 'error' => ["message" => $e->getMessage()]]);
            return;
        } catch (\Stripe\Exception\RateLimitException $e) {
            // Too many requests made to the API too quickly
            $this->payments->updatepaymentPaymentLogs([
                "status" => "FAILED",
                "remarks" => $e->getMessage()
            ], $id);
            echo json_encode(["status" => false, 'error' => ["message" => $e->getMessage()]]);
            return;
        } catch (\Stripe\Exception\InvalidRequestException $e) {
            // Invalid parameters were supplied to Stripe's API
            $this->payments->updatepaymentPaymentLogs([
                "status" => "FAILED",
                "remarks" => $e->getMessage()
            ], $id);
            echo json_encode(["status" => false, 'error' => ["message" => $e->getMessage()]]);
            return;
        } catch (\Stripe\Exception\AuthenticationException $e) {
            // Authentication with Stripe's API failed
            $this->payments->updatepaymentPaymentLogs([
                "status" => "FAILED",
                "remarks" => $e->getMessage()
            ], $id);
            echo json_encode(["status" => false, 'error' => ["message" => $e->getMessage()]]);
            return;
        } catch (\Stripe\Exception\ApiConnectionException $e) {
            // Network communication with Stripe failed
            $this->payments->updatepaymentPaymentLogs([
                "status" => "FAILED",
                "remarks" => $e->getMessage()
            ], $id);
            echo json_encode(["status" => false, 'error' => ["message" => $e->getMessage()]]);
            return;
        } catch (\Stripe\Exception\ApiErrorException $e) {
            // Generic Stripe API errors
            $this->payments->updatepaymentPaymentLogs([
                "status" => "FAILED",
                "remarks" => $e->getMessage()
            ], $id);
            echo json_encode(["status" => false, 'error' => ["message" => $e->getMessage()]]);
            return;
        } catch (\Exception $e) {
            // Catch any other errors
            $this->payments->updatepaymentPaymentLogs([
                "status" => "FAILED",
                "remarks" => $e->getMessage()
            ], $id);
            echo json_encode(["status" => false, 'error' => ["message" => $e->getMessage()]]);
            return;
        }
    }

    public function hold_payment()
    {
        // REDUNDANT NOW WITH AUTOMATIC CAPTURE INSTEAD OF MANUAL
        $inputValues = $this->getPayload();
        $payment_id = $inputValues["payment_id"];
        $payment_method_id = $inputValues["payment_method_id"];
        $this->payments->updatepaymentPaymentLogs([
            "status" => "HOLD",
            "payment_method_id" => $payment_method_id
        ], $payment_id);

        echo json_encode(['status' => true, 'message' => 'Payment Hold successfully']);
        return;
    }


    // Capture the payment later
    public function capture_payment()
    {
        $this->glbl();
        $inputValues = json_decode(file_get_contents('php://input'), true);
        $payment_intent_id = $inputValues['payment_intent_id'];
        $payment_id = $inputValues['payment_id'];
        $hp_id = $inputValues['hp_id'];
        $hp_user_info = $this->mc_constants->getUserData($hp_id);

        $hp_data['username'] = $hp_user_info['username'];
        $hp_data['id'] = $this->mc_constants->getQuickBloxUserListByLogin($hp_data['username']);
        $hp_data['name'] = $this->mc_constants->get_hp_data_username($hp_data['username']);

        try {
            // Capture the payment
            $paymentIntent = \Stripe\PaymentIntent::retrieve($payment_intent_id);

            // Check if the status is 'succeeded' or 'requires_capture'
            if ($paymentIntent->status == 'succeeded') {
                echo json_encode([
                    'status' => true,
                    'message' => 'Payment successfully captured!',
                    'captured_payment' => $paymentIntent,
                    'hp_data' => $hp_data
                ]);
                return;
            } else if ($paymentIntent->status == 'requires_capture') {
                $paymentIntent->capture();
                $this->payments->updatepaymentPaymentLogs([
                    "status" => "CAPTURED",
                ], $payment_id);

                echo json_encode([
                    'status' => true,
                    'message' => 'Payment successfully captured!',
                    'captured_payment' => $capturedPayment,
                    'hp_data' => $hp_data
                ]);
                return;
            } else {
                echo json_encode([
                    'status' => false,
                    'message' => 'Payment is not in the required state for capture.',
                    'hp_data' => $hp_data
                ]);
                return;
            }
        } catch (\Stripe\Exception\ApiErrorException $e) {
            $this->payments->updatepaymentPaymentLogs([
                "status" => "FAILED",
                "remarks" => $e->getMessage()
            ], $payment_id);
            echo json_encode(['success' => false, 'message' => 'Error capturing payment: ' . $e->getMessage()]);
        }
    }


    private function attachCustomerToPaymentMethod($paymentMethod, $customerId, $createMethod = false)
    {
        try {
            if ($createMethod) {
                $paymentMethod = \Stripe\PaymentMethod::create([
                    'type' => $paymentMethod,
                ]);
            } else {
                $paymentMethod = \Stripe\PaymentMethod::retrieve($paymentMethod);
            }
            $paymentMethod->attach([
                'customer' => $customerId,
            ]);
        } catch (\Stripe\Exception\CardException $e) {
            throw new Exception($e->getMessage());
        } catch (\Stripe\Exception\ApiConnectionException $e) {
            throw new Exception($e->getMessage());
        } catch (\Stripe\Exception\ApiErrorException $e) {
            throw new Exception($e->getMessage());
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
        return $paymentMethod;
    }


    public function createPaymentIntent()
    {
        $this->glbl();
        try {
            $inputValues = $this->getPayload();
            $p_info = $inputValues['p_info'];
            $method_type = $inputValues['method_type'];

            $amount = (int) $p_info['total_charges'];
            $custom_payment_method = $p_info['payment_method'];

            $userId = $this->tank_auth->ci->session->userdata['user_id'];
            $customerId = $this->getCreateCustomerStripeID();
            $paymentMethod = $this->attachCustomerToPaymentMethod($method_type, $customerId, true);
            $id = $this->createPaymentLogs($p_info, $userId, $amount);

            if (!isset($id)) {
                echo json_encode(["status" => false, "message" => "Logs can not be created, please try again"]);
                return;
            }

            if ($method_type == 'wechat_pay') {
                // Create a PaymentIntent with Alipay as the payment method
                $paymentIntent = \Stripe\PaymentIntent::create([
                    'amount' => $amount,  // Amount in the smallest currency unit (e.g., cents)
                    'currency' => $this->currency,  // Currency of the payment
                    'customer' => $customerId,  // Attach the payment method to the customer
                    'payment_method' => $paymentMethod->id,  // Attach the Alipay payment method
                    'payment_method_types' => [$method_type],  // Specify Alipay as a payment method
                    "payment_method_options" => [
                        'wechat_pay' => [
                            'client' => 'web',
                        ],
                    ]
                ]);
            } elseif ($method_type == 'alipay') {
                // Create a PaymentIntent with Alipay as the payment method
                $paymentIntent = \Stripe\PaymentIntent::create([
                    'amount' => $amount,  // Amount in the smallest currency unit (e.g., cents)
                    'currency' => $this->currency,  // Currency of the payment
                    'customer' => $customerId,  // Attach the payment method to the customer
                    'payment_method' => $paymentMethod->id,  // Attach the Alipay payment method
                    'payment_method_types' => [$method_type]
                ]);
            } else {
                $paymentIntent = \Stripe\PaymentIntent::create([
                    'amount' => $amount,  // Amount in the smallest currency unit (e.g., cents)
                    'currency' => $this->currency,  // Currency of the payment
                    'customer' => $customerId,  // Attach the payment method to the customer
                    'payment_method' => $paymentMethod->id,  // Attach the Alipay payment method
                    'payment_method_types' => [$method_type],
                    "capture_method" => "manual"
                ]);
            }

            // // Confirm the PaymentIntent and provide the return URL
            $paymentIntent->confirm([
                'return_url' => base_url('virtual_consult/payment/payment_confirmation?logs_id=' . $id),  // Your custom return URL
            ]);
            $this->payments->updatepaymentPaymentLogs([
                "response" => json_encode($paymentIntent)
            ], $id);

            echo json_encode(['clientSecret' => $paymentIntent->client_secret]);
        } catch (\Stripe\Exception\ApiErrorException $e) {
            // Handle the error
            echo json_encode(['error' => $e->getMessage()]);
        }
    }

    public function payment_confirmation()
    {
        // print_r($_GET);die;
        $id = $_GET['logs_id'];
        $this->payments->updatepaymentPaymentLogs([
            "response" => json_encode($_GET)
        ], $id);
        // Assuming you already have the PaymentIntent ID and the Client Secret
        $paymentIntentId = $_GET['payment_intent'];  // Extract PaymentIntent ID from query parameters
        $paymentIntentClientSecret = $_GET['payment_intent_client_secret'];  // Extract Client Secret

        $paymentIntent = \Stripe\PaymentIntent::retrieve($paymentIntentId);

        // Verify the PaymentIntent status
        if ($paymentIntent->status == 'succeeded') {
            $this->payments->updatepaymentPaymentLogs([
                "status" => "CAPTURED"
            ], $id);
            $this->session->set_flashdata('success', 'Payment success!');
            return redirect('/virtual_consult/patient/search');
        } else {
            $this->payments->updatepaymentPaymentLogs([
                "status" => "FAILED"
            ], $id);
            $this->session->set_flashdata('failed', 'Payment failed or was not confirmed.');
            return redirect('/virtual_consult/patient/search');
        }
    }
    public function getStripe()
    {
        echo json_encode(["stripe_key" => $this->publishable_key]);
    }


    public function create_order_authorization()
    {

        $inputValues = $this->getPayload();
        $p_info = $inputValues['p_info'];

        $amount = (int) $p_info['total_charges'];
        $userId = $this->tank_auth->ci->session->userdata['user_id'];
        $id = $this->createPaymentLogs($p_info, $userId, $amount);

        $accessToken = $this->getPaypalAccessToken();
        $order_request = curl_init();
        curl_setopt_array($order_request, [
            CURLOPT_URL => $this->paypal_url . '/v2/checkout/orders',
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $accessToken,
            ],
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode([
                'intent' => 'AUTHORIZE',
                'application_context' => [
                    'shipping_preference' => 'NO_SHIPPING'
                ],
                'purchase_units' => [
                    [
                        'reference_id' => time(),
                        'description' => 'Sandbox testing for amount $' . $order->order_amount,
                        'amount' => [
                            'value' => $amount,
                            'currency_code' => 'AUD'
                        ],
                    ]
                ]
            ]),
            CURLOPT_RETURNTRANSFER => true,
        ]);
        $order_response = curl_exec($order_request);
        if (curl_errno($order_request)) {
            $error_message = 'Error creating Authorization: CURL ERROR NO: ' . curl_errno($order_request) . PHP_EOL . 'Error: ' . curl_error($order_request);
            $this->paypal_orders->update_order($order_id, [
                'error' => $error_message
            ]);
            throw new Exception($error_message, curl_errno($order_request));
        }
        curl_close($order_request);
        $response = json_decode($order_response, true);

        $this->payments->updatepaymentPaymentLogs([
            "response" => json_encode($response),
            "payment_method_id" => $response['id']
        ], $id);

        echo $order_response;
        exit;
    }

    function confirm_order_authorization()
    {
        $inputValues = $this->getPayload();
        $order_id = $inputValues["order_id"];
        $payment_method_id = $inputValues["authorizationID"];

        $this->payments->updatepaymentPaymentLogsByMethodID([
            "status" => "HOLD",
            "payment_method_id" => $payment_method_id
        ], $order_id);
        echo json_encode(['status' => true, 'message' => 'Payment Hold successfully']);
        return;
    }

    function capture_paypal_payment($order_id = null)
    {
        if (empty($order_id)) {
            redirect('paypal');
            exit;
        }

        $accessToken = $this->getPaypalAccessToken();
        $capture_request = curl_init();
        curl_setopt_array($capture_request, [
            CURLOPT_URL => 'https://api-m.sandbox.paypal.com/v2/payments/authorizations/' . $order_id . '/capture',
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $accessToken,
                'PayPal-Request-Id: ' . time() . '_' . $order_id
            ],
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode([
                'amount' => [
                    'currency_code' => 'AUD',
                    'value' => 410,
                ],
            ]),
            CURLOPT_RETURNTRANSFER => true,
        ]);
        $capture_response = curl_exec($capture_request);
        if (curl_errno($capture_request)) {
            $error_message = 'Error Capturing Payment: CURL ERROR NO: ' . curl_errno($capture_request) . PHP_EOL . 'Error: ' . curl_error($capture_request);
            $this->paypal_orders->update_order($order_id, [
                'error' => $error_message
            ]);
            throw new Exception($error_message, curl_errno($capture_request));
        }
        curl_close($capture_request);
        $response = json_decode($capture_response, true);
        if ($response['status'] == 'COMPLETED') {
            $this->paypal_orders->update_order($order_id, [
                'captured_at' => date('Y-m-d H:i:s'),
                'status' => 'captured',
            ]);
        } elseif (in_array($response['status'], ['DECLINED', 'FAILED'])) {
            $this->paypal_orders->update_order($order_id, [
                'failed_at' => date('Y-m-d H:i:s'),
                'status' => 'failed',
            ]);
        }
        redirect('paypal');
        exit;
    }


    //Yashvir Consult Now  
    private function getPayload()
    {
        return json_decode(file_get_contents('php://input'), true);
    }
    private function getCreateCustomerStripeID()
    {
        $userId = $this->tank_auth->ci->session->userdata['user_id'];
        $user = $this->payments->getUserRow('id', $userId);
        if ($user->stripe_customer_id != "") {
            $customerId = $user->stripe_customer_id;
        } else {
            try {
                $customer = \Stripe\Customer::create([
                    'email' => $user->email,
                    'name' => $user->username
                ]);

                $customerId = $customer->id;
                $this->payments->updateUser('id', $userId, ['stripe_customer_id' => $customerId]);
            } catch (\Exception $e) {
                // Handle the exception (log it, return an error response, etc.)
                error_log('Stripe Customer Creation Error: ' . $e->getMessage());
            }
        }
        return $customerId;
    }

    private function getPayPalAccessToken()
    {
        $url = PAYPAL_API_BASE_URL . "/v1/oauth2/token"; // Dynamic URL

        $clientId = PAYPAL_CLIENT_ID;
        $clientSecret = PAYPAL_CLIENT_SECRET;

        $headers = [
            "Accept: application/json",
            "Accept-Language: en_US"
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_USERPWD, "$clientId:$clientSecret");
        curl_setopt($ch, CURLOPT_POSTFIELDS, "grant_type=client_credentials");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        curl_close($ch);

        $data = json_decode($response, true);
        return $data['access_token'] ?? null;
    }


    public function createPaymentIntentSetup()
    {
        $this->glbl();
        try {

            $inputValues = $this->getPayload();

            $p_info = $inputValues['p_info'];
            $_POST = $inputValues['p_info'] ?? [];

            $_POST['hp_user_id'] = "";
            $_POST['payment_method'] = isset($_POST['payment_method']) ? (string) $_POST['payment_method'] : '-1';
            $_POST['type'] = isset($_POST['type']) ? (string) $_POST['type'] : '-1';

            $this->load->library('form_validation');

            $this->form_validation->set_rules('hp_user_id', $this->lang->line('hp_user_id'), 'required|integer');
            $this->form_validation->set_rules('service_id', $this->lang->line('service_id'), 'required|integer');
            $this->form_validation->set_rules('service_category_id', $this->lang->line('service_category_id'), 'required|integer');
            $this->form_validation->set_rules('service_name', $this->lang->line('service_name'), 'required|trim');
            $this->form_validation->set_rules('hp_name', $this->lang->line('hp_name'), 'required|trim');
            $this->form_validation->set_rules('service_price', $this->lang->line('service_price'), 'required|decimal');
            $this->form_validation->set_rules('platform_fee', $this->lang->line('platform_fee'), 'required|decimal');
            $this->form_validation->set_rules('total', $this->lang->line('total'), 'required|decimal');
            $this->form_validation->set_rules('type', $this->lang->line('type'), 'required|integer');
            $this->form_validation->set_rules('payment_method', $this->lang->line('payment_method'), 'required|integer|in_list[0,1]');

            // if ($this->form_validation->run() == FALSE) {
            //     echo json_encode([
            //         'status' => false,
            //         'errors' => validation_errors()
            //     ], JSON_UNESCAPED_UNICODE); 
            //     exit;
            // }




            $userId = $this->tank_auth->ci->session->userdata['user_id'];

            // $data['patient_user_id'] = $userId;
            // $data['hp_user_id'] = $p_info['hp_user_id'];
            // $data['service_id'] = $p_info['service_id'];
            // $data['service_category_id'] = $p_info['service_category_id'];
            // $data['service_name'] = $p_info['service_name'];
            // $data['hp_name'] = $p_info['hp_name'];
            // $data['service_type'] = $p_info['service_type'];//0=Consult Now, 1=Appointment, 2=Virtual Consult
            // $data['service_price'] = $p_info['service_price'];
            // $data['payment_method'] = $p_info['payment_method'];
            // $data['platform_fee'] = $p_info['platform_fee'];
            // $data['subtotal'] = $p_info['subtotal'];
            // $data['total'] = $p_info['total'];//0=Stripe, 1=Paypal

            $ip_address = $this->input->ip_address();
            $current_datetime = date('Y-m-d H:i:s');
            $data = [
                "patient_user_id" => $userId,
                "hp_user_id" => $p_info['hp_user_id'] ?? null,
                "service_id" => $p_info['service_id'] ?? null,
                "service_category_id" => $p_info['service_category_id'] ?? null,
                "service_type" => $p_info['service_type'] ?? null,
                "service_price" => $p_info['service_price'] ?? null,
                "payment_method" => $p_info['payment_method'] ?? 0,
                "platform_fee" => $p_info['platform_fee'] ?? 0,
                "tax" => $p_info['tax'] ?? 0,
                "subtotal" => $p_info['subtotal'] ?? 0,
                "total" => $p_info['total'] ?? 0,
                "is_entry" => $p_info['is_entry_consult'] ?? 0,
                "ip" => $ip_address, // Store user IP
                "created_at" => $current_datetime, // Store current timestamp
                "payload" => json_encode($p_info, JSON_UNESCAPED_UNICODE)
            ];




            if (!$userId) {
                echo json_encode(["status" => false, "message" => "User not authenticated"]);
                return; // Prevent further processing
            }

            $med_ser_log_id = $this->payments->createMedicalServiceLogs($data);
            if ($med_ser_log_id < 1) {
                echo json_encode(["status" => false, "message" => "Logs cannot be created, please try again"]);
                return; // Prevent further processing
            }

            $metaData = [
                'patient_user_id' => $userId,
                'hp_user_id' => $p_info['hp_user_id'],
                'med_ser_log_id' => $med_ser_log_id,
            ];
            $baseUrl = $p_info['currentUrl'];


            if ($p_info['payment_method'] == 0) {

                $customerId = $this->getCreateCustomerStripeID();
                $sessions = $this->stripeCheckoutSession($customerId, $p_info, $metaData, $baseUrl);

                if (isset($sessions['error']) && $sessions['error'] === true) {
                    echo json_encode(["status" => false, "error" => $sessions['message']], 400);
                    exit;
                }
                if (!empty($sessions) && isset($sessions->id)) {
                    $this->payments->updateMedicalServiceLogs('id', $med_ser_log_id, ['payment_session_id' => $sessions->id]);
                    echo json_encode(["status" => true, "message" => "", "url" => $sessions->url], 200);
                } else {
                    echo json_encode(["status" => false, "error" => "Session creation failed"], 400);
                }
            } elseif ($p_info['payment_method'] == 1) {
                $customerEmailId = $this->mc_constants->get_email_by_userid($userId);
                $sessions = $this->paypalCheckoutSession($customerEmailId, $p_info, $metaData, $baseUrl);

                if (!is_array($sessions) && !is_object($sessions)) {
                    error_log("Unexpected PayPal Session Response: " . json_encode($sessions));
                }

                if (isset($sessions->error) && $sessions->error === true) {
                    echo json_encode(["status" => false, "error" => $sessions->message], 400);
                    exit;
                }
                if (!empty($sessions) && isset($sessions->id)) {
                    $this->payments->updateMedicalServiceLogs('id', $med_ser_log_id, ['payment_session_id' => $sessions->id]);
                    echo json_encode(["status" => true, "message" => "", "url" => $sessions->url], 200);
                } else {
                    echo json_encode(["status" => false, "error" => "PayPal session creation failed"], 400);
                }

            } else {
                echo json_encode(["status" => false, "error" => "Pyament Method not Found"], 400);
            }
        } catch (\Stripe\Exception\ApiErrorException $e) {
            // Handle the error
            echo json_encode(["status" => false, 'error' => $e->getMessage()], 400);
        }
        die;
    }

    public function stripeCheckoutSession($customerId, $p_info, $metaData, $baseUrl = '')
    {
        try {
            $successUrl = $baseUrl . '?token={CHECKOUT_SESSION_ID}';
            $cancelUrl = $baseUrl . '?token={CHECKOUT_SESSION_ID}';

            $sessions = $this->stripe->checkout->sessions->create([
                'customer' => $customerId,
                'line_items' => [
                    [
                        'price_data' => [
                            'currency' => CURRENCY,
                            'product_data' => [
                                'name' => $this->lang->line('medical_service') . ': ' . $p_info['service_name'],
                            ],
                            'unit_amount' => $p_info['total'] * 100, // amount in cents
                        ],
                        'quantity' => 1,
                    ],
                ],
                'payment_intent_data' => [
                    'description' => $this->lang->line('medical_service') . ': ' . $p_info['service_name'],
                ],
                'mode' => 'payment',
                'success_url' => $successUrl,
                'cancel_url' => $cancelUrl,
                'metadata' => $metaData,
                'expires_at' => time() + (30 * 60) // 30 minutes expiry
            ]);

            return $sessions; // Return session object instead of echoing JSON

        } catch (\Exception $e) {
            return ["error" => true, "message" => $e->getMessage()];
        }
    }

    public function paypalCheckoutSession($customerId, $p_info, $metaData, $baseUrl = '')
    {
        $accessToken = $this->getPayPalAccessToken();
        if (!$accessToken) {
            return ["error" => true, "message" => "Failed to get PayPal access token"];
        }

        $url = PAYPAL_API_BASE_URL . "/v2/checkout/orders";


        $payload = [
            "intent" => "CAPTURE",
            "purchase_units" => [
                [
                    "amount" => [
                        "currency_code" => CURRENCY,
                        "value" => number_format($p_info['total'], 2, '.', '')
                    ],
                    "description" => $this->lang->line('medical_service') . ': ' . $p_info['service_name'],
                    "custom_id" => json_encode($metaData),
                ]
            ],
            "application_context" => [
                //"return_url" => $baseUrl ,
                // "cancel_url" => $baseUrl ,
                "return_url" => $baseUrl . "?payment_status=approved",
                "cancel_url" => $baseUrl . "?payment_status=cancelled",
                "brand_name" => "Your Business Name",
                "landing_page" => "BILLING",
                "user_action" => "PAY_NOW"
            ]
        ];




        $headers = [
            "Content-Type: application/json",
            "Authorization: Bearer $accessToken"
        ];

        // Send API request to create order
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        curl_close($ch);

        $data = json_decode($response, true);

        if (isset($data['id'])) {
            $orderId = $data['id']; // PayPal Order ID

            // Get approval URL (Redirects user to PayPal)
            $approvalUrl = null;
            foreach ($data['links'] as $link) {
                if ($link['rel'] === 'approve') {
                    $approvalUrl = $link['href'];
                    break;
                }
            }
            return (object) [
                'id' => $orderId,
                'url' => $approvalUrl
            ];
        }

        return ["error" => true, "message" => "Failed to create PayPal session"];
    }











    public function cancelRefundMedicalService()
    {
        $this->glbl();
        try {

            $inputValues = $this->getPayload();

            $med_ser_id = $inputValues['med_ser_id'];


            $this->load->library('form_validation');

            $this->form_validation->set_rules('med_ser_id', $this->lang->line('med_ser_id'), 'required|integer');

            // if ($this->form_validation->run() == FALSE) {
            //     echo json_encode([
            //         'status' => false,
            //         'errors' => validation_errors()
            //     ], JSON_UNESCAPED_UNICODE); 
            //     exit;
            // }




            $userId = $this->tank_auth->ci->session->userdata['user_id'];

            $medical_service_payment = $this->payments->getMedicalServicePaymentRow('medical_service_id', $med_ser_id);

            if (!$userId || $medical_service_payment->patient_user_id != $userId) {
                echo json_encode(["status" => false, "message" => "User not authenticated"]);
                return;
            }
            if (!$medical_service_payment->transaction_id) {
                echo json_encode(["status" => false, "message" => "Transaction Id not found"]);
                return;
            }
            if ($medical_service_payment->status != 1) {
                echo json_encode(["status" => false, "message" => "This transaction has already been refunded or has failed. No further action is required."]);
                return;
            }

            try {

                $refundResult = $this->stripe->refunds->create(
                    [
                        'payment_intent' => $medical_service_payment->transaction_id,
                        'metadata' => [
                            'refundBy' => $userId,
                            'service_id' => $med_ser_id
                        ],
                    ]
                );
                $transactionId = $refundResult->payment_intent ?? null;
                if ($refundResult->status == 'succeeded') {
                    echo json_encode(["status" => true, "message" => "Refund processed successfully.", "data" => $refundResult], 200);
                } else {
                    echo json_encode(["status" => false, 'message' => "Refund failed."], 400);
                }
            } catch (\Exception $e) {
                echo json_encode(["status" => false, 'message' => "Refund processing failed: " . $e->getMessage()], 400);
            }
        } catch (\Stripe\Exception\ApiErrorException $e) {
            // Handle the error
            echo json_encode(["status" => false, 'message' => "Refund processing failed: " . $e->getMessage()], 400);
        }
        die;
    }
    public function checkPaymentStatusBySessionId()
    {
        $this->glbl();

        $payment_session_id = $this->input->post('payment_session_id');
        if (!$payment_session_id) {
            echo json_encode(["status" => "error", "message" => "Invalid request"]);
            exit;
        }
        try {
            $result = $this->payments->checkPaymentStatusBySessionId('payment_session_id', $payment_session_id);

            if ($result) {
                echo json_encode(["status" => true, 'data' => $result]);
            } else {
                echo json_encode(["status" => false]);
            }
        } catch (Exception $e) {
            echo json_encode(["status" => "error", "message" => $e->getMessage()]);
        }
    }











    public function reAssignHPByPateint()
    {

        $this->glbl();
        try {

            $inputValues = $this->getPayload();

            $med_ser_id = $inputValues['med_ser_id'];
            $hp_user_id = $inputValues['hp_user_id'];


            $this->load->library('form_validation');

            $this->form_validation->set_rules('hp_user_id', $this->lang->line('hp_user_id'), 'required|integer');
            $this->form_validation->set_rules('med_ser_id', $this->lang->line('med_ser_id'), 'required|integer');


            // if ($this->form_validation->run() == FALSE) {
            //     echo json_encode([
            //         'status' => false,
            //         'errors' => validation_errors()
            //     ], JSON_UNESCAPED_UNICODE); 
            //     exit;
            // }




            $userId = $this->tank_auth->ci->session->userdata['user_id'];


            $med_ser_hp_assign = $this->payments->getMedicalServiceHPAssignRow('medical_service_id', "$med_ser_id");
            if (!$med_ser_hp_assign) {
                echo json_encode(["status" => false, "message" => "HP Assign not found for Service ID {$med_ser_id}"]);
                return;
            }
            if ($med_ser_hp_assign->status == 0) {
                echo json_encode(["status" => false, "message" => "Waiting For HP Response"]);
                return;
            }


            $data = [
                'patient_user_id' => $med_ser_hp_assign->patient_user_id,
                'hp_user_id' => $hp_user_id,
                'medical_service_id' => $med_ser_id,
                "status" => 0,
            ];

            $med_ser_hpa_row = $this->payments->createMedicalServiceHPAssign($data);

            if (!$med_ser_hpa_row) {
                echo json_encode(["status" => false, "message" => "medical_services_hpa not created"]);
                return;
            }

            $med_ser_hpa_row = $this->payments->getMedicalServiceHPAssignRow('medical_service_id', $med_ser_hp_assign->medical_service_id);
            if ($med_ser_hpa_row->status == 1) {
                $url = base_url() . PATIENT_WAITING_ROOM_URL;
            } elseif ($med_ser_hpa_row->status == 2) {
                $med_ser_row = $this->payments->getMedicalServiceRow('id', $med_ser_hpa_row->medical_service_id);
                //print_R($med_ser_row);
                $med_ser_log_row = $this->payments->getMedicalServiceLogsRow('id', $med_ser_row->medical_services_log_id);
                $payload = json_decode($med_ser_log_row->payload, true);

                $param = encryptParam("response_doctor=0&med_ser_id=$med_ser_hpa_row->medical_service_id");
                $url = $payload['currentUrl'] . "?data=" . urlencode($param);
            }

            $data = [
                "hp_user_id" => $med_ser_hpa_row->hp_user_id,
                "patient_user_id" => $med_ser_hpa_row->patient_user_id,
                "hp_assign_status" => $med_ser_hpa_row->status,
                "med_ser_log_id" => "",
                "med_ser_id" => $med_ser_hpa_row->medical_service_id ?? "",
                "ms_hpassignid" => $med_ser_hpa_row->id ?? "",
                "ms_paymentid" => "",
                "url" => $url,
                "type" => "Status Update BY HP",
                "timestamp" => date("Y-m-d H:i:s")
            ];

            $response = emitSocketEvent(
                "HP_assign_status",
                $data
            );
            echo json_encode(["status" => true, "hp_assign_status" => $med_ser_hpa_row->status, "message" => "HP Assigned Successfully",]);
            return;
        } catch (\Exception $e) {
            echo json_encode(["status" => false, 'error' => $e->getMessage()], 400);
        }
    }




    public function acceptRejectMedicalServiceByHP()
    {

        // $this->glbl();
        try {

            $inputValues = $this->getPayload();

            $medical_service_id = $inputValues['medical_service_id'];
            $status = $inputValues['status'];//0=Pending, 1=Accepted, 2=Rejected

            $this->load->library('form_validation');

            $this->form_validation->set_rules('medical_service_id', $this->lang->line('medical_service_id'), 'required|integer');
            $this->form_validation->set_rules('status', $this->lang->line('status'), 'required|integer');


            // if ($this->form_validation->run() == FALSE) {
            //     echo json_encode([
            //         'status' => false,
            //         'errors' => validation_errors()
            //     ], JSON_UNESCAPED_UNICODE); 
            //     exit;
            // }




            $userId = 2765;// $this->tank_auth->ci->session->userdata['user_id'];


            $med_ser_hp_assign = $this->payments->getMedicalServiceHPAssignRow('medical_service_id', "$medical_service_id");
            if (!$med_ser_hp_assign) {
                echo json_encode(["status" => false, "message" => "HP Assign not found for Service ID {$medical_service_id}"]);
                return;
            }

            // if ($status == 0) {
            //     echo json_encode(["status" => false, "message" => "Invalid Status Input"]);
            //     return;
            // }

            // if ($status === $med_ser_hp_assign->status) {
            //     echo json_encode(["status" => false, "message" => "Status already in use"]);
            //     return;
            // }

            // if ($med_ser_hp_assign->status == 2) {
            //     echo json_encode(["status" => false, "message" => "HP Assign has been rejected"]);
            //     return;
            // }
            // if ($med_ser_hp_assign->hp_user_id != $userId) {
            //     echo json_encode(["status" => false, "message" => "You are not authorized"]);
            //     return;
            // }




            //print_R($med_ser_hp_assign);
            //die("ssssssssss");
            // stdClass Object
            // (
            // [id] => 1
            // [patient_user_id] => 2766
            // [hp_user_id] => 2765
            // [medical_service_id] => 4
            // [status] => 0
            // [created_at] => 2025-02-26 16:27:03
            // [updated_at] => 2025-03-06 17:54:49
            // )



            $data = [
                'patient_user_id' => $med_ser_hp_assign->patient_user_id,
                'hp_user_id' => $userId,
                'medical_service_id' => $med_ser_hp_assign->medical_service_id,
                "status" => $status
            ];

            $med_ser_hpa_row = $this->payments->createMedicalServiceHPAssign($data);

            if (!$med_ser_hpa_row) {
                echo json_encode(["status" => false, "message" => "medical_services_hpa not created"]);
                return;
            }

            $med_ser_hpa_row = $this->payments->getMedicalServiceHPAssignRow('medical_service_id', $med_ser_hp_assign->medical_service_id);
            if ($med_ser_hpa_row->status == 1) {
                $url = base_url() . PATIENT_WAITING_ROOM_URL;
            } elseif ($med_ser_hpa_row->status == 2) {
                $med_ser_row = $this->payments->getMedicalServiceRow('id', $med_ser_hpa_row->medical_service_id);
                //print_R($med_ser_row);
                $med_ser_log_row = $this->payments->getMedicalServiceLogsRow('id', $med_ser_row->medical_services_log_id);
                $payload = json_decode($med_ser_log_row->payload, true);

                $param = encryptParam("response_doctor=0&med_ser_id=$med_ser_hpa_row->medical_service_id");
                $url = $payload['currentUrl'] . "?data=" . urlencode($param);
            }

            $data = [
                "hp_user_id" => $med_ser_hpa_row->hp_user_id,
                "patient_user_id" => $med_ser_hpa_row->patient_user_id,
                "hp_assign_status" => $med_ser_hpa_row->status,
                "med_ser_log_id" => "",
                "med_ser_id" => $med_ser_hpa_row->medical_service_id ?? "",
                "ms_hpassignid" => $med_ser_hpa_row->id ?? "",
                "ms_paymentid" => "",
                "url" => $url,
                "type" => "Status Update BY HP",
                "timestamp" => date("Y-m-d H:i:s")
            ];

            $response = emitSocketEvent(
                "HP_assign_status",
                $data
            );
            echo json_encode(["status" => true, "hp_assign_status" => $med_ser_hpa_row->status, "message" => "",]);
            return;
        } catch (\Exception $e) {
            echo json_encode(["status" => false, 'error' => $e->getMessage()], 400);
        }
    }


    public function cronMedicalServiceHPAssignCheckUpdate()
    {
        try {
            $affectedRecords = $this->payments->cronMedicalServiceHPAssignCheckUpdate();
            //print_r($affectedRecords);die;
            if (!empty($affectedRecords)) {
                error_log("CronTimeLog=======> " . print_r($affectedRecords, true));
                foreach ($affectedRecords as $record) {
                    // print_r($record);
                    $payload = json_decode($record['payload'], true);

                    $med_ser_id = $record['medical_service_id'];
                    $param = encryptParam("response_doctor=0&med_ser_id=$med_ser_id");
                    $url = $payload['currentUrl'] . "?data=" . urlencode($param);

                    //send alert to HP (Doctor)
                    $response = emitSocketEvent(
                        "HP_assign_status",
                        [
                            "hp_user_id" => $record['hp_user_id'],
                            "patient_user_id" => $record['patient_user_id'],
                            "hp_assign_status" => $record['hp_assign_status'],
                            "med_ser_log_id" => "",
                            "med_ser_id" => $record['medical_service_id'] ?? "",
                            "ms_hpassignid" => $record['assign_id'] ?? "",
                            "ms_paymentid" => "",
                            "url" => $url,// will be blank 
                            "type" => "time exceed " . HP_ACCEPT_WAITING_TIME . " Min",
                            "timestamp" => date("Y-m-d H:i:s")
                        ]
                    );
                    error_log('Cron Update for Patent websocket response=====>' . $response);
                    echo "Response from Node.js: " . $response; //die;
                    // $response["hp_assign_status"][] = [
                    //     "id" => $record['assign_id'],
                    //     "patient_user_id" => $record['patient_user_id'],
                    //     "hp_user_id" => $record['hp_user_id'],
                    //     "currentUrl" =>$payload['currentUrl']
                    // ];
                    // echo "Affected ID: " . $record['assign_id'] . "\n";
                }

                // Return JSON response
                // echo json_encode($response);
                return;
            }
            echo json_encode(["status" => false, "message" => "No records updated."]);
            return;

        } catch (\Exception $e) {
            http_response_code(400);
            echo json_encode(["status" => false, "error" => $e->getMessage()]);
        }
    }


    public function getUserId()
    {
        $userId = $this->tank_auth->ci->session->userdata['user_id'];
        echo json_encode(['user_id' => $userId]);
    }

}
