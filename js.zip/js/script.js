
$(document).ready(function() {
	$(window).scroll(function () {
	    var scroll = $(window).scrollTop();
	    if (scroll >= 100) {
	    	$(".p-filters").addClass("sticky-filter");
	    } else {
	    	$(".p-filters").removeClass("sticky-filter");
	    }
    });

	$(window).scroll(function () {
	    var scroll = $(window).scrollTop();
	    if (scroll >= 1) {
	    	$("header").addClass("sticky-header");
	    } else {
	    	$("header").removeClass("sticky-header");
	    }
    });

	$(window).scroll(function () {
	    var scroll = $(window).scrollTop();
	    if (scroll >= 1) {
	    	$("#medical-practice-sec .appointment-header").addClass("sticky-appointment-header");
	    } else {
	    	$("#medical-practice-sec .appointment-header").removeClass("sticky-appointment-header");
	    }
    });
	
    $(".responsive-filter-bar").click(function(e){
	    $(".filter-list").toggleClass("show-filter-list");
		$(".overlay-responsive").addClass("show-overlay-responsive");
		$("body").addClass("modal-open");
	    e.preventDefault();
    });

    $(".close-filter-list").click(function(f){
	    $(".filter-list").removeClass("show-filter-list");
		$(".overlay-responsive").removeClass("show-overlay-responsive");
		$("body").removeClass("modal-open");
	    f.preventDefault();
    });
   
	$(".toggle-drop-btn").click(function (e) {
		e.preventDefault(); // Prevent any default action (if needed)
	
		const $this = $(this);
		const $li = $this.closest('li');
	
		if ($this.hasClass('show-filter-list')) {
			// If already open, close it
			$this.removeClass('show-filter-list');
			$li.removeClass('active-drop');
		} else {
			// Close all others
			$("ul.filter-list .toggle-drop-btn").removeClass('show-filter-list');
			$("ul.filter-list li").removeClass('active-drop');
	
			// Open the clicked one
			$this.addClass('show-filter-list');
			$li.addClass('active-drop');
		}
	});
	


    $(".patiend_menu .close-dmenu").click(function () {
        hideMenu();
    });

    $('body').on("click", function (e) {
	    if ($(e.target).is('.patiend_menu'))
	    {
	        hideMenu();
	    }
    });
	
	var removeClass = true;
    $(".lang-drop-button").click(function() {
      $(".lang-dropdown").toggleClass('show-lang-dropdown');
      removeClass = false;
    });
    $("html").click(function() {
      if (removeClass) {
        $(".lang-dropdown").removeClass('show-lang-dropdown');
      }
      removeClass = true;
    });

	$(".toggle-btn").click(function() {
		$(".mobile-menu-container").addClass('active-mobile-menu');
		$(".overlay-mobile-menu").addClass('active-overlay-mobile-menu');
	  });
	  $(".close-toggle-btn").click(function() {
		$(".mobile-menu-container").removeClass('active-mobile-menu');
		$(".overlay-mobile-menu").removeClass('active-overlay-mobile-menu');
	  });

	  const dropl = document.querySelectorAll(".menu-dropdown-btn");
    dropl.forEach((dropl) => {
      dropl.addEventListener('click', function() {
        this.classList.toggle('show-drop-menu');
        $("li").removeClass("show-drop-menu");
      });
    });

	$('.card-radio').change(function() {
		if (this.value == 'card') {
		  $(".card-details-dropdown").addClass("show-card-details-dropdown");
		}
		else if (this.value == 'PayPal', 'apple-pay', 'google-pay', 'wechat-pay', 'alipay') {
		  $(".card-details-dropdown").removeClass("show-card-details-dropdown");
		}
	  
	  });

	$(".coupon-text").click(function() {
		$(".coupon-div").addClass('show-coupon-div');
	});

	if($('.tabs-carousel').length) {
		$('.tabs-carousel').owlCarousel({
			loop:true,
			nav:true,
			responsive:{
				0:{
					items:1
				},
				576:{
					items:2
				},
				768:{
					items:3
				},
				1000:{
					items:3
				}
			}
		});
	}
	$( ".owl-prev").html('<img src="https://dev.medcallz.com.au/assets/images/virtual_consult/carousel-prev.svg">');
	$( ".owl-next").html('<img src="https://dev.medcallz.com.au/assets/images/virtual_consult/carousel-next.svg">');
	
});

$(document).ready(function() {
    $(".doctor-detail-trigger").click(function() {
      $(".doctor-detail-modal").addClass('show-modal');
	  $("body").addClass('modal-open');
    });
	$(".close-button").click(function() {
		$(".doctor-detail-modal").removeClass('show-modal');
		$("body").removeClass('modal-open');
	  });
});

$(document).ready(function() {
	$('.remove-selected-holiday').on('click', function(){
	    $(this).closest('.selected-holiday-wrap').hide()
	}); 
});


$(document).ready(function() {
	$('.delete-contact-details-list').on('click', function(){
	    $(this).closest('li').hide()
	}); 
});

$(document).ready(function() {
    $(".join-ml-input-trigger").click(function() {
      $(".join-mp-modal").addClass('show-modal');
	  $("body").addClass('modal-open');
    });
	$(".close-button").click(function() {
		$(".join-mp-modal").removeClass('show-modal');
		$("body").removeClass('modal-open');
	  });
});

$(document).ready(function() {
	var stepshide = true;
		$("#proceed-payment-button").click(function(){
		$(".book-step-1").hide();
		$(".book-step-2").show();
		stepshide = false;
		$(window).scrollTop(0);
		});
	
		var stepscheckout = true;
		$("#checkout-button").click(function(){
			$(".book-step-2").hide();
			$(".book-step-final").show();
			stepscheckout = false;
			$(window).scrollTop(0);
			});
	});

$(document).ready(function() {
    $(".canceltrigger").click(function() {
      $(".cancel-modal").addClass('show-modal');
	  $("body").addClass('modal-open');
    });
	$(".close-button").click(function() {
		$(".cancel-modal").removeClass('show-modal');
		$("body").removeClass('modal-open');
	  });
});

$(document).ready(function() {
    $(".view-deatils-modal-btn").click(function() {
      $(".view-deatils-modal").addClass('show-modal');
	  $("body").addClass('modal-open');
    });
	$(".close-button").click(function() {
		$(".view-deatils-modal").removeClass('show-modal');
		$("body").removeClass('modal-open');
	  });
});

$(document).ready(function() {
	$("#medicare-subsity").click(function () {
		if ($(this).is(":checked")) {
			$(".insurance-subsity-form-content").show();
		} else {
		  $(".insurance-subsity-form-content").hide();
		}
	});
});

// $(document).ready(function() {
//     $('.custom-select2 select').select2();
// });

$(document).ready(function() {
	if($("#booking-date-datepicker").length) {	
		$("#booking-date-datepicker").datepicker({
			firstDay: 1,
			showOtherMonths: true,
			changeMonth: true,
			changeYear: true,
			dateFormat: "dd/mm/yy",
			beforeShow: function( input, inst){
				$(inst.dpDiv).addClass('flex-datepicker');
			},
			onClose: function(dateText, inst) { 
				var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
				$(this).datepicker('setDate', new Date(year, 1));
				$(inst.dpDiv).removeClass('flex-datepicker');
			}
		});
	}
	if($("#video-consult-dob-datepicker").length) {	
		$("#video-consult-dob-datepicker").datepicker({
			firstDay: 1,
			showOtherMonths: true,
			changeMonth: true,
			changeYear: true,
			dateFormat: "dd/mm/yy",
			beforeShow: function( input, inst){
				$(inst.dpDiv).addClass('flex-datepicker');
			},
			onClose: function(dateText, inst) { 
				var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
				$(this).datepicker('setDate', new Date(year, 1));
				$(inst.dpDiv).removeClass('flex-datepicker');
			}
		});
	}

	if($("#video-consult-invoice-patient-datepicker").length) {	
		$("#video-consult-invoice-patient-datepicker").datepicker({
			firstDay: 1,
			showOtherMonths: true,
			changeMonth: true,
			changeYear: true,
			dateFormat: "dd/mm/yy",
			beforeShow: function( input, inst){
				$(inst.dpDiv).addClass('flex-datepicker');
			},
			onClose: function(dateText, inst) { 
				var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
				$(this).datepicker('setDate', new Date(year, 1));
				$(inst.dpDiv).removeClass('flex-datepicker');
			}
		});
	}

	if($("#mp-date-of-service-datepicker").length) {	
		$("#mp-date-of-service-datepicker").datepicker({
			firstDay: 1,
			showOtherMonths: true,
			changeMonth: true,
			changeYear: true,
			dateFormat: "dd/mm/yy",
			beforeShow: function( input, inst){
				$(inst.dpDiv).addClass('flex-datepicker');
			},
			onClose: function(dateText, inst) { 
				var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
				$(this).datepicker('setDate', new Date(year, 1));
				$(inst.dpDiv).removeClass('flex-datepicker');
			}
		});
	}

	if($("#tests-requeste-datepicker").length) {	
		$("#tests-requeste-datepicker").datepicker({
			firstDay: 1,
			showOtherMonths: true,
			changeMonth: true,
			changeYear: true,
			dateFormat: "dd/mm/yy",
			beforeShow: function( input, inst){
				$(inst.dpDiv).addClass('flex-datepicker');
			},
			onClose: function(dateText, inst) { 
				var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
				$(this).datepicker('setDate', new Date(year, 1));
				$(inst.dpDiv).removeClass('flex-datepicker');
			}
		});
	}

	if($("#video-consult-invoice-patient-datepicker").length) {	
		$("#video-consult-invoice-patient-datepicker").datepicker({
			firstDay: 1,
			showOtherMonths: true,
			changeMonth: true,
			changeYear: true,
			dateFormat: "dd/mm/yy",
			beforeShow: function( input, inst){
				$(inst.dpDiv).addClass('flex-datepicker');
			},
			onClose: function(dateText, inst) { 
				var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
				$(this).datepicker('setDate', new Date(year, 1));
				$(inst.dpDiv).removeClass('flex-datepicker');
			}
		});
	}

	if($("#notes-by-datepcker").length) {	
		$("#notes-by-datepcker").datepicker({
			firstDay: 1,
			showOtherMonths: true,
			changeMonth: true,
			changeYear: true,
			dateFormat: "dd/mm/yy",
			beforeShow: function( input, inst){
				$(inst.dpDiv).addClass('flex-datepicker');
			},
			onClose: function(dateText, inst) { 
				var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
				$(this).datepicker('setDate', new Date(year, 1));
				$(inst.dpDiv).removeClass('flex-datepicker');
			}
		});
	}

	if($("#date-collected-datepcker").length) {
		$("#date-collected-datepcker").datepicker({
			firstDay: 1,
			showOtherMonths: true,
			changeMonth: true,
			changeYear: true,
			dateFormat: "dd/mm/yy",
			beforeShow: function( input, inst){
				$(inst.dpDiv).addClass('flex-datepicker');
			},
			onClose: function(dateText, inst) { 
				var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
				$(this).datepicker('setDate', new Date(year, 1));
				$(inst.dpDiv).removeClass('flex-datepicker');
			}
		});
	}

	if($("#video-consult-health-provider-datepcker").length) {
		$("#video-consult-health-provider-datepcker").datepicker({
			firstDay: 1,
			showOtherMonths: true,
			changeMonth: true,
			changeYear: true,
			dateFormat: "dd/mm/yy",
			beforeShow: function( input, inst){
				$(inst.dpDiv).addClass('flex-datepicker');
			},
			onClose: function(dateText, inst) { 
				var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
				$(this).datepicker('setDate', new Date(year, 1));
				$(inst.dpDiv).removeClass('flex-datepicker');
			}
		});
	}
	if($("#video-consult-private-insurance-datepicker").length) {
		$("#video-consult-private-insurance-datepicker").datepicker({
			firstDay: 1,
			showOtherMonths: true,
			changeMonth: true,
			changeYear: true,
			dateFormat: "dd/mm/yy",
			beforeShow: function( input, inst){
				$(inst.dpDiv).addClass('flex-datepicker');
			},
			onClose: function(dateText, inst) { 
				var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
				$(this).datepicker('setDate', new Date(year, 1));
				$(inst.dpDiv).removeClass('flex-datepicker');
			}
		});
	}
	if($("#video-consult-medicare-expire-datepicker").length) {
		$("#video-consult-medicare-expire-datepicker").datepicker({
			firstDay: 1,
			showOtherMonths: true,
			changeMonth: true,
			changeYear: true,
			dateFormat: 'dd-mm-yy',
			beforeShow: function( input, inst){
				$(inst.dpDiv).addClass('flex-datepicker');
			},
			onClose: function(dateText, inst) { 
				var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
				$(this).datepicker('setDate', new Date(year, 1));
				$(inst.dpDiv).removeClass('flex-datepicker');
			}
		});
	}
	
	if($("#medical-expiry-datepicker").length) {
		$("#medical-expiry-datepicker").datepicker({
			firstDay: 1,
			showOtherMonths: true,
			changeMonth: true,
			changeYear: true,
			dateFormat: "dd/mm/yy",
			beforeShow: function( input, inst){
				$(inst.dpDiv).addClass('flex-datepicker');
			},
			onClose: function(dateText, inst) { 
				var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
				$(this).datepicker('setDate', new Date(year, 1));
				$(inst.dpDiv).removeClass('flex-datepicker');
			}
		});
	}

	if($("#video-consult-medicare-expire-datepicker").length) {
		$("#video-consult-medicare-expire-datepicker").datepicker({
			firstDay: 1,
			showOtherMonths: true,
			changeMonth: true,
			changeYear: true,
			dateFormat: "dd/mm/yy",
			beforeShow: function( input, inst){
				$(inst.dpDiv).addClass('flex-datepicker');
			},
			onClose: function(dateText, inst) { 
				var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
				$(this).datepicker('setDate', new Date(year, 1));
				$(inst.dpDiv).removeClass('flex-datepicker');
			}
		});
	}
	if($("#appointment-edit-date-datepicker").length) {
		$("#appointment-edit-date-datepicker").datepicker({
			firstDay: 1,
			showOtherMonths: true,
			changeMonth: true,
			changeYear: true,
			dateFormat: "dd/mm/yy",
			beforeShow: function( input, inst){
				$(inst.dpDiv).addClass('flex-datepicker');
			},
			onClose: function(dateText, inst) { 
				var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
				$(this).datepicker('setDate', new Date(year, 1));
				$(inst.dpDiv).removeClass('flex-datepicker');
			}
		});
	}

	if($("#edit-patient-detail-dob-datepicker").length) {
		$("#edit-patient-detail-dob-datepicker").datepicker({
			firstDay: 1,
			showOtherMonths: true,
			changeMonth: true,
			changeYear: true,
			dateFormat: "dd/mm/yy",
			beforeShow: function( input, inst){
				$(inst.dpDiv).addClass('flex-datepicker');
			},
			onClose: function(dateText, inst) { 
				var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
				$(this).datepicker('setDate', new Date(year, 1));
				$(inst.dpDiv).removeClass('flex-datepicker');
			}
		});
	}
	if($("#insurance-medicare-expire-datepicker").length) {	
		$("#insurance-medicare-expire-datepicker").datepicker({
			firstDay: 1,
			showOtherMonths: true,
			changeMonth: true,
			changeYear: true,
			dateFormat: "dd/mm/yy",
			beforeShow: function( input, inst){
				$(inst.dpDiv).addClass('flex-datepicker');
			},
			onClose: function(dateText, inst) { 
				var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
				$(this).datepicker('setDate', new Date(year, 1));
				$(inst.dpDiv).removeClass('flex-datepicker');
			}
		});
	}
	if($("#video-consult-medicare-expire-datepicker").length) {
		$("#video-consult-medicare-expire-datepicker").datepicker({
			firstDay: 1,
			showOtherMonths: true,
			changeMonth: true,
			changeYear: true,
			dateFormat: "dd/mm/yy",
			beforeShow: function( input, inst){
				$(inst.dpDiv).addClass('flex-datepicker');
			},
			onClose: function(dateText, inst) { 
				var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
				$(this).datepicker('setDate', new Date(year, 1));
				$(inst.dpDiv).removeClass('flex-datepicker');
			}
		});
	}

 

 

});

$(document).ready(function() {
	$(".cancel-appointment-list-modal-btn").click(function() {
		$(".cancel-appointment-list-modal").addClass('show-modal');
		$("body").addClass('modal-open');
	});
	$(".close-button").click(function() {
		$(".cancel-appointment-list-modal").removeClass('show-modal');
		$("body").removeClass('modal-open');
		});
	});

$(document).ready(function() {
	$(".edit-deatils-modal-btn").click(function() {
		$(".edit-deatils-modal").addClass('show-modal');
		$("body").addClass('modal-open');
	});
	$(".close-button").click(function() {
		$(".edit-deatils-modal").removeClass('show-modal');
		$("body").removeClass('modal-open');
		});
	});

$(document).ready(function() {
		var proceedpaybtn = true;
	$("#proceed-payment-button").click(function(){
	$(".book-step-1").hide();
	$(".book-step-2").show();
	proceedpaybtn = false;
	$(window).scrollTop(0);
	});
});

$(document).ready(function() {
	var togglebarbtn = true;
	$('.toggle-bar-btn').click(function() { 
	  $('.toggle-bar-btn').not(this).removeClass('show-absolute-button')
	  $(this).toggleClass('show-absolute-button');
	  togglebarbtn = false;
	});

    $('.absolute-cancel-button').click(function() {
        $('.toggle-bar-btn').removeClass('show-absolute-button')
    });
	$("html").click(function() {
		if (togglebarbtn) {
		  $(".toggle-bar-btn").removeClass('show-absolute-button');
		}
		togglebarbtn = true;
	  });
});

$(document).ready(function() {
	const mpflexbtn = document.querySelectorAll('.mp-inner-heading-flex-button');
    mpflexbtn.forEach(div => {
            div.addEventListener('click', function() {
                this.classList.toggle('hide-mp-inner-heading-flex-button');
            });
        });
});

$(document).ready(function() {
	var mttableactionbtn = true;
	$('.mt-table-action-button').click(function() { 
	  $('.mt-table-action-button').not(this).removeClass('mt-table-action-button-active')
	  $(this).toggleClass('mt-table-action-button-active');
	  mttableactionbtn = false;
	});

	$("html").click(function() {
		if (mttableactionbtn) {
		  $(".mt-table-action-button").removeClass('mt-table-action-button-active');
		}
		mttableactionbtn = true;
	  });
});

$(document).ready(function() {
    $("#edit-patient-details-btn").click(function() {
      $(".patient-details-view-container").hide();
	  $(".patient-details-edit-container").show();
    });
});


$(document).ready(function() {
	var mttogglebarbtn = true;
	$('.remove-selected-holiday').click(function() { 
	  $('.remove-selected-holiday').not(this).removeClass('hide-mp-inner-heading-flex-button')
	  $(this).toggleClass('hide-mp-inner-heading-flex-button');
	  mttogglebarbtn = false;
	});

	$("html").click(function() {
		if (mttogglebarbtn) {
		  $(".remove-selected-holiday").removeClass('hide-mp-inner-heading-flex-button');
		}
		mttogglebarbtn = true;
	  });
});

$(document).ready(function() {
	var mptabletoggle = true;
	$('.mp-appointent-days-flex-responsive').click(function() { 
		$(this).closest('.desktop-mp-appointment-list').toggleClass('show-desktop-mp-appointment-list');
		mptabletoggle = false;
	});
});


$(document).ready(function() {
function hideMenu() {
    $("body").removeClass("siderbarmenu-active");
    $(".patiend_menu").removeClass("visible");
    $(".page-inner").removeClass("sidebar-visible");
}
});

// $(document).ready(function() {
// 	const tabButtons = document.querySelectorAll('.tab-button');
// 	const tabContents = document.querySelectorAll('.tab-content');
  
//   tabButtons.forEach(button => {
// 	  button.addEventListener('click', function () {
// 		const tab = this.getAttribute('data-tab');
  
// 		tabButtons.forEach(btn => btn.classList.remove('active'));
// 		tabContents.forEach(content => content.classList.remove('active'));
  
// 		this.classList.add('active');
// 		document.querySelector(`.tab-content[data-tab="${tab}"]`).classList.add('active');
  
// 		document.querySelector('.tab-contents').scrollTo({ top: 0, behavior: 'smooth' });
// 	  });
// 	  tabButtons[0].classList.add('active');
// 	  tabContents[0]?.classList?.add('active');
// 	});
// });	

$(document).ready(function() {
	const modaltabButtons = document.querySelectorAll('.modal-tab-button');
	const modaltabContents = document.querySelectorAll('.modal-tab-content');
  
	modaltabButtons.forEach(button => {
	  button.addEventListener('click', function () {
		const tab = this.getAttribute('data-tab');
  
		modaltabButtons.forEach(btn => btn.classList.remove('active'));
		modaltabContents.forEach(content => content.classList.remove('active'));
  
		this.classList.add('active');
		document.querySelector(`.modal-tab-content[data-tab="${tab}"]`).classList.add('active');
  
		document.querySelector('.modal-tab-contents').scrollTo({ top: 0, behavior: 'smooth' });
	  });
	  modaltabButtons[0].classList.add('active');
	  modaltabContents[0].classList.add('active');
	});
});



$(document).ready(function() {
	$(".video-consult-tab-button").click(function() {
		$(".video-consult-container").show();
		$(".past-consult-container").hide();
		$(".video-consult-tab-button").addClass("active");
		$(".past-consult-tab-button").removeClass("active");
	  });
	  
	  $(".past-consult-tab-button").click(function() {
		$(".video-consult-container").hide();
		$(".past-consult-container").show();
		$(".past-consult-tab-button").addClass("active");
		$(".video-consult-tab-button").removeClass("active");
	  });
});

$( document ).ready(function() {
	//customselectdesign();
});


$(document).ready(function() {
	var filter_cntry_class = true;
    $(".filter_cntry").click(function() {
      $(this).toggleClass('filter_cntry_active');
      filter_cntry_class = false;
    });
    $("html").click(function() {
      if (filter_cntry_class) {
        $(".filter_cntry").removeClass('filter_cntry_active');
      }
      filter_cntry_class = true;
    });
});

function customselectdesign(element) {
    var x, i, j, l, ll, selElmnt, a, b, c;
    
    // Check if the element parameter is provided
    if (element) {
        // If an element is passed, apply functionality to that element only
        x = [element];  // Make it an array with one element
    } else {
        // If no element is passed, apply functionality to all elements with the class 'custom-select'
        x = document.getElementsByClassName("custom-select");
    }

    l = x.length;

    for (i = 0; i < l; i++) {
        // Remove any previously created custom select elements (select-selected and select-items divs)
        var existingSelected = x[i].getElementsByClassName("select-selected");
        var existingItems = x[i].getElementsByClassName("select-items");

        // Remove the old custom select if they exist
        if (existingSelected.length > 0) {
            x[i].removeChild(existingSelected[0]);
        }
        if (existingItems.length > 0) {
            x[i].removeChild(existingItems[0]);
        }

        selElmnt = x[i].getElementsByTagName("select")[0];
        ll = selElmnt.length;

        // Create a new DIV that will act as the selected item
        a = document.createElement("DIV");
        a.setAttribute("class", "select-selected");
        a.innerHTML = '<span>' + selElmnt.options[selElmnt.selectedIndex].innerHTML + '</span>';
        x[i].appendChild(a);

        // Create a new DIV that will contain the option list
        b = document.createElement("DIV");
        b.setAttribute("class", "select-items select-hide");

        // Loop through the options and create a new DIV for each
        for (j = 0; j < ll; j++) {
            c = document.createElement("DIV");
            c.innerHTML = selElmnt.options[j].innerHTML;

            // Add click event to each option
            c.addEventListener("click", function (e) {
                var s = this.parentNode.parentNode.getElementsByTagName("select")[0];
                var h = this.parentNode.previousSibling;
                for (var i = 0; i < s.length; i++) {
                    if (s.options[i].innerHTML == this.innerHTML) {
                        s.selectedIndex = i;
                        h.innerHTML = this.innerHTML;
                        var y = this.parentNode.getElementsByClassName("same-as-selected");
                        for (var k = 0; k < y.length; k++) {
                            y[k].removeAttribute("class");
                        }
                        this.setAttribute("class", "same-as-selected");
                        break;
                    }
                }
                h.click(); // Trigger click to close the dropdown
            });

            b.appendChild(c);
        }

        x[i].appendChild(b);

        // Add event listener to toggle the dropdown on click
        a.addEventListener("click", function (e) {
            e.stopPropagation();
            closeAllSelect(this);
            this.nextSibling.classList.toggle("select-hide");
            this.classList.toggle("select-arrow-active");
        });
    }

    // Function to close all select boxes except the one clicked
    document.addEventListener("click", function (e) {
        closeAllSelect(e.target);
    });
}

// Function to close all select boxes except the one clicked
function closeAllSelect(elmnt) {
    var x, y, i, arrNo = [];
    x = document.getElementsByClassName("select-items");
    y = document.getElementsByClassName("select-selected");

    for (i = 0; i < y.length; i++) {
        if (elmnt == y[i]) {
            arrNo.push(i);
        } else {
            y[i].classList.remove("select-arrow-active");
        }
    }

    for (i = 0; i < x.length; i++) {
        if (arrNo.indexOf(i) > -1) {
            continue;
        }
        x[i].classList.add("select-hide");
    }
}

