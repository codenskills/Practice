$(function () {
    var site_l = window.location.origin.replace(/:\d+/, '') + ':3000';
    var socket = io(site_l, {
        path: "/nodejs/",
        transports: ['websocket']
    });
    socket.on("connect", () => {
        console.log("Patient WebSocket connected:", socket.id);
    });

    socket.on("connect_error", (err) => {
        console.error("Patient WebSocket connection error:", err.message);
    });

    // Listen for HP_assign_status
    socket.on("HP_assign_status", (data) => {
        try {
            let jsonData = JSON.parse(data);
            console.log("HP_assign_status Response:", jsonData);

            if (jsonData.hp_assign_status == 2 || jsonData.hp_assign_status == 1) {

                fetch(`${baseUrl}virtual_consult/payment/getUserId`)
                    .then(response => response.json())
                    .then(data => {
                        //console.log("Logged-in User ID:", data.user_id);
                        if (jsonData.patient_user_id == data.user_id) {
                            if (window.location.href !== `${jsonData.url}`) {
                                console.log(`url=====${jsonData.url}`);
                                if (jsonData.url) {
                                    window.location.href = jsonData.url;
                                }
                            }
                            // if (window.location.href !== `${baseUrl}virtual_consult/patient/online_waiting_room`) {
                            //     window.location.href = `${baseUrl}virtual_consult/patient/online_waiting_room`;
                            // }
                            //console.log(`${baseUrl}virtual_consult/patient/online_waiting_room`);
                            //console.log("Status changed, closing WebSocket...");
                        }
                        //document.cookie = "HP_Assign=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                    })
                    .catch(error => console.error("Error:", error));

            } else {
                fetch(`${baseUrl}virtual_consult/payment/getUserId`)
                    .then(response => response.json())
                    .then(data => {
                        console.log("Logged-in User ID:", data.user_id);
                        // if (jsonData.patient_user_id == data.user_id) {
                        //     if (window.location.href !== `${baseUrl}virtual_consult/patient/online_waiting_room`) {
                        //         window.location.href = `${baseUrl}virtual_consult/patient/online_waiting_room`;
                        //     }
                        // }

                    })
                    .catch(error => console.error("Error:", error));
            }
        } catch (error) {
            console.error("Error parsing WebSocket response:", error.message);
        }
    });

    // socket.on("disconnect", () => {
    //     console.log("WebSocket connection closed");
    // });
    // let hpassignCookie = getCookie("HP_Assign");

    // if (hpassignCookie) {
    //     try {
    //         let cookieData = JSON.parse(hpassignCookie);
    //         let ms_logid = cookieData.ms_logid;
    //         let patient_user_id = cookieData.patient_user_id;

    //         console.log(`Sending ms_logid ${ms_logid} and patient_user_id ${patient_user_id} via WebSocket:"`);

    //         // Send ms_logid when WebSocket connects
    //          socket.emit("HP_assign_status", { ms_logid: ms_logid, patient_user_id: patient_user_id });

    //     } catch (error) {
    //         console.error("Error parsing HP_Assign cookie:", error.message);
    //     }

    // } else {
    //     console.log("HP_Assign cookie not found or expired. WebSocket not started.");
    // }
});

// if (req.method === 'POST' && req.url === '/send_event') {
//     let body = '';

//     req.on('data', chunk => {
//         body += chunk.toString(); // Collect request data
//     });

//     req.on('end', () => {
//         try {
//             const data = JSON.parse(body);
//            // console.log("Received API request:", data);
//            // console.log("Received API event_name:", data.event_name);
//             console.log("Received API event_data:", data.event_data);

//             if (!data.event_name) throw new Error("Missing event_name");

//             // Allow event_data to be object or array
//             if (!Array.isArray(data.event_data) && typeof data.event_data !== "object") {
//                 throw new Error("event_data must be an array or object");
//             }

//             io.emit(data.event_name, JSON.stringify(data.event_data));

//             res.writeHead(200, { 'Content-Type': 'application/json' });
//             res.end(JSON.stringify({ success: true, data: data.event_data }));

//         } catch (error) {
//             console.error("Error processing request:", error);
//             res.writeHead(400, { 'Content-Type': 'application/json' });
//             res.end(JSON.stringify({ error: error.message }));
//         }
//     });

//     req.on('error', error => {
//         console.error("Request Error:", error.message);
//         res.writeHead(500, { 'Content-Type': 'application/json' });
//         res.end(JSON.stringify({ error: "Request processing error" }));
//     });
// }